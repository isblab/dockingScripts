#bash
# the tmp directory to be created/cleaned is /scratch/jobid/ref/node

SCRATCH=/state/partition1
#SCRATCH=.

#hostname
TMPDIR=$SCRATCH/$1
if ! [ -d $TMPDIR ]; then
	mkdir $TMPDIR
fi

TMPDIR=$SCRATCH/$1/$3
if ! [ -d $TMPDIR ]; then
	mkdir $TMPDIR
fi

TMPDIR=$SCRATCH/$1/$3/$2
#if ! [ -d $TMPDIR ]; then
	rm -rf $TMPDIR
	mkdir $TMPDIR
#fi

# if [ $4 == 1 ]; then
#	`rm $SCRATCH/$1/$3/$3out*`
# else
#	sleep 10s
# fi

#cp -R moil_data $TMPDIR

ulimit -c 0

