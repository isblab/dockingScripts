#TODO: change this to remove DOCK RESULTS instead

# this script can be run as a cron job such that it runs every hour or so.
#
# it scans the specified SRC folder, looking (in subfolders *.loopp) for completed loopp results (*.results.tgz) that are at least 30 minutes old,
# but less than 30 days old, that are also NOT found in the specified DEST folder.  In this case,  the results are copied, and unzipped.

use File::Spec;
use File::Copy;

$srcFolder = shift;
$dstFolder = shift;
$queuedFolder = shift;
$now = localtime;


if( ! -d $srcFolder || ! -d $dstFolder ) {
	print "ERROR: SRC=$srcFolder and DST=$dstFolder must both exist.\n";
	exit;
}



$log = "$srcFolder/../monitorLooppResults.log";
open LOG, ">>$log";


$thirtyMinutes = 0.5 / 24.0;
	# thirty minutes expressed in days

#
# For each .loopp work folder, if it is recent enough, ensure results exist on the webserver disk.
# If the folder is more than 45 days old, then delete it.
#
@folders = glob( "$srcFolder/*.loopp" );
foreach( @folders ) {
	$folder = $_;
	@tgz = glob( "$folder/*results.tgz" );
	if( ! scalar @tgz == 1 ) {
		next;
	}
	$tgz = @tgz[ 0 ];
	$age = -M $tgz;
	if( $age < 30 && $age > $thirtyMinutes ) {
		( $v, $d, $f ) = File::Spec->splitpath( $tgz );
		if( ! -e "$dstFolder/$f" ) {
			print LOG "$now\t$f does not exist at $dstFolder...copying...";
			copy( $tgz, "$dstFolder/$f" );
			print LOG "and unzipping...";
			system( "tar -C $dstFolder -xzf $dstFolder/$f" );
			print LOG "done.\n";
		}
	}
	elsif( $age > 45 ) {
		print LOG "$now\tRemoving work folder $folder, age = $age days.\n";
		system( "rm -rf $folder" );
	}
}

#
# remove results from the webserver that are more than 30 days old
#
@files = glob( "$dstFolder/*" );
foreach( @files ) {
	$file = $_;
	$age = -M $file;
	if( $age > 30 ) {
		print LOG "$now\tRemoving $file, age = $age days.\n";
		system( "rm -rf $file" );
	}
}

#
# remove semaphore files that may have been left behind if loopp jobs died or were killed
#
@files = glob( "$queuedFolder/*" );
foreach( @files ) {
	$file = $_;
	$age = -M $file;
	if( $age > 3 ) {
		print LOG "$now\tRemoving $file, age = $age days.\n";
		system( "rm -rf $file" );
	}
}



close LOG;
copy( $log, "$dstFolder/.." );

