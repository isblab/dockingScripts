awk -f /junior/ravid/scripts/select_chain.awk chain=$1 $2
