#include "geometric_hash.hpp"
#include "sasautil.hpp"

ostream *out;
char scratch_dir[512], command[8192];

void read_profile(Molecule *m){
	Aminoacid* aacid[m->aminoacid.size()+1];
	int maaindex=0;
	for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = m->aminoacid.begin(); aaitr != m->aminoacid.end(); aaitr++)
		aacid[maaindex++] = ((Aminoacid*) aaitr->second);
	
	sort(aacid, aacid+m->aminoacid.size(),less<Aminoacid*>());	
	/*for(int i = 0; i < maaindex; i++)
		for(int j = i+1; j < maaindex; j++)
			if(less<Aminoacid*>()(aacid[j],aacid[i])){
				Aminoacid* aa = aacid[i];
				aacid[i] = aacid[j];
				aacid[j] = aa;
			}*/
	
	stringstream ss (stringstream::in | stringstream::out);
	string filename;
	ss << m->pdbcode << "_" << m->chain << ".profile";
	ss >> filename;
	fstream fin(filename.c_str(), fstream::in);
	if(!fin.is_open()){
		*out << "ERROR: profile not present" << endl;
		out->flush(); exit(1);
	}
	
	char buf[8192];
	do {
		fin.getline(buf,8192);
	} while ((string(buf)).find("position") == string::npos);
	fin.getline(buf,8192);
	
	int aaindex = 0;
	while(!fin.eof() && ((string(buf)).find("Lambda") == string::npos)){
		fin.getline(buf,8192);
		if(fin.gcount() > 150){
			Aminoacid* aa = aacid[aaindex];
	
			float entropy;
			{
				stringstream line(buf+150,stringstream::in);
				line >> entropy;
			}
		
			aa->entropy_sequence = entropy;
			aaindex++;
			*out << aa->get_symbol() << " " << aa->entropy_sequence << endl;
		}
	}
	fin.close();
}

/*
 * Arguments: receptor-chains ligand-chains model#
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	//cout << "read molecule config" << endl; cout.flush();
	read_dock_config();
	//cout << "read dock config" << endl; cout.flush();
		
	Complex* cr = new Complex(argv[1],argv[2], PDB);
	for(hash_map<char, Molecule*, hash<char>, eqint>::iterator mitr = cr->molecules.begin(); mitr != cr->molecules.end(); mitr++){
		Molecule* m = mitr->second;
		read_profile(m);
	}
	
	Complex* cl = new Complex(argv[3],argv[4], PDB);
	for(hash_map<char, Molecule*, hash<char>, eqint>::iterator mitr = cl->molecules.begin(); mitr != cl->molecules.end(); mitr++){
		Molecule* m = mitr->second;
		m->pdbcode = "l";
		read_profile(m);
	}
	string scorefile(argv[5]);
	string detailedscorefile(argv[6]);
	unsigned int frame_number = atoi(argv[7]);
	
	//cout << "computing overlap" << endl; cout.flush();
	// overlap
	Object *receptor = new Object(cr,cr);
	for(int i = 0; i < cr->num_atoms; i++){
		Atom * a = cr->atom[i];
		a->is_buried = (a->sa == 0);
	}
	receptor->build_grid();
	//cout << "r finding surface" << endl; cout.flush();
	receptor->grid_compute_atom_neighbors();
	receptor->grid_find_surface();
	//cout << "r finding distance from surface" << endl; cout.flush();
	receptor->grid_compute_distance_from_surface();
	//cout << "r finding curvature" << endl; cout.flush();
	receptor->grid_compute_curvature();
	
	Object *ligand = new Object(cl,cl);
	for(int li = 0; li < cl->num_atoms; li++){
		Atom * al = cl->atom[li];
		al->is_buried = (al->sa == 0);
	}
	ligand->build_grid();
	ligand->grid_compute_atom_neighbors();
	ligand->grid_find_surface();
	ligand->grid_compute_distance_from_surface();
	ligand->grid_compute_curvature();
	
	float atoms_vs_distance[NUM_DTRANSFORM_DIVISIONS], points_vs_distance[NUM_DTRANSFORM_DIVISIONS];
	for(int i = 0; i < NUM_DTRANSFORM_DIVISIONS; i++){
		atoms_vs_distance[i] = 0;
		points_vs_distance[i] = 0;
	}

	Vector zero = Vector(0,0,0);
	GridCell *cell;
	for(int li = 0; li < cl->num_atoms; li++){
		Atom * al = cl->atom[li];
		GridCell *cell = receptor->access_point_in_grid(al->position,&zero);
		//*out << al->index << " " << cell << endl;
		if(cell != NULL && cell->type != EXTERIOR){
			if(cell->distance_from_surface < -3.5)	atoms_vs_distance[4]++;
			else if(cell->distance_from_surface < -2.0)	atoms_vs_distance[3]++;
			else if(cell->distance_from_surface < -0.5)	atoms_vs_distance[2]++;
			else if(cell->distance_from_surface < 0.5) atoms_vs_distance[1]++;
			else atoms_vs_distance[0]++;
		}
	}
	
	for(unsigned int index = 0; index < ligand->grid_num_xdivisions*ligand->grid_num_ydivisions*ligand->grid_num_zdivisions; index++){
		if(ligand->grid[index] != NULL && ligand->grid[index]->type == SURFACE){
			int x = (index/ligand->grid_num_ydivisions)/ligand->grid_num_zdivisions;
			int y = (index/ligand->grid_num_zdivisions) % ligand->grid_num_ydivisions;
			int z = index % ligand->grid_num_zdivisions;

			Vector v = Vector( GRID_SPACING*(x+0.5), GRID_SPACING*(y+0.5), GRID_SPACING*(z+0.5) ) + *(ligand->grid_origin);
			cell = receptor->access_point_in_grid(&v,&zero);
			if(cell != NULL && cell->type != EXTERIOR){
				float ds = 0 - cell->distance_from_surface;
				float e_ds = 0;
				if(ds < -1.0)	e_ds = 0;
				else if(ds < 0)	e_ds = (1+ds)*(1+ds)*(1+ds);
				else	e_ds = (1-ds)*(1-ds)*(1-ds);
				float c = ligand->grid[index]->curvature;
				
				//*out << v.x << " " << v.y << " " << v.z << " " << cell->type << " " << ds << endl;
				if(ds > 3.5)
					points_vs_distance[4] += c * cell->curvature;
				else if(ds > 2.0)
					points_vs_distance[3] += c * cell->curvature;
				else if(ds > 0.5)
					points_vs_distance[2] += c * cell->curvature;
				else if(ds > -0.5)
					points_vs_distance[1] += ( 1 - (cell->curvature-1) * (c-1));
				else
					points_vs_distance[0] += c * cell->curvature;
				//*out << ds << " " << c << " " << cell->curvature << endl;
			}
		}
	}
	
	// surface area
	compute_sasa(cr, cl);
	float surface_area[NUM_RESIDUE_TYPES];
	for(int i = 0; i < NUM_RESIDUE_TYPES; i++)
		surface_area[i] = 0;
	for(int i = 0; i < cr->num_aminoacids; i++){
	 	Aminoacid *aa = cr->aminoacid[i];
	 	//cout << aa->name << " " << aa->index << " " << aa->alpha_carbon << endl;
	 	surface_area[aa->type] += aa->sa;
	}
	for(int i = 0; i < cl->num_aminoacids; i++){
		Aminoacid *aa = cl->aminoacid[i];
	 	//cout << aa->name << " " << aa->index << " " << aa->alpha_carbon << endl;
	 	surface_area[aa->type] += aa->sa;
	}
	float solvation_energy = 0;
	for(int i = 0; i < NUM_RESIDUE_TYPES; i++)
		solvation_energy -= surface_area[i]*residue_solvation_energy[i];
	cout << "solvationE " << solvation_energy << endl;
	
	// pair potential
	int num_residue_types = NUM_RESIDUE_TYPES*NUM_ENTROPY_DIVISIONS;
	short residue_contacts[num_residue_types][num_residue_types];
	for(int i = 0; i < num_residue_types; i++)
		for(int j = 0; j < num_residue_types;j++)
			residue_contacts[i][j] = 0;
	float pair_potential = 0;
	for(int i = 0; i < cr->num_aminoacids; i++){
	 	Aminoacid *ra = cr->aminoacid[i];
	 	for(int j = 0; j < cl->num_aminoacids; j++){
			Aminoacid *la = cl->aminoacid[j];
			if(ra->alpha_carbon != NULL && la->alpha_carbon != NULL && Vector::distance(ra->alpha_carbon->position,la->alpha_carbon->position) < SS_CUTOFF){
				if(ra->type < NUM_RESIDUE_TYPES_CONSERV && la->type < NUM_RESIDUE_TYPES_CONSERV){
				 	int ratype=ra->type,latype=la->type;
					if(ra->entropy_sequence <= ENTROPY_INT1_MAX)	ratype = ra->type;
					else if(ra->entropy_sequence <= ENTROPY_INT2_MAX)	ratype = NUM_RESIDUE_TYPES_CONSERV + ra->type;
					else	ratype = 2*NUM_RESIDUE_TYPES_CONSERV + ra->type;
					if(la->entropy_sequence <= ENTROPY_INT1_MAX)	latype = la->type;
					else if(la->entropy_sequence <= ENTROPY_INT2_MAX)	latype = NUM_RESIDUE_TYPES_CONSERV + la->type;
					else	latype = 2*NUM_RESIDUE_TYPES_CONSERV + la->type;
	
					cout << ratype << "," << latype << endl; cout.flush();
				 	//pair_potential += typeconservation_potential[ratype][latype];
				 	if(ratype <= latype)
						residue_contacts[ratype][latype]++;
					else
						residue_contacts[latype][ratype]++;
				}
		 	}
	 	}
	}

	fstream fscore(scorefile.c_str(),fstream::out | fstream::app);
    fscore << solvation_energy+pair_potential << "\t" << frame_number << "\t" << solvation_energy << "\t" << pair_potential << endl;
	cout << frame_number << "\t" << solvation_energy << "\t" << pair_potential << endl;
	fscore.close();
	
	fstream fdetailedscore(detailedscorefile.c_str(),fstream::out | fstream::app);
	fdetailedscore << frame_number << "\t";
	for(int i = 0; i < NUM_DTRANSFORM_DIVISIONS; i++)
		fdetailedscore << points_vs_distance[i] << " ";
	for(int i = 0; i < NUM_DTRANSFORM_DIVISIONS; i++)
		fdetailedscore << atoms_vs_distance[i] << " ";
	for(int i = 0; i < NUM_RESIDUE_TYPES; i++)
		fdetailedscore << (0 - surface_area[i]) << " ";
	for(int i = 0; i < num_residue_types; i++)
		for(int j = i; j < num_residue_types; j++)
		fdetailedscore << residue_contacts[i][j] << " ";
	fdetailedscore << endl;
	fdetailedscore.close();	
}