/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"

ostream *out;
char scratch_dir[512], command[8192];
string *native_sequence;
Complex* cnative;
bool **native_contact;


void read_loopp_alignment(int alignno, const char* tag, Alignment** la){
	for(short ai=0; ai<1; ai++){
		stringstream ss (stringstream::in | stringstream::out);
		ss << string(tag) << "_" << ai << ".info";
		string filename;
		ss >> filename;
		fstream fin(filename.c_str(), fstream::in);
		*out << filename << " " << fin.is_open() << endl; out->flush();
		do{
			fin.getline(buf,BUFSIZE);
		}while((string(buf)).find("align_len") == string::npos);
		string s = string(buf);
		short align_len = atoi((s.substr(s.find("align_len")+10,s.find("ene=")-(s.find("align_len")+10))).c_str());
		float score = atof((s.substr(s.find("ene=")+4,s.length()-(s.find("ene=")+4))).c_str());
		
		do{
			fin.getline(buf,BUFSIZE);
		}while((string(buf)).find("begin1") == string::npos);
		s = string(buf);
		short sbegin1 = s.find("begin1");
		short sbegin2 = s.find("begin2");
		int beginX = atoi((s.substr(sbegin1+7,sbegin2-(sbegin1+7))).c_str());
		int beginS = atoi((s.substr(sbegin2+7,s.size()-(sbegin2+7))).c_str());
		
		int numsegments = align_len/50;
		if(align_len %50 != 0)	numsegments++;
		
		string seqX="", seqS="";
		for(int si=0; si<numsegments; si++){
			for(int i=0; i<4; i++)	fin.getline(buf,BUFSIZE);
			fin.getline(buf,BUFSIZE);
			stringstream line = stringstream(buf,stringstream::in);
			string s;	line >> s;
			seqS = seqS + s;
			*out << s << endl; 
			
			fin.getline(buf,BUFSIZE);
			fin.getline(buf,BUFSIZE);
			stringstream line2 = stringstream(buf,stringstream::in);
			line2 >> s;
			seqX = seqX + s;
			*out << s << endl; out->flush();
			
			if(si<numsegments-1){
				for(int i=0; i<5; i++)	fin.getline(buf,BUFSIZE);
			}
		}
		
		Alignment* a = new Alignment(seqX,seqS,ai);
		a->score = score;
		a->qstart = beginX+1;
		const char* seqXc = seqX.c_str();
		a->qend = a->qstart-1;
		for(int k = 0; k < seqX.size(); k++)
			if(seqXc[k] != '-')	(a->qend)++;
		if(ai == 0)	*la = a;
		else	*ga = a;
		*out << a << " " << alignno << " " << align_len << " " << a->size << " " << a->qstart << " " << a->qend << endl;
	}
}

/*
 * INCOMPLETE, the goal is to look at different mutations at interface and score detrimental ones
 * 
 * Arguments: pdbid in lower case
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	read_dock_config();
	
	Complex *c = new Complex(argv[1],argv[2], PDB);
	Molecule* mc1 = (Molecule*) c->molecules.begin()->second;
	Molecule* mc2 = (Molecule*) c->molecules.end()->second;
	int num_chain1_residues, num_chain2_residues;
	num_chain1_residues = mc1->num_aminoacids;
	//num_chain2_residues = mc2->num_aminoacids;
	float residue_contact_factor[c->num_aminoacids][c->num_aminoacids], residue_bkbn_contact_factor[c->num_aminoacids][2];
	float bkbn_bkbn_contact_factor[2][2]; // ignoring now, should consider if there are deletions
	for(int laindex = 0; laindex < c->num_aminoacids; laindex++){
		for(int raindex = 0; raindex < c->num_aminoacids; raindex++)
			residue_contact_factor[laindex][raindex] = 0;
		residue_bkbn_contact[laindex][0] = 0;
		residue_bkbn_contact[laindex][1] = 0;
	}	
				
	for(int laindex = 0; laindex < c->num_aminoacids; laindex++){
		Aminoacid *la = c->aminoacid[laindex];
		if(la->centroid != NULL)
			for(int raindex = 0; raindex < c->num_aminoacids; raindex++){
			 	Aminoacid *ra = c->aminoacid[raindex];
			 	if(la->chain < ra->chain){
			 		if(ra->centroid != NULL){
			 			float factor = 0.0;
			 			d2 = Vector::distance_squared(vl,*(ar->centroid));
#ifdef 	STEP_POTENTIAL 			
						if(d2 < AA_CUTOFF_SQUARED)
#endif
#ifdef LINEAR_SPLINE_POTENTIAL										 			
						if(d2 < AA_SMTHP_CUTOFF_SQUARED)
#endif												
						{	
							contact=true;								
#ifdef 	STEP_POTENTIAL 	
							factor = 1.0;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL	 									
				 			if(d2 < AA_CUTOFF_SQUARED)	factor = 1.0;
							else{ float d=sqrt(d2);	factor = AA_SMTHP_FACTOR(d); }
#endif						
						}
						residue_contact_factor[laindex][raindex] = factor;
			 		}
					
					// backbone centroid and backbone backbone contacts
				 	{
				 		Vector *vaa[3];
						vaa[0] = al->centroid;
						vaa[1] = (al->amide_nitrogen == NULL) ? NULL : al->amide_nitrogen->position;
						vaa[2] = (al->carbonyl_oxygen == NULL) ? NULL : al->carbonyl_oxygen->position;
						for(int aapi = 0; aapi < 3; aapi++) 
						 	if(vaa[aapi]  != NULL){
								Vector vl = tr->inverse_transform(*(vaa[aapi]));
								for(int raindex = 0; raindex < receptor->c->num_aminoacids; raindex++){
									Aminoacid *ra = receptor->c->aminoacid[raindex];
								  if(ra->type >= 0)	
									for(int aapj = 0; aapj < 3; aapj++){  
										float d, d2, factor=0;
										if((aapi == 0 && aapj != 0 && al->type >= 0) || 
										 (aapi != 0 && aapj == 0 && ra->centroid != NULL)) {
										 	bool computefactor=false;
										 	if(aapi == 0 && aapj == 1 && ra->amide_nitrogen != NULL){
										 		computefactor=true;
												d2=Vector::distance_squared(vl,*(ra->amide_nitrogen->position));
										 	}
											if(aapi == 0 && aapj == 2 && ra->carbonyl_oxygen != NULL){
												computefactor=true;
												d2=Vector::distance_squared(vl,*(ra->carbonyl_oxygen->position));
											}
											if(aapi != 0){
												computefactor=true;
												d2=Vector::distance_squared(vl,*(ra->centroid));
											}
											
											if(computefactor)
#ifdef 	STEP_POTENTIAL 			
												if(d2 < BS_CUTOFF_SQUARED)
#endif
#ifdef LINEAR_SPLINE_POTENTIAL										 			
												if(d2 < BS_SMTHP_CUTOFF_SQUARED)
#endif												
												{	
#ifdef 	STEP_POTENTIAL 	
													factor = 1.0;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL	 									
						 							if(d2 < BS_CUTOFF_SQUARED)	factor = 1.0;
													else{ float d=sqrt(d2);	factor = BS_SMTHP_FACTOR(d); }
#endif						
												}
											if(aapi == 0 && aapj != 0 && al->type >= 0){									
												details->residue_contacts_core[al->type][19+aapj] += factor;
												details->residue_contacts_core[19+aapj][al->type] += factor;
											} else {
												details->residue_contacts_core[ra->type][19+aapi] += factor;
												details->residue_contacts_core[19+aapi][ra->type] += factor;
											}
										}
						
										if(aapi > 0 && aapj > 0){
											bool computefactor=false;
										 	if(aapj == 1 && ra->amide_nitrogen != NULL){
										 		computefactor=true;
												d2=Vector::distance_squared(vl,*(ra->amide_nitrogen->position));
										 	}
											if(aapj == 2 && ra->carbonyl_oxygen != NULL){
												computefactor=true;
												d2=Vector::distance_squared(vl,*(ra->carbonyl_oxygen->position));
											}
											
											if(computefactor)
#ifdef 	STEP_POTENTIAL 			
												if(d2 < BB_CUTOFF_SQUARED)
#endif
#ifdef LINEAR_SPLINE_POTENTIAL										 			
												if(d2 < BB_SMTHP_CUTOFF_SQUARED)
#endif												
												{	
#ifdef 	STEP_POTENTIAL 	
													factor = 1.0;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL	 									
						 							if(d2 < BB_CUTOFF_SQUARED)	factor = 1.0;
													else{ float d=sqrt(d2);	factor = BB_SMTHP_FACTOR(d); }
#endif		
												}
											details->residue_contacts_core[19+aapi][19+aapj] += factor;
											if(aapi != aapj)	details->residue_contacts_core[19+aapj][19+aapi] += factor;											
										}
									} // aapj
								}
							}
			 		}
				}
			}
	}
	
	
	
	fstream fin("seqids", fstream::in);
	*out << filename << " " << fin.is_open() << endl; out->flush();
	do{
		fin.getline(buf,BUFSIZE);
		if(fin.gcount() > 0) {
			string seqid = string(buf);
			
			Transformation *tr = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,mid);
			tr->vmetrics = new VerificationMetrics();
			tr->vmetrics->rmsd = tr->vmetrics->lrmsd = tr->vmetrics->irmsd = 100; 
			DetailedScoringMetrics *details = tr->detailed_scores = new DetailedScoringMetrics();
			
			// read alignment
			
		}
	}while((string(buf)).find("align_len") == string::npos);
}
