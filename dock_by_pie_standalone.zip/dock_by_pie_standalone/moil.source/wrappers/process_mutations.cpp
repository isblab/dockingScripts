/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"

ostream *out;
char scratch_dir[512], command[8192];
string *native_sequence;
Complex* cnative;
bool **native_contact;

/*
 * Arguments: pdbid in lower case
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	read_dock_config();
	
	Complex *c = new Complex(argv[1],argv[2], PDB);
	c->compute_aacontacts();
	
	// compute 3 body contacts
	bool aa3contact[c->num_aminoacids][c->num_aminoacids][c->num_aminoacids];
	for(int i = 0; i < c->num_aminoacids; i++)
		for(int j = 0; j < c->num_aminoacids; j++)
			for(int k = 0; k < c->num_aminoacids; k++)
				aa3contact[i][j][k] = false;
		
	for(int i = 0; i < c->num_aminoacids; i++)
		for(int j = i+3; j < c->num_aminoacids; j++)
			if(c->aacontact[i][j])
				for(int k = j+3; k < c->num_aminoacids; k++)
					if(c->aacontact[i][k] && c->aacontact[j][k])
						aa3contact[i][j][k] = true;
	
	// compute feature vector for native
	short twobody_contacts[NUM_RESIDUE_TYPES][NUM_RESIDUE_TYPES], threebody_contacts[NUM_RESIDUE_TYPES][NUM_RESIDUE_TYPES][NUM_RESIDUE_TYPES];
	for(int i = 0; i < NUM_RESIDUE_TYPES; i++)
		for(int j = i; j < NUM_RESIDUE_TYPES; j++){
			twobody_contacts[i][j] = 0;
			for(int k = j; k < NUM_RESIDUE_TYPES; k++)
				threebody_contacts[i][j][k] = 0;
		}
	
	for(int i = 0; i < c->num_aminoacids; i++){
		Aminoacid *aa1 = c->aminoacid[i];
		short type1 = aa1->type;
		for(int j = i+3; j < c->num_aminoacids; j++){
			Aminoacid *aa2 = c->aminoacid[j];
			short type2 = aa2->type;
			if(c->aacontact[i][j] && type1 >= 0 && type2 >= 0){
				if(type1 <= type2)
					twobody_contacts[type1][type2]++;
				else
					twobody_contacts[type2][type1]++;
				for(int k = j+3; k < c->num_aminoacids; k++)
					if(aa3contact[i][j][k]){
						Aminoacid *aa3 = c->aminoacid[k];
						short type3 = aa3->type;
						if(type3>0){
							short type[3];
							type[0] = type1; type[1] = type2; type[2] = type3;
							for(short i = 0; i < 3; i++)
								for(short j = i+1; j < 3; j++)
									if(type[j] < type[i]){
										short t = type[i];
										type[i] = type[j];
										type[j] = t;
									}
							threebody_contacts[type[0]][type[1]][type[2]]++;
						}
					}
			}
		}
	}
	
	fstream fnative("nativefeatures",fstream::out);
	for(unsigned short i = 0; i < 20; i++)
		for(unsigned short j = i; j < 20; j++)
			fnative << twobody_contacts[i][j] << " ";
	for(unsigned short i = 0; i < 20; i++)
		for(unsigned short j = i; j < 20; j++)
			for(unsigned short k = j ; k < 20; k++)
				fnative << threebody_contacts[i][j][k] << " ";
	fnative << endl;
	fnative.close();
	
	Molecule *m = c->molecules[argv[2][0]];
	fstream fmutations("mutations",fstream::in);
	fstream fmutationfeatures("mutationfeatures",fstream::out);
	while(fmutations.good()){
		char buf[8192];			
		fmutations.getline(buf,8192);
		if(fmutations.gcount() > 0){
			stringstream line(buf,stringstream::in);
			string pdbid;
			line >> pdbid;
			
			hash_map<unsigned int, short, hash<unsigned int>,eqint> mutatedtype;
			while(line.good()){
				char nativerestype, mutatedrestype;
				string mutatedresidue;
				line >> nativerestype;
				line >> mutatedresidue;
				line >> mutatedrestype;
				
				if(m->aminoacid.count(mutatedresidue.c_str()) > 0){
					Aminoacid *aa = m->aminoacid[mutatedresidue.c_str()];
					mutatedtype[aa->cindex] = get_aatype(mutatedrestype);
					cout << aa->name << " " << nativerestype << " " << mutatedrestype << endl;
				}
			}
				
			// compute features
			for(int i = 0; i < NUM_RESIDUE_TYPES; i++)
				for(int j = i; j < NUM_RESIDUE_TYPES; j++){
					twobody_contacts[i][j] = 0;
					for(int k = j; k < NUM_RESIDUE_TYPES; k++)
						threebody_contacts[i][j][k] = 0;
				}
				
			for(unsigned int i = 0; i < c->num_aminoacids; i++){
				Aminoacid *aa1 = c->aminoacid[i];
				short type1 = aa1->type;
				if(mutatedtype.count(i) > 0)
					type1 = mutatedtype[i];
				for(unsigned int j = i+3; j < c->num_aminoacids; j++){
					Aminoacid *aa2 = c->aminoacid[j];
					short type2 = aa2->type;
					if(mutatedtype.count(j) > 0)
						type2 = mutatedtype[j];
					if(c->aacontact[i][j] && type1 >= 0 && type2 >= 0){
						if(type1 <= type2)
							twobody_contacts[type1][type2]++;
						else
							twobody_contacts[type2][type1]++;
						for(unsigned int k = j+3; k < c->num_aminoacids; k++)
							if(aa3contact[i][j][k]){
								Aminoacid *aa3 = c->aminoacid[k];
								short type3 = aa3->type;
								if(mutatedtype.count(k) > 0)
									type3 = mutatedtype[j];
								if(type3>0){
									short type[3];
									type[0] = type1; type[1] = type2; type[2] = type3;
									for(short i = 0; i < 3; i++)
										for(short j = i+1; j < 3; j++)
											if(type[j] < type[i]){
												short t = type[i];
												type[i] = type[j];
												type[j] = t;
											}
								threebody_contacts[type[0]][type[1]][type[2]]++;
								}
							}
					}
				}
			}
	
			for(unsigned short i = 0; i < 20; i++)
				for(unsigned short j = i; j < 20; j++)
					fmutationfeatures << twobody_contacts[i][j] << " ";
			for(unsigned short i = 0; i < 20; i++)
				for(unsigned short j = i; j < 20; j++)
					for(unsigned short k = j ; k < 20; k++)
						fmutationfeatures << threebody_contacts[i][j][k] << " ";
			fmutationfeatures << endl;		
		}
	}
	
	fmutations.close();
	fmutationfeatures.close();	
}
