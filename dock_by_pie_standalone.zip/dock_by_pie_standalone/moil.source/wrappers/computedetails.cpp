/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];
extern char *tmp_dir;
extern bool **aacontact_core, **aacontact_rim, *aarcontact, *aalcontact;
unsigned short dock_type;

#define ZDOCK 2
#define PATCHDOCK 1

/*
 * Arguments: receptor-chains ligand-chains model#
 * transformation is applied to defined for ligand in zdock and pdock. 
 * """"""""when translated transformation is defined on receptor""""""""""
 * but moilr defines it for receptor
 * 		do preprocessing (build data structures) accordingly
 */
int main(int argc, char *argv[]){
	out = &cout;
	dock_type = atoi(argv[1]);
	
	read_molecule_config();
	read_dock_config();
	
	Complex *cr, *cl, *clb;
	cr = new Complex(argv[2],argv[3], PROCESSED);
	cl = new Complex(argv[4],argv[5], PROCESSED);
	if(dock_type == PATCHDOCK)
		clb = new Complex(argv[8],argv[5], PDB);
	
	Object *receptor = new Object(cr,cr);
	Object *ligand = new Object(cl,cl);
	
	receptor->preprocess_receptor();
	ligand->preprocess_ligand();
	receptor->build_contact_grid(ligand->max_grid_point_distance + sqrt(3)*GRID_SPACING/2.0);
	ligand->build_contact_grid(receptor->max_grid_point_distance + sqrt(3)*GRID_SPACING/2.0);
	
	//ligand->print_grid((char*)(string("lgrid.wrl")).c_str(),VRML1);
	
	// copying to scratch done in the submission script, working on scratch copy
	string transfile(argv[6]);
	fstream transin(transfile.c_str(),fstream::in);
	vector<Transformation*> transformations;
	while(transin.good()){
		transin.read(buf,Transformation::basic_byte_size);
		if(transin.gcount() > 0){
			Transformation *tr = new Transformation(buf,TN_BASIC);
			tr->vmetrics = new VerificationMetrics();
			transformations.push_back(tr);
		}
	}
	transin.close();
	*out << endl << "read transformations " << transformations.size() << endl;
	
	// compute rmsd
	if(dock_type == PATCHDOCK){
		unsigned int max_num_atoms = cr->num_atoms + cl->num_atoms;
		Vector reference_points[max_num_atoms+1], model_points[max_num_atoms+1];
		int point_index = 0;
	
		for(int i = 0; i < cr->num_aminoacids; i++){
		 	Aminoacid *aa = cr->aminoacid[i];
		 	if(aa->alpha_carbon != NULL){
				reference_points[point_index] = Vector(aa->alpha_carbon->position);
				model_points[point_index] = Vector(aa->alpha_carbon->position);
				point_index++;
		 	}
		}
		
		unsigned int ligand_start = point_index;
		for(int i = 0; i < cl->num_aminoacids; i++){
		 	Aminoacid *aa = clb->aminoacid[i];
		 	if(aa->alpha_carbon != NULL){
				reference_points[point_index] = Vector(aa->alpha_carbon->position);
				point_index++;
		 	}
		}
	
		for(vector<Transformation*>::iterator titr = transformations.begin(); titr != transformations.end(); titr++){
			Transformation *tr = *titr;
			
			point_index = ligand_start;
			for(int i = 0; i < cl->num_aminoacids; i++){
			 	Aminoacid *aa = cl->aminoacid[i];
			 	if(aa->alpha_carbon != NULL){
					Aminoacid *aa = cl->aminoacid[i];
					Vector v = model_points[point_index] = tr->inverse_transform(*(aa->alpha_carbon->position));
					/*out << "ref\t" << reference_points[point_index].x << "," << reference_points[point_index].y << ","<< reference_points[point_index].z 
						<< "\tmodel\t" << v.x << "," << v.y << "," << v.z << endl;*/
					point_index++;
			 	}
			}
			tr->vmetrics->rmsd = compute_rmsd(point_index, &reference_points[0], &model_points[0]);
			//*out << tr->vmetrics->rmsd << " ";
			//tr->print_details(out,TN_BASIC);
			//if(tr->frame_number == 1757)
			//	tr->write_as_pdb(cl, string("model.pdb"), false);
		}
		*out << "computed rmsd" << endl;
	}
	
	// data structure initialization
	aacontact_core = (bool **) malloc(sizeof(bool*) * (ligand->c->num_aminoacids + 1));
	aacontact_rim = (bool **) malloc(sizeof(bool*) * (ligand->c->num_aminoacids + 1));
	for(int i = 0 ; i < ligand->c->num_aminoacids; i++){
		aacontact_core[i] = (bool *) malloc(sizeof(bool) * (receptor->c->num_aminoacids + 1));
		aacontact_rim[i] = (bool *) malloc(sizeof(bool) * (receptor->c->num_aminoacids + 1));
		for(int j = 0 ; j < receptor->c->num_aminoacids; j++)
			aacontact_core[i][j] = aacontact_rim[i][j] = false;
	}
	aarcontact = (bool *) malloc(sizeof(bool) * (receptor->c->num_aminoacids + 1));
	for(int j = 0 ; j < receptor->c->num_aminoacids; j++)		aarcontact[j] = false;
	aalcontact = (bool *) malloc(sizeof(bool) * (ligand->c->num_aminoacids + 1));
	for(int j = 0 ; j < ligand->c->num_aminoacids; j++)	aalcontact[j] = false;
				
	string detailedscorefile(argv[7]);
	fstream fdetailedout(detailedscorefile.c_str(),fstream::out | fstream::app);
	for(vector<Transformation*>::iterator titr = transformations.begin(); titr != transformations.end(); titr++){
		Transformation *tr = *titr;
		receptor->compute_detailed_scores(ligand,tr);
		tr->print_details(&fdetailedout,TN_PROTPROT_DETAILED_SCORE_VERIFY);
		*out << tr->frame_number << endl;
		//break;
	}
	fdetailedout.close();	
}
