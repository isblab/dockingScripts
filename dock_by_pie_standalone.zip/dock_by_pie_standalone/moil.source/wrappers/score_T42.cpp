#include "object.hpp"
#include "sasautil.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];
extern char *tmp_dir;

/*
 * Arguments: receptor-chains ligand-chains #models
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	coarsen_atomtypesto20();
	read_dock_config();
	
	fstream sortin("sorted.ids", ios::in);
	while(sortin.good()){
		long frame_number;
		sortin >> frame_number;
		selected_ids.insert(frame_number);
		sorted_trids.push_back(frame_number);
	}
	sortin.close();
	
	hash_map<long,Transformation *,hash<long>,eqlong> selected_tr;
	int start = atoi(argv[1]);
	int end = atoi(argv[2]);
	Complex *r, *l, *c;
		r = new Complex(buf,"A", PDB);
	Transformation *tr;
	sprintf(buf,"details",start,end);
	fstream fdetails(buf,fstream::out | fstream::out);
	
	for( int mid = start ; mid < end; mid++){
		cout << "scoring model " << mid << endl;
		sprintf(buf,"models/alignedm%d",mid);
		l = new Complex(buf,"B", PDB);
		c = new Complex(buf,"AB", PDB);
		
		tr = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,mid);
		tr->vmetrics = new VerificationMetrics();
		tr->vmetrics->rmsd = tr->vmetrics->lrmsd = tr->vmetrics->irmsd = 100; 
		DetailedScoringMetrics *details = tr->detailed_scores = new DetailedScoringMetrics();
		
		//change in surface area
		for(int i = 0 ; i < NUM_RESIDUE_TYPES; i++){
			details->delta_sasa[i] = 0;
			details->delta_vdwsa[i] = 0;
		}
		for(int i = 0; i < NUM_ATOM_TYPES; i++){
			details->delta_sasa_atom[i] = 0;
			details->delta_vdwsa_atom[i] = 0;
		}
		
		r->compute_volume_sasa(false,false);
		l->compute_volume_sasa(false,false);
		c->compute_volume_sasa(false,false);
		
		for(int i = 0; i < r->num_aminoacids; i++){
			Aminoacid *am = r->aminoacid[i];
			Aminoacid *ac = c->molecules[am->chain]->aminoacid[am->index.c_str()];
			float delta_sa = am->sa - ac->sa;
			if(delta_sa > 0 && am->type >= 0)
				tr->detailed_scores->delta_sasa[am->type] += delta_sa;
				 
			for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = am->atom.begin(); aitr != am->atom.end(); aitr++){
				Atom *atmm = (Atom *) aitr->second;
				Atom *atmc = ac->atom[(const char*) aitr->first];
				delta_sa = atmm->sasa - atmc->sasa;
				if(delta_sa > 0 && atmm->type >= 0)
					details->delta_sasa_atom[atmm->type] += delta_sa;
				delta_sa = atmm->vdwsa - atmc->vdwsa;
				if(delta_sa > 0 && atmm->type >= 0)
					details->delta_vdwsa_atom[atmm->type] += delta_sa;
			}
		}
		for(int i = 0; i < l->num_aminoacids; i++){
			Aminoacid *am = l->aminoacid[i];
			Aminoacid *ac = c->molecules[am->chain]->aminoacid[am->index.c_str()];
			float delta_sa = am->sa - ac->sa;
			if(delta_sa > 0 && am->type >= 0)
				tr->detailed_scores->delta_sasa[am->type] += delta_sa;
			
			for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = am->atom.begin(); aitr != am->atom.end(); aitr++){
				Atom *atmm = (Atom *) aitr->second;
				Atom *atmc = ac->atom[(const char*) aitr->first];
				delta_sa = atmm->sasa - atmc->sasa;
				if(delta_sa > 0 && atmm->type >= 0)
					details->delta_sasa_atom[atmm->type] += delta_sa;
				delta_sa = atmm->vdwsa - atmc->vdwsa;
				if(delta_sa > 0 && atmm->type >= 0)
					details->delta_vdwsa_atom[atmm->type] += delta_sa;
			}
		}
		
		// compute residue contacts
		for(int i = 0; i < NUM_RESIDUE_TYPES; i++){
			tr1->details->delta_sasa[i] += (tr2->details->delta_sasa[i] + 
			tr1->details->delta_sasa[i];
			details->delta_vdwsa[i] = 0;
			tr1->delta
			for(int j = 0 ; j < NUM_RESIDUE_TYPES; j++)
				tr->detailed_scores->residue_contacts[i][j] = 0;
			
		for(int i = 0; i < NUM_ATOM_TYPES; i++)
			for(int j = 0 ; j < NUM_ATOM_TYPES; j++)
				tr->detailed_scores->atom_contacts[i][j] = 0;
		
		int num_clashes = 0, num_bbclashes = 0;	
		for(int laindex = 0; laindex < l->num_aminoacids; laindex++){
			Aminoacid *la = l->aminoacid[laindex];
			if(la->centroid != NULL)
				for(int raindex = 0; raindex < r->num_aminoacids; raindex++){
					Aminoacid *ra = r->aminoacid[raindex];
					if(ra->centroid != NULL && Vector::distance_squared(*(la->centroid),*(ra->centroid)) < SS_CUTOFF*SS_CUTOFF){
						short ratype=ra->type, latype=la->type;
						if(ratype >= 0 && latype>= 0)
						if(ratype <= latype)
							tr->detailed_scores->residue_contacts[ratype][latype]++;
						else
							tr->detailed_scores->residue_contacts[latype][ratype]++;						
					}
					
					for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator laitr = la->atom.begin(); laitr != la->atom.end(); laitr++){
						Atom *al = (Atom *) laitr->second;
						for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator raitr = ra->atom.begin(); raitr != ra->atom.end(); raitr++){
							Atom *ar = (Atom *) raitr->second;
							double d2 = Vector::distance_squared(al->position,ar->position);
							if(d2 >= 9.0 && d2 < AA_CUTOFF*AA_CUTOFF){
								if(al->atom_type < ar->atom_type)
									details->atom_contacts[al->atom_type][ar->atom_type]++;
								else
									details->atom_contacts[ar->atom_type][al->atom_type]++;
							}
							if(d2 < 9.0){
								num_clashes++;
								if(al->isbbatom && ar->isbbatom && d2 < 2.25)
									num_bbclashes++;
							}	
						}
					}
				}
		}
		
		tr->eResiduepair = num_clashes;
		tr->eElectrostatic = num_bbclashes;
		tr->print_details(&fdetails,TN_DETAILED_SCORE_VERIFY);
		delete c;	delete r;	delete l;
		delete tr;
	}
	fdetails.close();
}
