/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];
extern char *tmp_dir;
extern bool **aacontact_core, **aacontact_rim, *aarcontact, *aalcontact;
unsigned short dock_type;

/*
 * Arguments: pdbcode 
 */
int main(int argc, char *argv[]){
	out = &cout;
	dock_type = atoi(argv[1]);
	
	read_molecule_config();
	read_dock_config();
	
	char buf[8192*32];
	string filename = string(getenv(string("HOME").c_str())) + "/" + string(DOCK_DIR) + "bt";
	fstream fresidue(filename.c_str());
    while(fresidue.good()){
    	fresidue.getline(buf,8192);
    	if(fresidue.gcount() > 0){
	    	stringstream ss (stringstream::in | stringstream::out);
	    	ss << buf;
	    	int aa1, aa2;
	    	ss >> aa1; ss >> aa2;
	    	int i = aa1-1;
		    int j = aa2-1;
		    float value;
			ss >> value;
			residue_potential[j][i] = residue_potential[i][j] = value;
    	}
    }
    fresidue.close();
	
	Complex *c = new Complex(argv[1],"-", PDB);
	
	float aacontact[20][20];
	for(int i = 0; i < 20; i++)
		for(int j = 0; j < 20; j++)
			aacontact[i][j] = 0;
			
	for(int i = 0; i < c->num_aminoacids; i++){
		Aminoacid *aa = c->aminoacid[i];
		if(aa->centroid != NULL)
			cout << "aminoacid " << aa->index << " centroid (" << aa->centroid->x << "," << aa->centroid->y << "," << aa->centroid->z << ")" << endl;
	}

	float d,d2;
	for(int i = 0; i < c->num_aminoacids; i++){
		Aminoacid *aa1 = c->aminoacid[i];
		if(aa1->centroid != NULL)
			for(int j = i+2; j < c->num_aminoacids; j++){
				Aminoacid *aa2 = c->aminoacid[j];
				if(aa2->centroid != NULL){
					short type1 = aa1->type, type2 = aa2->type;
					if((d2 = Vector::distance_squared(aa1->centroid,aa2->centroid)) < 6.5*6.5){
						if(type1 >= 0 && type2 >= 0)
							aacontact[type1][type2] += 0;
					}
					if(d2 < AA_SMTHP_CUTOFF_SQUARED){
						d = sqrt(d2);
						float factor = AA_SMTHP_FACTOR(d);
						if(type1 >= 0 && type2 >= 0)
							aacontact[type1][type2] += factor;
						cout << "aa1: " << aa1->index << " aa2: " << aa2->index << " centroid distance " << d << " factor " << factor << endl;
					}
				}
			}
	}
	
	float btscore=0;
	for(int i = 0; i < 20; i++)
		for(int j = 0; j < 20; j++)
			btscore += aacontact[i][j] * residue_potential[i][j];
	
	cout << "protein " << argv[1] << " btscore " << btscore << endl;
}
