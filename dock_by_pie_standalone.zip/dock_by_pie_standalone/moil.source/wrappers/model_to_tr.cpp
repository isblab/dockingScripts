/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];
extern char *tmp_dir;

Transformation *identity;

Transformation *get_transformation(string model_filename, string receptor_pdb_filename, string ligand_pdb_filename, char model_rchain, char model_lchain){
  	stringstream ss (stringstream::in | stringstream::out);
	ss << getenv(string("HOME").c_str()) << "/scripts/select_chain.sh " << model_rchain << " models/" << model_filename << ".pdb > tm/" << model_filename << "_" << model_rchain << ".pdb";
	ss.getline(buf,2048);
	int ret = system(buf);
	cout << buf << " " << ret << endl;
	
	ss.clear();
	ss << getenv(string("HOME").c_str()) << "/external/tmalign tm/" << model_filename << "_" << model_rchain << ".pdb  ../" << receptor_pdb_filename << ".pdb > tm/" 
		<< model_filename << "_" << model_rchain << "_vs_rec.tmali";
	ss.getline(buf,2048);
	ret = system(buf);
	cout << buf << " " << ret << endl;
	
	ss.clear();
	ss << getenv(string("HOME").c_str()) << "/scripts/select_chain.sh " << model_lchain << " models/" << model_filename << ".pdb > tm/" << model_filename << "_" << model_lchain << ".pdb";
	ss.getline(buf,2048);
	ret = system(buf);
	cout << buf << " " << ret << endl;
	
	ss.clear();
	ss << getenv(string("HOME").c_str()) << "/external/tmalign tm/" << model_filename << "_" << model_lchain << ".pdb ../" << ligand_pdb_filename << ".pdb  > tm/" 
		<< model_filename << "_" << model_lchain << "_vs_lig.tmali";
	ss.getline(buf,2048);
	ret = system(buf);
	cout << buf << " " << ret << endl;
	
	// parse tmalign file, read the relative transformations
	sprintf(buf,"tm/%s_%c_vs_rec.tmali",model_filename, model_rchain);
	fstream raliin(buf,fstream::in);
	Transformation *tr_rec_to_model = NULL;
	while(raliin.good() && tr_rec_to_model == NULL){
    	raliin.getline(buf,8192);
    	if(raliin.gcount() > 0){
    		//cout << string(buf) << endl;
    		if(string(buf).find("rotation matrix to rotate Chain")!=string::npos){
    			raliin.getline(buf,8192);
    			Vector *translation, *ex, *ey, *ez;
    			double A[3][4];
    			for(int i = 0; i < 3; i++){
    				raliin.getline(buf,8192);
    				stringstream ss(buf,stringstream::in);
					string tag;
					ss >> tag;
					for(int j = 0; j <4; j++){
						ss >> A[i][j];
					}
    			}
    			translation = new Vector(A[0][0],A[1][0],A[2][0]);
    			ex = new Vector(A[0][1],A[1][1],A[2][1]);
    			ey = new Vector(A[0][2],A[1][2],A[2][2]);
    			ez = new Vector(A[0][3],A[1][3],A[2][3]);
    			/*ex = new Vector(A[0][1],A[0][2],A[0][3]);
    			ey = new Vector(A[1][1],A[1][2],A[1][3]);
    			ez = new Vector(A[2][1],A[2][2],A[2][3]);*/
    			tr_rec_to_model = new Transformation(translation, ex, ey, 1.0, 0, 0);
    			tr_rec_to_model->print_details(&cout,TN_BASIC);
    			/*{
    				Complex *c = new Complex( "../3ho4B","-",PROCESSED);
    				tr_rec_to_model->write_as_pdb(c, "-", false, "test.pdb", true);
    				tr_rec_to_model->write_as_pdb(c, "-", false, "testinv.pdb", false);
    			}*/
    		}
    	}
	}
	raliin.close();
	
	// parse tmalign file, read the relative transformations
	sprintf(buf,"tm/%s_%c_vs_lig.tmali",model_filename, model_lchain);
	fstream laliin(buf,fstream::in);
	Transformation *tr_lig_to_model = NULL;
	while(laliin.good() && tr_lig_to_model == NULL){
    	laliin.getline(buf,8192);
    	if(laliin.gcount() > 0){
    		//cout << string(buf) << endl;
    		if(string(buf).find("rotation matrix to rotate Chain")!=string::npos){
    			laliin.getline(buf,8192);
    			Vector *translation, *ex, *ey, *ez;
    			float A[3][4];
    			for(int i = 0; i < 3; i++){
    				laliin.getline(buf,8192);
    				stringstream ss(buf,stringstream::in);
					string tag;
					ss >> tag;
					for(int j = 0; j <4; j++){
						ss >> A[i][j];
					}
    			}
    			translation = new Vector(A[0][0],A[1][0],A[2][0]);
    			ex = new Vector(A[0][1],A[1][1],A[2][1]);
    			ey = new Vector(A[0][2],A[1][2],A[2][2]);
    			ez = new Vector(A[0][3],A[1][3],A[2][3]);
    			tr_lig_to_model = new Transformation(translation, ex, ey, 1.0, 0, 0);
    		}
    	}
	}
	laliin.close();
	
	float d, ud;
	identity->distance(&d, &ud, tr_lig_to_model);
	if( d > 2.0 || ud >= 0.1) {
		tr_lig_to_model->print_details(&cout,TN_BASIC);
		cout << "ligand transformed receptor fixed " << model_filename << endl;
		Reference_Frame *rf = identity->invert(tr_lig_to_model);
		Transformation *trinv = new Transformation(rf->translation, rf->ex, rf->ey,1.0,0,0);
		return trinv;
	} else
		return tr_rec_to_model;
}

/*
 * Arguments: 
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	read_dock_config();
	
	string receptor_pdb_filename = string(argv[1]);
	string ligand_pdb_filename = string(argv[2]);
	char model_rchain = argv[3][0];
	char model_lchain = argv[4][0];
	int start = atoi(argv[5]);
	int end = atoi(argv[6]);
	
	Vector *translation = new Vector(0,0,0);
    Vector *ex = new Vector(1,0,0);
    Vector *ey = new Vector(0,1,0);
    identity = new Transformation(translation, ex, ey, 1.0, 0, 0);

	fstream transout("moilr.trans",fstream::out);
	for(int i = start; i < end; i++){
    	cout << "converting model " << i << endl;
    	sprintf(buf,"m%d",i);
    	string model_filename = string(buf);
    	Transformation *tr = get_transformation(model_filename, receptor_pdb_filename, ligand_pdb_filename, model_rchain, model_lchain);
    	tr->frame_number = i;
    	tr->write_binary(&transout,TN_BASIC);
    }
    transout.close();
}

