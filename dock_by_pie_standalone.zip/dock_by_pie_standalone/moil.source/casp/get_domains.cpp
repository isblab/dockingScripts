/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"
#include "align_utilities.hpp"
const char* pdbcode;
string* chains;
int filetype;

string* seqres_sequence, *sequence;
hash_map<const char*, Sequence*, hash<const char*>, eqstr> matching_sequences, matching_sequences_in_pdb, sequences_with_struct_alignment;
hash_map<const char*, Molecule*, hash<const char*>, eqstr> homologues;
char **malignment;
const char ***malignment_indices;

ostream *out;
char scratch_dir[512], command[8192];
#ifndef BUFSIZE
#define BUFSIZE 16384
#endif
extern char buf[16384];
extern char *tmp_dir;
extern bool **aacontact_core, **aacontact_rim, *aarcontact, *aalcontact;

vector<Sequence*> sequence_homologues;

/*
 * directed distance, how well cluster [s1,e1] covers [s2,e2]
 */
double interval_distance(short s1, short e1, short s2, short e2){
	short intersect_start = maximum(s1,s2);
	short intersect_end = minimum(e1,e2);
	short union_start = minimum(s1,s2);
	short union_end = maximum(e1,e2);
	short size1 = e1 - s1;
	short size2 = e2 - s2;
	short intersect_size = intersect_end - intersect_start; 
	float d;
	//d = 1.0 - ((float) (intersect_size))/(union_end - union_start);
	//d = 1.0 - ((float) 2.0 * (intersect_size))/(size1 + size2);
	//d = 1.0 - ((float) 1.25 * (intersect_size))/(0.2 * size1 + size2);
	d = 1.0 - ((float) 1.25 * (intersect_size))/(size1);
	d = 1.0 - ((float) 1.25 * 1.2 * (intersect_size))/(size1 + 0.2 * size2);
	if(d < 0)	d = 0;
	
	/*if(intersect_size > 0.8 * size1){
		d = 0;
	} else {
	}*/
	
	return d; 
}

double cluster_intervals_KMedians(short *interval_start, short *interval_end,short extent, int n, int K){
	int max_trials = 100;
	short cluster[max_trials][K+1][2];
	vector<short> cluster_members[max_trials][K+1];
	
	int index = 0, best_trial;
	float min_spread;
	srand(time(0));
	for(int trial = 0 ; trial < max_trials ; trial++){
		// set initial centroids
		index = 0;
		bool taken[n];
		for(int i = 0 ; i < n; i++)
			taken[i] = false;
	
		while(index < K){
			int p = rand()%(n-index);
			int k = 0;
			int permuted_index;
			for(int j = 0 ; j < n ; j++)
				if(!taken[j]){
					if(k++ == p){
						taken[j] = true;
						permuted_index = j;
						break;
					}
				}
						
			cluster[trial][index][0] = interval_start[permuted_index];
			cluster[trial][index][1] = interval_end[permuted_index];
			cluster_members[trial][index].push_back(permuted_index);
			index++;
		}
		cluster[trial][K][0] = 1;
		cluster[trial][K][1] = extent;
#ifdef DEBUG
		*out << "initialized means " << index << endl; out->flush();
#endif
		
		int num_iterations = 0;
		float spread, new_spread = 0;
		bool done = false;
		while(!done){
			done = false;
			spread = new_spread;
			new_spread = 0;
			
			//do not associate any points with the cluster
			if(num_iterations > 0)
				for(int i = 0 ; i < K; i++){
					cluster_members[trial][i].clear();
				}
	
			// compute the closest centroid for each point and add it to the corresponding cluster
			float dij;
			for(short i = 0 ; i < n; i++){
				float closest_distance;
				int closest_cluster;
				for(int j = 0 ; j < K+1; j++){
					dij = interval_distance(cluster[trial][j][0], cluster[trial][j][1], interval_start[i], interval_end[i]);

					if(j == 0){
						closest_distance = dij;
						closest_cluster = 0;
					} else if(dij < closest_distance){
						closest_distance = dij;
						closest_cluster = j;
					}
				}
				cluster_members[trial][closest_cluster].push_back(i);
			}
			
			// update the cluster centroids
			for(int i = 0 ; i < K+1; i++){
				if(i < K){
					float sum_start=0, sum_end=0;
					for(vector<short>::iterator itr = cluster_members[trial][i].begin(); itr != cluster_members[trial][i].end(); itr++){
						short mi = *itr;
						sum_start += interval_start[mi];
						sum_end += interval_end[mi];
					}
					short csize = cluster_members[trial][i].size();
					cluster[trial][i][0] = sum_start / csize;
					cluster[trial][i][1] = sum_end / csize;
				}
				
				float cspread = 0;
				for(vector<short>::iterator itr = cluster_members[trial][i].begin(); itr != cluster_members[trial][i].end(); itr++){
					short mi = *itr;
					dij = interval_distance(cluster[trial][i][0], cluster[trial][i][1], interval_start[mi], interval_end[mi]);
					cspread += dij;
				}
				new_spread += cspread;
			}
			
			num_iterations++;
			done = (num_iterations > 50) || (num_iterations > 1 && (spread - new_spread)/spread <= .01);

#ifdef DEBUG			
			*out << "#iterations " << num_iterations << " spread " << new_spread << endl;
#endif			
		}
		if(trial == 0 || new_spread < min_spread){
			best_trial = trial;
			min_spread = new_spread;
		}
	}

	cout << "Kmeans clustering, assume one fixed cluster, K = " << K << " spread " << min_spread << endl; 
	for(int i = 0 ; i < K+1; i++){
		cout << "cluster " << i << " [" << cluster[best_trial][i][0] << ","  << cluster[best_trial][i][1] << "]" << endl;
	}
	
	return min_spread;
}

#define FASTACMD "/proj/ravid/software/blast-2.2.17/bin/fastacmd"
#define NR_DB "/proj/ravid/blast/db/nr"
#define LALIGN "/proj/ravid/software/fasta/bin/lalign35"
extern hash_map<long, Alignment*, hash<long>, eqlong> seq_alignments;

void read_blast_hits_fillin_alignments(char chain, unsigned short db, string dir){
	stringstream ss (stringstream::in | stringstream::out);
	ss << dir << "/" << pdbcode << "_" << chain << ".";
	switch(db){
		case DB_PDBAA:
			ss << "matches";
		break;
		case DB_SWISSPROT:
			ss << "spmatches";
		break;
		case DB_NR:
			ss << "allmatches";
		break;
		case DB_STRING:
			ss << "stmatches";
		break;
	}
	string filename;
	ss >> filename;
	fstream fin(filename.c_str(), fstream::in);
	
	if(!fin.is_open()){
		*out << "Error opening file " << filename << endl;
		exit(1);
	}
	
	hash_set<const char*, hash<const char*>, eqstr> matching_seqtags;
	int round = 1;
	bool done = false;
	stringstream* line;
	string last_index;
	long aindex= 0;
	do{
		if(round == 1){
			do{
				fin.getline(buf,BUFSIZE);
			}while((string(buf)).find("letters)") == string::npos);
			line = new stringstream(buf,stringstream::in);
			string s;
			*line >> s;
			int start = s.find("(") + 1;
			int end = s.find("letter");
			int length = atoi(s.substr(start,end - start).c_str());
			
			sprintf(buf,"%d",length-1);
			last_index = *(new string(buf));
			*out << "seq length " << length << " " << last_index << endl;
		}
		
		do{
			fin.getline(buf,BUFSIZE);
			if(!fin.good()){
				*out << "no hits found" << endl;
				return;
			}
		}while((string(buf)).find("Results from round") == string::npos);
		
		if(round == 1){
			do{
				fin.getline(buf,BUFSIZE);
			}while((string(buf)).find("Sequences producing significant alignments") == string::npos);
			fin.getline(buf,BUFSIZE);
			//*out << "check " << buf << endl;
		} else {
			do{
				fin.getline(buf,BUFSIZE);
			}while((string(buf)).find("Sequences not found previously") == string::npos);
			fin.getline(buf,BUFSIZE);
		}
		
		bool round_done = false;
		
		// read ids of sequences producing significant alignments
		while (fin.good() && buf[0] != '>'){
			fin.getline(buf,BUFSIZE);
			if(string(buf).find("|") != string::npos){
				stringstream ss(buf,stringstream::in);
				string s; ss >> s;
				matching_seqtags.insert((new string(s.c_str()))->c_str());
			}
		}
		if(!fin.good()){
			*out << "ERROR : Check file format " << filename << endl;
			return; 
		}
		
		*out << round << " read matching sequences" << endl;
		round_done = false;
		// get alignments and scores
		while (!round_done){
			while((string(buf)).size() == 0)
				fin.getline(buf,BUFSIZE);
			
			// additional alignments from previous match - 
			while((string(buf)).find("Score") != string::npos || (string(buf)).find("Query:") != string::npos){
				do{
					fin.getline(buf,BUFSIZE);
				}while((string(buf)).find("Sbjct") == string::npos);
				fin.getline(buf,BUFSIZE);
				while((string(buf)).size() == 0)
					fin.getline(buf,BUFSIZE);
			}
			//*out << "|" << buf << endl;
			
			done =  ((string(buf)).find("Database:") != string::npos);
			round_done = done || ((string(buf)).find("Searching") != string::npos && (string(buf)).find("done") != string::npos);
			
			if(!round_done){
				vector<string> current_seqids;
				bool reading_seqids = true, first_newline = true;
				string current_seqtag;
				while(reading_seqids){
					reading_seqids = ((string(buf)).find("Length =") == string::npos);
					if(reading_seqids){
						bool start_newline = ((string(buf)).find("|") != string::npos);
						if(start_newline){
							if(!first_newline){
								current_seqids.push_back(current_seqtag);
								//*out << current_seqtag << endl;
							} else	first_newline= false;
							
							current_seqtag = string(buf).substr(1);
						} else {
							current_seqtag += string(buf);
						}
						fin.getline(buf,BUFSIZE);
					}
				}
				current_seqids.push_back(current_seqtag);
				
				// am at Length =
				bool alignment_done = false;
				string aseq1 = "", aseq2 = "";
				int qstart, qend, sstart, send;
				bool read_scores = false;
				float score, eval, identities,positives;
				do{
					string s;
					if(!read_scores){
						do{
							fin.getline(buf,BUFSIZE);
						}while((string(buf)).find("Score") == string::npos);
						line = new stringstream(buf,stringstream::in);
						*line >> s; *line >> s; *line >> s;
						score = atof(s.c_str());
						*line >> s; *line >> s; *line >> s; *line >> s; *line >> s;
						eval = atof(s.substr(0,s.find(",")).c_str());
						
						do{
							fin.getline(buf,BUFSIZE);
						}while((string(buf)).find("Identities") == string::npos);
						line = new stringstream(buf,stringstream::in);
						*line >> s; *line >> s; *line >> s; *line >> s;
						identities = atof(s.substr(1,s.find("%")).c_str());
						*line >> s; *line >> s; *line >> s; *line >> s;
						positives = atof(s.substr(1,s.find("%")).c_str());
						
						read_scores = true;
						
						fin.getline(buf,BUFSIZE);
					}
					
					while((string(buf)).find("Query") == string::npos)
						fin.getline(buf,BUFSIZE);
					
					line = new stringstream(buf,stringstream::in);
					*line >> s; 
					if(aseq1 == "")
						*line >> qstart;
					else
						*line >> s; 
					*line >> s; *line >> qend;
					alignment_done = (s.size() < 60);
					aseq1 += s;
					
					do{
						fin.getline(buf,BUFSIZE);
						line = new stringstream(buf,stringstream::in);
						*line >> s; 
						if(aseq2 == "")
							*line >> sstart;
						else
							*line >> s; 
						*line >> s; *line >> send;
					}while((string(buf)).find("Sbjct") == string::npos);
					aseq2 += s;
					fin.getline(buf,BUFSIZE);
					fin.getline(buf,BUFSIZE);
					if(!alignment_done)
						alignment_done = ((string(buf)).size() == 0);
				}while(!alignment_done);
				
				Alignment* a = new Alignment(aseq1,aseq2,aindex++);
				a->score = score;
				a->eval = eval;
				a->identities = identities;
				a->positives = positives;
				a->qstart = qstart;
				a->qend = qend;
				a->sstart = sstart;
				a->send = send;
				seq_alignments[aindex] = a;
				
				for(vector<string>::iterator sitr = current_seqids.begin(); sitr != current_seqids.end(); sitr++){
					string seqid = *sitr;
					Sequence *s;
					if(matching_sequences.count(seqid.c_str()) == 0){
						matching_sequences[(new string(seqid))->c_str()] = new Sequence(seqid);	
					}
					s = matching_sequences[seqid.c_str()];
					s->seq_alignment = a;
					
					string tag = s->database + "|" + s->id + "|"; 
					if(matching_seqtags.count(tag.c_str()) > 0)
						matching_seqtags.erase(matching_seqtags.find(tag.c_str()));
				}
			}
			
		}
		*out << round << " read matching alignments" << endl;
		*out << "round " << round << " #matches " << matching_sequences.size() << " #alignments " << seq_alignments.size() << " #alignments to fill in " << matching_seqtags.size() << endl;
		round++;
	} while(!done);
	fin.close();

	// fill in alignments
	int seqno=0;
	sprintf(buf,"mkdir sequences");
	int ret = system(buf);
	sprintf(buf,"mkdir alignments");
	ret = system(buf);
	for(hash_set<const char*, hash<const char*>, eqstr>::iterator sitr = matching_seqtags.begin(); sitr != matching_seqtags.end(); sitr++){
		string tag = string((char*) *sitr);
		Sequence* s = new Sequence(tag);
		{
			stringstream ss (stringstream::in | stringstream::out);
			ss << FASTACMD << " -d " << NR_DB << " -s " << s->id << " >> sequences/" << seqno << ".fasta";
			ss.getline(buf,2048);
		}
		ret = system(buf);
		if(ret!=0)	
			*out << "FASTACMD ERROR " << string(buf) << " " << ret << endl;
		else {
			// get alignment
			stringstream ss (stringstream::in | stringstream::out);
			ss << LALIGN << " " << string(pdbcode) << ".seq " << " sequences/" << seqno << ".fasta >> alignments/" << seqno << ".ali";
			ss.getline(buf,2048);
		
			ret = system(buf);
			if(ret!=0)	
				*out << "LALIGN ERROR " << string(buf) << " " << ret << endl;
			else {
				string align_filename;
				stringstream ss (stringstream::in | stringstream::out);
				ss << "alignments/" << seqno << ".ali";
				ss >> align_filename;
		
				Alignment *a = read_lalign_alignment(sequence,(char*)(new string(align_filename.c_str()))->c_str(), seq_alignments.size() + seqno);
				if(a!=NULL){
					s->seq_alignment = a;
					matching_sequences[(new string(tag.c_str()))->c_str()] = s;
					//*out << "alignment " << a->index << " " << a->qstart << " " << a->qend << endl; out->flush();
				}
			}
		}
		
		seqno++;
	}
	
	*out << "#matching sequences " << matching_sequences.size() << " #alignments " << seq_alignments.size() << endl;
}


/*
 * Arguments: pdbid chain domain1_start domain1_end domain2_start domain2_end 
 */
int main(int argc, char *argv[]){
	out = &cout;
	
//	read_molecule_config();
//	read_dock_config();
	
	string tag = string(argv[1]);
	cout << "tag " << tag << endl;
	pdbcode = tag.c_str();
	char chain = '-';
	
	string seq="";
	{
		stringstream ss (stringstream::in | stringstream::out);
		ss << tag << ".seq";
		string filename;
		ss >> filename;
		fstream fin(filename.c_str(), fstream::in);
		fin.getline(buf,16384);
		while(!fin.eof()){
			fin.getline(buf,16384);
			stringstream line(buf,stringstream::in);
			string tag;
			line >> tag;
			seq = seq + tag;
		}
		fin.close();
	}
	sequence = new string(seq.c_str());
	cout << "sequence:\t" << seq << endl;

	//read_blast_hits_fillin_alignments(chain, DB_NR, ".");
	read_optm_local_hits("optm_local.info");
	
	unsigned index=0;
	int nsequences = matching_sequences.size();
	short start[ nsequences+1], end[ nsequences+1];
	hash_set<int, hash<int> , eqint> alignments_considered;
	for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr = matching_sequences.begin(); sitr != matching_sequences.end(); sitr++){
		Sequence *s = (Sequence *) sitr->second;
		Alignment *a = s->seq_alignment;
		
	  if(alignments_considered.count((int) a->index) == 0){
		alignments_considered.insert((int) a->index);
		
		// consider pieces of length atleast 50
		if(a->qend - a->qstart + 1 >= 50){
			start[index] = a->qstart;
			end[index] = a->qend;
			index++;
		}
	  }
	}
	nsequences = index;
	
	// sort by start
	for(int i = 0; i < nsequences; i++)
		for(int j = i+1; j < nsequences; j++){
			if(start[j] < start[i] || (start[j] == start[i] && end[j] > end[i])){
				short t = start[i];
				start[i] = start[j];
				start[j] = t;
				t = end[i];
				end[i] = end[j];
				end[j] = t;
			}
		}
	
	cout << "number\tstart\tend\n"; 
	for(int i = 0; i < nsequences; i++){
		cout << i+1 << "\t" << start[i] << "\t" << end[i] << endl;
	}
	
	/* cluster and find 5 sequences	*/
	cluster_intervals_KMedians(start, end, sequence->size(), nsequences, 2);
	cluster_intervals_KMedians(start, end, sequence->size(), nsequences, 3);
	cluster_intervals_KMedians(start, end, sequence->size(), nsequences, 4);
	cluster_intervals_KMedians(start, end, sequence->size(), nsequences, 5);
}
