/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

void compute_fragment_sasa(Complex *c, unsigned short start, unsigned short end);

void compute_sasa(Complex *cr, Complex *cl);
