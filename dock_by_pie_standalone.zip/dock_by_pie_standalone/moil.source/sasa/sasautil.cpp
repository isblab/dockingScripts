/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"

#define SCALE		100		/* SASA scale variable */
#define MAXPOINTS	256		/* Max number of points on sphere */

typedef struct	{
	Atom *a;
	float x,y,z;
	float radius2;
	float vdwsa, sasa, overlapvolume, seoverlapvol;
	unsigned int 	mask[8], pmask[8]; 
	unsigned int 	vmask[DISTANCE_DIVISIONS_FOR_VOLUME][8], sevmask[DISTANCE_DIVISIONS_FOR_VOLUME][8];
	
	unsigned int	box;
	unsigned short	number;		// array index
	unsigned short blockid;
} atom_type;

typedef struct 	{
	unsigned int	mask[2*SCALE][8];	/* Boolean Masks */
	float		x,y,z;			/* Coordinates of point */
} point_type;

typedef struct {
  int distance,id;
} distance_type;
distance_type *dmat[MAXPOINTS];

atom_type atm[MAX_ATOMS], *abox[MAX_ATOMS];

unsigned int	box_offset[27];		/* Non-bond box offsets */
unsigned char closest_point[100][200];
point_type point[MAXPOINTS];
Vector *sasa_samplepoints;

unsigned short		num_box_atoms;
float	max_d, max_d2;

int atom_points;		/* # of points on sphere */
int	atom_resolution;	/* Grid resolution */
unsigned int	sasacount[258];		/* Binary->Decimal conv. table */

float hydrophobicity[NUM_RESIDUE_TYPES];
bool sasa_initialized = false;

int num_atoms_protein1, num_bbclashes, num_clashes;
unsigned short atom_vdw_repulsion[NUM_ATOM_VDWREPULSION_DIVISIONS+1];
float delta_vdwsapair;

extern string piedock_home;

void init_sasa(){
	unsigned	seed;
  	srandom(time(NULL));
  	
  	atom_resolution=200;
  	
  	char points_filename[512];
	sprintf(points_filename, "%s/moil.dock/sasa_points",piedock_home);
	FILE *fp=fopen(points_filename,"r");
	
	if(fp!=NULL){
		int fpnum=fileno(fp);
		read(fpnum,&atom_points,4);
		read(fpnum,&atom_resolution,4);
		for(int i=0;i<atom_points;i++)
			read(fpnum,point[i].mask,32*atom_resolution);
		read(fpnum,closest_point,20000);
		read(fpnum,sasacount,1024);
		fclose(fp);
	} else {
		*out << "ERROR: Compute SASA - no look-up table data file available. Expected " << points_filename << endl;
		exit(-1);
	}
	
	// set max d box offsets
	int l=0;
	for(int i= -1;i<=1;i++) {
		for(int j= -1;j<=1;j++) {
			for(int k= -1;k<=1;k++) {
				box_offset[l]=i*1000000+j*1000+k;
				l++;
  			}
		}
	}
	
	max_d+=2*(Atom::get_max_radius());
	max_d2=max_d*max_d;
	
	/* currently using the sampling of points on unit sphere as defined by Scott in the rapid sasa calculation
	 * do't know the points, figuring out what they are 
	 * are the points uniformly distributed? check and reposition points after capri */
	sasa_samplepoints = new Vector[MAXPOINTS];
	hash_map<int,vector<unsigned int>,hash<int>,eqint> point_vs_thetaphi;
	for(unsigned int theta_index = 0; theta_index < 100; theta_index++)
		for(unsigned int phi_index = 0; phi_index < 200; phi_index++){
			int k=closest_point[theta_index][phi_index];
			if(point_vs_thetaphi.count(k) == 0){
				point_vs_thetaphi[k] = *(new vector<unsigned int>);
				point_vs_thetaphi[k].clear();
			}
			point_vs_thetaphi[k].push_back((theta_index)*200+phi_index);
		}
	
	*out << "size " << 	point_vs_thetaphi.size() << endl;
	for(hash_map<int,vector<unsigned int>,hash<int>,eqint>::iterator hitr = point_vs_thetaphi.begin(); hitr != point_vs_thetaphi.end(); hitr++){
		int pindex = (int) hitr->first;
		//cout << pindex << " " << point_vs_thetaphi[pindex].size() << "\t"; cout.flush();
		
		Vector sum_points=Vector(0,0,0);
		vector<unsigned int> thetas,phis;
		thetas.clear(); phis.clear();
		for(vector<unsigned int>::iterator itr = point_vs_thetaphi[pindex].begin(); itr != point_vs_thetaphi[pindex].end(); itr++){
			int thetai = ((unsigned int) *itr)/200;
			int phii = ((unsigned int) *itr) % 200;
			thetas.push_back(thetai);
			phis.push_back(phii);
			
			float sin_theta = sin(thetai*PI/100);
			Vector v = Vector(sin_theta*sin(phii*PI/100),sin_theta*cos(phii*PI/100),cos(thetai*PI/100));
			sum_points = sum_points + v;
		} 
		
		Vector v = sum_points * (1.0/point_vs_thetaphi[pindex].size());
		v.normalize();
		sasa_samplepoints[pindex] = v;
		//cout << v.x << "," << v.y << "," << v.z << endl; 
		
		/*sort(thetas.begin(),thetas.end());
		sort(phis.begin(),phis.end());
		
		for(vector<unsigned int>::iterator itr = thetas.begin(); itr != thetas.end(); itr++){
			cout << (unsigned int) *itr << "-";
		}
		cout << endl;
		
		for(vector<unsigned int>::iterator itr = phis.begin(); itr != phis.end(); itr++){
			cout << (unsigned int) *itr << "-";
		}
		cout << endl;
		/*/
	}
	*out << "obtained points" << endl; cout.flush();
	
	hydrophobicity[TRP] = 3.06;
	hydrophobicity[ILE] = 2.45;
	hydrophobicity[PHE] = 2.43;
	hydrophobicity[LEU] = 2.31;
	hydrophobicity[CYS] = 2.09;
	hydrophobicity[MET] = 1.67;
	hydrophobicity[VAL] = 1.66;
	hydrophobicity[TYR] = 1.31;
	hydrophobicity[PRO] = 0.98;
	hydrophobicity[ALA] = 0.42;
	hydrophobicity[THR] = 0.35;
	hydrophobicity[HIS] = 0.18;
	hydrophobicity[GLY] = 0.0;
	hydrophobicity[SER] = -0.05;
	hydrophobicity[GLN] = -0.30;
	hydrophobicity[ASN] = -0.82;
	hydrophobicity[GLU] = -0.87;
	hydrophobicity[ASP] = -1.05;
	hydrophobicity[LYS] = -1.35;
	hydrophobicity[ARG] = -1.37;
	hydrophobicity[AMIDE_N] = hydrophobicity[CARBONYL_O] = hydrophobicity[CTER] = hydrophobicity[NTER] = 0.0;
}

/*
 * Masks have to be transformed upon rotation, 
 */
void rotation_map_masks(Transformation *tr, unsigned int *rmask){
	
}

bool box_less(atom_type *a1, atom_type *a2){
	if (a1->box<a2->box)
		return(true);
	else
		if (a1->box>a2->box)
			return(false);
		else
			if (a1->number<a2->number)
				return(true);
			else
				return(false);
}

/*
 * Definition of surface area of a particle - Area not in overlap with other particles
 * if include_probe is set to true, we grow particles are by probe radius and check if the particle is not buried  
 */
void compute(unsigned short num_atoms, bool include_probe, bool computevolumeoverlap, bool computesevol){
	computesevol=false;
	if(num_atoms > MAX_ATOMS){
		*out << "ERROR: compute sasa num atoms larger than MAX_ATOMS" << endl; out->flush();
		exit(-1);
	}
	
	if(!sasa_initialized){
		init_sasa();
		sasa_initialized = true;
	}
	
	num_box_atoms=0;
	
	float center[3];
	for(int i =0; i < 3; i++)	center[i] = 0;
	for(int i = 0 ; i < num_atoms; i++){
		center[0] += atm[i].x;
		center[1] += atm[i].y;
		center[2] += atm[i].z;
	}
	for(int i =0; i < 3; i++)	center[i] /= num_atoms;
	
	for(unsigned short i = 0 ; i < num_atoms; i++){
		atm[i].box=((unsigned int)((atm[i].x-center[0])/max_d)+500)*1000000	+((int)((atm[i].y-center[1])/max_d)+500)*1000 +(int)((atm[i].z-center[2])/max_d)+500;
		atm[i].number=i;
		atm[i].radius2 = atm[i].a->radius*atm[i].a->radius;
		
		if (atm[i].a->radius>0.0){	
			abox[num_box_atoms]= &atm[i];
			num_box_atoms++;
		}
		
		for(int m=0; m < 8; m++){
			atm[i].mask[m]=atm[i].a->mask[m];
			if(include_probe || computesevol)	atm[i].pmask[m]=atm[i].a->pmask[m];
			if(computevolumeoverlap)
				for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	atm[i].vmask[v][m]=atm[i].a->vmask[v][m];
			if(computesevol)
				for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	atm[i].sevmask[v][m]=atm[i].a->sevmask[v][m];
		}
	}
	delta_vdwsapair=0;
	//*out << "n-" << num_atoms << " " << num_box_atoms << "\t";out->flush();
	
	short	cboxstart; unsigned short cboxend;
	atom_type *a1,*a2;
	float phi,theta,d,d2;
	float dx,dy,dz;
	float a1r,a2r,a1r2,a2r2, a1pr,a1pr2, a2pr, a2pr2;
	float cos_alpha;
	
	// sort abox to efficiently identify atoms in the same box
	sort(&abox[0],&abox[0] +num_box_atoms,box_less);
	//*out << "sorted box"<< endl; out->flush();
	
	hash_map<unsigned int,unsigned short, hash<int>, eqint> box_start, box_end; 
	//unsigned short num_distinct_boxid=0;
	hash_set<unsigned int, hash<int>, eqint> distinct_boxid;
	unsigned short boxstart=0;
	while(boxstart<num_box_atoms) {
		unsigned int box_id=abox[boxstart]->box;
		
		/// find boundary of active non-bond box -- all atoms between boxstart and boxend are in the same box
		unsigned short boxend=boxstart;
		while (boxend<num_box_atoms && abox[boxend]->box==box_id)	boxend++;
		
		//cout << "sort " << boxstart << " " << abox[boxstart]->box << " " << abox[boxstart]->number << " " << abox[boxstart]->a->cindex << endl;
		distinct_boxid.insert(box_id);
		box_start[box_id] = boxstart;
		box_end[box_id] = boxend;
		//num_distinct_boxid++;
		boxstart=boxend;	
	}
	
	for(hash_set<unsigned int, hash<int>, eqint>::iterator itr = distinct_boxid.begin(); itr != distinct_boxid.end(); itr++){
		unsigned int box_id=(unsigned int) *itr;
		unsigned short boxstart=box_start[box_id], boxend=box_end[box_id];
			
		for(int l=0;l<=13;l++) {
			unsigned int cbox_id=box_id+box_offset[l];
			if(distinct_boxid.count(cbox_id) > 0){
				cboxstart=box_start[cbox_id];
				cboxend=box_end[cbox_id];
				//cout << " look " << box_id << " " << boxstart << " " << boxend << " " << cbox_id << " " << cboxstart << " " << cboxend << endl; 
				for(unsigned short i=boxstart;i<boxend;i++) {
					a1=abox[i];
					float a1x,a1y,a1z;
					a1x=a1->x;
					a1y=a1->y;
					a1z=a1->z;
					a1r=a1->a->radius;
					a1r2=a1->radius2;
					a1pr=a1->a->radius + probe_radius;
					a1pr2=(a1->a->radius + probe_radius)*(a1->a->radius + probe_radius);
					for(unsigned short j=cboxstart;j<cboxend;j++) {
						a2=abox[j];
						if(a1->blockid != a2->blockid && ((box_id != cbox_id) || (a1->number < a2->number))){
							//cout << "compare " << a1->a->cindex << " " << a2->a->cindex << endl;
							dx=a2->x-a1x;
							dy=a2->y-a1y;
							dz=a2->z-a1z;
							d2=dx*dx+dy*dy+dz*dz;
							/* Do these two atoms overlap? 
							 * it is possible that one atom buries the other atom */
							double maxcontactd2 = (a1->a->radius + a2->a->radius)*(a1->a->radius + a2->a->radius);
							double max_contactd2_withprobe=(a1->a->radius + a2->a->radius + 2*probe_radius)*(a1->a->radius + a2->a->radius + 2*probe_radius);
							if (d2 > 0 && d2<max_contactd2_withprobe) {
								/* determine distance and orientation */
								d=sqrt(d2);
								dx/=d; dy/=d; dz/=d;
								//*out << "d " << d << " " << dx << " " << dy << " " << dz << " "; out->flush();
								theta=acos(dz);
								int theta_index = (int)(theta/PI*100.0);
								if(theta_index == 100) theta_index = 99;
								if(dx == 0 && dy == 0)	phi = 0;
								else	phi=atan2(dx,dy);
								if (phi<0.0) phi+=2.0*PI;
								int phi_index = (int)(phi/PI*100.0);
								if(phi_index == 200) phi_index = 199;
								//*out << theta << " " << theta_index << " " << phi_index << endl; out->flush();
								
								int k1=closest_point[theta_index][phi_index];
								
								/* Now get the cooridnates for the vector of a2 */
								phi+=PI;
								if (phi>=2.0*PI)	phi-=2.0*PI;
								theta=PI-theta;
									
								int k2=closest_point[(int)(theta/PI*100.0)][(int)(phi/PI*100.0)];
									
								a2r=a2->a->radius;
								a2r2=a2->radius2;
								if(d2<maxcontactd2){
									cos_alpha = (a1r2+d2-a2r2)/(2.0*a1r*d);
									if(cos_alpha > 1.0) cos_alpha = 1.0;
									if(cos_alpha < -1.0) cos_alpha = -1.0;
									int m=(int)(SCALE*1.4142136*sqrt(1.0-cos_alpha));
									//*out << k1 << " " << m << "\t"; out->flush();
									
									for(int mi=0; mi < 8; mi++)
										a1->mask[mi]=a1->mask[mi]&(point[k1].mask[m][mi]);
									delta_vdwsapair += 2*PI*a1r2*(1-cos_alpha);
									
									//if(a1->a->index == 1082 || a2->a->index == 1082)
									//	cout << "overlap " << a1->a->index << " " << a2->a->index << "\t" << a1->number << " " << a2->number << " " 
									//		<< num_atoms << "\t" << k1 << " " << k2 << "\t" << m << "\t";
									
									cos_alpha = (a2r2+d2-a1r2)/(2.0*a2r*d);
									if(cos_alpha > 1.0) cos_alpha = 1.0;
									if(cos_alpha < -1.0) cos_alpha = -1.0;
		              				m=(int)(SCALE*1.4142136*sqrt(1.0-cos_alpha));
		              				//*out << k2 << " " << m << " " << "\t"; out->flush();
		  							
		  							//if(a1->a->index == 1082 || a2->a->index == 1082)
		  							//	cout << m << endl;
		  							
		  							for(int mi=0; mi < 8; mi++)
		  								a2->mask[mi]=a2->mask[mi]&(point[k2].mask[m][mi]);
		  							delta_vdwsapair += 2*PI*a2r2*(1-cos_alpha);	 							
		 							//*out << "done" << endl; out->flush();
		 							
		 							if(d2 < ATOM_CLASH_CUTOFF_SQUARED && (num_atoms_protein1 - a1->number)*(a2->number - num_atoms_protein1 + 1) > 0){
		 							 if(a1->a->isbbatom && a2->a->isbbatom && BBATOM_CLASH_CUTOFF_SQUARED)	num_bbclashes++;
		 							 if(a1->a->radius>0.3 && a2->a->radius>0.3) num_clashes++;
		 							}
		 							if(d2 < 4*a1->a->radius*a2->a->radius && (num_atoms_protein1 - a1->number)*(a2->number - num_atoms_protein1 + 1) > 0){
		 								double ratio = sqrt(d2/(4*a1->a->radius*a2->a->radius));
		 								atom_vdw_repulsion[((unsigned short) (ratio*NUM_ATOM_VDWREPULSION_DIVISIONS))]++;
		 							}
								}
							
								if(include_probe || computesevol){
									a2pr=a2->a->radius + probe_radius;
									a2pr2=(a2->a->radius + probe_radius)*(a2->a->radius + probe_radius);
									
									cos_alpha = (a1pr2+d2-a2pr2)/(2.0*a1pr*d);
									if(cos_alpha > 1.0) cos_alpha = 1.0;
									if(cos_alpha < -1.0) cos_alpha = -1.0;
									int m=(int)(SCALE*1.4142136*sqrt(1.0-cos_alpha));
									//*out << k << " " << m << "\t"; out->flush();
									
									for(int mi=0; mi < 8; mi++)
										a1->pmask[mi]=a1->pmask[mi]&(point[k1].mask[m][mi]);
									
									cos_alpha = (a2pr2+d2-a1pr2)/(2.0*a2pr*d);
									if(cos_alpha > 1.0) cos_alpha = 1.0;
									if(cos_alpha < -1.0) cos_alpha = -1.0;
		              				m=(int)(SCALE*1.4142136*sqrt(1.0-cos_alpha));
		              				//*out << k << " " << m << " " << "\t"; out->flush();
		  							
		  							for(int mi=0; mi < 8; mi++)
		  								a2->pmask[mi]=a2->pmask[mi]&(point[k2].mask[m][mi]);	 							
		 							//*out << "done" << endl; out->flush();
								}
								
								if(computevolumeoverlap && d2<maxcontactd2){
									a2r=a2->a->radius;
									a2r2=a2->radius2;
									short minv = (sqrt(d2)-a2r)*(DISTANCE_DIVISIONS_FOR_VOLUME+1)/a1->a->radius;
									//*out << a1->a->index << ":" << a2->a->index << " " << d2 << " " << a2r << " minv " << minv << "\t";  
									for(short v = DISTANCE_DIVISIONS_FOR_VOLUME;v>minv && v>0 ;v--){
										a1r=a1->a->radius*v/(DISTANCE_DIVISIONS_FOR_VOLUME+1);
										a1r2=a1r*a1r;
										//float d2 = (a1r + a2->a->radius)*(a1r + a2->a->radius);
										
										cos_alpha = (a1r2+d2-a2r2)/(2.0*a1r*d);
										if(cos_alpha > 1.0) cos_alpha = 1.0;
										if(cos_alpha < -1.0) cos_alpha = -1.0;
										int m=(int)(SCALE*1.4142136*sqrt(1.0-cos_alpha));
										
										for(int mi=0; mi < 8; mi++)
											a1->vmask[v-1][mi]=a1->vmask[v-1][mi]&(point[k1].mask[m][mi]);
									}
									
									a1r=a1->a->radius;
									a1r2=a1->radius2;
									minv = (sqrt(d2)-a1r)*(DISTANCE_DIVISIONS_FOR_VOLUME+1)/a2->a->radius;
									//*out << d2 << ":" << a1r << ":" << minv << endl;
									for(short v = DISTANCE_DIVISIONS_FOR_VOLUME;v>minv && v>0 ;v--){
										a2r=a2->a->radius*v/(DISTANCE_DIVISIONS_FOR_VOLUME+1);
										a2r2=a2r*a2r;
										//float d2 = (a2r + a1->a->radius)*(a2r + a1->a->radius);
										
										cos_alpha = (a2r2+d2-a1r2)/(2.0*a2r*d);
										if(cos_alpha > 1.0) cos_alpha = 1.0;
										if(cos_alpha < -1.0) cos_alpha = -1.0;
		              					int m=(int)(SCALE*1.4142136*sqrt(1.0-cos_alpha));
		              				
		  								for(int mi=0; mi < 8; mi++)
		  									a2->vmask[v-1][mi]=a2->vmask[v-1][mi]&(point[k2].mask[m][mi]);	 							
									}
								}
								
								if(computesevol){
									a2pr=a2->a->radius + probe_radius;
									a2pr2=a2pr*a2pr;
									
									short minv = (sqrt(d2)-a2pr)*(DISTANCE_DIVISIONS_FOR_VOLUME+1)/(a1->a->radius+probe_radius);
									for(short v = DISTANCE_DIVISIONS_FOR_VOLUME;v>minv && v>0 ;v--){
										a1r=(a1->a->radius+probe_radius)*v/(DISTANCE_DIVISIONS_FOR_VOLUME+1);
										a1r2=a1r*a1r;
										
										cos_alpha = (a1r2+d2-a2pr2)/(2.0*a1r*d);
										if(cos_alpha > 1.0) cos_alpha = 1.0;
										if(cos_alpha < -1.0) cos_alpha = -1.0;
										int m=(int)(SCALE*1.4142136*sqrt(1.0-cos_alpha));
										
										for(int mi=0; mi < 8; mi++)
											a1->sevmask[v-1][mi]=a1->sevmask[v-1][mi]&(point[k1].mask[m][mi]);
									}
									
									a1pr=a1->a->radius + probe_radius;
									a1pr2=a1pr * a1pr;
									minv = (sqrt(d2)-a1pr)*(DISTANCE_DIVISIONS_FOR_VOLUME+1)/(a2->a->radius+probe_radius);
									//*out << d2 << ":" << a1r << ":" << minv << endl;
									for(short v = DISTANCE_DIVISIONS_FOR_VOLUME;v>minv && v>0 ;v--){
										a2r=(a2->a->radius+probe_radius)*v/(DISTANCE_DIVISIONS_FOR_VOLUME+1);
										a2r2=a2r*a2r;
										
										cos_alpha = (a2r2+d2-a1pr2)/(2.0*a2r*d);
										if(cos_alpha > 1.0) cos_alpha = 1.0;
										if(cos_alpha < -1.0) cos_alpha = -1.0;
		              					int m=(int)(SCALE*1.4142136*sqrt(1.0-cos_alpha));
		              				
		  								for(int mi=0; mi < 8; mi++)
		  									a2->sevmask[v-1][mi]=a2->sevmask[v-1][mi]&(point[k2].mask[m][mi]);	 							
									}
								}
							}
						}
					}
				}
			}
		}
	}
	//*out << "summing up" << endl; out->flush();	
	/* Now sum up invididual atomic surface areas */
	for(int i=0;i<num_atoms;i++) {
		atm[i].sasa = atm[i].vdwsa = 0.0;
		if (atm[i].a->radius>0.0) {
			/* Count total number of exposed surface points */
			unsigned short num_points=0, num_points_with_probe=0;
			for(int m = 0; m < 8; m++){
				num_points += (sasacount[atm[i].mask[m]&0x000000ff]+sasacount[atm[i].mask[m]>>8&0x000000ff]+
								sasacount[atm[i].mask[m]>>16&0x000000ff]+sasacount[atm[i].mask[m]>>24&0x000000ff]);
				if(include_probe || computesevol)
					num_points_with_probe += (sasacount[atm[i].pmask[m]&0x000000ff]+sasacount[atm[i].pmask[m]>>8&0x000000ff]+
								sasacount[atm[i].pmask[m]>>16&0x000000ff]+sasacount[atm[i].pmask[m]>>24&0x000000ff]);
			}
			//*out << num_points << " " << atom_points << " " << MAXPOINTS << endl;
			if(num_points_with_probe == 0)
      			for(int m = 0; m < 8; m++)	atm[i].pmask[m]=0x00000000;
      		
      		atm[i].vdwsa=4.0*PI*atm[i].radius2*(double)num_points/(double)atom_points;
      		if(include_probe || computesevol){
      			//atm[i].sasa=4.0*PI*atm[i].radius2*(double)num_points_with_probe/(double)atom_points;
      			atm[i].sasa=4.0*PI*(atm[i].a->radius+probe_radius)*(atm[i].a->radius+probe_radius)*(double)num_points_with_probe/(double)atom_points;
      			//cout << atm[i].a->name << " " << atm[i].a->radius << " SASA " << atm[i].sasa << endl;
      		}
      		
      		if(computevolumeoverlap){
				double dr = atm[i].a->radius/(DISTANCE_DIVISIONS_FOR_VOLUME+1);
      			atm[i].overlapvolume = atm[i].vdwsa * dr;
				for(int v=DISTANCE_DIVISIONS_FOR_VOLUME-1;v>=0;v--){
					unsigned short num_points=0;
					for(int m = 0; m < 8; m++){
						num_points += (sasacount[atm[i].vmask[v][m]&0x000000ff]+sasacount[atm[i].vmask[v][m]>>8&0x000000ff]+
								sasacount[atm[i].vmask[v][m]>>16&0x000000ff]+sasacount[atm[i].vmask[v][m]>>24&0x000000ff]);
					}
					float radius = atm[i].a->radius*(v+1)/(DISTANCE_DIVISIONS_FOR_VOLUME+1);
					atm[i].overlapvolume += 4.0*PI*radius*radius*dr*(double)num_points/(double)atom_points;
				
				}
      		}
      		
      		if(computesevol){
      			double dr = atm[i].a->radius/(DISTANCE_DIVISIONS_FOR_VOLUME+1);
      			atm[i].seoverlapvol = atm[i].sasa * dr;
				for(int v=DISTANCE_DIVISIONS_FOR_VOLUME-1;v>=0;v--){
					unsigned short num_points=0;
					for(int m = 0; m < 8; m++){
						num_points += (sasacount[atm[i].sevmask[v][m]&0x000000ff]+sasacount[atm[i].sevmask[v][m]>>8&0x000000ff]+
								sasacount[atm[i].sevmask[v][m]>>16&0x000000ff]+sasacount[atm[i].sevmask[v][m]>>24&0x000000ff]);
					}
					float radius = atm[i].a->radius*(v+1)/(DISTANCE_DIVISIONS_FOR_VOLUME+1);
					atm[i].seoverlapvol += 4.0*PI*radius*radius*dr*(double)num_points/(double)atom_points;
				
				}
      		}	
		}
	}		
}

//void compute(unsigned short num_atoms){
//	bool include_probe = false;
//	compute(num_atoms,include_probe);
//}

void compute_sasa(Complex *cr, Complex *cl){
	for(int i = 0 ; i < cr->num_atoms+cl->num_atoms; i++){
		Atom *a;
		if(i < cr->num_atoms)
			a = cr->atom[i];
		else
			a = cl->atom[i-cr->num_atoms];
		atm[i].a = a;
		atm[i].x = a->position->x;
		atm[i].y = a->position->y;
		atm[i].z = a->position->z;
		atm[i].blockid = a->cindex;
		
		for(int m = 0; m < 8; m++)
			atm[i].a->mask[m]=0xffffffff;
	}
	compute(cr->num_atoms+cl->num_atoms, false,false,false);
	for(int i = 0 ; i < cr->num_atoms+cl->num_atoms; i++){
		atm[i].a->vdwsa = atm[i].vdwsa;
		atm[i].a->sasa = atm[i].sasa;
	}
		
	float sa = 0.0;
	for(hash_map<char, Molecule*, hash<char>, eqint>::iterator mitr = cr->molecules.begin(); mitr != cr->molecules.end(); mitr++){
		Molecule *m = mitr->second;
		switch(m->type){
			case PROTEIN:
				Protein *p = (Protein*) m;
				for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = p->aminoacid.begin(); aaitr != p->aminoacid.end(); aaitr++){
					Aminoacid *aa = aaitr->second;
					aa->sa = 0;
					for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = aa->atom.begin(); aitr != aa->atom.end(); aitr++){
						Atom* a = aitr->second;
						aa->sa += a->sasa;
						sa += a->sasa;
					}
				}
			break;
		}
	}
	for(hash_map<char, Molecule*, hash<char>, eqint>::iterator mitr = cl->molecules.begin(); mitr != cl->molecules.end(); mitr++){
		Molecule *m = mitr->second;
		m->sa = 0;
		switch(m->type){
			case PROTEIN:
				Protein *p = (Protein*) m;
				for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = p->aminoacid.begin(); aaitr != p->aminoacid.end(); aaitr++){
					Aminoacid *aa = aaitr->second;
					aa->sa = 0;
					for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = aa->atom.begin(); aitr != aa->atom.end(); aitr++){
						Atom* a = aitr->second;
						aa->sa += a->sasa;
						m->sa += a->sasa;
						sa += a->sasa;
					}
				}
			break;
		}
	}
	*out << "SASA is " << sa << " A^2." << endl;	
}

void compute_fragment_sasa(Complex *c, unsigned short start, unsigned short end){
	unsigned short i = 0;
	// computing relative solvent accessibility
	// using the fact that no atom is in two aminoacids
	{
		for(unsigned int j = start; j < c->num_aminoacids && j < end; j++){
			Aminoacid *aa = c->aminoacid[j];
			aa->rsa = 0;
			if(aa->atom.size() > 0){
				short count=0;
				for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = aa->atom.begin(); aitr != aa->atom.end(); aitr++){
					Atom *a = (Atom*) aitr->second;
					atm[count].a = a;
					atm[count].x = a->position->x;
					atm[count].y = a->position->y;
					atm[count].z = a->position->z;
					atm[count].blockid = a->cindex;
					for(int m = 0; m < 8; m++){
						a->mask[m] = a->pmask[m] = 0xffffffff;
					}
					//*out << a->index << " " << a->radius << endl;
					count++;
				}
				
				compute(count,true,false,false);
				for(int i = 0; i < count; i++){
					//if(!(((atm[i].a)->name == "N") || ((atm[i].a)->name == "O") || ((atm[i].a)->name == "CA") || ((atm[i].a)->name != "C")))
						aa->rsa += atm[i].sasa;
				}
				*out << aa->index << " " << count << " " << aa->rsa << endl; out->flush();
			}
		}
	}
	
	for(unsigned short j = 0 ; j < c->num_atoms; j++){
		Atom *a = c->atom[j];
		if(a->monocindex >= start && a->monocindex < end){ 
			atm[i].a = a;
			atm[i].x = a->position->x;
			atm[i].y = a->position->y;
			atm[i].z = a->position->z;
			atm[i].blockid = a->cindex;
		
			for(int m = 0; m < 8; m++)
				a->pmask[m]=a->mask[m]=0xffffffff;
				
			i = i+1;
		}
	}
	unsigned short num_sasa_atoms = i;
	
	compute(num_sasa_atoms, true, false, false);
	
	for(int i = 0 ; i < num_sasa_atoms; i++){
		atm[i].a->vdwsa = atm[i].vdwsa;
		atm[i].a->sasa = atm[i].sasa;
	}
	
	float sa = 0;
	for(unsigned int j = start; j < c->num_aminoacids && j < end; j++){
		Aminoacid *aa = c->aminoacid[j];
		aa->sa = 0;
		for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = aa->atom.begin(); aitr != aa->atom.end(); aitr++){
			Atom* a = aitr->second;
			aa->sa += a->sasa;
			sa += a->sasa;
		}
		aa->rsa = aa->sa / aa->rsa;
	}
	*out << "fragment SASA is " << sa << " A^2." << endl;
}

void Complex::compute_volume_sasa(bool computevolumeoverlap, bool computesevol){
	// computing relative solvent accessibility
	// using the fact that no atom is in two aminoacids
	{
		for(int j = 0; j < num_monomers; j++){
			Monomer *mr = monomer[j];
			mr->rsa = 0;
			if(mr->atom.size() > 0){
				short count=0;
				for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = mr->atom.begin(); aitr != mr->atom.end(); aitr++){
					Atom *a = (Atom*) aitr->second;
					atm[count].a = a;
					atm[count].x = a->position->x;
					atm[count].y = a->position->y;
					atm[count].z = a->position->z;
					atm[count].blockid = a->cindex;
					for(int m = 0; m < 8; m++){
						a->mask[m] = a->pmask[m] = 0xffffffff;
					}
					//*out << a->index << " " << a->radius << endl;
					count++;
				}
				
				compute(count,true,false,false);
				for(int i = 0; i < count; i++){
					//if(!(((atm[i].a)->name == "N") || ((atm[i].a)->name == "O") || ((atm[i].a)->name == "CA") || ((atm[i].a)->name != "C")))
						mr->rsa += atm[i].sasa;
				}
				*out << mr->index << " " << count << " " << mr->rsa << endl; out->flush();
			}
		}
	}
	
	for(int i = 0 ; i < num_atoms; i++){
		Atom *a = atom[i];
		atm[i].a = a;
		atm[i].x = a->position->x;
		atm[i].y = a->position->y;
		atm[i].z = a->position->z;
		atm[i].blockid = a->cindex;
		
		for(int m = 0; m < 8; m++){
			a->pmask[m]=a->mask[m]=0xffffffff;
			if(computevolumeoverlap)
				for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	a->vmask[v][m]=0xffffffff;
			if(computesevol)
				for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	a->sevmask[v][m]=0xffffffff;
			
			if(a->is_buried){
				// setting the atom as buried in the vdw sense was used in the submitted paper
				a->mask[m]=0x00000000;	
				//a->pmask[m]=0x00000000;
				if(computevolumeoverlap)
					for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	a->vmask[v][m]=0x00000000;
				if(computesevol)
					for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	a->sevmask[v][m]=0x00000000;
			}
		}
	}
	
	compute(num_atoms,true,computevolumeoverlap,computesevol);
	
	for(int i = 0 ; i < num_atoms; i++){
		atm[i].a->vdwsa = atm[i].vdwsa;
		atm[i].a->sasa = atm[i].sasa;
		if(computevolumeoverlap){
			atm[i].a->overlapvolume = atm[i].overlapvolume;
			atm[i].a->volume = (4.0/3.0)*PI*(atm[i].a->radius)*(atm[i].a->radius)*(atm[i].a->radius) - atm[i].overlapvolume;
		}
		for(int m = 0; m < 8; m++){
			atm[i].a->mask[m]=atm[i].mask[m];
			atm[i].a->pmask[m]=atm[i].pmask[m];
			if(computevolumeoverlap){
				for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	atm[i].a->vmask[v][m]=atm[i].vmask[v][m];
			}
			if(computesevol)
				for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	atm[i].a->sevmask[v][m]=atm[i].sevmask[v][m];
		}
		//if(!(atm[i].a->is_buried) && atm[i].sa == 0)
		//	for(int m = 0; m < 8; m++)	*out << "\t" << atm[i].a->mask[m] << endl;
	}
	
	sa=0.0;
	for(hash_map<char, Molecule*, hash<char>, eqint>::iterator mitr = molecules.begin(); mitr != molecules.end(); mitr++){
		Molecule *m = mitr->second;
		m->sa = 0;
		switch(m->type){
			case PROTEIN:
				Protein *p = (Protein*) m;
				for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = p->aminoacid.begin(); aaitr != p->aminoacid.end(); aaitr++){
					Aminoacid *aa = aaitr->second;
					aa->sa = 0;
					float side_chain_sa = 0;
					for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = aa->atom.begin(); aitr != aa->atom.end(); aitr++){
						Atom* a = aitr->second;
						aa->sa += a->sasa;
						m->sa += a->sasa;
						sa += a->sasa;
						if(!((a->name == "N") || (a->name == "O") || (a->name == "CA") || (a->name != "C")))
							side_chain_sa += a->sasa;
					}
					if(aa->type < 0){
						*out << "sasa " << aa->name << " " << aa->index << " " << aa->sa << endl;
					}
					if(aa->rsa > 0){
						aa->rsa = aa->sa / aa->rsa;
						//aa->rsa = side_chain_sa / (aa->rsa);
					}
					if(aa->rsa > 1.0){
						*out << "WARNING: sasa rsa>1 " << aa->index << " sa " << aa->sa << " rsa " << aa->rsa << endl;
						for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = aa->atom.begin(); aitr != aa->atom.end(); aitr++){
							Atom *a = (Atom*) aitr->second;
							*out << a->index << " " << a->sasa/(4*PI*a->radius*a->radius) << endl;
						}
					}
					//*out << "RSA " << pdbcode << "|" << chains << "|" << " " << aa->type << " " << aa->rsa << " " << aa->name << " " << aa->index << endl;
				}
			break;
			case NA : case DNA : case RNA:
				NucleicAcid *n = (NucleicAcid*) m;
				for(hash_map<const char*, Nucleotide*, hash<const char*>,eqstr>::iterator nitr = n->nucleotide.begin(); nitr != n->nucleotide.end(); nitr++){
					Nucleotide *nt = nitr->second;
					nt->sa = 0;
					float side_chain_sa = 0;
					for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = nt->atom.begin(); aitr != nt->atom.end(); aitr++){
						Atom* a = aitr->second;
						nt->sa += a->sasa;
						m->sa += a->sasa;
						sa += a->sasa;
						if(!((a->name == "N") || (a->name == "O") || (a->name == "CA") || (a->name != "C")))
							side_chain_sa += a->sasa;
					}
					if(nt->type < 0){
						*out << "sasa " << nt->name << " " << nt->index << " " << nt->sa << endl;
					}
					if(nt->rsa > 0){
						nt->rsa = nt->sa / nt->rsa;
					}
					if(nt->rsa > 1.0){
						*out << "WARNING: sasa rsa>1 " << nt->index << " sa " << nt->sa << " rsa " << nt->rsa << endl;
						for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = nt->atom.begin(); aitr != nt->atom.end(); aitr++){
							Atom *a = (Atom*) aitr->second;
							*out << a->index << " " << a->sasa/(4*PI*a->radius*a->radius) << endl;
						}
					} 
				}
			break;
		}
	}
	//cout << "SASA is " << sa << " A^2." << endl;
}

bool *is_receptor_atom_in_contact = NULL;

/*
 * Works by sampling points on each atom that will get buried at the interface
 * Points that are already buried in receptor and ligand separately are included in the masks and are taken
 * as buried in compute()
 * 
 */
void compute_deltavolsa_approx1(Object *receptor, Object *ligand, Vector *transformed_position, unsigned int *ligand_atoms_in_contact, unsigned int array_size, 
  GridCell **rcell, Transformation *tr, ProtProtDetailedScoringMetrics *details){
  	vector<int> receptor_atom_in_contact;
  	
  	if(is_receptor_atom_in_contact == NULL){
  		is_receptor_atom_in_contact = (bool *) malloc(sizeof(bool) * receptor->c->num_atoms);
		for(int i = 0; i < receptor->c->num_atoms; i++)
			is_receptor_atom_in_contact[i] = false;
  	}
				
	unsigned short num_ligand_atoms_in_contact=0;
	//*out << "check " << num_ligand_atoms_in_contact << endl; out->flush();
	for(unsigned int ai = 0; ai < array_size; ai++){
		unsigned int li = ligand_atoms_in_contact[ai];
		Atom * al = ligand->c->atom[li];
		//if(al->sa > 0){
			GridCell *cell = rcell[li];
			
			//*out << ai << " " << li << " " << cell << endl; out->flush();
			if(cell->atom_overlap_neighbors != NULL) {
				unsigned short* atom_neighbors = cell->atom_overlap_neighbors;
				for(int ani = 0; ani < cell->num_atom_overlap_neighbors; ani++){
					int racindex = atom_neighbors[ani];
					if(!is_receptor_atom_in_contact[racindex]){
						is_receptor_atom_in_contact[racindex] = true;
						receptor_atom_in_contact.push_back(racindex);
					}
				}
			}
			/*if(cell->atom_contact_neighbors != NULL) {
				unsigned short* atom_neighbors = cell->atom_contact_neighbors;
				for(int ani = 0; ani < cell->num_atom_contact_neighbors; ani++){
					int racindex = atom_neighbors[ani];
					if(!is_receptor_atom_in_contact[racindex]){
						is_receptor_atom_in_contact[racindex] = true;
						receptor_atom_in_contact.push_back(racindex);
					}
				}
			}*/
			
			unsigned short i = num_ligand_atoms_in_contact;
			atm[i].a = al;
			Vector v = transformed_position[al->cindex];
			atm[i].x = v.x;
			atm[i].y = v.y;
			atm[i].z = v.z;
			atm[i].blockid = 0;
			
			//*out << i << "-" << atm[i].a << "-" << atm[i].a->aacindex << " ";
			num_ligand_atoms_in_contact++;
		//}
	}
	//*out << endl;

	unsigned short num_receptor_atoms_in_contact = 0;
	for(vector<int>::iterator itr = receptor_atom_in_contact.begin(); itr != receptor_atom_in_contact.end(); itr++){
		int j = (int) *itr;		
	//for(int j = 0; j < receptor->c->num_atoms; j++){
		//if(is_receptor_atom_in_contact[j]){
		//if(receptor->c->atom[j]->sa > 0){
			Atom *a = receptor->c->atom[j];
			unsigned short i = num_receptor_atoms_in_contact + num_ligand_atoms_in_contact;
			atm[i].a = a;
			atm[i].x = a->position->x;
			atm[i].y = a->position->y;
			atm[i].z = a->position->z;
			atm[i].blockid = 1;
			//*out << i << " " << atm[i].a->index << " " << atm[i].a->name << " " << atm[i].a->aacindex << " " << atm[i].a->aaindex << endl; out->flush();
			//*out << i << "-" << atm[i].a << "-" << atm[i].a->aacindex << " ";
			num_receptor_atoms_in_contact++;
		//}
		is_receptor_atom_in_contact[j] = false;
	}
	//cout << endl;
	
	unsigned short num_atoms = num_ligand_atoms_in_contact + num_receptor_atoms_in_contact;
	//cout << num_ligand_atoms_in_contact << " num rec contact " << num_receptor_atoms_in_contact << " " << receptor_atom_in_contact.size() << endl; out->flush();
	/*for(int i = 0 ; i < num_atoms; i++)
		*out << i << " " << atm[i].a->aacindex << endl; out->flush();*/
	
	if(num_atoms > 0){
		num_atoms_protein1 = num_ligand_atoms_in_contact;
		num_clashes = num_bbclashes = 0;
		for(unsigned short i=0; i < NUM_ATOM_VDWREPULSION_DIVISIONS; i++)	atom_vdw_repulsion[i]=0;
		*out << tr->frame_number << " " << num_atoms << " " << num_ligand_atoms_in_contact << " ";
		//compute(num_atoms,true,true,true);
		compute(num_atoms,true,false,false);
		tr->delta_vdwsapair = delta_vdwsapair;
		for(unsigned short i=0; i < NUM_ATOM_VDWREPULSION_DIVISIONS; i++)	details->atom_vdw_repulsion[i]=atom_vdw_repulsion[i];
	}
	
	for(int i = 0 ; i < NUM_RESIDUE_TYPES; i++)	details->delta_sasa[i] = details->delta_vdwsa[i] = 0;//details->delta_vol[i] = details->delta_sevol[i] = 0;
	for(int i = 0 ; i < NUM_ATOM_TYPES; i++)	details->delta_sasa_atom[i] = details->delta_vdwsa_atom[i] = 0;//details->delta_vol_atom[i] = details->delta_sevol_atom[i] = 0;
	
	for(int i = 0 ; i < num_atoms; i++){
		//*out << "vdwsaa " << atm[i].a->vdwsa << ":" << atm[i].a->sasa << " " << atm[i].a->overlapvolume << "|" << atm[i].a->seoverlapvol << endl;
		//*out << "vdwsa " << atm[i].vdwsa << ":" << atm[i].sasa << " " << atm[i].overlapvolume << "|" << atm[i].seoverlapvol << endl;
		
		atm[i].a->vdwsa_complex = atm[i].vdwsa;
		atm[i].a->sasa_complex = atm[i].sasa;
		atm[i].vdwsa = atm[i].a->vdwsa - atm[i].vdwsa;
		atm[i].sasa = atm[i].a->sasa - atm[i].sasa;
		atm[i].overlapvolume = atm[i].a->overlapvolume - atm[i].overlapvolume;
		atm[i].seoverlapvol = atm[i].a->seoverlapvol - atm[i].seoverlapvol;
		if(atm[i].vdwsa < 0 || atm[i].sasa < 0 ){ //|| atm[i].overlapvolume < 0 || atm[i].seoverlapvol < 0){
			*out << "ERROR: sasa " << atm[i].a->vdwsa << ":" << atm[i].a->sasa << " " << atm[i].a->overlapvolume << " " << atm[i].a->seoverlapvol << " " << atm[i].a->is_buried << " " 
				<< atm[i].vdwsa << ":" << atm[i].sasa << ":" << atm[i].overlapvolume << ":" << atm[i].seoverlapvol << " tr " << tr->frame_number << endl;
			if(atm[i].vdwsa < 0)	atm[i].vdwsa = 0;
			if(atm[i].sasa < 0)	atm[i].sasa = 0;
			if(atm[i].overlapvolume < 0)	atm[i].overlapvolume = 0;
			if(atm[i].seoverlapvol < 0)	atm[i].seoverlapvol = 0;
		}
		
		//*out << "vdwsaf " << atm[i].vdwsa << ":" << atm[i].sasa << " " << endl;
		//*out << "vdwsa " << atm[i].a->index << " " << atm[i].vdwsa << endl; out->flush();
			
		int residue_type;
		if(i < num_ligand_atoms_in_contact){
			residue_type = ligand->c->aminoacid[atm[i].a->monocindex]->type;
		} else {
			//*out << i << " " << atm[i].a->index << " " << atm[i].a->name << " " << atm[i].a->aacindex << " " << atm[i].a->aaindex << endl; out->flush();
			residue_type = receptor->c->aminoacid[atm[i].a->monocindex]->type;
		}
		if(residue_type >= 0){
			details->delta_vdwsa[residue_type] += atm[i].vdwsa;
			details->delta_sasa[residue_type] += atm[i].sasa;
			//details->delta_vol[residue_type] += atm[i].overlapvolume;
			//details->delta_sevol[residue_type] += atm[i].seoverlapvol;
		}
		if(atm[i].a->atom_type >= 0){
			details->delta_sasa_atom[atm[i].a->atom_type] += atm[i].sasa;
			details->delta_vdwsa_atom[atm[i].a->atom_type] += atm[i].vdwsa;
			//details->delta_vol_atom[atm[i].a->atom_type] += atm[i].overlapvolume;
			//details->delta_sevol_atom[atm[i].a->atom_type] += atm[i].seoverlapvol;
		}
	}
}

/*
 * Rotating masks on the ligand is quite expensive so recomputing masks for the relevant portion of the receptor
 */
void Object::compute_deltavolsa_approx2(Object *receptor, Object *ligand, Vector *transformed_position, unsigned int *ligand_atoms_in_contact, unsigned int array_size, 
  GridCell **rcell, Transformation *tr, ProtProtDetailedScoringMetrics *details){
	bool ligand_atom_in_contact[ligand->c->num_atoms];
	for(int i = 0; i < ligand->c->num_atoms; i++)
		ligand_atom_in_contact[i] = false;
				
	for(unsigned int ai = 0; ai < array_size; ai++){
		unsigned int li = ligand_atoms_in_contact[ai];
		Atom * al = ligand->c->atom[li];
		ligand_atom_in_contact[li] = true;
		// find second shell atoms for this atom
		for(vector<Atom*>::iterator anitr = al->neighbors.begin(); anitr != al->neighbors.end(); anitr++){
			ligand_atom_in_contact[((Atom*) *anitr)->cindex] = true;
		}
	}
	
	bool computevolumeoverlap=false, computesevol=false;
	// compute the burials for atoms in the first shell of ligand
	unsigned short count=0;
	for(int i = 0; i < ligand->c->num_atoms; i++)
		if(ligand_atom_in_contact[i] && (ligand->c->atom[i]->name).c_str()[0] != 'H'){
			Atom *a = ligand->c->atom[i];
			atm[count].a = a;
			Vector v = transformed_position[i];
			atm[count].x = v.x;
			atm[count].y = v.y;
			atm[count].z = v.z;
			atm[count].blockid = a->cindex;
			
			for(int m = 0; m < 8; m++){
				a->pmask[m]=a->mask[m]=0xffffffff;
				if(computevolumeoverlap)
					for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	a->vmask[v][m]=0xffffffff;
				if(computesevol)
					for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	a->sevmask[v][m]=0xffffffff;
				
				if(a->is_buried){
					a->mask[m]=0x00000000;	
					//a->pmask[m]=0x00000000;
					if(computevolumeoverlap)
						for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	a->vmask[v][m]=0x00000000;
					if(computesevol)
						for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	a->sevmask[v][m]=0x00000000;
				}
			}
			count=count+1;
		}
	if(count>0){
		//*out << tr->frame_number << " ligandmasks " << count << " " << array_size << endl;
		compute(count,true,computevolumeoverlap,computesevol);
		for(int i = 0 ; i < count; i++){
			atm[i].a->vdwsa = atm[i].vdwsa;
			atm[i].a->sasa = atm[i].sasa;
			if(computevolumeoverlap){
				atm[i].a->overlapvolume = atm[i].overlapvolume;
				atm[i].a->volume = (4.0/3.0)*PI*(atm[i].a->radius)*(atm[i].a->radius)*(atm[i].a->radius) - atm[i].overlapvolume;
			}
			for(int m = 0; m < 8; m++){
				atm[i].a->mask[m]=atm[i].mask[m];
				atm[i].a->pmask[m]=atm[i].pmask[m];
				if(computevolumeoverlap){
					for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	atm[i].a->vmask[v][m]=atm[i].vmask[v][m];
				}
				if(computesevol)
					for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	atm[i].a->sevmask[v][m]=atm[i].sevmask[v][m];
			}
		}
	}
	
	// compute areas as earlier
	compute_deltavolsa_approx1(receptor, ligand, transformed_position, ligand_atoms_in_contact, array_size, rcell, tr, details); 
}

/*
 * Collect change in sasa per residue
 */
void Object::compute_deltasa_byresidue(Object *receptor, Object *ligand, Vector *transformed_position, unsigned int *ligand_atoms_in_contact, unsigned int array_size,
  GridCell **rcell, Transformation *tr, float *delta_sasar, float *delta_sasal, float *delta_vdwsar, float *delta_vdwsal){
  	for(int i = 0; i < receptor->c->num_aminoacids; i++)	delta_sasar[i] = delta_vdwsar[i] = 0;
	for(int i = 0; i < ligand->c->num_aminoacids; i++)	delta_sasal[i] = delta_vdwsal[i] = 0;
	
  	bool ligand_atom_in_contact[ligand->c->num_atoms];
	for(int i = 0; i < ligand->c->num_atoms; i++)
		ligand_atom_in_contact[i] = false;
				
	for(unsigned int ai = 0; ai < array_size; ai++){
		unsigned int li = ligand_atoms_in_contact[ai];
		Atom * al = ligand->c->atom[li];
		ligand_atom_in_contact[li] = true;
		// find second shell atoms for this atom
		for(vector<Atom*>::iterator anitr = al->neighbors.begin(); anitr != al->neighbors.end(); anitr++){
			ligand_atom_in_contact[((Atom*) *anitr)->cindex] = true;
		}
	}
	
	bool computevolumeoverlap=false, computesevol=false;
	// compute the burials for atoms in the first shell of ligand
	unsigned short count=0;
	for(int i = 0; i < ligand->c->num_atoms; i++)
		if(ligand_atom_in_contact[i] && (ligand->c->atom[i]->name).c_str()[0] != 'H'){
			Atom *a = ligand->c->atom[i];
			atm[count].a = a;
			Vector v = transformed_position[i];
			atm[count].x = v.x;
			atm[count].y = v.y;
			atm[count].z = v.z;
			atm[count].blockid = a->cindex;
			
			for(int m = 0; m < 8; m++){
				a->pmask[m]=a->mask[m]=0xffffffff;
				if(computevolumeoverlap)
					for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	a->vmask[v][m]=0xffffffff;
				if(computesevol)
					for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	a->sevmask[v][m]=0xffffffff;
				
				if(a->is_buried){
					a->mask[m]=0x00000000;	
					//a->pmask[m]=0x00000000;
					if(computevolumeoverlap)
						for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	a->vmask[v][m]=0x00000000;
					if(computesevol)
						for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	a->sevmask[v][m]=0x00000000;
				}
			}
			count=count+1;
		}
		
	if(count>0){
		*out << tr->frame_number << " ligandmasks " << count << " " << array_size << endl;
		compute(count,true,computevolumeoverlap,computesevol);
		for(int i = 0 ; i < count; i++){
			atm[i].a->vdwsa = atm[i].vdwsa;
			atm[i].a->sasa = atm[i].sasa;
			if(computevolumeoverlap){
				atm[i].a->overlapvolume = atm[i].overlapvolume;
				atm[i].a->volume = (4.0/3.0)*PI*(atm[i].a->radius)*(atm[i].a->radius)*(atm[i].a->radius) - atm[i].overlapvolume;
			}
			for(int m = 0; m < 8; m++){
				atm[i].a->mask[m]=atm[i].mask[m];
				atm[i].a->pmask[m]=atm[i].pmask[m];
				if(computevolumeoverlap){
					for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	atm[i].a->vmask[v][m]=atm[i].vmask[v][m];
				}
				if(computesevol)
					for(int v=0;v<DISTANCE_DIVISIONS_FOR_VOLUME;v++)	atm[i].a->sevmask[v][m]=atm[i].sevmask[v][m];
			}
		}
	}
	
	vector<int> receptor_atom_in_contact;
  	if(is_receptor_atom_in_contact == NULL){
  		is_receptor_atom_in_contact = (bool *) malloc(sizeof(bool) * receptor->c->num_atoms);
		for(int i = 0; i < receptor->c->num_atoms; i++)
			is_receptor_atom_in_contact[i] = false;
  	}
				
	unsigned short num_ligand_atoms_in_contact=0;
	for(unsigned int ai = 0; ai < array_size; ai++){
		unsigned int li = ligand_atoms_in_contact[ai];
		Atom * al = ligand->c->atom[li];
		GridCell *cell = rcell[li];
		
		if(cell->atom_overlap_neighbors != NULL) {
			unsigned short* atom_neighbors = cell->atom_overlap_neighbors;
			for(int ani = 0; ani < cell->num_atom_overlap_neighbors; ani++){
				int racindex = atom_neighbors[ani];
				if(!is_receptor_atom_in_contact[racindex]){
					is_receptor_atom_in_contact[racindex] = true;
					receptor_atom_in_contact.push_back(racindex);
				}
			}
		}
		
		unsigned short i = num_ligand_atoms_in_contact;
		atm[i].a = al;
		Vector v = transformed_position[al->cindex];
		atm[i].x = v.x;
		atm[i].y = v.y;
		atm[i].z = v.z;
		atm[i].blockid = 0;
		
		num_ligand_atoms_in_contact++;
	}
	
	unsigned short num_receptor_atoms_in_contact = 0;
	for(vector<int>::iterator itr = receptor_atom_in_contact.begin(); itr != receptor_atom_in_contact.end(); itr++){
		int j = (int) *itr;		
		Atom *a = receptor->c->atom[j];
		unsigned short i = num_receptor_atoms_in_contact + num_ligand_atoms_in_contact;
		atm[i].a = a;
		atm[i].x = a->position->x;
		atm[i].y = a->position->y;
		atm[i].z = a->position->z;
		atm[i].blockid = 1;
		//*out << i << " " << atm[i].a->index << " " << atm[i].a->name << " " << atm[i].a->aacindex << " " << atm[i].a->aaindex << endl; out->flush();
		//*out << i << "-" << atm[i].a << "-" << atm[i].a->aacindex << " ";
		num_receptor_atoms_in_contact++;
		is_receptor_atom_in_contact[j] = false;
	}
	
	int num_atoms = num_ligand_atoms_in_contact + num_receptor_atoms_in_contact;
	
	if(num_atoms > 0){
		num_atoms_protein1 = num_ligand_atoms_in_contact;
		num_clashes = num_bbclashes = 0;
		for(unsigned short i=0; i < NUM_ATOM_VDWREPULSION_DIVISIONS; i++)	atom_vdw_repulsion[i]=0;
		*out << tr->frame_number << " " << num_atoms << " " << num_ligand_atoms_in_contact << " ";
		compute(num_atoms,true,false,false);
		//tr->num_bbclashes = num_bbclashes;
		//tr->num_clashes = num_clashes; 
		tr->delta_vdwsapair = delta_vdwsapair;
	}
		
	for(int i = 0 ; i < num_atoms; i++){
		//atm[i].a->vdwsa_complex = atm[i].vdwsa;
		//atm[i].a->sasa_complex = atm[i].sasa;
		atm[i].vdwsa = atm[i].a->vdwsa - atm[i].vdwsa;
		atm[i].sasa = atm[i].a->sasa - atm[i].sasa;
		if(atm[i].vdwsa < 0 || atm[i].sasa < 0){
			*out << "ERROR: vdwsa " << atm[i].a->vdwsa << ":" << atm[i].vdwsa << *out << " " << atm[i].a->sasa << ":" << atm[i].sasa << endl; 
			if(atm[i].sasa < 0)	atm[i].sasa = 0;
			if(atm[i].vdwsa < 0)	atm[i].vdwsa = 0;
		}	
		
		//*out << "vdwsa " << atm[i].a->index << " " << atm[i].vdwsa << endl; out->flush();
		int residue_index;
		if(i < num_ligand_atoms_in_contact){
			residue_index = atm[i].a->monocindex;
			delta_sasal[residue_index] += atm[i].sasa;
			delta_vdwsal[residue_index] += atm[i].vdwsa;
		} else {
			residue_index = atm[i].a->monocindex;
			delta_sasar[residue_index] += atm[i].sasa;
			delta_vdwsar[residue_index] += atm[i].vdwsa;
		}
		tr->eSolvation += atm[i].sasa;
	}
}

