/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "process_complex.hpp"

#define BUFFER_WIDTH 4.0

int main(int argc, char *argv[]){
	out = &cout;	
	read_molecule_config();
	read_dock_config();
	
	pdbcode = argv[1];
	chains = new string(argv[2]);
	const char* chains_c = chains->c_str();
	hash_set<int,hash<int>,eqint> reference_interface_ligand_residues,reference_interface_receptor_residues;
	Complex* cref = new Complex(pdbcode,chains_c, PDB);
	for(int i = 0; i < cref->num_aminoacids; i++){
 		Aminoacid *ra = cref->aminoacid[i];
 		//*out << ra->chain << " " << chains_c[0] << endl;
 		if(ra->chain == chains_c[0] && ra->alpha_carbon != NULL){
 			for(int j = 0; j < cref->num_aminoacids; j++){
		 		Aminoacid *la = cref->aminoacid[j];
		 		if(la->chain == chains_c[1] && la->alpha_carbon != NULL){	
				 	if(Vector::distance(ra->alpha_carbon->position, la->alpha_carbon->position) < SS_CUTOFF){
				 		reference_interface_ligand_residues.insert(la->cindex - cref->mmonostart[chains_c[1]]);
				 		reference_interface_receptor_residues.insert(ra->cindex - cref->mmonostart[chains_c[0]]);
				 	}
		 		}
		 	}
		}
 	}
 	*out << "interface " << reference_interface_receptor_residues.size() << " " << reference_interface_ligand_residues.size() << endl;
 	for(hash_set<int,hash<int>,eqint>::iterator iitr = reference_interface_receptor_residues.begin(); iitr != reference_interface_receptor_residues.end(); iitr++)
 		*out << *iitr << " ";
 	*out << endl;
 	for(hash_set<int,hash<int>,eqint>::iterator iitr = reference_interface_ligand_residues.begin(); iitr != reference_interface_ligand_residues.end(); iitr++)
 		*out << *iitr << " ";
 	*out << endl;
 	
	char buf[2048];
	int ret;
	hash_map<char, hash_map<const char*, Sequence*, hash<const char*>, eqstr>, hash<char>, eqint> blast_hits;
	for(int i = 0; i < chains->length(); i++){
		char chain = chains->c_str()[i];
		
		read_blast_hits(chain,DB_PDBAA,".");
		blast_hits[chain] = *(new hash_map<const char*, Sequence*, hash<const char*>, eqstr>);
		for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr = matching_sequences.begin(); sitr != matching_sequences.end(); sitr++){
			Sequence *s = (Sequence *) sitr->second;
			if(s->seq_alignment->identities <= 90 && s->seq_alignment->positives >= 35)
				blast_hits[chain][(const char*) sitr->first] = s;
		}
		matching_sequences.clear();
	}
	
	int chainindex=0;
	hash_set<const char*, hash<const char*>, eqstr> blast_pdbids[chains->length()];
	for(hash_map<char, hash_map<const char*, Sequence*, hash<const char*>, eqstr>, hash<char>, eqint>::iterator bitr=blast_hits.begin(); bitr!=blast_hits.end();bitr++){
		char chain = bitr->first;
		hash_map<const char*, Sequence*, hash<const char*>, eqstr> matches = bitr->second;
		blast_pdbids[chainindex] = *(new hash_set<const char*, hash<const char*>, eqstr>);
		for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator mitr=matches.begin(); mitr!=matches.end(); mitr++){
			Sequence *s = (Sequence *) mitr->second;
			if(s->id_lowercase.length() == 4){
				blast_pdbids[chainindex].insert((s->id_lowercase).c_str());
				// read_blast_hits does not have one alignment per sequence
				Alignment *sa = s->seq_alignment, *a = new Alignment(sa->aseq1,sa->aseq2,0);
				a->score = sa->score;
				a->eval = sa->eval;
				a->identities = sa->identities;
				a->positives = sa->positives;
				a->qstart = sa->qstart;
				a->qend = sa->qend;
				a->sstart = sa->sstart;
				a->send = sa->send;
				s->seq_alignment = a;
			}
		}
		*out << "#matches " << chain << " " << matches.size() << " " << blast_pdbids[chainindex].size() << endl;
		chainindex++;
	}
	hash_set<const char*, hash<const char*>, eqstr> intersection;
	for(hash_set<const char*, hash<const char*>, eqstr>::iterator itr = blast_pdbids[0].begin(); itr != blast_pdbids[0].end(); itr++){
		bool found = true;
		for(int i = 1; i < chainindex && found; i++){
			found = (blast_pdbids[i].count(*itr) > 0);
		}
		if(found)	intersection.insert(*itr);
	}
	*out << "#templates " << intersection.size() << endl << "list:\t";
	for(hash_set<const char*, hash<const char*>, eqstr>::iterator itr = intersection.begin(); itr != intersection.end(); itr++)
		*out << *itr << " ";
	*out << endl;
	
	// check if interface has not heavily mutated
	for(hash_map<char, hash_map<const char*, Sequence*, hash<const char*>, eqstr>, hash<char>, eqint>::iterator bitr=blast_hits.begin(); bitr!=blast_hits.end();bitr++){
		char chain = bitr->first;
		int offset = 0;
		hash_map<const char*, Sequence*, hash<const char*>, eqstr> matches = bitr->second;
		//*out << chain << " " << matches.size() << endl;
		for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator mitr=matches.begin(); mitr!=matches.end(); mitr++){
			Sequence *s = (Sequence *) mitr->second;
			Alignment *a = s->seq_alignment;
			int qindex = a->qstart-1, sindex = a->sstart-1;
			int n = a->aseq1.size();
			const char* aseq1c = a->aseq1.c_str();
			const char* aseq2c = a->aseq2.c_str();
			
			*out << s->id_lowercase << " " << a << " ";
			hash_map<long, long, hash<long>, eqlong> q_vs_s, s_vs_q;
			for(int i = 0 ; i < n ; i++){
				int sindexc = sindex + offset;
				if(aseq1c[i] != '-' && aseq2c[i] != '-'){
					s_vs_q[qindex] = sindexc;
					q_vs_s[sindexc] = qindex;
					*out << qindex << "-" << sindex << "-" << sindexc << " ";
				}
				if(aseq1c[i] != '-')	qindex++;
				if(aseq2c[i] != '-')	sindex++;	
			}
			*out << endl;
			
			hash_set<int,hash<int>,eqint>::iterator iitr, ibegin, iend;
			if(chain == chains_c[0]){
				ibegin = reference_interface_receptor_residues.begin(); 
				iend = reference_interface_receptor_residues.end();
			} else{
				ibegin = reference_interface_ligand_residues.begin(); 
				iend = reference_interface_ligand_residues.end();
			}
			*out << a->aseq1 << endl << a->aseq2 << endl;
			*out << "interface:\t";
			for(iitr = ibegin; iitr != iend; iitr++){
				int index = *iitr;
				//if(index >= a->qstart && index < a->qend){
					char qc='-',sc='-';
					int qindex = a->qstart-1, i;
					for(i = 0 ; i < n ; i++){
						if(aseq1c[i] != '-'){
							qindex++;
							if(qindex == index+1) {
								qc=aseq1c[i];
								sc=aseq2c[i];
								break;
							}
						}
					}
					*out << index << "-" << i << " " << qc << sc << " ";
					if(qc != '-' && sc != '-')	a->positives_interface++;
					if(qc == sc && qc != '-')	a->identities_interface++;
					if(qc == '-' || sc == '-')	a->gaps_interface++;
				//}
			}
			*out << endl;
		}
	}
	
	// select sequences
	Sequence *rconformation_selected=NULL, *lconformation_selected=NULL;
	float rbest_score=0,lbest_score=0; 
	unsigned int rnum_selected=0, lnum_selected=0;
	for(hash_map<char, hash_map<const char*, Sequence*, hash<const char*>, eqstr>, hash<char>, eqint>::iterator bitr=blast_hits.begin(); bitr!=blast_hits.end();bitr++){
		char chain = bitr->first;
		int rlength = ((Protein*)cref->molecules[chain])->num_aminoacids;
		
		int countsim = 0, countp = 0, counts = 0;
		hash_map<const char*, Sequence*, hash<const char*>, eqstr> matches = bitr->second;
		for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator mitr=matches.begin(); mitr!=matches.end(); mitr++){
			Sequence *s = (Sequence *) mitr->second;
			Alignment *a = s->seq_alignment;
			if(a->identities >= 35)	countsim++;
			int ref_interface_size;
			if(chain == chains_c[0]){
				ref_interface_size = reference_interface_receptor_residues.size();
			} else {
				ref_interface_size = reference_interface_ligand_residues.size();
			}
			cout << "scores " << s->id_lowercase << " " << a->positives << " " << a->identities << " " << a->positives_interface << " " 
				<< a->identities_interface << " " << ref_interface_size << " " << a << endl;
			bool interfaceok = (a->positives_interface/ref_interface_size >= 0.8 && a->identities_interface/ref_interface_size >= 0.6 && a->gaps_interface <= 5);
			if(interfaceok){
				if(s->id_lowercase.length() > 0){
					countp++;
					float tmscore=0;
					int seqlength=0;
					{
						stringstream ss (stringstream::in | stringstream::out);
						ss << getenv(string("HOME").c_str()) << "/scripts/select_chain.sh " << (s->chain) << " \"" << getenv(string("HOME").c_str()) << "/" << PDB_DIR << "/pdb" << (s->id_lowercase) << ".ent\" > tm/"
							<< s->id_lowercase << "_" << s->chain << ".pdb";
						ss.getline(buf,2048);
						int ret;// = system(buf);
						cout << buf << " " << ret << endl;
						
						ss.clear();
						//ss << getenv(string("HOME").c_str()) << "/external/tmalign " << pdbcode << "_" << chain << ".pdb tm/" << s->id_lowercase << "_" << s->chain << ".pdb" 
						//	<< " > tm/" << chain << "_vs_" << (s->id_lowercase) << "_" << (s->chain) << ".tm";
						ss << getenv(string("HOME").c_str()) << "/external/tmalign tm/" << s->id_lowercase << "_" << s->chain << ".pdb " << pdbcode << "_" << chain << ".pdb > tm/"
							<< (s->id_lowercase) << "_" << (s->chain) << "_vs_" << chain << ".tm";
						ss.getline(buf,2048);
						cout << buf << " "; cout.flush();
						ret = system(buf);
						cout << ret << endl;
							
						ss.clear();	
						//ss << "./tm/" << chain << "_vs_" << (s->id_lowercase) << "_" << (s->chain) << ".tm";
						ss << "./tm/" << (s->id_lowercase) << "_" << (s->chain) << "_vs_" << chain << ".tm";
						string filename; ss >> filename;
						fstream alignin(filename.c_str(), fstream::in);
						
						do{
							alignin.getline(buf,2048);
						}while(alignin.good() && (string(buf)).find("Chain 2:") == string::npos);
						
						if(alignin.good()){
							{
								string s;
								stringstream line(string(buf),stringstream::in);
								line >> s; line >> s; line >> s;
								line >> seqlength;
							}
							
							do{
								alignin.getline(buf,2048);
							}while(alignin.good() && (string(buf)).find("Aligned length=") == string::npos);
						
							if(alignin.good()){	
								string s = string(buf);
								stringstream line(s.substr(s.find("TM-score=")+9),stringstream::in);
								//line >> s;
								line >> tmscore;
								//cout << "tmscore " << s << endl;
							}
						}

						alignin.close(); 
					}
					
					float lratio = seqlength/((float)rlength);
					cout << "check " << chain << " " << seqlength << " " << rlength << " " << lratio << endl;
					if(tmscore >= 0.65 && lratio <= 1.2 && lratio >= 0.8){
					// check the lengths of the proteins to avoid fusions
						counts++;	
						if(chain == chains_c[0]){
							cout << "receptor " << rnum_selected++ << " ";
							if(tmscore <= 0.95 && tmscore > rbest_score){
								rbest_score = tmscore;
								rconformation_selected=s;
							}
						} else {
							cout << "ligand " << lnum_selected++ << " ";
							if(tmscore <= 0.95 && tmscore > lbest_score){
								lbest_score = tmscore;
								lconformation_selected=s;
							}
						}
						cout << s->id_lowercase << " " << s->chain << " " << tmscore << " " << lratio << " " << a->identities_interface << " " << a->positives_interface 
							<< " " << a->gaps_interface << " " << ref_interface_size << endl;
					}
				}
			}
		}
		*out << chain << ": #similar " <<  countsim << " #possible " << countp << " #selected " << counts << endl;
	}
	if(rconformation_selected != NULL)
		cout << "bestreceptor " << rconformation_selected->id_lowercase << " " << rconformation_selected->chain << endl;
	if(lconformation_selected != NULL)
		cout << "bestligand " << lconformation_selected->id_lowercase << " " << lconformation_selected->chain << endl;
}
