/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

//#include "process_complex.hpp"
#include "object.hpp"

#define BUFFER_WIDTH 4.0
ostream *out;
char buf[8192] , scratch_dir[128];

/*
 * For each model of the receptor and ligand, compute metrics
 * of similarity of interface with bound conformation
 */
int main(int argc, char *argv[]){
	out = &cout;	
	read_molecule_config();
	read_dock_config();
	
	Complex *cr, *cl;
	cr = new Complex(("../" + string(argv[1])).c_str(),argv[2], PROCESSED);//PDB);
	cl = new Complex(("../" + string(argv[1])).c_str(),argv[3], PROCESSED);//PDB);
	string s = string(argv[1]);
	string pdbid = s;//.substr(s.length()-4,4);
	cout << "pdbid " << pdbid << endl;
	
	hash_set<int,hash<int>,eqint> ref_interface_ligand_residues,ref_interface_receptor_residues;
	hash_set<int,hash<int>,eqint> ref_interface_ligand_residues_capri,ref_interface_receptor_residues_capri;
	for(int i = 0 ; i < cr->num_aminoacids; i++){
		Aminoacid *ra = cr->aminoacid[i];
		for(int j = 0; j < cl->num_aminoacids; j++){
			Aminoacid *la = cl->aminoacid[j];
			float d_ca, d_cd;
			 				
	 		if((ra->alpha_carbon != NULL && la->alpha_carbon != NULL && (d_ca = Vector::distance(ra->alpha_carbon->position, la->alpha_carbon->position)) < SS_CUTOFF) ||
	 		  (ra->centroid != NULL && la->centroid != NULL && (d_cd = Vector::distance(ra->centroid, la->centroid)) < SS_CUTOFF)){
				ref_interface_receptor_residues.insert(i);
				ref_interface_ligand_residues.insert(j);
	 		  }		 	
			
			// defining the interface used for computing irmsd
			for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator raitr = ra->atom.begin(); raitr != ra->atom.end(); raitr++){
				Atom *ratom = (Atom *) raitr->second;
			 	if(ratom->name.c_str()[0] != 'H'){
		 			for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator laitr = la->atom.begin(); laitr != la->atom.end(); laitr++){
		 				Atom *latom = (Atom *) laitr->second;
		 				if(latom->name.c_str()[0] != 'H'){
						 	if(Vector::distance(ratom->position, latom->position) <= CAPRI_INTERFACE_CUTOFF){
							 	ref_interface_receptor_residues_capri.insert(i);
								ref_interface_ligand_residues_capri.insert(j);
		 					}
		 				}
			 		}
				}
			}
		}
	}
	
 	*out << "interface " << ref_interface_receptor_residues_capri.size() << " " << ref_interface_ligand_residues_capri.size() << endl;
 	
 	Complex *cref;
	// read list of conformations
	for(int ci = 0 ; ci < 2 ; ci++){
		string filename;
		if(ci == 0){
			cref = cr;
			filename="../rec_unbound";
		} else {
			cref = cl;
			filename="../lig_unbound";
		}
		fstream listin(filename.c_str(), fstream::in);
		while(listin.good()){
			listin.getline(buf,8092);
			if(listin.gcount() > 0){
				string s;
				stringstream line(string(buf),stringstream::in);
				line >> s;
			  if(s.substr(0,4) != "best"){ 
				line >> s; 
				string pdbid;
				line >> pdbid;
				string chain;
				line >> chain;
				
				string fileid;
				if(ci == 0)	fileid="R"; else	fileid="L";
				fileid = fileid + pdbid + "_" + chain + "/" + string(argv[1]) + "m_";
				if(ci == 0)	fileid+=string(argv[2]); 
				else	fileid+=string(argv[3]);
				fileid = fileid + ".B99990001";
				fstream fin((fileid+".pdb").c_str(), fstream::in);
				if(fin.good()){
					fin.close();
					Complex *c = new Complex(fileid.c_str(),"-",PDB);
					// assume the sequences are identical in the target and the model
					hash_set<int,hash<int>,eqint>::iterator itr, begin, end;
					for(int mi = 0 ; mi < 2; mi++){
						if(ci == 0){
							if(mi==0){
								begin = ref_interface_receptor_residues_capri.begin();
								end = ref_interface_receptor_residues_capri.end();
							} else {
								begin = ref_interface_receptor_residues.begin();
								end = ref_interface_receptor_residues.end();
							}
						} else {
							if(mi==0){
								begin = ref_interface_ligand_residues_capri.begin();
								end = ref_interface_ligand_residues_capri.end();
							} else {
								begin = ref_interface_ligand_residues.begin();
								end = ref_interface_ligand_residues.end();
							}
						}
						Vector ref_interface_points[c->num_atoms+1], hom_interface_points[c->num_atoms+1];
						int pindex = 0;
						for(itr = begin; itr != end; itr++){
							int aaindex = *itr;
							Aminoacid *aaref = cref->aminoacid[aaindex];
							Aminoacid *aahom = c->aminoacid[aaindex];
							if(aaref->type != aahom->type){
								*out << "ERROR: aminoacids do not match " << fileid << " " << aaref->index << " " << aahom->index << endl;
							} else {
								for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = aaref->atom.begin(); aitr != aaref->atom.end(); aitr++){
									Atom *aref = (Atom *) aitr->second;
									if(aahom->name.c_str()[0] != 'H' && aahom->atom.count(aref->name.c_str())>0){
										Atom *ahom = aahom->atom[aref->name.c_str()];
										ref_interface_points[pindex] = *(aref->position);
										hom_interface_points[pindex] = *(ahom->position);
										pindex++;
									}
								}
							}
						}
						Transformation *tr = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0, 0);
						float hirmsd = compute_rmsd(pindex , ref_interface_points, hom_interface_points, tr);
						if(mi==0) cout << "capri_"; else cout << "res_";
						cout << "irmsd " << ci << " " << pdbid << " " << chain << " " << hirmsd << " " << pindex << endl;
					}
				} else {
					*out << "could not find file " << fileid << ".pdb" << endl;
				}
			  }
			}
		}
	}


}
