/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "utilities.hpp"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <ext/hash_set>

#define stdext __gnu_cxx;
using namespace std;
using namespace stdext;

class tid_with_score {
	public:
		float score;
		int tid;
	tid_with_score &operator =(const tid_with_score&);
	bool operator<(tid_with_score const& ) const;
};

tid_with_score& tid_with_score::operator=(const tid_with_score& t1){
	this->score = t1.score;
	this->tid = t1.tid;
	return *this;
}

bool tid_with_score::operator <(tid_with_score const& t2) const{
	//cout << "compare " << tid << " " << t2.tid << " " << (score > t2.score) << endl; 
	return (score > t2.score);
}

char buf[8192];

int format1(int argc, char *argv[]){
	int num_transforms = atoi(argv[1]);
	int num_homologues = atoi(argv[2]);
	fstream fin(argv[3],ios::in);
	
	int rank[num_transforms+1][num_homologues+1];
	float irmsd[num_transforms+1];	
	int current_rank[num_homologues+1];
	for(int i = 0; i <= num_homologues; i++)	current_rank[i] = 1;
	while(fin.good()){
		fin.getline(buf,8192);
		if(fin.gcount() > 0){
			stringstream ss(buf,stringstream::in);
			float s; ss >> s;
			int htid; ss >> htid;
			int tid = htid % num_transforms;
			int homid = htid/num_transforms;
			if(num_transforms == 54000 && tid == 0){
				tid = 54000;
				homid--;
			}
			rank[tid][homid] = current_rank[homid]++;
			if(homid == 0)	ss >> irmsd[tid];
		}
	}
	
	int num_homologues_considered = 0.6*num_homologues;
	for(int i = 1; i <= num_transforms; i++){
		sort(rank[i],rank[i]+num_homologues+1);
		float avgrank=0;
		for(int j = 0; j <= num_homologues_considered; j++)	avgrank += rank[i][j];
		cout << avgrank/(num_homologues_considered+1) << " " << i << " " << irmsd[i] << " " << irmsd[i] << " - ";
		for(int j = 0; j <= num_homologues; j++)	cout << rank[i][j] << " ";
		cout << " |" << i << "| " << endl;
	}
}

int main(int argc, char *argv[]){
	//string tmp_dir = string("/scratch/")+"/"+string(getenv(string("JOB_ID").c_str()));
	int num_transforms = atoi(argv[1]);
	int num_pairs = atoi(argv[2]);
	hash_map<short,short,hash<short>,eqint> species_vs_numhompairs;
	hash_map<short,hash_set<short,hash<short>,eqint>,hash<short>,eqint> species_vs_rhom, species_vs_lhom;
	hash_map<const char*,short,hash<const char*>,eqstr> hom_ids;
	int homid=0, speciesid=0, num_pairs_sorted=0;
	hash_map<short, tid_with_score*, hash<short>, eqint> scores;
	hash_map<short, float*, hash<short>, eqint> final_rank;
	bool initialized_species = false;
	int tcount = 1;
	hash_map<int,int,hash<int>,eqint> trtid_vs_localtid, localtid_vs_trtid;
	while(num_pairs_sorted < num_pairs){
		// read scores for pairs in a given species
		fstream fin(argv[3],ios::in);
		while(fin.good()){
			fin.getline(buf,8192);
			if(fin.gcount() > 0){
				stringstream ss(buf,stringstream::in);
				int tid; ss >> tid;
				if(trtid_vs_localtid.count(tid) == 0){
					trtid_vs_localtid[tid] = tcount;
					localtid_vs_trtid[tcount] = tid;
					tcount++;
				}
				int ltid = trtid_vs_localtid[tid];
				int spid; ss >> spid;
				if(spid == speciesid){
					//cout << "tid " << tid << " " << ltid << " " << spid << endl;
					if(!initialized_species){
						species_vs_rhom[speciesid] = *(new hash_set<short,hash<short>,eqint>);
						species_vs_lhom[speciesid] = *(new hash_set<short,hash<short>,eqint>); 
						initialized_species = true;
					}
					string rid_s, lid_s;
					ss >> rid_s; ss >> lid_s;
					if(ltid == 1){
						short rid, lid;
						rid = atoi(rid_s.c_str());
						lid = atoi(lid_s.c_str());
						species_vs_rhom[speciesid].insert(rid);
						species_vs_lhom[speciesid].insert(lid);
					}
					
					string s = rid_s +"_"+lid_s;
					if(hom_ids.count(s.c_str()) == 0){
						hom_ids[(new string(s))->c_str()] = homid;
						scores[homid] = (tid_with_score *) malloc(sizeof(tid_with_score)*(num_transforms+1));
						homid++;
					}
					
					float score; ss >> score;
					scores[hom_ids[s.c_str()]][ltid].score = score;
					scores[hom_ids[s.c_str()]][ltid].tid = ltid;
				}
			}
		}
		fin.close();
		
		// get ranks
		int num_pairs = homid; 
		int rank[num_pairs][num_transforms+1];
		for(hash_map<short, tid_with_score*, hash<short>, eqint>::iterator itr = scores.begin(); itr != scores.end(); itr++){
			int homid = itr->first;
			tid_with_score *score = (tid_with_score*)(itr->second);
			
			cout << speciesid << " " << score[1].score << endl;	cout.flush();
			sort(score+1, score + (num_transforms+1));
			
			for(int i = 1; i <= num_transforms; i++)	rank[homid][score[i].tid] = i;
			cout << speciesid << " " << rank[0][1] << " " << score[rank[0][1]].score << endl;	cout.flush();
					
			delete score;
		}
		
		final_rank[speciesid] = (float *) malloc(sizeof(float)*(num_transforms+1));
		int numrhomologues = species_vs_rhom[speciesid].size();
		int numlhomologues = species_vs_lhom[speciesid].size();
		//cout << "species " << speciesid << " " << numrhomologues << " " << numlhomologues << endl;
		int num_pairs_considered = minimum(numrhomologues,numlhomologues);
		if(num_pairs_considered > 1){
			//num_pairs_considered = 0.60 * num_pairs_considered;
			num_pairs_considered = 1;
		}
		for(int i = 1; i <= num_transforms; i++){
			int mode_rank[num_pairs];
			for(int j = 0; j < num_pairs; j++)	mode_rank[j] = rank[j][i];
			sort(mode_rank,mode_rank+num_pairs);
			float mode_score=0;
			for(int j = 0; j < num_pairs_considered; j++)	mode_score += mode_rank[j];
			final_rank[speciesid][i] = mode_score/num_pairs_considered;
			if(i==1){
				cout << i << " " << speciesid << " " << final_rank[speciesid][i] << " " << rank[0][i] << " " << mode_rank[0] << " " 
					<< numrhomologues << " " << numlhomologues << " " << num_pairs << " " << num_pairs_considered << endl;
				cout.flush();
			}
		}
		
		// move on to next species
		speciesid++;
		num_pairs_sorted += hom_ids.size();
		hom_ids.clear();
		scores.clear();
		homid=0;
		initialized_species = false;
	}
	
	int num_species = speciesid;
	int num_species_considered = 0.6*num_species;
	for(int i = 1; i <= num_transforms; i++){
		float mode_rank[num_species];
		for(int j = 0; j < num_species; j++){
			mode_rank[j] = final_rank[j][i];
		}
		sort(mode_rank,mode_rank+num_species);
		float avg_rank = 0;
		for(int j = 0; j < num_species_considered; j++)	avg_rank += mode_rank[j];
		cout << avg_rank/num_species_considered << " ";
		//cout << i << " ";
		cout << localtid_vs_trtid[i] << " ";
		for(int j = 0; j < num_species; j++)	cout << mode_rank[j] << " ";
		cout << endl;
	}
}
