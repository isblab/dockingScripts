#include "molecule.hpp"
#include "rmsd.h"

ostream *out;

int main(int argc, char *argv[]){
	out=&cout;
	
	read_molecule_config();
	read_dock_config();
	
	if(argc < 6)	cout << "Usage: model rchains lchains" << endl;
	
	string rchains=string(argv[2]);
	string lchains=string(argv[3]);
	
	Complex* c = new Complex(argv[1],(rchains+lchains).c_str(),PDB);
	
	// compute heavy atom clashes
	unsigned short num_clashes = 0, num_bbclashes = 0;
	Molecule *ml = c->molecules[lchains.c_str()[0]];
	Molecule *mr = c->molecules[rchains.c_str()[0]];
	cout << mr->chain << " " << ml->chain << endl;
	for(hash_map<unsigned short, Atom*, hash<unsigned short>,eqint>::iterator litr = ml->atom.begin(); litr != ml->atom.end(); litr++){
		Atom * al = (Atom *) litr->second;
		if((al->name).c_str()[0] != 'H'){
			for(hash_map<unsigned short, Atom*, hash<unsigned short>,eqint>::iterator ritr = mr->atom.begin(); ritr != mr->atom.end(); ritr++){
				Atom *ar = (Atom *) ritr->second;
				if((ar->name).c_str()[0] != 'H'){
					double d2 = Vector::distance_squared(al->position,ar->position);
					if(d2 < 9.0){
						//cout << al->index << " (" << al->position->x << "," << al->position->y << "," << al->position->z << ")\t"
						//	<< al->index << " (" << al->position->x << "," << al->position->y << "," << al->position->z << ")\t" << d2 << endl;
						num_clashes++;
						if(al->isbbatom && ar->isbbatom && d2 < 2.25)
							num_bbclashes++;
					}
				}
			}
		}
	}
	
	cout << string(argv[1]) << " clashes " << num_clashes << " bbclashes " << num_bbclashes << endl;
}
