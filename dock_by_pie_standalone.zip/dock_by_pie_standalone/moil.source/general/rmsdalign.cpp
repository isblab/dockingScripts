/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"

ostream *out;
char scratch_dir[512], command[8192];

/*
 * Arguments: protein1 protein2 2vs1outfile
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	read_dock_config();
	
	Complex *c1 = new Complex(argv[1], argv[2], PDB);
	Complex *c2 = new Complex(argv[3], argv[4], PDB);
	
	Vector c1point[c1->num_aminoacids*4+1], c2point[c2->num_aminoacids*4+1];
	
	for(int i = 0; i < c1->num_aminoacids; i++){
	 	Aminoacid *aa = c1->aminoacid[i];
	 	//if((aa->alpha_carbon == NULL)
			c1point[4*i] = Vector(aa->atom["N"]->position);
			c1point[4*i+1] = Vector(aa->atom["CA"]->position);
			c1point[4*i+2] = Vector(aa->atom["C"]->position);
			c1point[4*i+3] = Vector(aa->atom["O"]->position);
	}
	
	for(int i = 0; i < c2->num_aminoacids; i++){
	 	Aminoacid *aa = c2->aminoacid[i];
	 	//if((aa->alpha_carbon == NULL)
	 		c2point[4*i] = Vector(aa->atom["N"]->position);
			c2point[4*i+1] = Vector(aa->atom["CA"]->position);
			c2point[4*i+2] = Vector(aa->atom["C"]->position);
			c2point[4*i+3] = Vector(aa->atom["O"]->position);
	}
	
	// loopp some models are incomplete - based on the length of alignment?
	// largest substring of sequences
	int begin1=0, begin2=0;
	/*string seq="CFLVNLNADPALNELLVYYLKEHTLIGSANSQDIQLCGMGILPEHCIIDITSEGQVMLTPQKNTRTFVNGSSVSSPIQLHHGDRILWGNNHFFRLNLP";
	string seq1=((Molecule*) c1->molecules.begin()->second)->compute_aasequence();
	string seq2=((Molecule*) c2->molecules.begin()->second)->compute_aasequence();
	begin1=seq.find(seq1), begin2=seq.find(seq2);
	cout << begin1 << " " << c1->num_aminoacids << " " << begin2 << " " << c2->num_aminoacids << "\t";
	if(begin1<begin2){
		begin1=begin2-begin1;	begin2=0;
	}	else {
		begin2=begin1-begin2; begin1=0;
	} */ 
	
	Transformation *c2_to_c1 = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
	int num_points = min(c1->num_aminoacids,c2->num_aminoacids)*4;
	float rmsd = compute_rmsd(num_points, &c1point[begin1*4], &c2point[begin2*4],c2_to_c1);
	cout << begin1 << " " << begin2 << " " << rmsd << endl;
	
	c2_to_c1->write_as_pdb(c2, "-", false, string(argv[5]),true);
}
