/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];

/*
 * Arguments: unbound chains transformed outfile tags
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	stringstream ss (stringstream::in | stringstream::out);
	ss << argv[1] << ".pdb";
	string filename;
	ss >> filename;
	fstream fin(filename.c_str(), fstream::in);
	
	string transfile(argv[2]);
	unsigned int frame_number = atoi(argv[3]);
	
	Vector *translation, *ex, *ey, *ez;
	int lineno=0;
	while (!fin.eof()){
		fin.getline(buf,8192);
		stringstream ss(buf,stringstream::in);
		string tag;
		ss >> tag; ss >> tag; ss >> tag; ss >> tag; ss >> tag; ss >> tag;
		float x,y,z;
		ss >> x;
		ss >> y;
		ss >> z;
		Vector v = Vector(x,y,z);
		switch(lineno){
			case 0:
				translation = new Vector(v);
				break;
			case 1:
				ex = new Vector(v-*translation);
				break;
			case 2:
				ey = new Vector(v-*translation);
				break;
			case 3:
				ez = new Vector(v-*translation);
				break;
		}
		lineno++;	
	}
	fin.close();
	
	/*Vector v = ex->cross(ey) - *ez;
	cout << v.x << "," << v.y << "," << v.z << endl;*/
	Transformation *orig_to_model = new Transformation(translation, ex, ey, 1.0, 0, 0);
	orig_to_model->frame_number = frame_number;
	
	fstream transout(transfile.c_str(),fstream::out | fstream::app);
	orig_to_model->write_binary(&transout,TN_BASIC);
	orig_to_model->print_details(&cout,TN_BASIC);
	transout.close();	
	//orig_to_model->write_as_pdb(clu, string("model.pdb"), true);
}
