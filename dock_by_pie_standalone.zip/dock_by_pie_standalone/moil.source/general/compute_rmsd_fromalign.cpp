/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#define BUFSIZE 8192

ostream *out;
char scratch_dir[512], command[8192], buff[BUFSIZE];
hash_map<long, long, hash<long>, eqlong> p1_vs_p2, p2_vs_p1;

void read_alignments(Complex *c1, Complex *c2, string p1chain,string p2chain, const char* c1pdbid, const char* c2pdbid){
	string filename;
	string aseq1,aseq2,s;
	int qstart, sstart;
	bool alignment_done;
	stringstream *line;
	p1_vs_p2.clear();
	p2_vs_p1.clear();
	
	short tmalign = 1, nwa = 2, alignment = nwa;
	for(int i = 0; i < p2chain.size(); i++){
		Molecule *m = c1->molecules[p1chain.c_str()[i]];
		int offset1,offset2;
		if(m->chain == '-')	offset1 = 0;
		else	offset1 = c1->mmonostart[m->chain];; 
		{
			offset2 = c2->mmonostart[p2chain.c_str()[i]];
		}
		
		stringstream ss (stringstream::in | stringstream::out);
		ss << c1pdbid << "_" << (m->chain) << "_vs_" << string(c2pdbid) << "_" << p2chain.c_str()[i];
		if(alignment == nwa)	ss << ".ali";
		else	ss << ".tmali";
		ss >> filename;
		fstream fin;
		fin.open(filename.c_str(), ios::in);

		if(fin.is_open()){
			*out << "align file " << filename << " offsets " << offset1 << " " << offset2 << endl;
			aseq1 = ""; aseq2 = "";
			qstart = sstart = 1;
			
			if(alignment == nwa){
				// reading input from the output of nwa
				fin.getline(buff,BUFSIZE);
				fin.getline(buff,BUFSIZE);
				do{
					line = new stringstream(buff,stringstream::in);
					*line >> s;
					aseq1 += s;
					fin.getline(buff,BUFSIZE);
				}while((string(buff)).find(">>") == string::npos);
				while(fin.good()){
					fin.getline(buff,BUFSIZE);
					if(fin.gcount() > 0){
						line = new stringstream(buff,stringstream::in);
						*line >> s;
						aseq2 += s;
						//*out << ">" << aseq2 << endl;
					}
				}
			} else {
				do{
					fin.getline(buff,BUFSIZE);
				}while(fin.good() && (string(buff)).find("Angstrom)") == string::npos);
					
				fin.getline(buff,BUFSIZE);
				aseq1=string(buff);
					
				fin.getline(buff,BUFSIZE);
				fin.getline(buff,BUFSIZE);
				aseq2=string(buff);
			}
			
			*out << aseq1 << endl << aseq2 << endl;
			
			int qindex = qstart-1, sindex = sstart-1;
			int n = aseq1.size();
			const char* aseq1c = aseq1.c_str();
			const char* aseq2c = aseq2.c_str();
			
			for(int i = 0 ; i < n ; i++){
				int qindexc = qindex + offset1;
				int sindexc = sindex + offset2;
				if(aseq1c[i] != '-' && aseq2c[i] != '-' && c2->aminoacid[sindexc]->alpha_carbon != NULL){
					p1_vs_p2[qindexc] = sindexc;
					p2_vs_p1[sindexc] = qindexc;
					*out << qindex << "-" << qindexc << "-" << sindex << "-" << sindexc << " ";
				}
				if(aseq1c[i] != '-')	qindex++;
				if(aseq2c[i] != '-')	sindex++;	
			}
			*out << endl; out->flush();
			fin.close();
		} else {
			cout << "ERROR: Alignment does not exist " << filename << endl;
			exit(-1);
		}
	}
	*out << p1_vs_p2.size() << "|" <<  p2_vs_p1.size() << endl;
	out->flush();
}

/*
 * Arguments: protein1 chains protein2 chains 2vs1outfile
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	read_dock_config();
	
	//Complex *c1 = new Complex(string((argv[1])+string("_")+string(argv[2])).c_str(), argv[2], PDB);
	Complex *c1 = new Complex(argv[1], argv[2], PDB);
	
	// modeller labels chains starting from A
	char c2chain[32];// = (char*) string(argv[5]).c_str();//[32];
	for(int i=0; i< string(argv[5]).size(); i++){
		//c2chain[i]='B'+i;
		c2chain[i] = argv[5][i];
	}
	c2chain[string(argv[5]).size()] = '\0';
	//if(argv[2][0] == '-' || string(argv[2]).size()==1)	c2chain[0] = '-';
	
	*out << "c2chain " << string(c2chain) << endl;
	Complex *c2 = new Complex(argv[3], c2chain, PDB);
	
	Vector c1point[4*c1->num_aminoacids+1], c2point[4*c2->num_aminoacids+1];
	
	read_alignments(c1, c2, string(argv[2]),string(argv[4]), argv[6], argv[7]);
	
	int num_points=0;
	for(int i = 0; i < c1->num_aminoacids; i++){
	 	Aminoacid *aa = c1->aminoacid[i];
	 	if(p1_vs_p2.count(i) > 0){
		 	int j = p1_vs_p2[i];
		 	Aminoacid *aa2 = c2->aminoacid[j];
		 	
		 	if(aa->atom.count("N") > 0 && aa2->atom.count("N") > 0){
		 		c1point[num_points] = Vector(aa->atom["N"]->position);
				c2point[num_points] = Vector(aa2->atom["N"]->position);
		 		num_points++;
			}
			if(aa->atom.count("CA") > 0 && aa2->atom.count("CA") > 0){
				c1point[num_points] = Vector(aa->atom["CA"]->position);
				c2point[num_points] = Vector(aa2->atom["CA"]->position);
		 		num_points++;
			} 
			if(aa->atom.count("C") > 0 && aa2->atom.count("C") > 0){
				c1point[num_points] = Vector(aa->atom["C"]->position);
				c2point[num_points] = Vector(aa2->atom["C"]->position);
		 		num_points++;
			} 
			if(aa->atom.count("O") > 0 && aa2->atom.count("O") > 0){
				c1point[num_points] = Vector(aa->atom["O"]->position);
				c2point[num_points] = Vector(aa2->atom["O"]->position);
		 		num_points++;
			}
	 	}
	}
	
	Transformation *c2_to_c1 = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
	float rmsd = compute_rmsd(num_points, &c1point[0], &c2point[0],c2_to_c1);
	cout << "BB rmsd " << rmsd << " " << num_points << endl;
	
	c2_to_c1->write_as_pdb(c2, c2->chains, false, string(argv[8]),true);
}
