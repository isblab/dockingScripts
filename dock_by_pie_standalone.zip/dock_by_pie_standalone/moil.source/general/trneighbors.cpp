/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192], filename[512];

#ifndef MTR_MAX_R_DISTANCE
#define MTR_MAX_R_DISTANCE 5.0
#define MTR_MAX_ROTATION_DISTANCE 0.20
#endif

/*
 * Select similar transformations, list in the original sorted order 
 * Arguments: transformationfile transformationid
 */
int main(int argc, char *argv[]){
	out = &cout;
	read_molecule_config();
	read_dock_config();
	
	fstream transin1(argv[1],ios::binary|ios::in);
	*out << argv[1] << " " << transin1.good() << " capri interface cutoff " << CAPRI_INTERFACE_CUTOFF << endl;
	long target_tr_id = atoi(argv[2]);
	
	Transformation *target_tr;
	if(transin1.good()){
		transin1.seekg(target_tr_id*Transformation::basic_byte_size,ios::beg);
		transin1.read(buf,Transformation::basic_byte_size);
		if(transin1.gcount() > 0){
			target_tr = new Transformation(buf,TN_BASIC);
			target_tr->print_details(&cout,TN_BASIC);
		}
	}
	
	string rpdbcode = string(argv[3]);
	string lpdbcode = string(argv[5]);
	Complex* cr = new Complex(("../"+rpdbcode).c_str(),argv[4], PROCESSED);
	Complex* cl = new Complex(("../"+lpdbcode).c_str(),argv[6], PROCESSED);
	
	// compute the interface
	Vector target_interface_points[cr->num_atoms+cl->num_atoms+1],neighbor_interface_points[cr->num_atoms+cl->num_atoms+1], ligand_untransformed_interface_points[cl->num_atoms+1];
	unsigned short num_receptor_interface_points=0, num_ligand_interface_points=0;
	hash_set<long,hash<long>,eqlong> reference_interface_contacts;
	hash_set<short,hash<short>,eqint> receptor_interface_residues, ligand_interface_residues;
	for(short cj = 0; cj < cl->num_aminoacids; cj++){
		Aminoacid *la = cl->aminoacid[cj];
		if(la->alpha_carbon != NULL){
			Vector v = target_tr->inverse_transform(*(la->alpha_carbon->position));
			for(short ci = 0; ci < cr->num_aminoacids; ci++){
				Aminoacid *ra = cr->aminoacid[ci];
			 	long cindex = (ra->cindex)*MAX_ATOMS + la->cindex;
			 			
				bool contact=false; // use capri definition of interface
				for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator raitr = ra->atom.begin(); raitr != ra->atom.end() && !contact; raitr++){
			 		Atom *ratom = (Atom *) raitr->second;
			 		if(ratom->name.c_str()[0] != 'H'){
		 				for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator laitr = la->atom.begin(); laitr != la->atom.end() && !contact; laitr++){
		 					Atom *latom = (Atom *) laitr->second;
		 					if(latom->name.c_str()[0] != 'H'){
							 	if(Vector::distance(ratom->position, target_tr->inverse_transform(*(latom->position))) <= CAPRI_INTERFACE_CUTOFF)
									contact=true;
							}
						}
					}
				}
	
//	 			if(ra->alpha_carbon != NULL && Vector::distance(*(ra->alpha_carbon->position),v) < SS_CUTOFF){
				if(contact){
//					cout << "contact " << cindex << endl;
					if(reference_interface_contacts.count(cindex) == 0)
						reference_interface_contacts.insert(cindex);
					if(receptor_interface_residues.count(ra->cindex) == 0){
						receptor_interface_residues.insert(ra->cindex);
						neighbor_interface_points[num_receptor_interface_points] = target_interface_points[num_receptor_interface_points] = Vector(ra->alpha_carbon->position);
						num_receptor_interface_points++;
					}
					if(ligand_interface_residues.count(la->cindex) == 0){
						ligand_interface_residues.insert(la->cindex);
						ligand_untransformed_interface_points[num_ligand_interface_points] = Vector(la->alpha_carbon->position);
						num_ligand_interface_points++;
					}
				}
			}
		}
	}
	for(unsigned short i = 0; i < num_ligand_interface_points; i++)
		target_interface_points[num_receptor_interface_points+i] = target_tr->inverse_transform(ligand_untransformed_interface_points[i]);
	
	float d,ud;
	int num_trans_selected=0;
	hash_map<long,Transformation *,hash<long>,eqlong> selected_tr;
	hash_map<long,float,hash<long>,eqlong> selected_tr_irms;
	fstream transin(argv[7],ios::binary|ios::in);
	while(transin.good()){
		transin.read(buf,Transformation::basic_byte_size);
		if(transin.gcount() > 0){
			Transformation *tr = new Transformation(buf,TN_BASIC);
			target_tr->distance(&d, &ud, tr);
			//cout << tr->frame_number << " " << d << " " << ud << endl;
			// select based on distance in transformation space
			/*if(d <= 10 && ud <= 0.6){
				selected_tr[tr->frame_number] = tr;
				num_trans_selected++;
			} else 
				delete tr;*/
			// select based on the rmsd of the interface residues in the target to the neighbor
			if(d <= 15 && ud <= 1.0){
				// compute irmsd
				for(unsigned short i = 0; i < num_ligand_interface_points; i++)
					neighbor_interface_points[num_receptor_interface_points+i] = tr->inverse_transform(ligand_untransformed_interface_points[i]);
				float irmsd = compute_rmsd(num_receptor_interface_points+num_ligand_interface_points, &target_interface_points[0], &neighbor_interface_points[0]);
				if(irmsd < 4.0){
					selected_tr[tr->frame_number] = tr;
					selected_tr_irms[tr->frame_number] = irmsd;
					num_trans_selected++;
				} else
					delete tr;
			} else 
				delete tr;
			if(tr->frame_number %1000000 == 0)
				cout << "at " << tr->frame_number << endl;
		}
	}
	transin.close();
	cout << "#selected " << num_trans_selected << " " << selected_tr.size() << endl;
	
	sprintf(filename, "%ld_rmssimilar",target_tr_id);
	fstream nout(filename, ios::out);
	for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator itr = selected_tr.begin(); itr != selected_tr.end(); itr++){
		long trid = (long) itr->first;
			Transformation *tr = (Transformation *) itr->second;
			target_tr->distance(&d, &ud, tr);
			nout << trid << " " << d << " " << ud << " " << selected_tr_irms[trid] << endl;
	}
	nout.close();
	
	cout << "#selected transformations " << selected_tr.size() << endl;
}

