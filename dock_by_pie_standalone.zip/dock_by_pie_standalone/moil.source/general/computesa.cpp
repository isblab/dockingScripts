/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "molecule.hpp"
#include "sasautil.hpp"

ostream *out;

/*
 * Arguments: pdbid (in lower case) chains <include probe>
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	read_dock_config();
	
	Complex *c = new Complex(argv[1],argv[2], PDB);
	c->compute_volume_sasa(false,false);
	
	cout << c->sa << endl;
	
	/*char buf[512];
	sprintf(buf,"%s_%s.sa",argv[1],argv[2]);
	fstream fsa(buf,fstream::out);
	for(int i=0; i < c->num_aminoacids; i++){
		Aminoacid *aa = c->aminoacid[i];
		fsa << aa->index << " " << aa->sa << endl; 
	}
	fsa.close();*/	
}
