/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "molecule.hpp"
#include "rmsd.h"

ostream *out;

int main(int argc, char *argv[]){
	out=&cout;
	
	read_molecule_config();
	read_dock_config();
	
	if(argc < 6)	cout << "Usage: receptor rchains ligand lchains transformedligand" << endl;
	
	Complex* cr = new Complex(argv[1],argv[2],PDB);
	Complex* cl = new Complex(argv[3],argv[4],PDB);
	Complex* clt = new Complex(argv[5],argv[4],PDB);
	
	unsigned int max_num_atoms = cr->num_atoms + cl->num_atoms;
	Vector reference_points[max_num_atoms+1], model_points[max_num_atoms+1];
	int point_index = 0;
	for(int i = 0; i < cr->num_aminoacids; i++){
	 	Aminoacid *aa = cr->aminoacid[i];
	 	if(aa->alpha_carbon != NULL){
			reference_points[point_index] = Vector(aa->alpha_carbon->position);
			model_points[point_index] = Vector(aa->alpha_carbon->position);
			point_index++;
	 	}
	}
	unsigned int ligand_start = point_index;
	
	for(int i = 0; i < cl->num_aminoacids; i++){
	 	Aminoacid *aa = cl->aminoacid[i];
	 	if(aa->alpha_carbon != NULL){
			Aminoacid *aa_ref = cl->aminoacid[i];
			Vector v = reference_points[point_index] = Vector(aa_ref->alpha_carbon->position);
			//cout << i << " " << point_index << " reference\t" << v.x << " " << v.y << " " << v.z << "\t";
			Aminoacid *aa_model = clt->aminoacid[i];
			v = model_points[point_index] = Vector(aa_model->alpha_carbon->position);
			//cout << " model\t" << v.x << " " << v.y << " " << v.z << endl;
			point_index++;
	 	}
	}
	
	float rmsd = compute_rmsd(point_index, &reference_points[0], &model_points[0]);
	cout << "rmsd\t" << rmsd << endl;
	fstream rout;
	rout.open((string("rmsd")).c_str(), fstream::out | fstream::app);
	rout << argv[5] << "\t" << rmsd << endl;
	rout.close();
}
