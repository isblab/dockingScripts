/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];

/*
 * Arguments: transformationfile transformationid ligandpdbid ligandchains
 */
int main(int argc, char *argv[]){
	out = &cout;
	read_molecule_config();
	//read_dock_config();
	
	fstream transin(argv[1],ios::binary|ios::in);
	*out << argv[1] << " " << transin.good() << endl;
	
	Complex *c = new Complex(("../"+string(argv[3])).c_str(),argv[4], PDB);
	long tid = atol(argv[2]);
	int flag = atoi(argv[5]);
	// transformation id starts with 0 and they are in increasing order of id
	while(transin.good()){
		transin.seekg(tid*Transformation::basic_byte_size,ios::beg);
		transin.read(buf,Transformation::basic_byte_size);
		if(transin.gcount() > 0){
			Transformation *tr = new Transformation(buf,TN_BASIC);
			tr->print_details(out,TN_BASIC);
			stringstream ss (stringstream::in | stringstream::out);
			if(flag==0)
				ss << "tr" << tr->frame_number << ".pdb";
			else
				ss << "tl" << tr->frame_number << ".pdb";
			string s; ss >> s;
			if(flag==0)
				tr->write_as_pdb(c, "-", false, s, true);
			else
				tr->write_as_pdb(c, "-", false, s, false);
			break;
		}
	}
	transin.close();
}
