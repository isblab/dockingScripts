/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include <mpi.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
using namespace std;

#define TAG 0
MPI_Status stat;
#define BUFFSIZE 1024*1024 
char buf[BUFFSIZE];
int procid, numprocs;
string **hosts, *host;
int masterprocessonnode;
vector<int> other_processes_on_node;
ostream *out;

void elect_leader_on_node(){
	hosts = new string*[numprocs];
	gethostname(buf,BUFFSIZE);
	hosts[procid] = host = new string(buf);
	
	for(int i=0;i<procid;i++){
		MPI_Ssend((void*) host->c_str(), host->size()+1, MPI_CHAR, i, TAG, MPI_COMM_WORLD);
	}	
	for(int i=procid+1;i<numprocs;i++){
		MPI_Recv(buf, BUFFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &stat);
		hosts[i] = new string(buf);
	}
	for(int i=numprocs-1; i > procid;i--){
		MPI_Ssend((void*) host->c_str(), host->size()+1, MPI_CHAR, i, TAG, MPI_COMM_WORLD);
	}
	for(int i = procid-1; i >= 0; i--){
		MPI_Recv(buf, BUFFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &stat);
		hosts[i] = new string(buf);
	}
	
	masterprocessonnode=procid;
	for(int i=0;i<numprocs;i++)
		if(i != procid && *hosts[i] == *host){
			other_processes_on_node.push_back(i);
			if(i < masterprocessonnode)
				masterprocessonnode = i;
		}
}

int main(int argc, char *argv[]){
	int ret = MPI_Init(&argc,&argv);
	if(ret == MPI_SUCCESS){
		MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
		MPI_Comm_rank(MPI_COMM_WORLD,&procid);
				
		if(procid == 0){
			cout << "Job running on " << numprocs << " processors" << endl;
			cout << "#args " << argc << endl;
			cout.flush();
		}
		
		char tmpdir[1024];
		sprintf(tmpdir, "/scratch/%s",getenv(string("JOB_ID").c_str()));
		
		char filename[256];
		sprintf(filename, "%s/out%d",tmpdir,procid);
		fstream outstream;
		outstream.open(filename,ios::out);
		if(!outstream.good()){
			cout << "ERROR: could not open file " << filename << "\n"; cout.flush();
			exit(-1);
		}
		out = &outstream;
		
		elect_leader_on_node();
		*out << masterprocessonnode << " " << procid << endl;
		
		// run script
		if(masterprocessonnode == procid) {
			sprintf(buf, "cp all.vtrans.gz %s/",tmpdir);	
			ret=system(buf);	*out << buf << "\t" << ret << endl; out->flush();
 			sprintf(buf, "gunzip %s/all.vtrans.gz",tmpdir);	
 			ret=system(buf);	*out << buf << "\t" << ret << endl; out->flush();
			sprintf(buf, "cp moilr.3body.vtrans.gz %s/",tmpdir);	
			ret=system(buf);	*out << buf << "\t" << ret << endl; out->flush();
			sprintf(buf, "gunzip %s/moilr.3body.vtrans.gz",tmpdir);	
			ret=system(buf);	*out << buf << "\t" << ret << endl; out->flush();
			
			for(vector<int>::iterator itr = other_processes_on_node.begin(); itr != other_processes_on_node.end(); itr++){
				MPI_Ssend((void*) host->c_str(), host->size()+1, MPI_CHAR, ((int) *itr), TAG, MPI_COMM_WORLD);
			}
		} else {
			MPI_Recv(buf, BUFFSIZE, MPI_CHAR,masterprocessonnode , TAG, MPI_COMM_WORLD, &stat);
		}
		
		sprintf(buf, "cat %s/all.vtrans | awk '{ if($7%%%d == %d) print $7\" \"$0 }' | sort -n | awk '{ $1=\"\"; print }' > %s/sorted.%d.vtrans"
			, tmpdir, numprocs, procid, tmpdir,procid);
		ret=system(buf);	*out << buf << "\t" << ret << endl; out->flush();
		
		sprintf(buf, "cat %s/moilr.3body.vtrans |  awk '{ if($7%%%d == %d) print }' > %s/moilr.3body.%d.vtrans"
			, tmpdir, numprocs, procid, tmpdir, procid);
		ret=system(buf);	*out << buf << "\t" << ret << endl; out->flush();
		
		sprintf(buf,"perl /proj/ravid/lp/scripts/process3body.pl %s/moilr.3body.%d.vtrans > %s/coarse3body%d"
			, tmpdir,procid,tmpdir,procid);
		ret=system(buf);	*out << buf << "\t" << ret << endl; out->flush();
		
		sprintf(buf,"cat %s/coarse3body%d | sort -n > %s/sortedcoarse3body%d"
			,tmpdir,procid,tmpdir,procid);
		ret=system(buf);	*out << buf << "\t" << ret << endl; out->flush();
		
		sprintf(buf,"python /proj/ravid/zlab/merge3bodyandrest.py %s/sortedcoarse3body%d %s/sorted.%d.vtrans > %s/moilr.c3body.%d.vtrans"
			,tmpdir,procid,tmpdir,procid,tmpdir,procid);
		ret=system(buf);	*out << buf << "\t" << ret << endl; out->flush();

		// assemble results
		if(procid == 0){
			for(int i=1;i<numprocs;i++)
				MPI_Recv(buf, 1024, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &stat);
				
			stringstream ss (stringstream::in | stringstream::out);
			ss << "cat ";
			for(int i=0;i<numprocs;i++)
				ss << string(tmpdir) << "/moilr.c3body."<< i << ".vtrans ";
			ss << "> " << string(tmpdir) << "/moilr.c3body.vtrans";
			ss.getline(buf,1024*1024);
			ret=system(buf);	cout << buf << "\t" << ret << endl; cout.flush();
				
			sprintf(buf,"gzip %s/moilr.c3body.vtrans",tmpdir);
			ret=system(buf);	cout << buf << "\t" << ret << endl; cout.flush();
				
			sprintf(buf,"cp %s/moilr.c3body.vtrans.gz .",tmpdir);
			ret=system(buf);	cout << buf << "\t" << ret << endl; cout.flush();
		} else {
			sprintf(buf,"scp %s/moilr.c3body.%d.vtrans %s:/%s/ ; sleep 30s",tmpdir,procid,hosts[0]->c_str(),tmpdir);
			int attempt=1;
			do {
				ret=system(buf);	*out << attempt << " " << buf << "\t" << ret << endl; out->flush();
			} while(ret != 0 && attempt++<=20);
			MPI_Ssend(buf, 1024, MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
		}
		
		MPI_Finalize();
		
		if(procid == 0)	cout << "done" << endl;
		
		return 0;
	} else {
		cout << "init failed" << endl;
		return 1;
	}
}
