/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include <mpi.h>
#include <iostream>
using namespace std;

int main(int argc, char *argv[]){
	int procid, numprocs;
	int ret = MPI_Init(&argc,&argv);
	if(ret == MPI_SUCCESS){
		MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
		MPI_Comm_rank(MPI_COMM_WORLD,&procid);
				
		if(procid == 0){
			cout << "Job running on " << numprocs << " processors" << endl;
			cout << "#args " << argc << endl;
			cout.flush();
		}
		
		while(1);
		
		MPI_Finalize();
		
		if(procid == 0)
			cout << "done" << endl;
		
		return 0;
	} else {
		cout << "init failed" << endl;
		return 1;
	}
}
