#include "object.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];

#define SPACED_ROTATIONS "232020.euler"
float **rot_angles;

/*
 * Arguments: transformationfile transformationid ligandpdbid ligandchains gridsize
 */
int main(int argc, char *argv[]){
	out = &cout;
	read_molecule_config();
	read_dock_config();
	
	fstream transin(argv[1],ios::binary|ios::in);
	*out << argv[1] << " " << transin.good() << endl;
	
	Complex *c = new Complex(("../"+string(argv[3])).c_str(),argv[4], PDB);
	long tid = atol(argv[2]);
	int gridsize;// = atoi(argv[5]);
	
	string filename = string(getenv(string("HOME").c_str())) + "/" + string(DOCK_DIR) + string(SPACED_ROTATIONS);
	fstream frotations(filename.c_str());
	int num_rotations;
    while(frotations.good()){
    	frotations.getline(buf,8192);
    	if(frotations.gcount() > 0)
    		num_rotations++;
    }
	rot_angles = (float**) malloc(sizeof(float*)*num_rotations);
	for(int i = 0 ; i < num_rotations; i++)	rot_angles[i] = (float*) malloc(sizeof(float)*3);
    
    frotations.clear();
    frotations.seekg(ios_base::beg);
    num_rotations=0;
    while(frotations.good()){
    	frotations.getline(buf,8192);
    	if(frotations.gcount() > 0){
    		stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
			ss >> rot_angles[num_rotations][0];
			ss >> rot_angles[num_rotations][1];
			ss >> rot_angles[num_rotations][2];
			num_rotations++;
    	}
    }
    frotations.close();
	
	unsigned short transbinasize = 2*(sizeof(float)+sizeof(unsigned int));
	// transformation id starts with 0 and they are in increasing order of id
	if(transin.good()){
		transin.seekg(tid*transbinasize,ios::beg);
		transin.read(buf,transbinasize);
		if(transin.gcount() > 0){
			float atomp, evdw;
			unsigned int translation, rotindex;
			char *current = buf;
			memcpy(&atomp,current,sizeof(float));
			current += sizeof(float);
			memcpy(&evdw,current,sizeof(float));
			current += sizeof(float);
			memcpy(&translation,current,sizeof(unsigned int));
			current += sizeof(unsigned int);
			memcpy(&rotindex,current,sizeof(unsigned int));
			current += sizeof(unsigned int);
			
			Transformation *tr = new Transformation(rot_angles[rotindex][0],rot_angles[rotindex][1], rot_angles[rotindex][2],0);
	
			c->compute_motions();
			float minx, maxx, miny, maxy, minz, maxz, maxr;
			int aindex = 0;
			Vector center = Vector(c->center);
			for(int i = 0 ; i < c->num_atoms; i++){
				Atom *a = c->atom[i];
				Vector v = *(a->position) - center;	// set grid_origin such that it is independent of rotation
				//Vector v = tr->transform(*(a->position) - center);
				if(aindex++ == 0){
					minx = maxx = v.x;
					miny = maxy = v.y;
					minz = maxz = v.z;
					maxr = a->radius;
				}
				
				maxx = (v.x > maxx)? v.x : maxx;
				minx = (v.x < minx)? v.x : minx;
				maxy = (v.y > maxy)? v.y : maxy;
				miny = (v.y < miny)? v.y : miny;
				maxz = (v.z > maxz)? v.z : maxz;
				minz = (v.z < minz)? v.z : minz;
				maxr = (a->radius > maxr) ? a->radius : maxr;
			}
		
			float grid_spacing=1.20;
			float spread = 2*maxr + 2*probe_radius + c->diameter + 10.0;
			float xextent = maxx - minx, yextent = maxy - miny, zextent = maxz - minz;
			float maxextent = max(xextent, (max(yextent,zextent)));
			int maxsize = ceil((spread+maxextent)/grid_spacing); 
			if(maxsize%2 == 1)	maxsize++;
			gridsize = maxsize; 
			*out << "extent " << xextent << " " << yextent << " " << zextent << " max r " << maxr << " " << gridsize << endl; out->flush();
			
			Vector *grid_origin = new Vector(minx-spread/2.0,miny-spread/2.0,minz-spread/2.0);
			
			float x = translation/(gridsize*gridsize);
			float y = ((translation/gridsize) % gridsize);
			float z = (translation % gridsize);
				
			if(x >= gridsize/2)	x = x - gridsize;
			if(y >= gridsize/2)	y = y - gridsize;
			if(z >= gridsize/2)	z = z - gridsize;	
			
			//*(tr->translation) = *(ligand->c->center) +tr->inverse_transform(*(ligand->grid_origin) - (Vector(-x,-y,-z)*grid_spacing + *(receptor->grid_origin) + *(receptor->c->center)));
	
			*(tr->translation) = *(c->center) +tr->inverse_transform(*(grid_origin) - (Vector(-x,-y,-z)*grid_spacing + *(grid_origin) + *(c->center)));
			tr->print_details(out,TN_BASIC);
			
			Reference_Frame* rf_invtr = Reference_Frame::invert(tr);
			Transformation *invtr = new Transformation(new Vector(rf_invtr->translation), new Vector(rf_invtr->ex), new Vector(rf_invtr->ey), 1.0, 0, 0);	
			invtr->print_details(out,TN_BASIC);
			
			stringstream ss (stringstream::in | stringstream::out);
			ss << "tlc" << tid << ".pdb";
			string s; ss >> s;
			tr->write_as_pdb(c, "-", false, s, true);
		}
	}
	transin.close();
}