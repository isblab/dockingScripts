/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "molecule.hpp"
#include "sasautil.hpp"
#include <sys/stat.h>

ostream *out;
char scratch_dir[512], command[8192], buf[8192];
extern char *tmp_dir;

/*
 * Arguements : pdbid proteinchains rna/dna chains
 */
int main(int argc, char *argv[]){
	out = &cout;	
	read_molecule_config(NA);
	read_dock_config();
	
	string prot_chains = string(argv[2]);
	string nuc_chains = string(argv[3]);
	string chains = prot_chains + nuc_chains;
	
	Complex* c = new Complex(argv[1],chains.c_str(), PDB);
	Complex *cp = new Complex(argv[1],prot_chains, PDB);
	Complex *cn = new Complex(argv[1],nuc_chains, PDB);		
	
	c->compute_volume_sasa(false,false);
	cp->compute_volume_sasa(false,false);
	cn->compute_volume_sasa(false,false);
	
	hash_map<int , float , hash<int>,eqint> delta_sasa;
	for(int i = 0; i < cp->num_monomers; i++){
		Monomer *am = cp->monomer[i];
		Monomer *ac = ((Protein*)c->molecules[am->chain])->aminoacid[am->index.c_str()];
		
		float delta_sa = am->sa - ac->sa;
		if(delta_sa > 0 && am->type >= 0)
			delta_sasa[am->type] += delta_sa;
	}

	for(int i = 0; i < cn->num_monomers; i++){
		Monomer *am = cn->monomer[i];
		Monomer *ac = ((NucleicAcid*)c->molecules[am->chain])->nucleotide[am->index.c_str()];
		
		float delta_sa = am->sa - ac->sa;
		if(delta_sa > 0 && am->type >= 0)
			delta_sasa[am->type] += delta_sa;
	}
	
	float eVdw = 0, eVdw_repulsion = 0;
	for(int lmindex = 0; lmindex < c->num_monomers; lmindex++){
		Monomer *lm = c->monomer[lmindex];
		if(prot_chains.find(lm->chain) != string::npos){
			Aminoacid *la = (Aminoacid*) lm; 
			for(int rmindex = 0; rmindex < c->num_monomers; rmindex++){
				Monomer *rm = c->monomer[rmindex];
				if(nuc_chains.find(rm->chain) != string::npos){
					Nucleotide *rn = (Nucleotide*) rm; 
					 for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator laitr = la->atom.begin(); laitr != la->atom.end(); laitr++){
						Atom *al = (Atom *) laitr->second;
						for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator raitr = rn->atom.begin(); raitr != rn->atom.end(); raitr++){
							Atom *ar = (Atom *) raitr->second;
							float d2 = Vector::distance_squared(al->position,ar->position);
									
							if(d2 < ATOM_SMTHP_DCUTOFF_SQUARED)							
							{	
								float factor = 0;
								float d_scaled = sqrt(d2/(3.2*ar->sigma));
								factor = VDW_ATTR(d_scaled);
								if(factor > 0){
									// 6-12 factor = 4 * a->sqrt_eps * ar->sigma_cubed * factor;
									factor = 4 * ar->sqrt_eps * factor;
									eVdw += factor * al->sqrt_eps;
								} else {
									factor = VDW_REPUL(d_scaled);
									factor = 4 * ar->sqrt_eps * factor;
									eVdw_repulsion += factor * al->sqrt_eps;
								}	
							}
						}
					}
		 		}
			}
		}	
	}
	cout << "eVdw " << eVdw << " repulsion " << eVdw_repulsion << endl;

	cout << "changes in surface area:" << endl;
		
#define OUTPUT_SASA_PER_RESIDUE
#ifdef 	OUTPUT_SASA_PER_RESIDUE
	cout << "protein part" << endl;
	for(int i = 0; i < cp->num_monomers; i++){
		Monomer *am = cp->monomer[i];
		Monomer *ac = ((Protein*)c->molecules[am->chain])->aminoacid[am->index.c_str()];
		
		float delta_sa = am->sa - ac->sa;
		cout << am->name << " " << am->index << " " << am->chain << " " << delta_sa << endl;
	}
	cout << "nucleic acid part" << endl;
	for(int i = 0; i < cn->num_monomers; i++){
		Monomer *am = cn->monomer[i];    
		Monomer *ac = ((NucleicAcid*)c->molecules[am->chain])->nucleotide[am->index.c_str()];
		
		float delta_sa = am->sa - ac->sa;
		cout << am->name << " " << am->index << " " << am->chain << " " << delta_sa << endl;
	}
#endif

	float sum = 0;
	for(hash_map<int , float , hash<int>,eqint>::iterator itr = delta_sasa.begin(); itr != delta_sasa.end(); itr++){
		int type = itr->first;
		float dsasa = itr->second;
		sum += dsasa;
		cout << type << " " << dsasa << endl;
	}
	cout << "sum " << sum << endl;
}

