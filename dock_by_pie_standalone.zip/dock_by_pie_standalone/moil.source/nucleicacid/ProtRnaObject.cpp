#include "object.hpp"

ProtRnaObject::ProtRnaObject(Complex *c, Complex *cH) : Object(c,cH) {
}

void ProtRnaObject::compute_detailed_scores_protrna(ProtRnaObject* ligand, Transformation *tr){
	ProtRnaDetailedScoringMetrics* dscores = new ProtRnaDetailedScoringMetrics();
	tr->detailed_scores = dscores;
	tr->compute_coordinates((void *)this, (void *)ligand);

	compute_prot_rna_energy_approx1(this,ligand,tr,dscores);

	tr->sEvolution_interface = tr->eVdw_repulsion;
}

/*
 * Compute residue pairs in contact
 */
void ProtRnaObject::compute_prot_rna_energy_approx1(ProtRnaObject *receptor, ProtRnaObject *ligand, Transformation *tr, ProtRnaDetailedScoringMetrics *details){
	int num_residue_types = NUM_RESIDUE_TYPES;
	for(int i = 0; i < num_residue_types; i++)
		for(int j = 0 ; j < NUM_RNA_PARTICLE_TYPES; j++)
			details->coarse_contacts[i][j] = 0;

	// compute vdw features
	Vector zero = Vector(0,0,0);
	GridCell *rcell, *lcell;
	tr->num_clashes = tr->num_bbclashes = 0;
	tr->eVdw_repulsion = tr->eVdw = 0.0;
	for(int li = 0; li < ligand->c->num_atoms; li++){
		Atom * al = ligand->c->atom[li];
		Vector vl = tr->inverse_transform(*(al->position));

		if((al->name).c_str()[0] != 'H'){
			rcell = receptor->access_point_in_grid(&(vl),&zero);
			Vector v = vl - *(receptor->grid_origin);
			int cellx = (int) (v.x/GRID_SPACING);
			int celly = (int) (v.y/GRID_SPACING);
			int cellz = (int) (v.z/GRID_SPACING);

			if(cellx >= 0 && cellx < receptor->grid_num_xdivisions && celly >= 0 && celly < receptor->grid_num_ydivisions && cellz >= 0 && cellz < receptor->grid_num_zdivisions){
				unsigned int index = (ATOM_NEIGHBOR_GS_BY_GS*(cellx/ATOM_NEIGHBOR_GS_BY_GS)*receptor->grid_num_ydivisions + ATOM_NEIGHBOR_GS_BY_GS*(celly/ATOM_NEIGHBOR_GS_BY_GS))*receptor->grid_num_zdivisions + ATOM_NEIGHBOR_GS_BY_GS*(cellz/ATOM_NEIGHBOR_GS_BY_GS);

				if(receptor->grid[index] != NULL){
					GridCell *coarse_cell = receptor->grid[index];

					// compute atom neighbors
					unsigned short* atom_neighbors[2];
					atom_neighbors[0] = coarse_cell->atom_overlap_neighbors;
					atom_neighbors[1] = coarse_cell->atom_contact_neighbors;
					int num_atom_neighbors[2];
					num_atom_neighbors[0] = coarse_cell->num_atom_overlap_neighbors;
					num_atom_neighbors[1] = coarse_cell->num_atom_contact_neighbors;
					for(unsigned short anli = 0; anli < 2; anli++)
						if(atom_neighbors[anli] != NULL)
							for(int ani = 0; ani < num_atom_neighbors[anli]; ani++){
								int racindex = atom_neighbors[anli][ani];
								Atom *ar = receptor->c->atom[racindex];
								ar->sasa_complex = 0;

								float d2 = Vector::distance_squared(vl,*(ar->position));
#ifdef 	STEP_POTENTIAL
								if(d2 < ATOM_STEPP_DCUTOFF_SQUARED)
#endif
#ifdef LINEAR_SPLINE_POTENTIAL
								if(d2 < ATOM_SMTHP_DCUTOFF_SQUARED)
#endif
								{
									float factor = 0;
									//float d6_inv = 1.0/(d2 * d2 * d2);
									//factor = (1.0 - 32.768 * ar->sigma_cubed * d6_inv)* d6_inv;
									float d_scaled = sqrt(d2/(3.2*ar->sigma));
									factor = VDW_ATTR(d_scaled);
									if(factor > 0){
										// 6-12 factor = 4 * a->sqrt_eps * ar->sigma_cubed * factor;
										factor = 4 * ar->sqrt_eps * factor;
										tr->eVdw += factor * al->sqrt_eps;
										//cout << tr->frame_number << " eVdw " << tr->eVdw << endl;

									} else {
										factor = VDW_REPUL(d_scaled);
										factor = 4 * ar->sqrt_eps * factor;
										tr->eVdw_repulsion += factor * al->sqrt_eps;
									}
							}
							if(d2 < ATOM_CLASH_CUTOFF_SQUARED){
								tr->num_clashes++;
								if(al->isbbatom && ar->isbbatom && d2 < BBATOM_CLASH_CUTOFF_SQUARED)
									tr->num_bbclashes++;
							}
						}
				}
			}
		}
	}

	// residue contacts
	{
		for(int laindex = 0; laindex < ligand->c->num_monomers; laindex++){
			Monomer *mmer = ligand->c->monomer[laindex];
			if(mmer->type > 0){
				Nucleotide *nal = (Nucleotide*) mmer;

				if(nal->type >= 0){
					// nucleotide residue contacts (centroid centroid)
					//*out << laindex << " " << nal->name << " " << nal->index << " " << nal->centroid << endl;
					if(nal->centroid != NULL){
						Vector vl = tr->inverse_transform(*(nal->centroid));
						for(int raindex = 0; raindex < receptor->c->num_aminoacids; raindex++){
							Aminoacid *ar = receptor->c->aminoacid[raindex];
							float d, d2, factor=0,nfactor;
							bool contact=false;

							if(ar->type >= 0 && ar->centroid != NULL){
								d2 = Vector::distance_squared(vl,*(ar->centroid));
								//*out << ar->name << " " << ar->index << " " << d2 << endl;
								if(d2 < RA_SMTHP_CUTOFF_SQUARED){
									contact=true;
									if(d2 < RA_CUTOFF_SQUARED)	factor = 1.0;
									else{ float d=sqrt(d2);	factor = RA_SMTHP_FACTOR(d); }
								}
							}

							if(contact){
								short ratype=ar->type, latype=-1;
								if(nal->type == RA)	latype = 2;
								if(nal->type == RU)	latype = 3;
								if(nal->type == C)	latype = 4;
								if(nal->type == G)	latype = 5;

								//*out << tr->frame_number << " contact " << ratype << " " << latype << " " << nal->name << " " << factor << endl;
								if(ratype >= 0 && latype>= 0)
									details->coarse_contacts[ratype][latype] += factor;
				 			}
						}
				 	}

				 	// phosphate residue contacts
				 	if(nal->phosphate != NULL){
						Vector vl = tr->inverse_transform(*(nal->phosphate->position));
						for(int raindex = 0; raindex < receptor->c->num_aminoacids; raindex++){
							Aminoacid *ar = receptor->c->aminoacid[raindex];
							float d, d2, factor=0,nfactor;
							bool contact=false;

							// nucleotide residue contacts (centroid centroid)
							if(ar->type >= 0 && ar->centroid != NULL){
								d2 = Vector::distance_squared(vl,*(ar->centroid));
								if(d2 < PA_SMTHP_CUTOFF_SQUARED){
									contact=true;
				 					if(d2 < PA_CUTOFF_SQUARED)	factor = 1.0;
									else{ float d=sqrt(d2);	factor = PA_SMTHP_FACTOR(d); }
								}
							}

							if(contact){
								short ratype=ar->type, latype=nal->type;
								if(ratype >= 0 && latype>= 0)
									details->coarse_contacts[ratype][0] += factor;
				 			}
						}
				 	}

				 	// sugar residue contacts
				 	if(nal->sugar_centroid != NULL){
						Vector vl = tr->inverse_transform(*(nal->sugar_centroid));
						for(int raindex = 0; raindex < receptor->c->num_aminoacids; raindex++){
							Aminoacid *ar = receptor->c->aminoacid[raindex];
							float d, d2, factor=0,nfactor;
							bool contact=false;

							// nucleotide residue contacts (centroid centroid)
							if(ar->type >= 0 && ar->centroid != NULL){
								d2 = Vector::distance_squared(vl,*(ar->centroid));
								if(d2 < SUGA_SMTHP_CUTOFF_SQUARED){
									contact=true;
									if(d2 < SUGA_CUTOFF_SQUARED)	factor = 1.0;
									else{ float d=sqrt(d2);	factor = SUGA_SMTHP_FACTOR(d); }
								}
							}

							if(contact){
								short ratype=ar->type, latype=nal->type;
								if(ratype >= 0 && latype>= 0)
									details->coarse_contacts[ratype][1] += factor;
							}
						}
					}
				}
			}
		}
	}
}

void ProtRnaObject::build_fft_prot_rna_bkbn_centroid_potential_grid_protein(float grid_spacing, MKL_Complex8 **fftgrid, unsigned short num_prot_particle_types,
 unsigned short num_rna_particle_types, float **potential, MKL_LONG *gridsize, Reference_Frame *tr){
	unsigned int size = gridsize[0] * gridsize[1] * gridsize[2];
	for(int ti = 0; ti < (num_rna_particle_types+1)/2; ti++)
		for(int i = 0; i < size; i++)
			(fftgrid[ti][i]).real = (fftgrid[ti][i]).imag = 0.0;

	Vector center = Vector(c->center);

	int nummarkings=0;
	for(int i = 0 ; i < c->num_aminoacids; i++){
		Aminoacid *aa = c->aminoacid[i];

	   //*out << "check aa " << aa->index << endl; out->flush();
		for(int napi = 0; napi < 3; napi++){
			Vector *v = NULL;
			short particle_type;
			v = (aa->centroid);
			particle_type = aa->type;
			if(particle_type >= 0 && particle_type < num_prot_particle_types && v != NULL){
				Vector taposition = tr->transform(*v - center) - *grid_origin;
				int vx = (int) (taposition.x/grid_spacing);
				int vy = (int) (taposition.y/grid_spacing);
				int vz = (int) (taposition.z/grid_spacing);

				float radius;
				switch(napi){
					case 0:
						radius = RA_SMTHP_CUTOFF;
					break;
					case 1:
						radius = PA_SMTHP_CUTOFF;
						break;
					case 2:
						radius = SUGA_SMTHP_CUTOFF;
						break;

				}

				float radius_squared = radius*radius;

				int minx,maxx,miny,maxy,minz,maxz;
				minx = maxx = vx;
				miny = maxy = vy;
				minz = maxz = vz;

				int level = 0;
				bool intersects_surface = true;
				while(intersects_surface){
					intersects_surface = false;
					bool intersectsxmin,intersectsxmax,intersectsymin,intersectsymax,intersectszmin,intersectszmax;
					for(int x = minx; x <= maxx; x++){
						for(int y = miny; y <= maxy; y++){
							for(int z = minz; z <= maxz; z++){
								Vector corner_000 = Vector( (((float) x) )*grid_spacing, (((float) y) )*grid_spacing, (((float) z) )*grid_spacing);
							//	Vector grid_center = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) + 0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing);
								bool intersects_cell = false;
								if( x == minx || x == maxx || y == miny || y == maxy || z == minz || z == maxz ){
									float d,d2,d_2;
									intersects_cell = ((d2 = Vector::distance_squared(taposition,corner_000)) <= radius_squared) || (level == 0);
									intersects_surface = intersects_surface || intersects_cell;

									if(intersects_cell){
										unsigned int index = (x*gridsize[1] + y)*gridsize[2] + z;
										float factor = 1.0;
										bool contact = false;
										float d=sqrt(d2);

										if(napi == 0){
											factor = 0.0;

											if(d2 < RA_SMTHP_CUTOFF_SQUARED){
												contact=true;
												if(d2 < RA_CUTOFF_SQUARED)	factor = 1.0;
												else{ float d=sqrt(d2);	factor = RA_SMTHP_FACTOR(d); }
											}
											for(int tj = 0; tj < 4; tj++){
												float score_contributed = potential[particle_type][tj] * factor;
												if(tj%2 == 0)
													fftgrid[tj/2+1][index].real += score_contributed;
												else
													fftgrid[tj/2+1][index].imag += score_contributed;
											}
										} else if(napi == 1){
											short tj = 0;
											if(d2 < PA_SMTHP_CUTOFF){
												contact=true;
												if(d2 < PA_SMTHP_CUTOFF)	factor = 1.0;
												else{ float d=sqrt(d2);	factor = PA_SMTHP_FACTOR(d); }
												float score_contributed = potential[particle_type][tj] * factor;
												fftgrid[tj/2][index].real += score_contributed;
											}

										} else if(napi == 2){
											short tj = 1;
											if(d2 < SUGA_SMTHP_CUTOFF_SQUARED){
												contact=true;
												if(d2 < SUGA_SMTHP_CUTOFF_SQUARED)	factor = 1.0;
												else{ float d=sqrt(d2);	factor = SUGA_SMTHP_FACTOR(d); }
												float score_contributed = potential[particle_type][tj] * factor;
												fftgrid[tj/2][index].imag += score_contributed;
											}
										}

										nummarkings++;

										if( x == minx)
											intersectsxmin = true;
										if( x == maxx)
											intersectsxmax = true;
										if( y == miny)
											intersectsymin = true;
										if( y == maxy)
											intersectsymax = true;
										if( z == minz)
											intersectszmin = true;
										if( z == maxz)
											intersectszmax = true;
									}
								}
							}
						}
					}
					if(intersectsxmin && minx > 0)
						minx--;
					if(intersectsxmax && maxx < gridsize[0] - 1)
						maxx++;
					if(intersectsymin && miny > 0)
						miny--;
					if(intersectsymax && maxy < gridsize[1] - 1)
						maxy++;
					if(intersectszmin && minz > 0)
						minz--;
					if(intersectszmax && maxz < gridsize[2] - 1)
						maxz++;

					level++;
				}
			}
		}
	}
	*out << "build fft protein rna potential grid #additional markings " << nummarkings << endl;
}

void ProtRnaObject::build_fft_prot_rna_bkbn_centroid_potential_grid_rna(float grid_spacing, MKL_Complex8 **fftgrid, unsigned short num_rna_particle_types,
 float **potential, MKL_LONG *gridsize, Reference_Frame *tr){
	unsigned int size = gridsize[0] * gridsize[1] * gridsize[2];
	for(int ti = 0; ti < (num_rna_particle_types+1)/2; ti++)
		for(int i = 0; i < size; i++)
			(fftgrid[ti][i]).real = (fftgrid[ti][i]).imag = 0.0;

	Vector center = Vector(c->center);

	int nummarkings=0;
	for(int i = 0; i < c->num_monomers; i++){
		Monomer *mmer = c->monomer[i];
		if(mmer->type > 0){
			Nucleotide *nal = (Nucleotide*) mmer;

			for(int napi = 0; napi < 3; napi++){
				Vector *v = NULL;
				short particle_type=-1;

				switch(napi){
					case 0 :
						v = (nal->centroid);
						if(nal->type == RA)	particle_type = 2;
						if(nal->type == RU)	particle_type = 3;
						if(nal->type == C)	particle_type = 4;
						if(nal->type == G)	particle_type = 5;
						break;
					case 1 :
						if(nal->phosphate != NULL)
							v = (nal->phosphate->position);
						particle_type = 0;
						break;
					case 2:
						if(nal->sugar_centroid != NULL)
							v = (nal->sugar_centroid);
						particle_type = 1;
						break;
				}

				if(particle_type >= 0 && particle_type < num_rna_particle_types && v != NULL){
					Vector taposition = tr->transform(*v - center) - *grid_origin;
					int vx = (int) (taposition.x/grid_spacing);
					int vy = (int) (taposition.y/grid_spacing);
					int vz = (int) (taposition.z/grid_spacing);

					float radius;
					switch(napi){
						case 0:
							radius = RA_SMTHP_CUTOFF;
						break;
						case 1:
							radius = PA_SMTHP_CUTOFF;
							break;
						case 2:
							radius = SUGA_SMTHP_CUTOFF;
							break;

					}

					radius=0;
					float radius_squared = radius*radius;

					int minx,maxx,miny,maxy,minz,maxz;
					minx = maxx = vx;
					miny = maxy = vy;
					minz = maxz = vz;

					int level = 0;
					bool intersects_surface = true;
					while(intersects_surface){
						intersects_surface = false;
						bool intersectsxmin,intersectsxmax,intersectsymin,intersectsymax,intersectszmin,intersectszmax;
						for(int x = minx; x <= maxx; x++){
							for(int y = miny; y <= maxy; y++){
								for(int z = minz; z <= maxz; z++){
									Vector corner_000 = Vector( (((float) x) )*grid_spacing, (((float) y) )*grid_spacing, (((float) z) )*grid_spacing);
								//	Vector grid_center = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) + 0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing);
									bool intersects_cell = false;
									if( x == minx || x == maxx || y == miny || y == maxy || z == minz || z == maxz ){
										float d,d2,d_2;
										intersects_cell = ((d2 = Vector::distance_squared(taposition,corner_000)) <= radius_squared) || (level == 0);
										intersects_surface = intersects_surface || intersects_cell;

										if(intersects_cell){
											unsigned int index = (x*gridsize[1] + y)*gridsize[2] + z;
											float factor = 1.0;

											// trilinear interpolate
											{
												Vector v = taposition * (1.0/grid_spacing);
												float wx[2],wy[2],wz[2];
												wx[0] = x+1.0 - v.x;
												wx[1] = v.x - x;
												wy[0] = y+1.0 - v.y;
												wy[1] = v.y - y;
												wz[0] = z+1.0 - v.z;
												wz[1] = v.z - z;

												for(int cci =0; cci <=1; cci++)
													for(int ccj =0; ccj <=1; ccj++)
														for(int cck =0; cck <=1; cck++){
															int nx = (x+cci)% gridsize[0];
															int ny = (y+ccj)% gridsize[1];
															int nz = (z+cck)% gridsize[2];
															unsigned int nindex = (nx*gridsize[1] + ny)*gridsize[2] + nz;
															float nfactor = factor *wx[cci]*wy[ccj]*wz[cck];
															if(particle_type %2 == 0)
																fftgrid[particle_type/2][nindex].real += nfactor;
															else
																fftgrid[particle_type/2][nindex].imag += nfactor;
														}
											}

											nummarkings++;

											if( x == minx)
												intersectsxmin = true;
											if( x == maxx)
												intersectsxmax = true;
											if( y == miny)
												intersectsymin = true;
											if( y == maxy)
												intersectsymax = true;
											if( z == minz)
												intersectszmin = true;
											if( z == maxz)
												intersectszmax = true;
										}
									}
								}
							}
						}
						if(intersectsxmin && minx > 0)
							minx--;
						if(intersectsxmax && maxx < gridsize[0] - 1)
							maxx++;
						if(intersectsymin && miny > 0)
							miny--;
						if(intersectsymax && maxy < gridsize[1] - 1)
							maxy++;
						if(intersectszmin && minz > 0)
							minz--;
						if(intersectszmax && maxz < gridsize[2] - 1)
							maxz++;

						level++;
					}
				}
			}
		}
	}
	*out << "build fft protein rna potential grid #additional markings " << nummarkings << endl;
}

