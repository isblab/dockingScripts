/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "dock_util.hpp"
#include "fftdock_util.hpp"

#define VDW_OPLS_APPROX

// the interior and intermediate clash penalties are very sensitive to grid_spacing used
//float grid_spacing=FFT_GRID_SPACING*1.2;

float grid_spacing=FFT_GRID_SPACING*1.6;

#define NUM_FFT_ATOM_TYPES 18
//#define NUM_FFT_ATOM_TYPES 20
#define NUM_FFT_ATOM_EIGENVECTORS 8


#ifdef SEPARATE_VDW_ATTR_REPUL
MKL_Complex8 *rec_shape_attr, *rec_shape_repul, *lig_shape_attr, *lig_shape_repul;
#endif

// rec_particlepfft has the fourier transforms for atom neighbor grids (one each)
// lig_particlepgrid contains fft computed for pairs of atom types 
short looplength=0;

DFTI_DESCRIPTOR_HANDLE fft_desc_handle;
MKL_LONG mkl_status;

// Shape complementarity scores can be cast as convolutions by either flipping the functions or by using ifts
bool flip=true;

//unsigned int max_transformations=1024*1024*4;
unsigned int max_transformations=1024*128*4;

transformationscore *work0, *work1;
unsigned int merge_output_index=0;
bool symmetrictrimer=false;

bool transscore_bettervdw(transformationscore t1,transformationscore t2){
	//return(t1.index < t2.index);
#ifdef SEPARATE_VDW_ATTR_REPUL
	return(t1.evdw_attr > t2.evdw_attr);
#else
	return(t1.evdw > t2.evdw);
#endif
}

bool transscore_bettercontactp(transformationscore t1,transformationscore t2){
	return(t1.particlep > t2.particlep);
}

bool transscore_bettersum(transformationscore t1,transformationscore t2){
	return(t1.score > t2.score);
}

bool (*transscore_better)(transformationscore t1,transformationscore t2) = &transscore_bettervdw;

extern float **atom18_potential, **atom20_potential, vdw_weight;
extern void coarsen_atomtypesto18();
extern void coarsen_atomtypesto20();
float ***particle_potential, **atomp_eigen_vector, *atomp_eigen_value;

float **prot_rna_potential;

void read_potential(){
	prot_rna_potential = (float**) malloc(NUM_RESIDUE_TYPES*sizeof(float*));
	for(int j = 0 ; j < NUM_RESIDUE_TYPES; j++)
		prot_rna_potential[j] = (float*) malloc(NUM_RNA_PARTICLE_TYPES*sizeof(float));

	int line=0;
	char buf[8192];
	string filename = "/junior/ravid/pierna/iterative_learn/vdw_res_sug_contacts1/potential";
	fstream fresidue_bkbn(filename.c_str(), ios::in);
	while(fresidue_bkbn.good()){
		fresidue_bkbn.getline(buf,8192);
		if(fresidue_bkbn.gcount() > 0){
			stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
			if(line == 0){
				string tag;	ss >> tag;
				ss >> vdw_weight;
				vdw_weight = 0.0-vdw_weight;
			} else {
				int aa, na;
				ss >> aa; ss >> na;
				float value;
				ss >> value;
				prot_rna_potential[aa][na] = 0-value;
				if(procid == 0)
					cout << aa << " " << na << " " << value << endl;
			}
			line=line+1;
		}
	}
	fresidue_bkbn.close();

	particle_potential = &prot_rna_potential;
}


void match_rotation(unsigned int rotation_index, Transformation *tr){
	*out << "rotationtr " << lig_shape << " "; tr->print_details(out,TN_BASIC);
	
	// build grid on the ligand
#ifdef VDW_OPLS_APPROX
	ligand->build_fft_opls_vdw_grid(grid_spacing,receptor->c->diameter, &lig_shape,gridsize, tr, false);
#else	
	ligand->build_fft_vdw_grid(grid_spacing, receptor->c->diameter,&lig_shape,gridsize, tr, false);
#endif	
	//write_tofile(lig_shape,"ligand");
	
	// fft
	mkl_status = DftiComputeForward(fft_desc_handle, lig_shape);
	if(mkl_status != DFTI_NO_ERROR){
		*out << rotation_index << " fft " << DftiErrorMessage(mkl_status) << endl; out->flush();
	}
	
	//cout << "state " << state << endl;
	if(state==FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP){
		switch(state){
			case FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP:
				((ProtRnaObject*) ligand)->build_fft_prot_rna_bkbn_centroid_potential_grid_rna(grid_spacing, lig_particlepgrid,NUM_RNA_PARTICLE_TYPES,prot_rna_potential,gridsize, tr);
				break;
		}
		
		for(int ti = 0; ti < num_particlep_arrays; ti++){
			mkl_status = DftiComputeForward(fft_desc_handle, lig_particlepgrid[ti]);
			if(mkl_status != DFTI_NO_ERROR)
				*out << rotation_index << " fft " << ti << " " << DftiErrorMessage(mkl_status) << endl;
		}
	}
	//write_tofile(lig_shape,"ligandfft");

	float real_fourier, imag_fourier;
	
	// product
	//*out << "computing product " << endl; out->flush();
	for(int i = 0; i < size; i++){
		// combined attractive and repulsive parts of vdw interaction
		{
			real_fourier = rec_shape[i].real*lig_shape[i].real - rec_shape[i].imag*lig_shape[i].imag;
			imag_fourier = rec_shape[i].real*lig_shape[i].imag + rec_shape[i].imag*lig_shape[i].real;
			lig_shape[i].real = real_fourier;
			lig_shape[i].imag = imag_fourier;
		}
			
		if(state==FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP){
			short n=0;
			switch(state){
				case FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP:
					n=3;
					break;
			}
			
			MKL_Complex8 lig[n];
			
			int z = (i % gridsize[2]) ;
			int y = ((i / gridsize[2]) % gridsize[1]) ;
			int x = i/(gridsize[2] * gridsize[1]) ;
			
			int xi = (gridsize[0] - x) % gridsize[0];
			int yi = (gridsize[1] - y) % gridsize[1];
			int zi = (gridsize[2] - z) % gridsize[2];
			
			unsigned int iinv = (xi*gridsize[1] + yi)*gridsize[2] + zi;
			
			for(int j=0; j< n; j++){
				if(j%2 == 0){
					lig[j].real = (lig_particlepgrid[j/2][i].real + lig_particlepgrid[j/2][iinv].real)/2;
					lig[j].imag = (lig_particlepgrid[j/2][i].imag - lig_particlepgrid[j/2][iinv].imag)/2;
				} else {
					float a,b;
					a = (lig_particlepgrid[j/2][i].real - lig_particlepgrid[j/2][iinv].real)/2;
					b = (lig_particlepgrid[j/2][i].imag + lig_particlepgrid[j/2][iinv].imag)/2;
					
					// need to multiply by -sqrt(-1) or divide by i
					lig[j].real = b;
					lig[j].imag = -a;
				}
			}
		
			float rsum=0,isum=0;
			if(state==FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP){
				/*/ if computing contacts
				for(int j=0; j< n; j++)
					for(int k=0; k< n; k++){
						rsum += (rec_particlepfft[j][i].real*lig[k].real - rec_particlepfft[j][i].imag*lig[k].imag)*(*particle_potential)[j][k];
						isum += (rec_particlepfft[j][i].imag*lig[k].real + rec_particlepfft[j][i].real*lig[k].imag)*(*particle_potential)[j][k];
					}*/
					
				// if computing potentials
				for(int j=0; j< n; j++){
					rsum += (rec_particlepfft[j][i].real*lig[j].real - rec_particlepfft[j][i].imag*lig[j].imag);
					isum += (rec_particlepfft[j][i].imag*lig[j].real + rec_particlepfft[j][i].real*lig[j].imag);
				}
			}
			
			particlep_sum[i].real = rsum;
			particlep_sum[i].imag = isum;
		}
	}
	//*out << "computed product " << endl; out->flush();
	//write_tofile(lig_shape,"convfft");
				
	// ift
	mkl_status = DftiComputeBackward(fft_desc_handle, lig_shape);
	if(mkl_status != DFTI_NO_ERROR)
		*out << rotation_index << " ift " << DftiErrorMessage(mkl_status) << endl;
	
	if(state==FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP){
		mkl_status = DftiComputeBackward(fft_desc_handle, particlep_sum);
		if(mkl_status != DFTI_NO_ERROR)
			*out << rotation_index << " ift particlep " << DftiErrorMessage(mkl_status) << endl;
	}
	//write_tofile(lig_shape,"conv");
	
	// collect scores
	float grid_spacing_cubed = grid_spacing*grid_spacing*grid_spacing;
	float size_inv = 1.0/size;
	for(unsigned int index = 0; index < size; index++){
		rotation_scores[index].index = index;
#ifdef VDW_OPLS_APPROX	
		rotation_scores[index].evdw_real = lig_shape[index].real*size_inv;	
		rotation_scores[index].evdw = lig_shape[index].real*size_inv + lig_shape[index].imag*size_inv;
		rotation_scores[index].evdw_imag = lig_shape[index].imag*size_inv;
#else
		rotation_scores[index].evdw_real = lig_shape[index].real*grid_spacing_cubed*size_inv;
		rotation_scores[index].evdw = (lig_shape[index].real - lig_shape[index].imag)*grid_spacing_cubed*size_inv;
		rotation_scores[index].evdw_imag = (0-lig_shape[index].imag)*grid_spacing_cubed*size_inv;
#endif		
		
		rotation_scores[index].rotindex = rotation_index;
		
		if(state==FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP){
			rotation_scores[index].particlep = particlep_sum[index].real * size_inv;
			rotation_scores[index].score = rotation_scores[index].particlep + rotation_scores[index].evdw*vdw_weight;
			
			//cout << rotation_index << " " << index << " " << rotation_scores[index].particlep << " " << rotation_scores[index].evdw << endl;
		}
	}
	
	/* this setting is very important in docking */
	float min_vdw_repulsion;
	// when grid_spacing is 1 INTERIOR_ATOM_SPREAD=1, INTERMEDIATE_IMAG=3 and INTERIOR_IMAG=8 and the factor is 140 the max clashes is 30 and average is around 8
	//min_vdw_repulsion = -(0.75*160 + 20)*INTERMEDIATE_IMAG*INTERMEDIATE_IMAG;
	
	// when grid_spacing is 1 and the factor is 320 the max clashes is 60 and the average is around 20
	min_vdw_repulsion = -(320)*INTERMEDIATE_IMAG*INTERMEDIATE_IMAG;
	//min_vdw_repulsion = -(120)*INTERMEDIATE_IMAG*INTERMEDIATE_IMAG;
	
	/* remove structures that do not touch or form heavy clashes
	 * 	doing this by setting the particlepscore to a very low value for filtered transforms */
	unsigned int num_removed=0, num_filtered=0;
	vector<transformationscore> filtered_transformations;
	
	//{
		for(unsigned int i = 0; i < size; i++){
			bool remove=false;
#ifdef VDW_OPLS_APPROX
			if(!(rotation_scores[i].evdw > 0 && (ABS(rotation_scores[i].evdw_real) > 0.5 || ABS(rotation_scores[i].evdw_imag) > 0.5)))
#else
			if(!(rotation_scores[i].evdw > min_vdw_repulsion && (ABS(rotation_scores[i].evdw_real) > 0.5 || ABS(rotation_scores[i].evdw_imag) > 0.5)))
#endif
			{
				rotation_scores[i].score = rotation_scores[i].evdw = rotation_scores[i].particlep = -1000000.0;
				remove=true;
#ifdef LOOP_CONSTRAINT
			} else if(looplength>0){
				*(tr->translation) = get_translation(&(rotation_scores[i]), tr);
				if(!chain_continuous(receptor->c,ligand->c,tr,true,looplength)){
					rotation_scores[i].score = rotation_scores[i].evdw = rotation_scores[i].particlep = -1000000.0;
					remove=true;
				} else {
					// get an improved lower bound on obstacle avoiding distance
					
				}
#endif							
			}
			if(remove)	num_removed++;
			else {
				filtered_transformations.push_back(rotation_scores[i]);
				num_filtered++;
			}
		}
	//}
		
	//sort(&rotation_scores[0], &rotation_scores[0] + size, transscore_better);
	sort(filtered_transformations.begin(),filtered_transformations.end(),transscore_better);
	
	transformationscore *current_inputarray,*current_outputarray;
	if(merge_output_index %2 == 0){
		current_outputarray = work0;
		current_inputarray = work1;
	} else {
		current_outputarray = work1;
		current_inputarray = work0;
	}
	merge_output_index++;
	//*out << work0 << " " << work1 << " " << current_inputarray << " " << current_outputarray << endl;
	
	merge( &(current_inputarray)[0], &(current_inputarray)[0] + min(max_transformations,num_node_transforms), 
		filtered_transformations.begin(),filtered_transformations.end(), &(current_outputarray)[0], transscore_better);
	
	num_node_transforms = min(num_node_transforms+num_filtered,max_transformations);
	node_result = current_outputarray;
	
	generation_stats[0] += size;
	generation_stats[1] += num_filtered;
	*out << "done rotation " << rotation_index << " " << num_removed << " " << num_filtered << " " << num_node_transforms << endl;
}

/*
 * node 0 arbitrates the distribution, no semaphores for now
 * 1 proc, it generates everything, > 1, node 0 does not generate anything
 */
void generate_transformations(int rotstart, int rotend){
    hash_set<int,hash<int>,eqint> missing;
    /*fstream fmissing("presentbitmap");
    while(fmissing.good()){
    	fmissing.getline(buf,8192);
    	if(fmissing.gcount() > 0){
    		stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
			int rotation, present;
			ss >> rotation;
			ss >> present;
			if(present == 0)	missing.insert(rotation);
    	}
    }
    fmissing.close();*/
	
	int start;
	node_transformations.clear();
	
	for(int i = 0; i < NUM_GENERATION_STATS; i++)	generation_stats[i] = 0;
	
	rotstart = max(rotstart,0);
	rotend = min(rotend,num_rotations);
	
	if(procid == 0){
		int nummissing=0;
		for(int i = rotstart; i < rotend; i++)
			if(missing.count(i) > 0)	nummissing++;
		cout << "total# missing rotations " << missing.size() << " in range " << nummissing << endl;
		
		if(numprocs == 1){
			for(int i=rotstart; i< rotend; i++){
				match_rotation( i );
			}
			
			// write node transforms to file
			write_nodetransforms_tofile(state,NULL);
			pieces[0] = num_node_transforms;
		} else {
			cout << "rotstart " << rotstart << " rotend " << rotend << endl;
			int current = rotstart;
			bool node_done[numprocs];
			for(int i = 1; i < numprocs; i++)	node_done[i] = false;
			bool done = false;
						
			while(!done){
				// receive a token and send work
				MPI_Recv(buff, BUFSIZE, MPI_CHAR, MPI_ANY_SOURCE, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
				int node = atoi(buff);
				
				sprintf(buff, "%d", current);
				MPI_Ssend(buff, 256, MPI_CHAR, node, GENERATE_TAG, MPI_COMM_WORLD);
				
				// ended the computation at the node
				if(current >= rotend)	node_done[node] = true;
				
				*out << "node " << node << " working on " << current << " " << node_done[node] << endl; out->flush();
				
				current = current + 1;
				if(current %1000 == 0){
					time(&current_time);
					cout << "at rotation " << current << " time " <<  difftime(current_time,start_time) << endl; cout.flush();
				}
				
				done = true;
				for(int i = 1; i < numprocs; i++)	done &= node_done[i];
			}
			
			cout << "finished assigning ids for matching" << endl;
		}
	} else {
		bool done = false;
		while(!done){
			sprintf(buff, "%d",procid);
			MPI_Ssend(buff, 256, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD);
			MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
			start = atoi(buff);
			if(start >= rotend){
				done = true;
				break;
			} else {
			  //if(missing.count(start) > 0)
				match_rotation( start );
			}
		}
		write_nodetransforms_tofile(state,NULL);
		pieces[0] = num_node_transforms;
	}
	
	time(&current_time);
	*out << "node " << procid << " generated transformations # " << num_node_transforms << "\t time:"
		<< difftime(current_time,start_time) << "s" << endl; out->flush();
}


void process_receptor(){
	// what is the target grid size
	rec_shape = NULL;
	gridsize[0] = gridsize[1] = gridsize[2] = 0;
	Transformation *identity = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);

#ifdef VDW_OPLS_APPROX
	receptor->build_fft_opls_vdw_grid(grid_spacing,  ligand->c->diameter,&rec_shape,gridsize, identity, true);
	//if(procid == 0)	
	//	receptor->fft_check_opls_vdw_accuracy(grid_spacing, rec_shape_attr, gridsize);
#else
	receptor->build_fft_vdw_grid(grid_spacing, ligand->c->diameter,&rec_shape,gridsize, identity, true);
#endif	
		
	size = gridsize[0] * gridsize[1] * gridsize[2];
	*out << "gridsize " << gridsize[0] << "," << gridsize[1] << "," << gridsize[2] << " " << rec_shape << endl;
	if(procid == 0)	cout << "grid spacing used " << grid_spacing << " size " << size << endl;
	
	if(flip){
		float tmpgrid[gridsize[0]][gridsize[1]][gridsize[2]][2];
		for(int i =0; i < gridsize[0]; i++)
			for(int j =0; j < gridsize[1]; j++)
				for(int k =0; k < gridsize[2]; k++){
					unsigned int index = (i*gridsize[1] + j)*gridsize[2] + k;
					tmpgrid[i][j][k][0] = rec_shape[index].real;
					tmpgrid[i][j][k][1] = rec_shape[index].imag;
				}
		
		for(int i =0; i < gridsize[0]; i++)
			for(int j =0; j < gridsize[1]; j++)
				for(int k =0; k < gridsize[2]; k++){
					int xi = (gridsize[0] - i) % gridsize[0];
					int yi = (gridsize[1] - j) % gridsize[1];
					int zi = (gridsize[2] - k) % gridsize[2];
					
					unsigned int index = (xi*gridsize[1] + yi)*gridsize[2] + zi;
					rec_shape[index].real = tmpgrid[i][j][k][0];
					rec_shape[index].imag = tmpgrid[i][j][k][1];
				}
	}
	
	mkl_status = DftiCreateDescriptor( &fft_desc_handle, DFTI_SINGLE, DFTI_COMPLEX, 3, gridsize );
	*out << DftiErrorMessage(mkl_status) << endl;
	mkl_status = DftiSetValue( fft_desc_handle, DFTI_PLACEMENT, DFTI_INPLACE );
	*out << DftiErrorMessage(mkl_status) << endl;
	
	strides[0]=0;
	strides[1]=gridsize[1]*gridsize[2];
	strides[2]=gridsize[2];
	strides[3]=1;
	/*mkl_status = DftiSetValue( fft_desc_handle, DFTI_INPUT_STRIDES, strides);
	*out << DftiErrorMessage(mkl_status) << endl;*/
	
	mkl_status = DftiCommitDescriptor(fft_desc_handle);
	*out << DftiErrorMessage(mkl_status) << endl;
	if(flip){
		//write_tofile(rec_shape,"recshape");
		mkl_status = DftiComputeForward(fft_desc_handle, rec_shape);
		*out << "receptor flip fft " << DftiErrorMessage(mkl_status) << endl;
		/*write_tofile(rec_shape,"recshapei");
		DftiComputeBackward(fft_desc_handle, rec_shape);
		write_tofile(rec_shape,"recshapefi");*/
	} else {
		mkl_status = DftiComputeBackward(fft_desc_handle, rec_shape);
		*out << "receptor ift " << DftiErrorMessage(mkl_status) << endl;
	}
	
	/*write_tofile(rec_shape,"receptorrift");
	mkl_status = DftiComputeForward(fft_desc_handle, rec_shape);
	*out << DftiErrorMessage(mkl_status) << endl;
	write_tofile(rec_shape,"receptorrfi");
	receptor->build_fft_vdw_grid(grid_spacing, ligand->c->diameter,&rec_shape,gridsize, identity, true);
	mkl_status = DftiComputeBackward(fft_desc_handle, rec_shape);
	*out << DftiErrorMessage(mkl_status) << endl;*/
	
	sqrt_size = sqrt(size);
	if(start_state == FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP){
		switch(state){
			case FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP:
				num_particlep_arrays = 3;
				break;
		}
			
		*out << "num_particlep_arrays " << num_particlep_arrays << endl;
		lig_particlepgrid = (MKL_Complex8 **) malloc(sizeof(MKL_Complex8 *) * num_particlep_arrays);
		for(int ti = 0; ti < num_particlep_arrays; ti++)
			lig_particlepgrid[ti] = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
		*out << "allocated space " << endl; out->flush();
			
		// use the ligand grid for computation
		switch(state){
			case FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP:
				read_potential();
				((ProtRnaObject*) receptor)->build_fft_prot_rna_bkbn_centroid_potential_grid_protein(grid_spacing, lig_particlepgrid,22,NUM_RNA_PARTICLE_TYPES , prot_rna_potential,gridsize,identity);
				break;
		}
		
		if(flip){
			float tmpgrid[gridsize[0]][gridsize[1]][gridsize[2]][2];
			for(int ti = 0; ti < num_particlep_arrays; ti++){
				for(int i =0; i < gridsize[0]; i++)
					for(int j =0; j < gridsize[1]; j++)
						for(int k =0; k < gridsize[2]; k++){
							unsigned int index = (i*gridsize[1] + j)*gridsize[2] + k;
							tmpgrid[i][j][k][0] = lig_particlepgrid[ti][index].real;
							tmpgrid[i][j][k][1] = lig_particlepgrid[ti][index].imag;
						}
				
				for(int i =0; i < gridsize[0]; i++)
					for(int j =0; j < gridsize[1]; j++)
						for(int k =0; k < gridsize[2]; k++){
							int xi = (gridsize[0] - i) % gridsize[0];
							int yi = (gridsize[1] - j) % gridsize[1];
							int zi = (gridsize[2] - k) % gridsize[2];
							
							unsigned int index = (xi*gridsize[1] + yi)*gridsize[2] + zi;
							lig_particlepgrid[ti][index].real = tmpgrid[i][j][k][0];
							lig_particlepgrid[ti][index].imag = tmpgrid[i][j][k][1];
						}
			}
		}
		
		for(int ti = 0; ti < num_particlep_arrays; ti++){
			if(flip){
				mkl_status = DftiComputeForward(fft_desc_handle, lig_particlepgrid[ti]);
				*out << "particlep flipped fft " << ti << " " << DftiErrorMessage(mkl_status) << endl;
			} else {
				mkl_status = DftiComputeBackward(fft_desc_handle, lig_particlepgrid[ti]);
				*out << "particlep ift " << ti << " " << DftiErrorMessage(mkl_status) << endl;
			}
		}
		
		int n=0;
		switch(state){
			case FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP:
				n = 3;
				break;
		}
			
		rec_particlepfft = (MKL_Complex8 **) malloc(sizeof(MKL_Complex8 *) * n);
		for(int ti = 0; ti < n; ti++)
			rec_particlepfft[ti] = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
		
		for(int i = 0; i < size; i++){
			MKL_Complex8 rec[n];
			
			int z = (i % gridsize[2]);
			int y = ((i / gridsize[2]) % gridsize[1]) ;
			int x = i/(gridsize[2] * gridsize[1]) ;
			
			int xi = (gridsize[0] - x) % gridsize[0];
			int yi = (gridsize[1] - y) % gridsize[1];
			int zi = (gridsize[2] - z) % gridsize[2];
			
			unsigned int iinv = (xi*gridsize[1] + yi)*gridsize[2] + zi;
			for(int j=0; j< n; j++){
				if(j%2 == 0){
					rec_particlepfft[j][i].real = (lig_particlepgrid[j/2][i].real + lig_particlepgrid[j/2][iinv].real)/2;
					rec_particlepfft[j][i].imag = (lig_particlepgrid[j/2][i].imag - lig_particlepgrid[j/2][iinv].imag)/2;
				} else {
					float a,b;
					a = (lig_particlepgrid[j/2][i].real - lig_particlepgrid[j/2][iinv].real)/2;
					b = (lig_particlepgrid[j/2][i].imag + lig_particlepgrid[j/2][iinv].imag)/2;
					
					// need to multiply by -sqrt(-1) or divide by i
					rec_particlepfft[j][i].real = b;
					rec_particlepfft[j][i].imag = -a;
				}
			}
		}
		
		*out << "computed particlep ifts for receptor" << endl; out->flush();
	}
	
	lig_shape = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
	
	particlep_sum = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
	rotation_scores = (transformationscore *) malloc(sizeof(transformationscore) * size);
	work0 = (transformationscore *) malloc(sizeof(transformationscore) * (size+max_transformations));
	work1 = (transformationscore *) malloc(sizeof(transformationscore) * (size+max_transformations));
}


void verify_prot_rna_transformations(){
	*out << "verify transformations " << node_transformations.size() << endl;
	
	int max_num_atoms = receptor->c->num_atoms + ligand->c->num_atoms;
	bool interface_capridefn=true, use_all_bbatom_for_rmsd=true;
	
	Vector reference_points[max_num_atoms+1], model_points[max_num_atoms+1], ligand_points[max_num_atoms+1];
	int point_index = 0;
	for(int i = 0; i < receptor->c->num_aminoacids; i++){
	 	Aminoacid *aa = receptor->c->aminoacid[i];
	 	{
	 	 	Aminoacid *aa_ref = aa;
			
			if(aa->atom.count("N") > 0 && aa_ref->atom.count("N") > 0 && use_all_bbatom_for_rmsd){
				reference_points[point_index] = Vector(aa_ref->atom["N"]->position);
				model_points[point_index] = Vector(aa->atom["N"]->position);
				point_index++;
			} 
			if(aa->atom.count("CA") > 0 && aa_ref->atom.count("CA") > 0){
				reference_points[point_index] = Vector(aa_ref->atom["CA"]->position);
				model_points[point_index] = Vector(aa->atom["CA"]->position);
				point_index++;
			} 
			if(aa->atom.count("C") > 0 && aa_ref->atom.count("C") > 0 && use_all_bbatom_for_rmsd){
				reference_points[point_index] = Vector(aa_ref->atom["C"]->position);
				model_points[point_index] = Vector(aa->atom["C"]->position);
				point_index++;
			} 
			if(aa->atom.count("O") > 0 && aa_ref->atom.count("O") > 0 && use_all_bbatom_for_rmsd){
				reference_points[point_index] = Vector(aa_ref->atom["O"]->position);
				model_points[point_index] = Vector(aa->atom["O"]->position);
				point_index++;
			}
			
			if(aa->centroid != NULL && aa_ref->centroid != NULL){
				reference_points[point_index] = Vector(aa_ref->centroid);
				model_points[point_index] = Vector(aa->centroid);
				point_index++;
			}
	 	}
	}
	int ligand_start = point_index;
	
	for(int i = 0; i < ligand->c->num_monomers; i++){
		Monomer *rm = ligand->c->monomer[i];
		if(rm->type > 0){
			Nucleotide *rn = (Nucleotide*) rm; 
	 	
	 	 	Nucleotide *rn_ref = rn;
			
			if(rn->atom.count("P") > 0 && rn_ref->atom.count("P") > 0){
				reference_points[point_index] = Vector(rn_ref->atom["P"]->position);
				ligand_points[point_index - ligand_start] = Vector(rn->atom["P"]->position);
				point_index++;
			}
			
			if(rn->centroid != NULL && rn_ref->centroid != NULL){
				reference_points[point_index] = Vector(rn_ref->centroid);
				ligand_points[point_index - ligand_start] = Vector(rn->centroid);
				point_index++;
			}
	 	}
	}
	int num_ligand_points = point_index - ligand_start;

	Transformation *receptor_orig_to_ref = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
	float rrmsd_ref_vs_orig = compute_rmsd(ligand_start, &reference_points[0], &model_points[0], receptor_orig_to_ref);
	
	Transformation *ligand_orig_to_ref = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0, 0);
	float lrmsd_ref_vs_orig = compute_rmsd(num_ligand_points, &reference_points[ligand_start], &ligand_points[0], ligand_orig_to_ref);
	
	if(procid == 0){
		cout << "rmsd ref_vs_orig " << rrmsd_ref_vs_orig << " lig_vs_orig " << lrmsd_ref_vs_orig << endl;
	}
	
	int count=0;
	hash_set<long,hash<long>,eqlong> reference_interface_contacts;
	hash_set<long,hash<long>,eqlong> reference_interface_contacts_capri;
	Vector ref_interface_points[max_num_atoms+1], reflig_interface_points[max_num_atoms+1];;
	int num_refrec_interface_points, num_reflig_interface_points;
	
	{	
		for(int i = 0; i < receptor->c->num_aminoacids; i++){
		 	Aminoacid *ra = receptor->c->aminoacid[i];
		 	{
		 		for(int j = 0; j < ligand->c->num_monomers; j++){
		 			Monomer *mmer = ligand->c->monomer[j];
					if(mmer->type > 0){
						Nucleotide *ln = (Nucleotide*) mmer; 
				 		long cindex = (ra->cindex)*MAX_ATOMS + ln->cindex;
				 		
				 		Vector vca, vcd;
				 		if(ln->centroid != NULL){
				 			vcd = Vector(ln->centroid);
				 		}
				 		if(ln->phosphate != NULL){
				 			vca = Vector(ln->phosphate->position);
				 		}
				 		
				 		if((ra->centroid != NULL && ln->centroid != NULL && (Vector::distance_squared(ra->centroid,vcd) < RA_CUTOFF_SQUARED)) ||
				 		  (ra->centroid != NULL && ln->phosphate != NULL && (Vector::distance_squared(ra->centroid,vca) < PA_CUTOFF_SQUARED))){
				 			reference_interface_contacts.insert(cindex);
				 		}
				 		
					 	// defining the interface used for computing irmsd
					 	for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator raitr = ra->atom.begin(); raitr != ra->atom.end(); raitr++){
					 		Atom *ratom = (Atom *) raitr->second;
					 		if(ratom->name.c_str()[0] != 'H'){
					 			for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator laitr = ln->atom.begin(); laitr != ln->atom.end(); laitr++){
					 				Atom *latom = (Atom *) laitr->second;
					 				if(latom->name.c_str()[0] != 'H'){
							 			Vector v = Vector(*(latom->position));
									 			
						 				if(Vector::distance(*(ratom->position), v) <= CAPRI_INTERFACE_CUTOFF){
						 					reference_interface_contacts_capri.insert(cindex);
						 		   		}
					 				}
					 			}
					 		}
					 	}
				 	}
				}
		 	}
		}
		
		hash_set<long,hash<long>,eqlong> *ref_interface_contacts;
		if(interface_capridefn) 	
			ref_interface_contacts = &(reference_interface_contacts_capri);
		else
			ref_interface_contacts = &(reference_interface_contacts);
		
		hash_set<int,hash<int>,eqint> added_ligand_residue, added_receptor_residue;
		num_refrec_interface_points =  num_reflig_interface_points = 0;
		for(hash_set<long,hash<long>,eqlong>::iterator itr = ref_interface_contacts->begin(); itr != ref_interface_contacts->end(); itr++){
			long index = *itr;
			int refrindex = index/MAX_ATOMS;
			int reflindex = index % MAX_ATOMS;
				
			if(added_receptor_residue.count(refrindex) == 0){
				added_receptor_residue.insert(refrindex);
					
				Aminoacid *aa = receptor->c->aminoacid[refrindex];
				Aminoacid *aa_ref = aa;	
				
				if(aa->atom.count("N") > 0 && aa_ref->atom.count("N") > 0 && use_all_bbatom_for_rmsd){
					ref_interface_points[num_refrec_interface_points++] = Vector(aa_ref->atom["N"]->position);
				} 
				if(aa->atom.count("CA") > 0 && aa_ref->atom.count("CA") > 0){
					ref_interface_points[num_refrec_interface_points++] = Vector(aa_ref->atom["CA"]->position);
				} 
				if(aa->atom.count("C") > 0 && aa_ref->atom.count("C") > 0 && use_all_bbatom_for_rmsd){
					ref_interface_points[num_refrec_interface_points++] = Vector(aa_ref->atom["C"]->position);
				} 
				if(aa->atom.count("O") > 0 && aa_ref->atom.count("O") > 0 && use_all_bbatom_for_rmsd){
					ref_interface_points[num_refrec_interface_points++] = Vector(aa_ref->atom["O"]->position);
				}
				
				if(aa->centroid != NULL && aa_ref->centroid != NULL){
					ref_interface_points[num_refrec_interface_points++] = Vector(aa_ref->centroid);
				}
			}
			if(added_ligand_residue.count(reflindex) == 0){
				added_ligand_residue.insert(reflindex);
				
				Monomer *rm = ligand->c->monomer[reflindex];
				if(rm->type > 0){
					Nucleotide *rn = (Nucleotide*) rm; 
	 	 			Nucleotide *rn_ref = rn;
				
					if(rn->atom.count("P") > 0 && rn_ref->atom.count("P") > 0){
						reflig_interface_points[num_reflig_interface_points++] = Vector(rn_ref->atom["P"]->position);
					}
					
					if(rn->centroid != NULL && rn_ref->centroid != NULL){
						reflig_interface_points[num_reflig_interface_points++] = Vector(rn_ref->centroid);
					}
				}
			}
		}
		
		// add ligand interface points at the end of ref_interface_points
		for(int i = 0;i < num_reflig_interface_points; i++){
			ref_interface_points[num_refrec_interface_points+i] = reflig_interface_points[i];
		}
	}
	
	// collect the points corresponding to the interface
	Vector receptor_interface_points[max_num_atoms+1];
	Vector ligand_interface_points[max_num_atoms+1];
	int num_receptor_interface_points,num_ligand_interface_points;
	{
		hash_set<long,hash<long>,eqlong> *ref_interface_contacts;
		if(interface_capridefn) 	
			ref_interface_contacts = &(reference_interface_contacts_capri);
		else
			ref_interface_contacts = &(reference_interface_contacts);
		
		num_receptor_interface_points = 0;
		num_ligand_interface_points = 0;
		
		hash_set<int,hash<int>,eqint> added_ligand_residue, added_receptor_residue;
		// assuming that the hash_set iterator lists elements in the same order every time
		for(hash_set<long,hash<long>,eqlong>::iterator itr = ref_interface_contacts->begin(); itr != ref_interface_contacts->end(); itr++){
			long index = *itr;
			int refrindex = index/MAX_ATOMS;
			int reflindex = index % MAX_ATOMS;
				
			if(added_receptor_residue.count(refrindex) == 0){
				added_receptor_residue.insert(refrindex);
				
				Aminoacid *aa = receptor->c->aminoacid[refrindex];
				Aminoacid *aa_ref = aa;
				
				if(aa->atom.count("N") > 0 && aa_ref->atom.count("N") > 0 && use_all_bbatom_for_rmsd){
					receptor_interface_points[num_receptor_interface_points++] = Vector(aa->atom["N"]->position);
				} 
				if(aa->atom.count("CA") > 0 && aa_ref->atom.count("CA") > 0){
					receptor_interface_points[num_receptor_interface_points++] = Vector(aa->atom["CA"]->position);
				} 
				if(aa->atom.count("C") > 0 && aa_ref->atom.count("C") > 0 && use_all_bbatom_for_rmsd){
					receptor_interface_points[num_receptor_interface_points++] = Vector(aa->atom["C"]->position);
				} 
				if(aa->atom.count("O") > 0 && aa_ref->atom.count("O") > 0 && use_all_bbatom_for_rmsd){
					receptor_interface_points[num_receptor_interface_points++] = Vector(aa->atom["O"]->position);
				}
				
				if(aa->centroid != NULL && aa_ref->centroid != NULL){
					receptor_interface_points[num_receptor_interface_points++] = Vector(aa->centroid);
				}
			}
			if(added_ligand_residue.count(reflindex) == 0){
				added_ligand_residue.insert(reflindex);
				
				Monomer *rm = ligand->c->monomer[reflindex];
				if(rm->type > 0){
					Nucleotide *rn = (Nucleotide*) rm; 
	 	 			Nucleotide *rn_ref = rn;
				
					if(rn->atom.count("P") > 0 && rn_ref->atom.count("P") > 0){
						ligand_interface_points[num_ligand_interface_points++] = Vector(rn->atom["P"]->position);
					}
					
					if(rn->centroid != NULL && rn_ref->centroid != NULL){
						ligand_interface_points[num_ligand_interface_points++] = Vector(rn->centroid);
					}
				}
			}
		}
	}
	
	short ref_num_contacts;
	/*if(interface_capridefn)	ref_num_contacts = (reference_interface_contacts_capri.size()>0?reference_interface_contacts_capri.size():1);
		else*/ ref_num_contacts = (reference_interface_contacts.size()>0?reference_interface_contacts.size():1);
	
	Transformation *reference_tr;
	Reference_Frame *receptor_ref_to_orig = Reference_Frame::invert(receptor_orig_to_ref);
	Vector reftr_ligandcm;
	{
		Reference_Frame *rf = new Reference_Frame((Reference_Frame*) ligand_orig_to_ref);
		rf = Reference_Frame::compose(receptor_ref_to_orig,rf);
		
		rf = Reference_Frame::invert(rf);
		reference_tr = new Transformation(rf->translation, rf->ex, rf->ey, rf->scale, 0, 0);
		reftr_ligandcm = reference_tr->inverse_transform(*(ligand->c->center_of_mass));
	}
	
	// process transformations
	
	bool compute_contact_metrics = true; //false;
	float rmsd, lrmsd,irmsd;
	short num_native_contacts_predicted, num_contacts;
	for(vector<Transformation*>::iterator titr = node_transformations.begin(); titr != node_transformations.end(); titr++){
		Transformation *tr = *titr;
		tr->vmetrics = new VerificationMetrics();
		*out << tr->frame_number << " ";
		
		// convert vector representation to matrix representation
		float U[3][3], translation[3];
		tr->ex->toarray(U[0]);
		tr->ey->toarray(U[1]);
		tr->ez->toarray(U[2]);
		tr->translation->toarray(translation);
		
		{			
			Vector model_interface_points[max_num_atoms+1];
			for(int i = 0 ; i < num_receptor_interface_points; i++)
				model_interface_points[i] = receptor_interface_points[i];
			for(int i = 0 ; i < num_ligand_interface_points; i++)
				model_interface_points[i+num_receptor_interface_points] = tr->inverse_transform(ligand_interface_points[i]);
				
			irmsd = compute_rmsd(num_receptor_interface_points+num_ligand_interface_points, ref_interface_points, &model_interface_points[0]);
		}
		
		*out << "|" << irmsd << "| ";
		
		for(int i = 0; i < num_ligand_points; i++){
			point_index = ligand_start + i;
		 	model_points[point_index] = ligand_points[i];
				
			// dock transformation
			model_points[point_index] = tr->inverse_transform(model_points[point_index]);
				
			// computing L_rms transform ligand such that receptor is aligned
			//model_points[point_index] = receptor_orig_to_ref->transform(model_points[point_index]);
		}
		
		if(irmsd < 10.0){
			lrmsd = compute_lrmsd(ligand_start + num_ligand_points, ligand_start, reference_points,&model_points[0], &(rmsd));
		} else {
			rmsd = lrmsd = irmsd;
		}
		
		tr->vmetrics->rmsd = rmsd;
		tr->vmetrics->lrmsd = lrmsd;
		tr->vmetrics->irmsd = irmsd;
		
		// computing residue contacts is currently the most expensive step so do it on demand
		hash_set<long,hash<long>,eqlong> model_interface_contacts;
		if(compute_contact_metrics){
			hash_set<int,hash<int>,eqint> model_interface_receptor_residues, model_interface_ligand_residues;
			
			for(int i = 0; i < receptor->c->num_aminoacids; i++){
			 	Aminoacid *ra = receptor->c->aminoacid[i];
			 	{
			 		for(int j = 0; j < ligand->c->num_monomers; j++){
			 			Monomer *mmer = ligand->c->monomer[j];
						if(mmer->type > 0){
							Nucleotide *ln = (Nucleotide*) mmer; 
					 		long cindex = (ra->cindex)*MAX_ATOMS + ln->cindex;
					 		
					 		Vector vca, vcd;
					 		if(ln->centroid != NULL){
					 			vcd = tr->inverse_transform(ln->centroid);
					 		}
					 		if(ln->phosphate != NULL){
					 			vca = tr->inverse_transform(ln->phosphate->position);
					 		}
					 		
					 		if((ra->centroid != NULL && ln->centroid != NULL && (Vector::distance_squared(ra->centroid,vcd) < RA_CUTOFF_SQUARED)) ||
					 		  (ra->centroid != NULL && ln->phosphate != NULL && (Vector::distance_squared(ra->centroid,vca) < PA_CUTOFF_SQUARED))){
					 		  	model_interface_ligand_residues.insert(ln->cindex);
						 		model_interface_receptor_residues.insert(ra->cindex);
					 			model_interface_contacts.insert(cindex);
					 		}
					 	}
					}
			 	}
			}
		
			num_contacts = model_interface_contacts.size();
		
			num_native_contacts_predicted=0;
			for(hash_set<long,hash<long>,eqlong>::iterator itr = reference_interface_contacts.begin(); itr != reference_interface_contacts.end(); itr++){
				long index = *itr;	
				if(model_interface_contacts.count(index) > 0)	num_native_contacts_predicted++;
			}
			
			*out << num_native_contacts_predicted << " " << ref_num_contacts << endl;
			
			tr->vmetrics->frac_native_contacts_predicted = ((float)num_native_contacts_predicted)/ref_num_contacts;
			tr->vmetrics->frac_nonnative_contacts_predicted = ((float)(num_contacts - num_native_contacts_predicted))/num_contacts;
			tr->num_contacts = num_contacts;
		}
				
		Vector tr_ligandcm = tr->inverse_transform(*(ligand->c->center_of_mass));
		tr->distance(&(tr->vmetrics->delta_U),reference_tr);
		tr->vmetrics->delta_r = Vector::distance(reftr_ligandcm,tr_ligandcm);
		
		if(count++ % 100000 == 0)	*out << "verified " << count << endl;
	}
	
}

void examine_reference_protrna(){
	receptor->preprocess_receptor();
	
	Transformation *reftr = new Transformation(new Vector(0,0,0),new Vector(1,0,0), new Vector(0,1,0), 1.0,1,-1);
	
	node_transformations.push_back(reftr);
	verify_prot_rna_transformations();
	((ProtRnaObject*) receptor)->compute_detailed_scores_protrna((ProtRnaObject*)ligand,reftr);
	
	float num_contacts = 0;
	ProtRnaDetailedScoringMetrics *detailed_scores = (ProtRnaDetailedScoringMetrics*) reftr->detailed_scores;
	for(unsigned short i = 0; i < NUM_RESIDUE_TYPES; i++)
		for(unsigned short j = 0; j <NUM_RNA_PARTICLE_TYPES ; j++)
			if(i % NUM_RESIDUE_TYPES < 20)
				num_contacts += detailed_scores->coarse_contacts[i][j];
				
	cout << "scores " << reftr->num_contacts << " " << reftr->eVdw << " " << reftr->eVdw_repulsion
		<< " " << reftr->num_clashes << " contacts " << num_contacts 
		<< endl;
	
	//reftr->vmetrics->frac_native_contacts_predicted = 1.0;
	fstream rout;
	rout.open((string("reference.ascore")).c_str(), fstream::out);
	reftr->print_details(&rout,TN_PROTRNA_DETAILED_SCORE_VERIFY);
	rout.close();
}


int main(int argc, char *argv[]){
	time(&start_time);
	int ret = MPI_Init(&argc,&argv);
	if(ret == MPI_SUCCESS){
		MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
		MPI_Comm_rank(MPI_COMM_WORLD,&procid);
				
		if(procid == 0){
			cout << "Job running on " << numprocs << " processors" << endl;
			cout << "#args " << argc << endl;
			cout.flush();
		}
		
		read_molecule_config(NA);
		float atomp_vdw_weight;
		if(NUM_FFT_ATOM_TYPES == 18){
			coarsen_atomtypesto18();
			particle_potential = &atom18_potential;
			atomp_vdw_weight = vdw_weight;
		} else if(NUM_FFT_ATOM_TYPES == 20){
			coarsen_atomtypesto20();
			particle_potential = &atom20_potential;
			atomp_vdw_weight = vdw_weight;
		}
		read_dock_config();
		node_tmp_dir = (char*) (new string(string(tmp_dir)+"/"+string(getenv(string("JOB_ID").c_str()))))->c_str();
		
		elect_leader_on_node();
		
		//initialize
		refpdbcode = string(argv[9]);
		sprintf(command, "%s/cluster_scripts/setup.sh %s %d %s %d",getenv(string("HOME").c_str()),getenv(string("JOB_ID").c_str()),procid, refpdbcode.c_str(), masterprocessonnode);
		ret = system(command);
		
		sprintf(scratch_dir, "%s/%s/%d",node_tmp_dir,refpdbcode.c_str(),procid);
		sprintf(filename, "%s/%s/%sout%d",node_tmp_dir,refpdbcode.c_str(),refpdbcode.c_str(),procid);
		//cout << filename << endl; cout.flush();
		fstream outstream;
		outstream.open(filename,ios::out);
		if(!outstream.good()){
			cout << "ERROR: could not open file " << filename << " " << errno << "\n"; cout.flush();
			exit(-1);
		}
		out = &outstream;
		
		*out << procid << " " << *host << " am_master " << masterprocessonnode << endl;
		*out << "setup " << command << " " << ret << endl;
		
		filetype = atoi(argv[1]);
		docktype = atoi(argv[2]);
		start_state = atoi(argv[3]);
		end_state = atoi(argv[4]);
		*out << "start " << start_state << " end " << end_state << endl;out->flush();
		
		stringstream ss (stringstream::in | stringstream::out);
		string s;
		ss << argv[5] << "_" << argv[6] << "_vs_" << argv[7] << "_" << argv[8] << "fft";
		ss >> s;
		tag = (char*) (new string(s.c_str()))->c_str();
		
		ss.clear();
		string ts;
		ss << s << ".trans";
		ss >> ts;
		transformations_file = (char*) (new string(ts.c_str()))->c_str();
		sprintf(local_transformations_file,"%s/%s",scratch_dir,transformations_file);
		
		rpdbcode = string(argv[5]);
		rchains = string(argv[6]);
		lpdbcode = string(argv[7]);
		lchains = string(argv[8]);
		refrchains = string(argv[10]);
		reflchains = string(argv[11]);
		
		Complex* cr = new Complex(("../"+rpdbcode).c_str(),rchains.c_str(), filetype);
		Complex* crH =cr;
		out->flush();
		receptor = new ProtRnaObject(cr,crH);
		
		Complex* cl = new Complex(("../"+lpdbcode).c_str(),lchains.c_str(), filetype);
		Complex* clH = cl;
		ligand = new ProtRnaObject(cl, clH);
		
		if(start_state == FFT_GENERATE_MATCHES_VDW 
				|| start_state == FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP
		 ){
			if(start_state != FFT_GENERATE_MATCHES_VDW){
				//transscore_better = &transscore_bettercontactp;
				transscore_better = &transscore_bettersum;
			}
			if(start_state == FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP)
				particle_potential = &residue_bkbn_potential;
			
			state=start_state;
			process_receptor();
			pieces.clear();
			
			//*out << "generating " << endl;
			read_rotations();
	
    		generate_transformations(atoi(argv[12]),atoi(argv[13]));
    		
    		state = GENERATE_MATCHES;
			collect_transformations(true,max_transformations);
			if(procid == 0)	cout << "grid spacing used " << grid_spacing << " size " << size << " start state " << start_state << " vdw_weight " << vdw_weight << endl;
		}
		
		if(procid == 0 && (start_state == CLUSTER_TRANS_FINE || start_state == CLUSTER_TRANS_COARSE || 
		  start_state == CLUSTER_TRANS_IRMSD || start_state == CLUSTER_TRANS_FRAC_NAT )){
			state = start_state;
			examine_transformations();
			switch(state){
				case CLUSTER_TRANS_FINE :
					cluster_sorted_transformations(receptor, ligand, 0);
					break;
				case CLUSTER_TRANS_COARSE:
					cluster_sorted_transformations(receptor, ligand, 2);
					break;
			}
		}
		
		if(start_state == SELECT_TRANS && procid == 0){
			state = SELECT_TRANS;
			examine_transformations();
			select_transformations();
		}
		
		if(start_state == VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA || start_state == EXAMINE_REFERENCE){
			reference = new Complex(("../"+refpdbcode).c_str(),(refrchains+reflchains).c_str(),PDB);
			referenceH = reference; 
			reference->compute_motions();
		}
		
		if(start_state == VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA){
			state = VERIFY_TRANS;
			
			receptor->preprocess_receptor();
			
			examine_transformations();
			read_transformations();
			verify_prot_rna_transformations();
			state = VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA;
			collect_transformations_verify_trans(true,false);
		}
		
		if(start_state == EXAMINE_REFERENCE && procid == 0){
			state = EXAMINE_REFERENCE;
			examine_reference_protrna();
		}
		
		MPI_Finalize();
		//outstream.close();
		
		if(procid == 0){
			time(&current_time);
			cout << "done" << " " << success << "\t time:" << difftime(current_time,start_time) << "s" << endl;
		}
		
		return 0;
	} else {
		cout << "init failed" << endl;
		return 1;
	}
}
