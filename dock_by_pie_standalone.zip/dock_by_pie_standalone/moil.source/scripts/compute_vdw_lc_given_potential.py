import sys
import string
import commands

efilename = string.join(sys.argv[1:2],'')
efile=open(efilename, "r")
eline=""
lineno=0
while efile:
	line=efile.readline()
	if len(line) > 0 :
		lineno=lineno+1
		eline=eline+' '+line
	else :
		break
etoken=eline.split("\n")
efile.close()

ne=len(etoken)
if etoken[ne-1] == "" : 
	ne=len(etoken)-1

filename = string.join(sys.argv[2:3],'')
file = open(filename,"r")

start=45

while file:
        line = file.readline()
	token=line.split()
	n=len(token)
#	sys.stdout.write("%d " %(n) + "%d " %(ne))

	if n > 1:
		energy=float(etoken[0])*(float(token[21])-9*float(token[28]))
	for j in range(n):
		if (j>=start) and j < ne+start-1 :
			if float(etoken[j-start+1]) != 0 :
				energy = energy +float(token[j]) * float(etoken[j-start+1])
	if n > 1:
		sys.stdout.write("%f " % (energy))
		sys.stdout.write("%s " % (token[7]))
		sys.stdout.write("%s " % (token[2]))
		sys.stdout.write("%s " % (token[0]))
		sys.stdout.write("%s " % (token[23]))
		sys.stdout.write("%s " % (token[19]))
		sys.stdout.write("%s " % (token[20]))
		sys.stdout.write("%f " % (energy - float(etoken[0]) * (float(token[21])-9*float(token[28])) ))
#		sys.stdout.write("%f " % (float(token[21])-9*float(token[28])) )
		sys.stdout.write("\n")
	else :
		break
file.close()
			

