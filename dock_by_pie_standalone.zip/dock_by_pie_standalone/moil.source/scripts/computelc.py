import sys
import string
import commands

#efile=open("/proj2/ravid/variations/contacts/nocons_nozdtmintersect/ineqc.307.parameters","r")
#efile=open("/proj2/ravid/variations/sasacontacts//nocons_nozdtmintersect/ineqv.245.parameters","r")
efile=open("/proj2/ravid/param/43/ineq.307.parameters","r")
#efile=open("/proj2/ravid/param/48/ineq.327.parameters","r")
#efile=open("/proj/ravid/lp/scripts/skolnick/ineq.245.parameters","r")
eline=""
lineno=0
while efile:
	line=efile.readline()
	if len(line) > 0 :
		lineno=lineno+1
		if (lineno == 1) :
			eline=eline+" 0\n"
		if (lineno == 252) :
			eline=eline+" 0\n0\n"
		eline=eline+' '+line
	else :
		break
etoken=eline.split("\n")
efile.close()

ne=len(etoken)
if etoken[ne-1] == "" : 
	ne=len(etoken)-1

filename = string.join(sys.argv[1:2],'')
file = open(filename,"r")

while file:
        line = file.readline()
	token=line.split()
	n=len(token)
#	sys.stdout.write("%d " %(n) + "%d " %(ne))

	energy=0
	for j in range(n):
		if (j>=24) and j < ne+24 :
			if float(etoken[j-24]) != 0 :
				energy = energy +float(token[j]) * float(etoken[j-24])
	if n > 1:
		sys.stdout.write("%f " % (energy))
#		sys.stdout.write("%s " % (token[6]))
		sys.stdout.write("%s " % (token[7]))
		sys.stdout.write("%s " % (token[2]))
		sys.stdout.write("%s " % (token[0]))
		sys.stdout.write("\n")
	else :
		break
file.close()
			

