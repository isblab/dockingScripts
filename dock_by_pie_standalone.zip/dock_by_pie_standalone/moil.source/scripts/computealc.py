import sys
import string
import commands

#efile=open("/proj/ravid/lp/scripts/dars/dars.parameters","r")
efile=open("/proj2/ravid/param/31/ineqv.230.parameters","r")
eline=""
lineno=0
while efile:
	line=efile.readline()
	if len(line) > 0 :
		lineno=lineno+1
		eline=eline+' '+line
	else :
		break
etoken=eline.split("\n")
efile.close()

# sys.stdout.write("%d\n " % (len(etoken)))

cstart=394
filename = string.join(sys.argv[1:2],'')
file = open(filename,"r")

while file:
        line = file.readline()
	token=line.split()

	energy=0
	for j in range(len(token)):
		if (j>= cstart) and (j < cstart + 230) :
			if float(etoken[j-cstart]) != 0 :
#				sys.stdout.write("%d " %(j) + " %s " %(token[j]) + " %s\n" % (etoken[j-cstart]))
				energy = energy +float(token[j]) * float(etoken[j-cstart])
	if len(token) > 1:
		sys.stdout.write("%f " % (energy))
		sys.stdout.write("%s " % (token[7]))
		sys.stdout.write("%s " % (token[0]))
		sys.stdout.write("%s " % (token[1]))
#		sys.stdout.write("%s " % (token[21]))
#		sys.stdout.write("%s " % (token[24]))
#		sys.stdout.write("%s " % (token[23]))
		#sys.stdout.write("100 100\n")
		sys.stdout.write("\n")
	else :
		break
file.close()
			

