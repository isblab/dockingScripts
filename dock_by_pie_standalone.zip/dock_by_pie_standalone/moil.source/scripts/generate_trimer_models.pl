#!/usr/bin/perl

sysopen(ifile, @ARGV[0], O_RDONLY);

my @prot , @chain , @transfile, @scorelist;

$lineno=0;
while( $line = <ifile>) {
	$lineno = $lineno + 1;
	my @token = split(" ", $line);
	if($token[0] eq "Unit"){
#		print "$line $token[0]\n";
		$prot[int($token[1])] = $token[2];
		$chain[int($token[1])] = $token[3];
	} elsif($token[0] eq "Transfile"){
		$transfile[int($token[1])][int($token[2])] = $token[3];
	} elsif($token[0] eq "JoinedSelection"){
		$scorelist = $token[1];
	}
}
close(ifile);

# print "$prot[0] $chain[0]\n";

sysopen(lfile, @ARGV[1], O_RDONLY);
my $fromRes = int $ARGV[2];
my $toRes = int $ARGV[3];

$TRTOPDB = "~/moilr/bin/trtopdb";

$lineno=0;
while($line = <lfile>){
	$lineno = $lineno + 1;
	if ($lineno >= $fromRes and $lineno <= $toRes) {
		my @token = split(" ", $line);
		my @tfile , @tno;
		$tfile[0] = $transfile[int($token[1])][int($token[2])];
		$tno[0] = int($token[3]);
		$tfile[1] = $transfile[int($token[4])][int($token[5])];
		$tno[1] = int($token[6]);
		#print "$tfile[0] $tno[0]\n";
		#print "$tfile[1] $tno[1]\n";
		my @command, @fixedchain;
		if( ( $token[1] eq 0 and $token[2] eq 1 and $token[4] eq 0 and $token[5] eq 2 ) 
			or ( $token[1] eq 0 and $token[2] eq 2 and $token[4] eq 0 and $token[5] eq 1 ) ){
			$command[0] = $TRTOPDB." ".$tfile[0]." ".$tno[0]." ".$prot[$token[2]]." ".$chain[$token[2]]." 1";
			$command[1] =  "mv tl".$tno[0].".pdb m".$lineno.".0.pdb";
			$command[2] = $TRTOPDB." ".$tfile[1]." ".$tno[1]." ".$prot[$token[5]]." ".$chain[$token[5]]." 1";
			$command[3] =  "mv tl".$tno[1].".pdb m".$lineno.".1.pdb";
			$fixedchain=0;
		} elsif( ( $token[1] eq 0 and $token[2] eq 2 and $token[4] eq 1 and $token[5] eq 2 )
			or ( $token[1] eq 1 and $token[2] eq 2 and $token[4] eq 0 and $token[5] eq 2 ) ){
			$command[0] = $TRTOPDB." ".$tfile[0]." ".$tno[0]." ".$prot[$token[1]]." ".$chain[$token[1]]." 0";
			$command[1] =  "mv tr".$tno[0].".pdb m".$lineno.".0.pdb";
			$command[2] = $TRTOPDB." ".$tfile[1]." ".$tno[1]." ".$prot[$token[4]]." ".$chain[$token[4]]." 0";
			$command[3] =  "mv tr".$tno[1].".pdb m".$lineno.".1.pdb";
			$fixedchain=2;
		} elsif( $token[1] eq 0 and $token[2] eq 1 and $token[4] eq 1 and $token[5] eq 2 ){ 
			$command[0] = $TRTOPDB." ".$tfile[0]." ".$tno[0]." ".$prot[0]." ".$chain[0]." 0";
			$command[1] =  "mv tr".$tno[0].".pdb m".$lineno.".0.pdb";
			$command[2] = $TRTOPDB." ".$tfile[1]." ".$tno[1]." ".$prot[2]." ".$chain[2]." 1";
			$command[3] =  "mv tl".$tno[1].".pdb m".$lineno.".1.pdb";
			$fixedchain=1;
		} elsif( $token[1] eq 1 and $token[2] eq 2 and $token[4] eq 0 and $token[5] eq 1 ){
			$command[0] = $TRTOPDB." ".$tfile[0]." ".$tno[0]." ".$prot[2]." ".$chain[2]." 1";
			$command[1] =  "mv tl".$tno[0].".pdb m".$lineno.".0.pdb";
			$command[2] = $TRTOPDB." ".$tfile[1]." ".$tno[1]." ".$prot[0]." ".$chain[0]." 0";
			$command[3] =  "mv tr".$tno[1].".pdb m".$lineno.".1.pdb";
			$fixedchain=1;
		}
		$command[4]="cat ../".$prot[$fixedchain].".pdb m".$lineno.".[01].pdb > m".$lineno.".pdb";
		for($i = 0 ; $i < 5 ; $i++){
			#system($command[$i]);
			print "$command[$i]\n";
		}
		
	}
}
close(lfile);

