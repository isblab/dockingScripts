/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "dock_util.hpp"

extern string piedock_home;
/*
 * Each node should have nearest neighbor information too 
 * Observe that hash_map also helps in search for nearest neighbors too
 * node_transformations only has those transformations that the node is responsible for
 * 
 * do something similar to frequent itemset mining
 *  start with pairs that can be combined and keep adding
 */
void generate_combinations(){
	*out << "compute neigbbors #cells " << transformations_by_cell.size() << " #transformations " << node_transformations.size() << endl;
	
	hash_set<long, hash<long>, eqlong> computed_contacts;
	computed_contacts.clear();
	combinations.clear();
	int level = 1;
	int count = 0;
	vector<MultiTransformation*> new_combinations;
	// add nearest_neighbor information
	// initialize level 1 transformations
	for(hash_map<long,vector<Transformation*>,hash<long>,eqlong>::iterator citr = transformations_by_cell.begin(); citr != transformations_by_cell.end(); citr++){
		long index = citr->first;
		int r_x,r_y,r_z;
		r_z = index % num_cmr_y_divisions;
		r_y = (index/num_cmr_y_divisions) % num_cmr_x_divisions;
		r_x = ((index/num_cmr_y_divisions) / num_cmr_x_divisions);
		
		bool my_cell = (contained_in(box[0],box[3],r_x) && contained_in(box[1],box[4],r_y) && contained_in(box[2],box[5],r_z));
		//*out << index << " " << r << " " << theta << " " << phi << " " << my_cell << endl;
		if(my_cell){
			int min_r_x,max_r_x,min_r_y,max_r_y,min_r_z,max_r_z;
			min_r_x = r_x - R_SPREAD;
			if(min_r_x <= 0) min_r_x = 0;
			max_r_x = r_x + R_SPREAD;
			if(max_r_x >= num_cmr_x_divisions - 1) max_r_x = num_cmr_x_divisions - 1;
			min_r_y = r_y - R_SPREAD;
			if(min_r_y <= 0) min_r_y = 0;
			max_r_y = r_y + R_SPREAD;
			if(max_r_y >= num_cmr_x_divisions - 1) max_r_y = num_cmr_y_divisions - 1;
			min_r_z = r_z - R_SPREAD;
			if(min_r_z <= 0) min_r_z = 0;
			max_r_z = r_z + R_SPREAD;
			if(max_r_z >= num_cmr_x_divisions - 1) max_r_z = num_cmr_z_divisions - 1;
			 
			vector<Transformation*> cell_transformations = citr->second;
			vector<Transformation*>::iterator titr = cell_transformations.begin(), tend = cell_transformations.end();
			while(titr != tend){
				Transformation *tr = (Transformation*) *titr;
				ligand->compute_contacts(receptor,ligand,tr); 
				computed_contacts.insert(tr->frame_number);
				if(tr->num_contacts >= MIN_RESIDUE_CONTACTS(level)
				 && tr->eResiduepair <= MAX_CONTACT_ENERGY(level)){
					sprintf(buff,"%ld",tr->frame_number);
					string mtrid = (* new string(buff));
					MultiTransformation* mtr = new MultiTransformation(mtrid,tr);
					combinations[mtrid.c_str()] = mtr;
					new_combinations.push_back(mtr);
					if(count % 100 == 0)
						*out << count << " " << mtrid << endl;
					count++;
					
					//*out << tr->frame_number << " - ";
					for(int irx = min_r_x; irx <= max_r_x; irx++){
						for(int iry = min_r_y; iry <= max_r_y; iry++){
							for(int irz = min_r_z; irz <= max_r_z; irz++){
								long nindex = (irx*num_cmr_x_divisions + iry)*num_cmr_y_divisions + irz;
								//*out << nindex << " ";
								if(transformations_by_cell.count(nindex) > 0){
									vector<Transformation*> adjacent_cell_transformations = transformations_by_cell[nindex];
									for(vector<Transformation*>::iterator adj_tritr = adjacent_cell_transformations.begin(); adj_tritr != adjacent_cell_transformations.end(); adj_tritr++){
										Transformation* adj_tr = *adj_tritr;
										// compute distance between transformations and add
										if(tr->frame_number != adj_tr->frame_number){
											float d,ud;
											tr->distance(&d,&ud,adj_tr);
											//*out << adj_tr->frame_number << " (" << d << ":" << ud << ") ";
											if(d <= MTR_MAX_R_DISTANCE && ud <= MTR_MAX_ROTATION_DISTANCE){
												(tr->details->nearest_neighbors).push_back(adj_tr);
											}
										}
									}
								}
							}
						}
					}
					//*out << " #nneighbors " << tr->nearest_neighbors.size() << endl;
				}
				titr++;
			}
		}	
	}
	
	/*out << "compute contacts " << count << endl;
	//count = 0;
	// should compute contacts of all transformations I hold not just those in node_transformations
	for(hash_map<long,vector<Transformation*>,hash<long>,eqlong>::iterator citr = transformations_by_cell.begin();
	 citr != transformations_by_cell.end(); citr++){
	 	vector<Transformation*> cell_trans = citr->second;
	 	for(vector<Transformation*>::iterator titr = cell_trans.begin(); titr != cell_trans.end(); titr++){
	 		Transformation *tr = *titr;
			ligand->compute_contacts(receptor,ligand,tr); 
			//count++;
	 	}
	}
	//*out << "computed contacts " << count << endl;*/
	
	int max_neighbors = 0;
	for(vector<Transformation*>::iterator titr = node_transformations.begin(); titr != node_transformations.end(); titr++){
		Transformation *tr = *titr;
		if(tr->details->nearest_neighbors.size() > max_neighbors)
			max_neighbors = tr->details->nearest_neighbors.size();
	}
	*out << "max neighbors " << max_neighbors << endl;

	//computing the nearest neighbors distribution
	int all_neighbor_distribution[max_neighbors+1], selected_neighbor_distribution[max_neighbors+1], qualified_neighbor_distribution[max_neighbors+1];
	for(int i = 0 ; i < max_neighbors; i++)
		all_neighbor_distribution[i] = 0;
	
	*out << "level 1 #combinations " << combinations.size() << " " << count << endl;	
	*out << "compute higher level combinations" << endl;
	
	for(vector<Transformation*>::iterator titr = node_transformations.begin(); titr != node_transformations.end(); titr++){
		Transformation *tr = *titr;
		all_neighbor_distribution[tr->details->nearest_neighbors.size()]++;
		/*out << tr->frame_number << "-(" << (tr->num_contacts) << "," 
		 << (tr->contact_score) << "," << (tr->nearest_neighbors.size()) << ")" << endl;*/
	}
	
	*out << "neighbor distribution: ";
	for(int i = 0 ; i < max_neighbors; i++)
		*out << all_neighbor_distribution[i] << " ";
	*out << endl;
	for(int i = 0 ; i < max_neighbors; i++){
		all_neighbor_distribution[i] = 0;
		qualified_neighbor_distribution[i] = 0;
		selected_neighbor_distribution[i] = 0;
	}
	
	level = 2;
	while(new_combinations.size() != 0 && level <= 4){
		vector<MultiTransformation*> frontier = new_combinations;
		new_combinations = *(new vector<MultiTransformation*>);
		for(vector<MultiTransformation*>::iterator mitr = frontier.begin(); mitr != frontier.end(); mitr++){
			MultiTransformation* mtr = *mitr;
			string mtrid = mtr->id;
			//*out << "mtrid " << mtrid << " -- " << endl;
			long mtr_tindex[mtr->transformations.size()];
			stringstream ss (stringstream::in | stringstream::out);
			ss << (string(mtrid.c_str()));
			int num_transformations = 0;
			while(ss.good()){
				ss >> mtr_tindex[num_transformations++];
			}
			
			hash_set<long, hash<long>, eqlong> examined_neighbor;
			hash_map<long, Transformation*, hash<long>, eqlong> common_neighbors;
			
			for(vector<Transformation*>::iterator titr = (mtr->transformations).begin(); titr != (mtr->transformations).end(); titr++){
				Transformation *tr = *titr;
				for(vector<Transformation*>::iterator nnitr = (tr->details->nearest_neighbors).begin(); nnitr != (tr->details->nearest_neighbors).end(); nnitr++){
					Transformation *nntr = *nnitr;
					long nntindex = nntr->frame_number;
					if(examined_neighbor.count(nntindex) == 0){
						examined_neighbor.insert(nntindex);
						
						// pick a neighbor that is not part of the combination
						// to avoid considering transformations multiple times pick only higher neighbors
						if(nntindex > mtr_tindex[num_transformations-1]){
							if(common_neighbors.count(nntindex) == 0)
								common_neighbors[nntindex] = nntr;
						}
					}
				}
			}
			all_neighbor_distribution[common_neighbors.size()]++;		
		
			
			vector<Transformation*> feasible_neighbors;		
			for(hash_map<long, Transformation*, hash<long>, eqlong>::iterator nnitr = common_neighbors.begin(); nnitr != common_neighbors.end(); nnitr++){ 
				Transformation *nntr = nnitr->second;
				long nntindex = nntr->frame_number;
				
				if(computed_contacts.count(nntindex) == 0){
					ligand->compute_contacts(receptor,ligand,nntr); 
					computed_contacts.insert(nntindex);
				}
				
				// weak form of consistency - require a transformation to be close to all transformations in a combination
				// ensuring this by picking transformations that are neighbors of all transformations in the combination
						
				// compute combination score
				float num_contacts, num_new_contacts;
				float vdw_energy, contact_score;
				mtr->score_addition(&num_new_contacts,&num_contacts,&vdw_energy,&contact_score,nntr);
				*out <<  nntindex << " - (" << num_new_contacts << "," << num_contacts << "," << vdw_energy << "," << contact_score << ") ";
				
				// check only repulsion because only this is closed under containment
				// for now, closure ko goli maro
				if(vdw_energy <= MAX_VDW_REPULSION && num_contacts >= MIN_RESIDUE_CONTACTS(level) && num_new_contacts > MIN_NEW_CONTACTS
				 && contact_score <= MAX_CONTACT_ENERGY(level))
					feasible_neighbors.push_back(nntr);
			}
			if(common_neighbors.size()>0)
				*out << endl;
			qualified_neighbor_distribution[feasible_neighbors.size()]++;
			
			//pick only good and diverse neighbors, cluster by sorting
			sort(feasible_neighbors.begin(), feasible_neighbors.end(),Transformation_Compare_Contacts());
			
			vector<Transformation*> clustered_neighbors;
			for(vector<Transformation*>::iterator titr = feasible_neighbors.begin(); titr != feasible_neighbors.end(); titr++){
				Transformation *tr = *titr;
				bool select = true;
				//*out << tr->frame_number << " " << clustered_neighbors.size() << " ";
				//out->flush();
				for(vector<Transformation*>::iterator titr2 = clustered_neighbors.begin(); titr2 != clustered_neighbors.end(); titr2++){
					Transformation *selected_tr = *titr2;
					float d, ud;
					selected_tr->distance(&d, &ud, tr);
					// need stronger requirements on distance
					if(d <= MTR_MAX_R_DISTANCE_FOR_GENERATION && ud <= MTR_MAX_ROTATION_DISTANCE_FOR_GENERATION){
						select = false;
					}
				}
				if(select){
					clustered_neighbors.push_back(tr);
				}
			}
			
			int outdegree = 0;
			for(vector<Transformation*>::iterator nnitr = clustered_neighbors.begin(); nnitr != clustered_neighbors.end(); nnitr++){
				Transformation *nntr = *nnitr;
				long nntindex = nntr->frame_number;
				
				stringstream ss (stringstream::in | stringstream::out);
				ss << mtrid << " " << nntindex;
				ss.getline(buff,BUFSIZE);
				// iterating combinations generates repeats
				if(combinations.count((string(buff)).c_str()) == 0){
					string enhanced_mtr_id = *(new string(buff));
					*out << "|" << enhanced_mtr_id << "| ";
					MultiTransformation *enhanced_mtr = new MultiTransformation(enhanced_mtr_id,mtr,nntr);
					combinations[enhanced_mtr_id.c_str()] = enhanced_mtr;
					new_combinations.push_back(enhanced_mtr);
					outdegree++;
				}
			}
			if(outdegree > 0)
				*out << endl;
			selected_neighbor_distribution[outdegree]++;
		}
		
		*out << "level " << level << " #new_combinations " << new_combinations.size() << " #combinations " << combinations.size() << endl;
		*out << "neighbor distribution:  " << endl;
		for(int i = 0 ; i < max_neighbors; i++)
			*out << all_neighbor_distribution[i] << "\t";
		*out << endl;
		*out << "clustered neighbor distribution: " << endl;
		for(int i = 0 ; i < max_neighbors; i++)
			*out << qualified_neighbor_distribution[i] << "\t";
		*out << endl;
		*out << "outdegree distribution: " << endl;
		for(int i = 0 ; i < max_neighbors; i++)
			*out << selected_neighbor_distribution[i] << "\t";
		*out << endl;
		for(int i = 0 ; i < max_neighbors; i++){
			all_neighbor_distribution[i] = 0;
			qualified_neighbor_distribution[i] = 0;
			selected_neighbor_distribution[i] = 0;
		}
		level++;
	}
	
	/*hash_map<const char*,MultiTransformation*,hash<const char*>,eqstr> filtered_combinations 
		= *(new hash_map<const char*,MultiTransformation*,hash<const char*>,eqstr>);
	for(hash_map<const char*,MultiTransformation*,hash<const char*>,eqstr>::iterator mitr = combinations.begin(); mitr != combinations.end(); mitr++){ 
		MultiTransformation* mtr = mitr->second;
		float num_contacts;
		float vdw_energy;
		mtr->score(&num_contacts,&vdw_energy);	
		if(num_contacts < MIN_RESIDUE_CONTACTS){
			//combinations.erase(mitr);
			//delete mtr;
		} else
			filtered_combinations[mitr->first] = mtr;
	}
	combinations = filtered_combinations;
	*out << "after filtering by number of contacts #combinations " << combinations.size() << endl;*/
}

extern hash_map<long,vector<Transformation*>,hash<long>,eqlong> clustered_transformations;

/*
 * Assume that the surfaces are generated
 */
int main(int argc, char *argv[]){
	time(&start_time);
	int ret = MPI_Init(&argc,&argv);
	if(ret == MPI_SUCCESS){
		MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
		MPI_Comm_rank(MPI_COMM_WORLD,&procid);
				
		if(procid == 0){
			cout << "Job running on " << numprocs << " processors" << endl;
			cout << "#args " << argc << endl;
			cout.flush();
		}
		
		read_molecule_config();
		
		read_dock_config();
		node_tmp_dir = (char*) (new string(string(tmp_dir)+"/"+string(getenv(string("JOB_ID").c_str()))))->c_str();
		
		elect_leader_on_node();
		
		//initialize
		refpdbcode = string(argv[9]);
		sprintf(command, "%s/cluster_scripts/setup.sh %s %d %s %d",piedock_home,getenv(string("JOB_ID").c_str()),procid, refpdbcode.c_str(), masterprocessonnode);
		ret = system(command);
		
		sprintf(scratch_dir, "%s/%s/%d",node_tmp_dir,refpdbcode.c_str(),procid);
		sprintf(filename, "%s/%s/%sout%d",node_tmp_dir,refpdbcode.c_str(),refpdbcode.c_str(),procid);
		//cout << filename << endl; cout.flush();
		fstream outstream;
		outstream.open(filename,ios::out);
		if(!outstream.good()){
			cout << "ERROR: could not open file " << filename << " " << errno << "\n"; cout.flush();
			exit(-1);
		}
		out = &outstream;
		
		*out << procid << " " << *host << " am_master " << masterprocessonnode << endl;
		*out << "setup " << command << " " << ret << endl;
		
		filetype = atoi(argv[1]);
		docktype = atoi(argv[2]);
		start_state = atoi(argv[3]);
		end_state = atoi(argv[4]);
		*out << "start " << start_state << " end " << end_state << endl;out->flush();
		
		stringstream ss (stringstream::in | stringstream::out);
		string s;
		ss << argv[5] << "_" << argv[6] << "_vs_" << argv[7] << "_" << argv[8];
		ss >> s;
		tag = (char*) (new string(s.c_str()))->c_str();
		
		ss.clear();
		string ts;
		ss << s << ".trans";
		ss >> ts;
		transformations_file = (char*) (new string(ts.c_str()))->c_str();
		sprintf(local_transformations_file,"%s/%s",scratch_dir,transformations_file);
		
		ss.clear();
		ss << s << ".combinations";
		string cs;
		ss >> cs;
		combinations_file = (char*) (new string(cs.c_str()))->c_str();
		sprintf(local_combinations_file,"%s/%s",scratch_dir,combinations_file);
		
		rpdbcode = string(argv[5]);
		rchains = string(argv[6]);
		lpdbcode = string(argv[7]);
		lchains = string(argv[8]);
		refrchains = string(argv[10]);
		reflchains = string(argv[11]);
		
		Complex* cr = new Complex(("../"+rpdbcode).c_str(),rchains.c_str(), filetype);
		Complex* crH =cr;// new Complex(("../"+rpdbcode).c_str(),rchains.c_str(), PQR);
		out->flush();
		receptor = new Object(cr,crH);
		
		Complex* cl = new Complex(("../"+lpdbcode).c_str(),lchains.c_str(), filetype);
		Complex* clH = cl;//new Complex(("../"+lpdbcode).c_str(),lchains.c_str(), PQR);
		ligand = new Object(cl, clH);
		
		ss.clear();
		ss << tag << ".info";
		ss >> s;
		ModelInfo *modelinfo = NULL;
		//struct stat stFileInfo;
  		//int filestatus = stat(s.c_str(),&stFileInfo);
  		//if(filestatus == 0){
  		 	
		fstream infoin(s.c_str(), ios::in);
		*out << s << " " << infoin.good() << endl; out->flush();
		if(infoin.good()){
			modelinfo = new ModelInfo();
			
			while(infoin.good()){
				infoin.getline(buff,8192);
				if(infoin.gcount() > 0){
					string pdbid = string(strtok(buff,":"));
					char *chain = strtok(NULL,":");
					char* aaindex = strtok(NULL,":");
					if((pdbid==rpdbcode) && (rchains.find(string(chain))!=string::npos) ){
						*out << cr->molecules.count(chain[0]) << " " << ((Protein*)cr->molecules[chain[0]])->aminoacid.count(aaindex) << endl;
						if(cr->molecules.count(chain[0]) > 0 && ((Protein*)cr->molecules[chain[0]])->aminoacid.count(aaindex) > 0){
							Aminoacid *aa = ((Protein*)cr->molecules[chain[0]])->aminoacid[aaindex];
							modelinfo->rinterface.insert(aa->cindex);
							*out << "added receptor interface residue " << aa->name << " " << aa->index << " " << modelinfo->rinterface.size() << endl;
						}
					} else if((pdbid==lpdbcode) && (lchains.find(string(chain))!=string::npos) ){
						*out << cl->molecules.count(chain[0]) << " " << ((Protein*)cl->molecules[chain[0]])->aminoacid.count(aaindex) << endl;
						if(cl->molecules.count(chain[0]) > 0 && ((Protein*)cl->molecules[chain[0]])->aminoacid.count(aaindex) > 0){
							Aminoacid *aa = ((Protein*)cl->molecules[chain[0]])->aminoacid[aaindex];
							modelinfo->linterface.insert(aa->cindex);
							*out << "added ligand interface residue " << aa->name << " " << aa->index << " " << modelinfo->linterface.size() << endl;
						}
					}
					*out << "interface residue " << pdbid << " " << string(chain) << " "
							<< (pdbid==lpdbcode) << " " << cl->chains << " " << lchains << " " << lpdbcode << " " << lchains.find(string(chain))
							<< " " << string(aaindex) << endl; out->flush();
				}
			}
			infoin.close();
			*out << "done reading info " << modelinfo->rinterface.size() << " " << modelinfo->linterface.size() << endl; out->flush();
		}		
		
		if(argc > 12)	symmetry = atoi(argv[12]);
		else	symmetry = 1;
		
		read_usphere_solution();
			
		//out->flush();
		//if(start_state < SCORE || start_state == VERIFY_TRANS)
		{
			receptor->preprocess_receptor();
			ligand->preprocess_ligand();
			receptor->build_contact_grid(ligand->max_grid_point_distance + sqrt(3)*GRID_SPACING/2.0);
			ligand->build_contact_grid(receptor->max_grid_point_distance + sqrt(3)*GRID_SPACING/2.0);
			
			preprocess();
		}
		pieces.clear();
		
		if(start_state < FILTER_STERIC_CLASHES && end_state >= FILTER_STERIC_CLASHES){
			state = FILTER_STERIC_CLASHES;
			examine_transformations();
			read_transformations();
			filter_steric_clashes();
			collect_transformations(false,0);
		}
		
		if(start_state < GENERATE_MODELS && end_state >= GENERATE_MODELS){
			state = GENERATE_MODELS;
			examine_transformations();
			read_transformations();
			generate_models();
		}
		
		if(start_state < SCORE && end_state >= SCORE){
			state = SCORE;
			read_combinations();
			score_models();
			collect_combinations();
		}
		
		if(start_state == COMPUTE_DETAILS){
			state = start_state;
			examine_transformations();
			read_transformations();
			
			for(vector<Transformation*>::iterator titr = node_transformations.begin(); titr != node_transformations.end(); titr++){
				Transformation *tr = (Transformation *) *titr;
				tr->vmetrics = new VerificationMetrics();
				tr->vmetrics->rmsd = tr->vmetrics->lrmsd = tr->vmetrics->irmsd = 100; 
			}
			state = VERIFY_TRANS_COMPUTE_DETAILS_PROTPROT;
			collect_transformations_verify_trans(true,false);
		}
		
		if(start_state == GENERATE_PDB){
			state = GENERATE_PDB;
			examine_transformations();
			read_transformations();
		}
		
		if(start_state == SELECT_TRANS && procid == 0){
			state = SELECT_TRANS;
			examine_transformations();
			select_transformations();
		}
		
		if(start_state == CONVERT_TRANS_TXT && procid == 0){
			state = SELECT_TRANS;
			examine_transformations();
			write_trans_txt();
		}
		
		if(start_state == SCD_GIVEN_INTERFACE && modelinfo != NULL){
			state = start_state;
			examine_transformations();
			read_transformations();
			filter_trans_basedon_info(modelinfo);
			
			//transformations_file = (char*) (new string(string(tag)+".consistenttrans"))->c_str();
			//collect_transformations();
			
			for(vector<Transformation*>::iterator titr = node_transformations.begin(); titr != node_transformations.end(); titr++){
				Transformation *tr = (Transformation *) *titr;
				tr->vmetrics = new VerificationMetrics();
				tr->vmetrics->rmsd = tr->vmetrics->lrmsd = tr->vmetrics->irmsd = 100; 
			}
			collect_transformations_verify_trans(false,false);
		}
		
		/*if(start_state == SELECT_SIMILAR_TRANS && procid == 0){
			state = SELECT_SIMILAR_TRANS;
			examine_transformations();
			select_similar_transformations(end_state);
		}*/
		
		if(procid == 0 && (start_state == CLUSTER_TRANS_FINE || start_state == CLUSTER_TRANS_COARSE || 
		  start_state == CLUSTER_TRANS_IRMSD || start_state == CLUSTER_TRANS_FRAC_NAT )){
			state = start_state;
			examine_transformations();
			switch(state){
				case CLUSTER_TRANS_FINE :
					cluster_sorted_transformations(receptor, ligand, 0);
					break;
				case CLUSTER_TRANS_COARSE:
					cluster_sorted_transformations(receptor, ligand, 2);
					break;
				case CLUSTER_TRANS_IRMSD :
					ligand->grid_compute_aacid_contacts();
					cluster_sorted_transformations(receptor, ligand, 3);
					break;
				case CLUSTER_TRANS_FRAC_NAT :
					cluster_sorted_transformations(receptor, ligand, 4);
					break;
			}
		}
		
		if(start_state == INCREMENTAL_CLUSTER_TRANS && procid == 0){
			state = INCREMENTAL_CLUSTER_TRANS;
			
			// read transformations to be clustered
			examine_transformations();
			
			// read cluster centers
			read_transformation_clusters();
			
			// incremental clustering
			cluster_sorted_transformations(receptor, ligand, 2);
		}
		
		if(start_state == COMPUTE_FEIG_SCORE){
			state = start_state;
			examine_transformations();
			compute_feig_score(receptor->c, ligand->c, "feig.options");
		}
		
		if(start_state == COMPUTE_ENTROPY_APPROX1){
			state = start_state;
			examine_transformations();
			compute_entropy_approx2(receptor, ligand, "entropy.options");
		}
		
		if(start_state == REFINE_TRANSFORMATION){
			state = start_state;
			examine_transformations();
			read_transformations();
			optimize_transformations();
			
			ss.clear();
			string ts;
			ss << string(tag) << "opt.trans";
			ss >> ts;
			transformations_file = (char*) (new string(ts.c_str()))->c_str();
			sprintf(local_transformations_file,"%s/%s",scratch_dir,transformations_file);
			collect_transformations(false,0);
		}
		
		if(start_state == REFINE_SIDECHAINS){
			state = start_state;
			examine_transformations();
			read_transformations();
			refine_sidechains(receptor,ligand,node_transformations);
		}
		
		if((start_state == EXAMINE_REFERENCE && procid == 0)
		 || (start_state == EXAMINE_REFERENCE_SEQAVG && procid == 0)
		 || (start_state == VERIFY_TRANS) || (start_state == VERIFY_COMBINATIONS) || (start_state == VERIFY_MODELS)
		 || (start_state == VERIFY_TRANS_COMPUTE_DETAILS_PROTPROT) || (start_state < VERIFY_TRANS_COMPUTE_DETAILS_PROTPROT && end_state >= VERIFY_TRANS_COMPUTE_DETAILS_PROTPROT)
		 || (start_state == VERIFY_TRANS_COMPUTE_SEQAVG_DETAILS) || (start_state < VERIFY_TRANS_COMPUTE_SEQAVG_DETAILS && end_state >= VERIFY_TRANS_COMPUTE_SEQAVG_DETAILS)
		 ){
			reference = new Complex(("../"+refpdbcode).c_str(),(refrchains+reflchains).c_str(),PDB);
			referenceH = reference; //new Complex(("../"+refpdbcode).c_str(),(refrchains+reflchains).c_str(),PQR);
			reference->compute_motions();
			read_alignments();
		}
		
		if(start_state == EXAMINE_REFERENCE && procid == 0){
			state = EXAMINE_REFERENCE;
			examine_reference();
			//read_homologues(LOOPP_ALIGN);
			//preprocess_homologues(LOOPP_ALIGN);
		}
		
		if(start_state == VERIFY_TRANS){
			state = VERIFY_TRANS;
			read_symmetries();
			examine_transformations();
			read_transformations();
			compute_entropy();
			verify_transformations();
			collect_transformations_verify_trans(false,false);
		}
		
		if(start_state == VERIFY_TRANS_COMPUTE_DETAILS_PROTPROT){
			state = VERIFY_TRANS;
			read_symmetries();
			examine_transformations();
			read_transformations();
			compute_entropy();
			initialize_transformation_localneighbors();
			verify_transformations();
			state = VERIFY_TRANS_COMPUTE_DETAILS_PROTPROT;
			collect_transformations_verify_trans(true,false);
		}
		
		if(start_state == EXAMINE_REFERENCE_SEQAVG && procid==0){
			state = EXAMINE_REFERENCE;
			read_symmetries();
			read_homologues(LOOPP_ALIGN);
			preprocess_homologues(LOOPP_ALIGN);
			pair_sequences_by_species();
			//examine_reference_seqavg();
		}
		
		if(start_state == VERIFY_TRANS_COMPUTE_SEQAVG_DETAILS){
			state = VERIFY_TRANS;
			read_symmetries();
			read_homologues(LOOPP_ALIGN);
			preprocess_homologues(LOOPP_ALIGN);
			examine_transformations();
			read_transformations();
			compute_entropy();
			verify_transformations();
			state = VERIFY_TRANS_COMPUTE_DETAILS_PROTPROT;
			collect_transformations_verify_trans(true,true);
		}
		
		if(start_state < GENERATE_COMBINATIONS && end_state >= GENERATE_COMBINATIONS){
			state = GENERATE_COMBINATIONS;
			examine_transformations();
			read_transformations();
			cout.flush(); out->flush();
			generate_combinations();
			cluster_combinations_by_sorting();
			collect_combinations();
		}
		
		if(start_state == VERIFY_COMBINATIONS){
			state = VERIFY_COMBINATIONS;
			read_symmetries();
			read_combinations();
			verify_combinations();
			collect_combinations();
		}
		
		MPI_Finalize();
		//outstream.close();
		
		if(procid == 0){
			time(&current_time);
			cout << "done" << " " << success << "\t time:" << difftime(current_time,start_time) << "s" << endl;
		}
		
		return 0;
	} else {
		cout << "init failed" << endl;
		return 1;
	}
}
