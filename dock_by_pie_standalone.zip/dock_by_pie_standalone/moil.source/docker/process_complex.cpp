/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "process_complex.hpp"

#define BUFFER_WIDTH 4.0
#define FASTACMD "/proj/ravid/software/blast-2.2.17/bin/fastacmd"
#define NR_DB "/proj/ravid/blast/db/nr"
#define STRING_DB "/proj/ravid/blast/db/string/v8.2"

/*
 * Goal:
 * 		- fix pdb2puth to work with multiple chains
 * 		- read the correct ent files
 * Hack
 * 		- read the crd files geenrated manually by running puth
 * 
 * Output
 * 		- ions in the pdb format to be added to the receptor ent file
 *		- the charge to be added might not be an integer - need to modify the charge of the ion in the wcon file
 * 			-- what if the ion is also present in the molecule - for now no
 * 		- the box size
 * 
 * Better to write a wrapper on ewald, box gets too big since cannot determine where the ligand is going to bind
 */
void neutralize(Complex* receptor, int nrchains, Complex* ligand, int nlchains){
	float charge = 0;
	float minx, maxx, miny, maxy, minz, maxz, maxr; // coordinates of the atom center
	int aindex = 0;
	for(int i = 0 ; i < receptor->num_atoms; i++){
		Atom *a = receptor->atom[i];
		Vector v = *(a->position);
		if(aindex++ == 0){
			minx = maxx = v.x;
			miny = maxy = v.y;
			minz = maxz = v.z;
			maxr = a->radius;
		}
		
		maxx = (v.x > maxx)? v.x : maxx;
		minx = (v.x < minx)? v.x : minx;
		maxy = (v.y > maxy)? v.y : maxy;
		miny = (v.y < miny)? v.y : miny;
		maxz = (v.z > maxz)? v.z : maxz;
		minz = (v.z < minz)? v.z : minz;
		maxr = (a->radius > maxr) ? a->radius : maxr;
	
		charge += a->charge;
	}
	
	for(int ai = 0; ai < ligand->num_atoms; ai++){
		Atom *a = ligand->atom[ai];
		charge += a->charge;
	}
	
	float ewald_charge = charge + (0.14)*(nrchains+nlchains);
	*out << "charge " << charge << " " << ewald_charge << endl;
	
	*out << "box receptor (" << minx-maxr << "," << miny-maxr << "," << minz-maxr << ")(" << maxx+maxr << "," << maxy+maxr << "," << maxz+maxr << ")" << endl;
	
	// find the extreme possible surface points
	minx=minx-maxr-ligand->diameter;
	miny=miny-maxr-ligand->diameter;
	minz=minz-maxr-ligand->diameter;
	maxx=maxx+maxr+ligand->diameter;
	maxy=maxy+maxr+ligand->diameter;
	maxz=maxz+maxr+ligand->diameter;
	
	*out << "box complex (" << minx << "," << miny << "," << minz << ")(" << maxx << "," << maxy << "," << maxz << ")" << endl;
	
	// add charges to neutralize the system
	int nions;
	if(ewald_charge > 0){
		nions = (int) ceil(charge);
	} else if(ewald_charge < 0){
		nions = (int) ceil(0-charge);
	}
	
	fstream pnout, cnout;
	pnout.open((string("neutralize.ent")).c_str(), fstream::out);
	pnout << setiosflags(ios::fixed) << setprecision(3);
	//pnout << "HEADER charges to be added to the receptor to neutralized the system" << endl;
	cnout.open((string("neutralize.crd")).c_str(), fstream::out);
	cnout << setiosflags(ios::fixed) << setprecision(5);
	
	int natoms = receptor->num_atoms + ligand->num_atoms;
	int naacids = receptor->num_aminoacids + ligand->num_aminoacids;
	int nratoms = receptor->num_atoms;
	int nraacids = receptor->num_aminoacids;
	srand(time(0));
	int xdivisions = (int) ((maxx-minx)/BUFFER_WIDTH) + 4;
	int ydivisions = (int) ((maxy-miny)/BUFFER_WIDTH) + 4;
	int zdivisions = (int) ((maxz-minz)/BUFFER_WIDTH) + 4;
	for(int j = 0; j < nions; j++){
		int plane = rand()%5;
		float x,y,z;
		if(plane < 2){
			if(plane == 0)
				x = minx - 1.5 * BUFFER_WIDTH;
			else
				x = maxx + 1.5 * BUFFER_WIDTH;
			
			int yz = rand()%(ydivisions*zdivisions);
			y = miny + (-1.5 + (float) (yz % ydivisions)) * BUFFER_WIDTH;
			z = minz + (-1.5 + (float) (yz / ydivisions)) * BUFFER_WIDTH;
		} else if(plane < 4){
			if(plane == 2)
				y = miny - 1.5 * BUFFER_WIDTH;
			else
				y = maxy + 1.5 * BUFFER_WIDTH;
			
			int xz = rand()%(xdivisions*zdivisions);
			x = minx + (-1.5 + (float) (xz % xdivisions)) * BUFFER_WIDTH;
			z = minz + (-1.5 + (float) (xz / xdivisions)) * BUFFER_WIDTH;
		} else {
			if(plane == 4)
				z = minz - 1.5 * BUFFER_WIDTH;
			else
				z = maxz + 1.5 * BUFFER_WIDTH;
			
			int xy = rand()%(ydivisions*zdivisions);
			y = miny + (-1.5 + (float) (xy % ydivisions)) * BUFFER_WIDTH;
			x = minx + (-1.5 + (float) (xy / ydivisions)) * BUFFER_WIDTH;
		}
		
		Vector v(x,y,z);
		*out << "Adding ion at (" << v.x << "," << v.y << "," << v.z << ")" << endl;
		
		string aname, aaname;
		if(ewald_charge < 0){
			aaname = "NAO";
			aname = "NA+";
		} else {
			aaname = "CL";
			aname = "CL";
		}	
		
		float coord[3];
		coord[0] = x;
		coord[1] = y;
		coord[2] = z;
		int ci[3];
		char cf[3][9];
		for(int i=0;i<3;i++){
			ci[i] = (int) coord[i];
			float d = coord[i] - ci[i];
			sprintf(cf[i],"%6.3f",d);
		}
		
		char buf[256];
		sprintf(buf,"ATOM  %5d  %-4s%-4s%c%4d    %4d.%s%4d.%s%4d.%s  1.00  0.00",
		 natoms+j+1,aname.c_str(),aaname.c_str(),' ',naacids+j+1,
		 ci[0],&cf[0][3],ci[1],&cf[1][3],ci[2],&cf[2][3]);
		pnout << buf << endl;
		
		for(int i=0;i<3;i++){
			ci[i] = (int) coord[i];
			float d = coord[i] - ci[i];
			sprintf(cf[i],"%8.5f",d);
		}
		sprintf(buf,"%5d%5d %-4s %-4s%4d.%s%4d.%s%4d.%s ", natoms+j+1, naacids+j+1, aaname.c_str(),aname.c_str(),
		 ci[0],&cf[0][3],ci[1],&cf[1][3],ci[2],&cf[2][3]); 
		cnout << buf << endl;
		//*out << buf << endl;
	}
	
	pnout.close();
	cnout.close();
}

/*
 * Works only for 2 chain complexes
 */
int main(int argc, char *argv[]){
	out = &cout;	
	read_molecule_config();
	read_dock_config();
	
	Complex* cr = new Complex(argv[1],argv[2], PDB);
	Complex* cl = new Complex(argv[3],argv[4], PDB);
	char rchain = argv[2][0];
	char lchain = argv[4][0];
	
	Molecule *molecule[2];
	molecule[0] = (Molecule*) cr->molecules.begin()->second;
	molecule[1] = (Molecule*) cl->molecules.begin()->second;
	
	bool usestring=false;//true;
	char buf[2048];
	int ret;
	hash_map<char, hash_map<const char*, Sequence*, hash<const char*>, eqstr>, hash<char>, eqint> blast_hits;
	for(int i = 0; i < 2; i++){
		pdbcode = molecule[i]->pdbcode.c_str();
		char chain = molecule[i]->chain;
		
		read_blast_hits(chain,DB_PDBAA,".");
		blast_hits[chain] = *(new hash_map<const char*, Sequence*, hash<const char*>, eqstr>);
		for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr = matching_sequences.begin(); sitr != matching_sequences.end(); sitr++){
			Sequence *s = (Sequence *) sitr->second;
			if(s->seq_alignment->identities >= 15)
				blast_hits[chain][(const char*) sitr->first] = s;
		}
		
		if(usestring){
			matching_sequences.clear();
			read_blast_hits(chain,DB_STRING,".");
			for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr = matching_sequences.begin(); sitr != matching_sequences.end(); sitr++){
				Sequence *s = (Sequence *) sitr->second;
				if(blast_hits[chain].count((const char*) sitr->first) == 0)
					if(s->seq_alignment->identities >= 10)
						blast_hits[chain][(const char*) sitr->first] = s;
			}
		} else {
			matching_sequences.clear();		
			read_blast_hits(chain,DB_NR,".");
			//read_blast_hits(chain,DB_SWISSPROT,".");
			for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr = matching_sequences.begin(); sitr != matching_sequences.end(); sitr++){
				Sequence *s = (Sequence *) sitr->second;
				if(blast_hits[chain].count((const char*) sitr->first) == 0)
					if(s->seq_alignment->identities >= 10)
						blast_hits[chain][(const char*) sitr->first] = s;
			}
		}
		matching_sequences.clear();
	}
	
	int chainindex=0;
	hash_set<const char*, hash<const char*>, eqstr> blast_pdbids[2];
	hash_map<char,hash_set<const char*, hash<const char*>, eqstr>, hash<char>, eqint> species;
	for(hash_map<char, hash_map<const char*, Sequence*, hash<const char*>, eqstr>, hash<char>, eqint>::iterator bitr=blast_hits.begin(); bitr!=blast_hits.end();bitr++){
		char chain = bitr->first;
		hash_map<const char*, Sequence*, hash<const char*>, eqstr> matches = bitr->second;
		blast_pdbids[chainindex] = *(new hash_set<const char*, hash<const char*>, eqstr>);
		species[chain] = *(new hash_set<const char*, hash<const char*>, eqstr>);
		*out << "#matches " << chain << " ";
		
		for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator mitr=matches.begin(); mitr!=matches.end(); mitr++){
			Sequence *s = (Sequence *) mitr->second;
		  	if(s->database == "pdb" && s->id_lowercase.length() == 4){
				blast_pdbids[chainindex].insert((s->id_lowercase).c_str());
				*out << s->id_lowercase << " ";
			}
			if(usestring){
				if(s->database != "pdb" && s->database == "str" && s->organism != "")	species[chain].insert((s->organism).c_str());
			} else {
				if(s->database != "pdb" && s->database != "str" && s->organism != "")	species[chain].insert((s->organism).c_str());
			}
		}
		*out << matches.size() << " " << blast_pdbids[chainindex].size() << endl;
		chainindex++;
	}
	
	// are there any known templates?
	hash_set<const char*, hash<const char*>, eqstr> pdbintersection;
	for(hash_set<const char*, hash<const char*>, eqstr>::iterator itr = blast_pdbids[0].begin(); itr != blast_pdbids[0].end(); itr++){
		bool found = true;
		for(int i = 1; i < chainindex && found; i++){
			found = (blast_pdbids[i].count(*itr) > 0);
		}
		if(found)	pdbintersection.insert(*itr);
	}
	*out << "#templates " << pdbintersection.size() << endl << "list:\t";
	for(hash_set<const char*, hash<const char*>, eqstr>::iterator itr = pdbintersection.begin(); itr != pdbintersection.end(); itr++)
		*out << *itr << " ";
	*out << endl;

	// find homologous sequences for the complex
	*out << "towards pairs of homologous sequences " << species[rchain].size() << " " << species[lchain].size() << endl;
	hash_map<char, hash_map<const char*, vector<Sequence*>*, hash<const char*>, eqstr>, hash<char>, eqint> homologous_sequences;
	homologous_sequences[rchain] = *(new hash_map<const char*, vector<Sequence*>*, hash<const char*>, eqstr>);
	homologous_sequences[lchain] = *(new hash_map<const char*, vector<Sequence*>*, hash<const char*>, eqstr>);
	hash_set<const char*, hash<const char*>, eqstr> species_intersection;
	
	if(!usestring){
		for(hash_set<const char*, hash<const char*>, eqstr>::iterator oitr = species[rchain].begin(); oitr != species[rchain].end(); oitr++){
			string organism = string((const char*) *oitr);
			if(species[lchain].count(organism.c_str()) != 0){
				for(int i = 0; i <2; i++){
					char chain= rchain;
					if(i == 1)	chain = lchain;
					vector<Sequence*> *sequences = homologous_sequences[chain][*oitr] = new vector<Sequence*>;
					for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr = blast_hits[chain].begin(); sitr != blast_hits[chain].end(); sitr++){
						Sequence *s = (Sequence *) sitr->second;
						bool toadd = (s->database != "str") && (s->organism == organism);
						for(vector<Sequence*>::iterator vitr = sequences->begin(); vitr != sequences->end() && toadd; vitr++){
							Sequence* s2 = (Sequence*) *vitr;
							if(s->seq_alignment == s2->seq_alignment)	toadd=false;
						}
						if(toadd){
							//*out << s->organism << " " << organism << toadd << endl;
							sequences->push_back(s);
						}
					}
				}
				int nr = homologous_sequences[rchain][*oitr]->size();
				int nl = homologous_sequences[lchain][*oitr]->size();
				*out << organism << " hompairs " << nr << " " << nl << endl;
				if(nr>0 && nl>0)	species_intersection.insert((new string(*oitr))->c_str());
			}
		}
		
		stringstream ss (stringstream::in | stringstream::out);
		ss << argv[1] << "_" << argv[2] << argv[4] << ".shomologues";
		string filename; ss >> filename;
		fstream fout(filename.c_str(), ios::out);
		*out << "#species with pairs of homologous sequences " << species_intersection.size() << endl;
		
		int num_species=0;
		for(hash_set<const char*, hash<const char*>, eqstr>::iterator itr = species_intersection.begin(); itr != species_intersection.end(); itr++){
			string organism = string((const char*) (*itr));
			*out << organism << endl;
			int nr = homologous_sequences[rchain][*itr]->size();
			int nl = homologous_sequences[lchain][*itr]->size();
			fout << "SPECIES " << organism << " # " << nr << " " << nl << endl;
			sprintf(buf,"mkdir loopp/%d", num_species);
			ret = system(buf);
			if(ret!=0)	*out << string(buf) << " " << ret << endl;
			
			for(int i = 0; i <2; i++){
				char chain= rchain;
				if(i == 1)	chain = lchain;
				
				sprintf(buf,"mkdir loopp/%d/chain%c", num_species,chain);
				int ret = system(buf);
				if(ret!=0)	*out << string(buf) << " " << ret << endl;
			
				vector<Sequence*> sequences = *(homologous_sequences[chain][*itr]);
				int seqno=0;
				for(vector<Sequence*>::iterator sitr = sequences.begin(); sitr != sequences.end(); sitr++){
					Sequence* s = (Sequence*) *sitr;
					fout << s->id_lowercase << " " << s->organism << " " << s->seq_alignment->positives << " " << s->seq_alignment->size << endl;
					stringstream ss (stringstream::in | stringstream::out);
					ss << FASTACMD << " -d " << NR_DB << " -s " << s->id << " >> loopp/" << num_species << "/chain" << chain << "/s" << seqno << "_" << i << ".fasta";
					ss.getline(buf,2048);
					ret = system(buf);
					if(ret!=0)	*out << string(buf) << " " << ret << endl;
					seqno++;
				}
			}
			num_species++;
		}
		fout.close();
		
		// find homologous sequences for each chain that do not form complexes
		sprintf(buf,"mkdir loopp/neg");
		ret = system(buf);
		if(ret!=0)	*out << string(buf) << " " << ret << endl;
		for(int i = 0; i <2; i++){
			char chain= rchain;
			if(i == 1)	chain = lchain;
				
			sprintf(buf,"mkdir loopp/neg/chain%c", chain);
			int ret = system(buf);
			if(ret!=0)	*out << string(buf) << " " << ret << endl;
			
			stringstream ss (stringstream::in | stringstream::out);
			ss << argv[1] << "_" << chain << ".neghomologues";
			string filename; ss >> filename;
			fstream fout(filename.c_str(), ios::out);
			
			int seqno=0;
			hash_map<int, Sequence*, hash<int>, eqint> chain_homologues;
			/*for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr=blast_hits[chain].begin(); sitr!=blast_hits[chain].end();sitr++){
				Sequence* s = sitr->second;
				bool tooutput = (s->database != "pdb" && s->organism != "" && species_intersection.count((s->organism).c_str()) == 0);
				for(int j = 0; j < seqno && tooutput; j++){
					Sequence *s1 = chain_homologues[j];
					tooutput = (s->seq_alignment != s1->seq_alignment);
				}
					
				if(tooutput){
				 	fout << s->id_lowercase << " " << s->organism << " " << s->seq_alignment->positives << " " << s->seq_alignment->size << endl;
					
					sprintf(buf,"mkdir loopp/neg/chain%c/%d",chain,seqno);
					ret = system(buf);
					if(ret!=0)	*out << string(buf) << " " << ret << endl;
					
					stringstream ss (stringstream::in | stringstream::out);
					ss << FASTACMD << " -d " << NR_DB << " -s " << s->id << " >> loopp/neg/chain" << chain << "/" << seqno << "/s" << ".fasta";
					ss.getline(buf,2048);
					ret = system(buf);
					if(ret!=0)	*out << endl << string(buf) << " " << ret << endl;
					
					chain_homologues[seqno] = s; 
					seqno++;
				}
			}*/
		}
	} else {
		hash_map<const char*, vector<string>, hash<const char*>, eqstr> recseqid_vs_cogids, ligseqid_vs_cogids;
		for(int ci = 0; ci < 2; ci++){
			cout << "check " << rchain << " " << blast_hits.count(rchain) << endl; cout.flush();
			hash_map<const char*, Sequence*, hash<const char*>, eqstr> list = blast_hits[rchain];
			hash_map<const char*, vector<string>, hash<const char*>, eqstr> *seqid_vs_cogids = &recseqid_vs_cogids;
			if(ci == 1){
				list = blast_hits[lchain];
				seqid_vs_cogids = &ligseqid_vs_cogids;
			}
			for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator itr = list.begin(); itr != list.end(); itr++){
				Sequence *s = itr->second;
				if(s->database == "str"){
					string tag = s->tag;
					vector<string> *cogids = new vector<string>;
					while(tag.find("cog{") != string::npos){
						int start = tag.find("cog{")+4;
						string cogid = tag.substr(start,tag.find("}") - start);
						cout << cogid << " " << tag << endl; cout.flush();
						if(cogid != "notfound")
							cogids->push_back(*(new string(cogid.c_str())));
						tag = tag.substr(tag.find("}")+1,tag.length());
					}
					cout << s->id << " " << cogids->size() << endl; cout.flush();
					if(cogids->size() > 0)	(*seqid_vs_cogids)[s->id_lowercase.c_str()] = *(cogids);
					else	delete cogids;
				}
			}
		}
		cout << "next phase\n"; cout.flush();
		
		hash_set<const char*, hash<const char*>, eqstr> species_intersection_with_cogids;
		hash_map<const char*, hash_set<const char*, hash<const char*>, eqstr>, hash<const char*>, eqstr> reccogid_vs_ligcogids;
		for(hash_set<const char*, hash<const char*>, eqstr>::iterator oitr = species[rchain].begin(); oitr != species[rchain].end(); oitr++){
			string organism = string((const char*) *oitr);
			if(species[lchain].count(organism.c_str()) != 0){
				int nhompair=0;
				for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr = blast_hits[rchain].begin(); sitr != blast_hits[rchain].end(); sitr++){
					Sequence *sr = (Sequence *) sitr->second;
					if((sr->database == "str") && (sr->organism == organism)){
						// check if experimental protein protein interaction information present for this protein
						string filename = "/proj/ravid/string/split_links/" + sr->id;
						fstream rlinkin(filename.c_str(), ios::in);
						hash_set<const char*, hash<const char*>, eqstr> rlinks;
						while(rlinkin.good()){
							rlinkin.getline(buf,8192);
							if(rlinkin.gcount() > 0){
								stringstream line(buf,stringstream::in);
								string lid; line >> lid; line >> lid;
								float neighborhood, fusion, cooccurence, coexpression, experimental, database, textmining, combined_score;
								line >> neighborhood;
								line >> fusion;
								line >> cooccurence;
								line >> coexpression;
								line >> experimental;
								line >> database;
								line >> textmining;
								line >> combined_score;
								if(fusion >= 50 || experimental >= 50)
								//if(combined_score >= 100)
									rlinks.insert((new string(lid.c_str()))->c_str());
							}
						}
						rlinkin.close();
						
						if(recseqid_vs_cogids.count(sr->id_lowercase.c_str()) > 0 && rlinks.size()> 0){
							for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr = blast_hits[lchain].begin(); sitr != blast_hits[lchain].end(); sitr++){
								Sequence *sl = (Sequence *) sitr->second;
								bool toadd = (sl->database == "str") && (sl->organism == organism) && (ligseqid_vs_cogids.count(sl->id_lowercase.c_str()) > 0) && (rlinks.count(sl->id.c_str()) > 0);
								for(vector<string>::iterator rcitr = recseqid_vs_cogids[sr->id_lowercase.c_str()].begin(); rcitr != recseqid_vs_cogids[sr->id_lowercase.c_str()].end() && toadd; rcitr++){
									string rcogid = *rcitr;
								 	if(reccogid_vs_ligcogids.count(rcogid.c_str()) == 0)
								 		reccogid_vs_ligcogids[rcogid.c_str()] = *(new hash_set<const char*, hash<const char*>, eqstr>);
								 	
								 	for(vector<string>::iterator lcitr = ligseqid_vs_cogids[sl->id_lowercase.c_str()].begin(); lcitr != ligseqid_vs_cogids[sl->id_lowercase.c_str()].end() && toadd; lcitr++){
										string lcogid = *lcitr;
										toadd = toadd && (reccogid_vs_ligcogids[rcogid.c_str()].count(lcogid.c_str()) == 0);
										// homodimer case
										if(reccogid_vs_ligcogids.count(lcogid.c_str()) > 0)
											toadd = toadd && (reccogid_vs_ligcogids[lcogid.c_str()].count(rcogid.c_str()) == 0);
								 	}
								}
								if(toadd){
									stringstream ss (stringstream::in | stringstream::out);
									ss << organism << "|" << nhompair++;
									ss.getline(buf,8192);
									string key = *(new string(buf));
									vector<Sequence*> *rsequences = homologous_sequences[rchain][key.c_str()] = new vector<Sequence*>;
									vector<Sequence*> *lsequences = homologous_sequences[lchain][key.c_str()] = new vector<Sequence*>;
									rsequences->push_back(sr);
									lsequences->push_back(sl);
									species_intersection.insert(key.c_str());
									*out << "pair " << sr->id << " " << sl->id << " " << key << endl;
									
									for(vector<string>::iterator rcitr = recseqid_vs_cogids[sr->id_lowercase.c_str()].begin(); rcitr != recseqid_vs_cogids[sr->id_lowercase.c_str()].end(); rcitr++){
										string rcogid = *rcitr;
									 	if(reccogid_vs_ligcogids.count(rcogid.c_str()) == 0)
									 		reccogid_vs_ligcogids[rcogid.c_str()] = *(new hash_set<const char*, hash<const char*>, eqstr>);
									 	
									 	for(vector<string>::iterator lcitr = ligseqid_vs_cogids[sl->id_lowercase.c_str()].begin(); lcitr != ligseqid_vs_cogids[sl->id_lowercase.c_str()].end() && toadd; lcitr++){
											string lcogid = *lcitr;
											reccogid_vs_ligcogids[rcogid.c_str()].insert(lcogid.c_str());
									 	}
									}
								}
							}
						}
					}
				}
				*out << organism << " hompairs " << nhompair << endl;
			}
		}
		
		stringstream ss (stringstream::in | stringstream::out);
		ss << argv[1] << "_" << argv[2] << argv[4] << ".shomologues";
		string filename; ss >> filename;
		fstream fout(filename.c_str(), ios::out);
		*out << "#species with pairs of homologous sequences " << species_intersection.size() << endl;
		
		int num_species=0;
		for(hash_set<const char*, hash<const char*>, eqstr>::iterator itr = species_intersection.begin(); itr != species_intersection.end(); itr++){
			string organism = string((const char*) (*itr));
			*out << organism << endl;
			int nr = homologous_sequences[rchain][*itr]->size();
			int nl = homologous_sequences[lchain][*itr]->size();
			fout << "SPECIES " << organism << " # " << nr << " " << nl << endl;
			sprintf(buf,"mkdir loopp/%d", num_species);
			ret = system(buf);
			if(ret!=0)	*out << string(buf) << " " << ret << endl;
			
			for(int i = 0; i <2; i++){
				char chain= rchain;
				if(i == 1)	chain = lchain;
				
				sprintf(buf,"mkdir loopp/%d/chain%c", num_species,chain);
				int ret = system(buf);
				if(ret!=0)	*out << string(buf) << " " << ret << endl;
			
				vector<Sequence*> sequences = *(homologous_sequences[chain][*itr]);
				int seqno=0;
				for(vector<Sequence*>::iterator sitr = sequences.begin(); sitr != sequences.end(); sitr++){
					Sequence* s = (Sequence*) *sitr;
					fout << s->id_lowercase << " " << s->organism << " " << s->seq_alignment->positives << " " << s->seq_alignment->size << endl;
					stringstream ss (stringstream::in | stringstream::out);
					ss << FASTACMD << " -d " << STRING_DB << " -s " << s->id << " >> loopp/" << num_species << "/chain" << chain << "/s" << seqno << "_" << i << ".fasta";
					ss.getline(buf,2048);
					ret = system(buf);
					if(ret!=0)	*out << string(buf) << " " << ret << endl;
					seqno++;
				}
			}
			num_species++;
		}
		fout.close();
		
		// find homologous sequences for each chain that do not form complexes
		sprintf(buf,"mkdir loopp/neg");
		ret = system(buf);
		if(ret!=0)	*out << string(buf) << " " << ret << endl;
		for(int i = 0; i <2; i++){
			char chain= rchain;
			if(i == 1)	chain = lchain;
				
			sprintf(buf,"mkdir loopp/neg/chain%c", chain);
			int ret = system(buf);
			if(ret!=0)	*out << string(buf) << " " << ret << endl;
			
			stringstream ss (stringstream::in | stringstream::out);
			ss << argv[1] << "_" << chain << ".neghomologues";
			string filename; ss >> filename;
			fstream fout(filename.c_str(), ios::out);
			
			int seqno=0;
			hash_map<int, Sequence*, hash<int>, eqint> chain_homologues;
			/*for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr=blast_hits[chain].begin(); sitr!=blast_hits[chain].end();sitr++){
				Sequence* s = sitr->second;
				bool tooutput = (s->database != "pdb" && s->organism != "" && species_intersection.count((s->organism).c_str()) == 0);
				for(int j = 0; j < seqno && tooutput; j++){
					Sequence *s1 = chain_homologues[j];
					tooutput = (s->seq_alignment != s1->seq_alignment);
				}
					
				if(tooutput){
				 	fout << s->id_lowercase << " " << s->organism << " " << s->seq_alignment->positives << " " << s->seq_alignment->size << endl;
					
					sprintf(buf,"mkdir loopp/neg/chain%c/%d",chain,seqno);
					ret = system(buf);
					if(ret!=0)	*out << string(buf) << " " << ret << endl;
					
					stringstream ss (stringstream::in | stringstream::out);
					ss << FASTACMD << " -d " << STRING_DB << " -s " << s->id << " >> loopp/neg/chain" << chain << "/" << seqno << "/s" << ".fasta";
					ss.getline(buf,2048);
					ret = system(buf);
					if(ret!=0)	*out << endl << string(buf) << " " << ret << endl;
					
					chain_homologues[seqno] = s; 
					seqno++;
				}
			}*/
		}
	}
}
