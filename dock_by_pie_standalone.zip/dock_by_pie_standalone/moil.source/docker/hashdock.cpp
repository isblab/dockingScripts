/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * This code is for verification purposes only not for distribution   */

#include "dock_util.hpp"

/*
 * node 0 arbitrates the distribution, no semaphores for now
 * 1 proc, it generates everything, > 1, node 0 does not generate anything
 */
void generate_transformations(bool filter){
	// Each node takes up a portion of the (i,j,k) space for docking
	int receptor_num_points = receptor->num_faces;
	
	int start;
	node_transformations.clear();
		
	for(int i = 0; i < NUM_GENERATION_STATS; i++)	generation_stats[i] = 0;
		
	if(procid == 0){
		if(numprocs == 1){
			for(int i=0; i<receptor_num_points; i++){
				receptor->match_surfaces(ligand,i,i+1, &node_transformations, filter, generation_stats);
				sort(node_transformations.begin(), node_transformations.end(),less<Transformation*>());
				pieces[i]=node_transformations.size();
				fstream transout;
				char tfilename[512];
				sprintf(tfilename, "%s/%s/%d/trans%d",node_tmp_dir,refpdbcode.c_str(),procid,i);
				transout.open(tfilename,ios::binary|ios::out);
				for(vector<Transformation*>::iterator titr = node_transformations.begin(); titr != node_transformations.end(); titr++){
					Transformation *tr = *titr;
					tr->write_binary(&transout,TN_BASIC);
					delete tr;
				}
				transout.close();
				node_transformations.clear();
			}
			/*char command[512*receptor_num_points];
			stringstream ss (stringstream::in | stringstream::out);
			ss << "cat ";
			for(int i=0; i<receptor_num_points; i++)	ss << "trans" << i << " ";
			ss << "> " << local_transformations_file;
			ss.getline(command,512*receptor_num_points);
			int ret = system(command);
			*out << state << " " << command << " " << ret << endl;
			sprintf(command, "cp %s %s",local_transformations_file,transformations_file);
			ret = system(command);
			cout << state << " " << command << " " << ret << endl;*/
		} else {
			int current = 0;
			bool node_done[numprocs];
			for(int i = 1; i < numprocs; i++)	node_done[i] = false;
			bool done = false;
			
			int num_allocated_to_node[numprocs];
			for(int i = 0; i < numprocs; i++)	num_allocated_to_node[i]=0;
			
			while(!done){
				// receive a token and send work
				MPI_Recv(buff, BUFSIZE, MPI_CHAR, MPI_ANY_SOURCE, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
				int node = atoi(buff);
				
				// follow a predetermined schedule
				//current = (num_allocated_to_node[node]++)*(numprocs-1) + (node-1);
				sprintf(buff, "%d", current);
				MPI_Ssend(buff, BUFSIZE, MPI_CHAR, node, GENERATE_TAG, MPI_COMM_WORLD);
				
				// ended the computation at the node
				if(current >= receptor_num_points)	node_done[node] = true;
				
				*out << "node " << node << " working on " << current << " " << node_done[node] << endl; out->flush();
				
				current = current + 1;
				
				done = true;
				for(int i = 1; i < numprocs; i++)	done &= node_done[i];
			}
			
			cout << "finished assigning ids for matching surface" << endl;
		}
	} else {
		bool done = false;
		while(!done){
			sprintf(buff, "%d",procid);
			MPI_Ssend(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD);
			MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
			start = atoi(buff);
			if(start >= receptor_num_points){
				done = true;
				break;
			} else {
				unsigned int before = node_transformations.size();
				receptor->match_surfaces(ligand,start,start+1,&node_transformations,filter,generation_stats);
				*out << start << " " << procid << " #node trans " << node_transformations.size() - before << endl;
				sort(node_transformations.begin(), node_transformations.end(),less<Transformation*>());
				pieces[start]=node_transformations.size();
				fstream transout;
				char tfilename[512];
				sprintf(tfilename, "%s/%s/%d/trans%d",node_tmp_dir,refpdbcode.c_str(),procid,start);
				transout.open(tfilename,ios::binary|ios::out);
				for(vector<Transformation*>::iterator titr = node_transformations.begin(); titr != node_transformations.end(); titr++){
					Transformation *tr = *titr;
					tr->write_binary(&transout,TN_BASIC);
					delete tr;
				}
				transout.close();
				node_transformations.clear();
			}
		}
	}
	
	long num_node_transformations=0;
	for(hash_map<unsigned int,long,hash<unsigned int>,eqint>::iterator pitr=pieces.begin(); pitr!=pieces.end(); pitr++){
		num_node_transformations += pitr->second;
	}
	time(&current_time);
	*out << "node " << procid << " generated transformations # " << num_node_transformations << "\t time:"
		<< difftime(current_time,start_time) << "s" << endl;
}

/*
 * Assume that the surfaces are generated
 */
int main(int argc, char *argv[]){
	time(&start_time);
	int ret = MPI_Init(&argc,&argv);
	//cout << "MPI init " << ret << endl; cout.flush();
	if(ret == MPI_SUCCESS){
		MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
		MPI_Comm_rank(MPI_COMM_WORLD,&procid);

		if(procid == 0){
			cout << "Job running on " << numprocs << " processors" << endl;
			cout << "#args " << argc << endl;
			cout.flush();
		}
		
		read_molecule_config();
		
		read_dock_config();
		//cout << "check again " << endl; cout.flush();		
		node_tmp_dir = (char*) (new string(string(tmp_dir)+"/"+string(getenv(string("JOB_ID").c_str()))))->c_str();
		
		elect_leader_on_node();
		
		//initialize
		refpdbcode = string(argv[9]);
		sprintf(command, "%s/cluster_scripts/setup.sh %s %d %s %d",getenv(string("HOME").c_str()),getenv(string("JOB_ID").c_str()),procid, refpdbcode.c_str(), masterprocessonnode);
		ret = system(command);
		
		sprintf(scratch_dir, "%s/%s/%d",node_tmp_dir,refpdbcode.c_str(),procid);
		sprintf(filename, "%s/%s/%sout%d",node_tmp_dir,refpdbcode.c_str(),refpdbcode.c_str(),procid);
		//cout << filename << endl; cout.flush();
		fstream outstream;
		outstream.open(filename,ios::out);
		if(!outstream.good()){
			cout << "ERROR: could not open file " << filename << " " << errno << "\n"; cout.flush();
			exit(-1);
		}
		out = &outstream;
		
		*out << procid << " " << *host << " am_master " << masterprocessonnode << endl;
		*out << "setup " << command << " " << ret << endl;
		
		filetype = atoi(argv[1]);
		docktype = atoi(argv[2]);
		start_state = atoi(argv[3]);
		end_state = atoi(argv[4]);
		*out << "start " << start_state << " end " << end_state << endl;out->flush();
		
		stringstream ss (stringstream::in | stringstream::out);
		string s;
		ss << argv[5] << "_" << argv[6] << "_vs_" << argv[7] << "_" << argv[8];
		ss >> s;
		tag = (char*) (new string(s.c_str()))->c_str();
		
		ss.clear();
		string ts;
		ss << s << ".trans";
		ss >> ts;
		transformations_file = (char*) (new string(ts.c_str()))->c_str();
		sprintf(local_transformations_file,"%s/%s",scratch_dir,transformations_file);
		
		ss.clear();
		ss << s << ".combinations";
		string cs;
		ss >> cs;
		combinations_file = (char*) (new string(cs.c_str()))->c_str();
		sprintf(local_combinations_file,"%s/%s",scratch_dir,combinations_file);
		
		rpdbcode = string(argv[5]);
		rchains = string(argv[6]);
		lpdbcode = string(argv[7]);
		lchains = string(argv[8]);
		refrchains = string(argv[10]);
		reflchains = string(argv[11]);
		
		Complex* cr = new Complex(("../"+rpdbcode).c_str(),rchains.c_str(), filetype);
		Complex* crH =cr;// new Complex(("../"+rpdbcode).c_str(),rchains.c_str(), PQR);
		out->flush();
		receptor = new Object(cr,crH);
		
		Complex* cl = new Complex(("../"+lpdbcode).c_str(),lchains.c_str(), filetype);
		Complex* clH = cl;//new Complex(("../"+lpdbcode).c_str(),lchains.c_str(), PQR);
		ligand = new Object(cl, clH);
		
		ss.clear();
		ss << tag << ".info";
		ss >> s;
		ModelInfo *modelinfo = NULL;
		//struct stat stFileInfo;
  		//int filestatus = stat(s.c_str(),&stFileInfo);
  		//if(filestatus == 0){
  		 	
		fstream infoin(s.c_str(), ios::in);
		*out << s << " " << infoin.good() << endl; out->flush();
		if(infoin.good()){
			modelinfo = new ModelInfo();
			
			while(infoin.good()){
				infoin.getline(buff,8192);
				if(infoin.gcount() > 0){
					string pdbid = string(strtok(buff,":"));
					char *chain = strtok(NULL,":");
					char* aaindex = strtok(NULL,":");
					if(pdbid==rpdbcode && rchains.find(string(chain))!=string::npos ){
						*out << cr->molecules.count(chain[0]) << " " << ((Protein*)cr->molecules[chain[0]])->aminoacid.count(aaindex) << endl;
						if(cr->molecules.count(chain[0]) > 0 && ((Protein*)cr->molecules[chain[0]])->aminoacid.count(aaindex) > 0){
							modelinfo->rinterface.insert(((Protein*)cr->molecules[chain[0]])->aminoacid[aaindex]->cindex);
							*out << "added receptor interface residue " << modelinfo->rinterface.size() << endl;
						}
					} else if(pdbid==lpdbcode && lchains.find(string(chain))!=string::npos ){
						*out << cl->molecules.count(chain[0]) << " " << ((Protein*)cl->molecules[chain[0]])->aminoacid.count(aaindex) << endl;
						if(cl->molecules.count(chain[0]) > 0 && ((Protein*)cl->molecules[chain[0]])->aminoacid.count(aaindex) > 0){
							modelinfo->linterface.insert(((Protein*)cl->molecules[chain[0]])->aminoacid[aaindex]->cindex);
							*out << "added ligand interface residue " << modelinfo->linterface.size() << endl;
						}
					}
					*out << "interface residue " << pdbid << " " << string(chain) << " " << string(aaindex) << endl; out->flush();
				}
			}
			infoin.close();
			*out << "done reading info " << modelinfo->rinterface.size() << " " << modelinfo->linterface.size() << endl; out->flush();
		}		
		
		if(argc > 12)	symmetry = atoi(argv[12]);
		else	symmetry = 1;
		
		read_usphere_solution();
			
		//out->flush();
		//if(start_state < SCORE || start_state == VERIFY_TRANS)
		{
			receptor->preprocess_receptor();
			ligand->preprocess_ligand();
			receptor->build_contact_grid(ligand->max_grid_point_distance + sqrt(3)*GRID_SPACING/2.0);
			ligand->build_contact_grid(receptor->max_grid_point_distance + sqrt(3)*GRID_SPACING/2.0);
			
			preprocess();
		}
		pieces.clear();
		
		if(start_state < GENERATE_MATCHES && end_state >= GENERATE_MATCHES){
			state = GENERATE_MATCHES;
			ligand->build_hash_table();
			//*out << "generating " << endl;
			if(end_state == GENERATE_MATCHES){
				generate_transformations(false);
			} else {
				generate_transformations(true);
				start_state = FILTER_STERIC_CLASHES;
			}
			collect_transformations(false,0);
		}
		
		MPI_Finalize();
		//outstream.close();
		
		if(procid == 0){
			time(&current_time);
			cout << "done" << " " << success << "\t time:" << difftime(current_time,start_time) << "s" << endl;
		}
		
		return 0;
	} else {
		cout << "init failed" << endl;
		return 1;
	}
}
