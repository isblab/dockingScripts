/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

// checkft does not work when vdw attraction and repulsion are computed separately
//#define SEPARATE_VDW_ATTR_REPUL

string SPACED_ROTATIONS="68760.euler";
//#define SPACED_ROTATIONS "232020.euler"

float **rot_angles;
int num_rotations;

#ifndef FFT_TRANS_SCORE
typedef struct {
	float evdw, particlep, evdw_real, evdw_imag , score;

#ifdef SEPARATE_VDW_ATTR_REPUL
	float evdw_attr, evdw_repul_core;
#endif

	unsigned int index, rotindex;
} transformationscore;
#define FFT_TRANS_SCORE
#endif

transformationscore *node_result,*rotation_scores;

MKL_LONG gridsize[3], strides[4];
unsigned int size;
float sqrt_size;

short num_particlep_arrays=0;
MKL_Complex8 *rec_shape, *lig_shape, **rec_particlepfft, **lig_particlepgrid, *particlep_sum;
unsigned int num_node_transforms=0;


void write_results_tofile(unsigned int rotation_index);

Vector get_translation(transformationscore *trscore, Transformation *tr);

void write_tofile(MKL_Complex8 *grid, string filename);

void read_rotations();

Transformation *convert_transformation(unsigned int translation, unsigned int rotindex);

void match_rotation(unsigned int rotation_index);

Transformation *read_transformation(char* buf);

void write_nodetransforms_tofile(int state, Transformation *reftr);


