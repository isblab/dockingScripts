/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "geometric_hash.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <ext/hash_map>

#define stdext __gnu_cxx;
using namespace std;
using namespace stdext;

ostream *out;

int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	
	int filetype = atoi(argv[1]);
	int representation = atoi(argv[2]);
	char* pdbcode = (char*) (new string(argv[3]))->c_str();
	char* chains = argv[4];
	
	cout << pdbcode << " " << chains << endl;
	Complex *c = new Complex(pdbcode, chains, filetype);
	
	Reference_Frame *rf = new Reference_Frame(new Vector(10,20,15), 
		new Vector(0.6,0.8,0), new Vector(0,0,1), 1.0, 1);
	
	fstream pdbout;
	pdbout.open(argv[5], fstream::out);
	pdbout << setiosflags(ios::fixed) << setprecision(3);
	
	int num_atoms = c->num_atoms;
	for(int i = 0; i < c->num_aminoacids; i++){
	 	Aminoacid *aa = c->aminoacid[i];
		for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = (aa->atom).begin(); aitr != (aa->atom).end(); aitr++){
			Atom *a = aitr->second;
			if((a->name).size() <= 3){
				Vector v = rf->transform(a->position);
				pdbout << "ATOM" << setiosflags(ios::right) << setw(7) <<  num_atoms++ << "  ";
				pdbout << resetiosflags(ios::right) << setiosflags(ios::left) << setw(3) << a->name 
					<< " " << aa->name << " " << aa->chain << "  ";
				pdbout << setw(6) << aa->index << "  ";
				pdbout << setw(8) << setprecision(3) << v.x 
					<< setw(8) << setprecision(3) << v.y
					<< setw(8) << setprecision(3) << v.z 
					<< "1.00 0.00" << endl;
			}
		}
	}
	pdbout.close();
	
	cout << "done" << endl;
	return 0;
}
