/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "align_utilities.hpp"

#include <mpi.h>
#include <sys/stat.h>
#include <ctime>

#ifndef DOCK_DIR
#define DOCK_DIR "moil.dock/"
#endif

#ifndef EQSTR
#define EQSTR
struct eqstr
{
  bool operator()(const char* s1, const char* s2) const
  {
    return strcmp(s1,s2) == 0;
  }
};
#endif

#ifndef NUM_RESIDUE_TYPES
#define NUM_RESIDUE_TYPES 22
#endif

//#define COMPLETE 0
#define GENERATE_MATCHES 1
#define FILTER_STERIC_CLASHES 2
#define GENERATE_COMBINATIONS 3
#define GENERATE_MODELS 4
#define SCORE 5
#define COMPUTE_DETAILS 6
#define COMPUTE_SEQAVG_DETAILS 7

#define SCD_GIVEN_INTERFACE 7 // SCD - select and compute details
#define SELECT_TRANS 10
#define CLUSTER_TRANS_FINE 20
#define CLUSTER_TRANS_COARSE 21
#define INCREMENTAL_CLUSTER_TRANS 22
#define CLUSTER_TRANS_IRMSD 23
#define CLUSTER_TRANS_FRAC_NAT 24
#define SELECT_SIMILAR_TRANS 30

#define REFINE_TRANSFORMATION 40
#define REFINE_SIDECHAINS 50

#define VERIFY_TRANS 100
#define VERIFY_TRANS_COMPUTE_DETAILS_PROTPROT 110
#define VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA 111
#define EXAMINE_REFERENCE 200
#define GENERATE_PDB 300
#define CONVERT_TRANS_TXT 310
#define CHECK_GRIDSCORE 500
#define VERIFY_COMBINATIONS 1000

#define VERIFY_TRANS_COMPUTE_SEQAVG_DETAILS 120
#define EXAMINE_REFERENCE_SEQAVG 210

#define VERIFY_MODELS 600

#define COMPUTE_FEIG_SCORE 700
#define COMPUTE_ENTROPY_APPROX1 800

#define FFT_GENERATE_MATCHES_VDW 1
#define FFT_GENERATE_MATCHES_ATOMP 2
#define FFT_GENERATE_MATCHES_EVATOMP 3
#define FFT_GENERATE_MATCHES_RESIDUEP 10
#define FFT_GENERATE_MATCHES_RESIDUE_BKBNP 20
#define FFT_GENERATE_MATCHES_PROTRNA_RESIDUE_BKBNP 2020
#define FFT_GENERATE_MATCHES_EVRESIDUE_BKBNP 21
#define FFT_GENERATE_MATCHES_MIXEDP 25
#define FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP 102
#define FFT_USE_REF_ROTATION 250
#define FFT_SYMMETRIC_DIMER 39
#define FFT_GENERATE_TRIMER 30
#define FFT_SYMMETRIC_TRIMER 29
#define SCORE_TRIMER 300
#define FFT_GENERATE_TETRAMER 70

#define NUM_GENERATION_STATS 6

#ifndef CALPHA
#define CALPHA 0
#define BACKBONE 1
#define ALLATOMS 2
#endif

// size for defining transformation grid
#define TRCLUSTERING_GRID_SPACING 6

// when is a transformation a neighbor?
#define R_SPREAD (6/TRCLUSTERING_GRID_SPACING)
#define UR_SPREAD 0.3

#ifndef MTR_MAX_R_DISTANCE
#define MTR_MAX_R_DISTANCE 5.0
#define MTR_MAX_ROTATION_DISTANCE 0.20
#endif

// clustering transformations while generation of combinations
// should be more stringent than those between combinations
#define MTR_MAX_R_DISTANCE_FOR_GENERATION 0.125
#define MTR_MAX_ROTATION_DISTANCE_FOR_GENERATION 0.125

#define NUM_TRANS_FILTERED 2048
#define TR_MAX_R_DISTANCE 8//2.5
#define TR_MAX_ROTATION_DISTANCE 0.25//0.25

#define MIN_DIVERSITY 0.1
#define NUM_CANDIDATES_MODELLED 1024
#define NUM_CONTACT_CLUSTERS NUM_CANDIDATES_MODELLED

#define BUFSIZE 1024*1024
#define TAG 0
#define GENERATE_TAG 1

#define contained_in(x,y,p) ((x <= p) && (p <= y))

#define MODELLER_EXE "external/modeller/bin/mod9v1"
#define GENERATE_MODELLER_SCRIPT "external/modeller/generate_modeller_script.sh"
#define RUN_MODELLER "external/modeller/run_modeller.sh"

class TransformationAndTag{
	public:
		Transformation *tr;
		unsigned int tag;
	TransformationAndTag(Transformation*,unsigned int);
	~TransformationAndTag();
};

namespace std{
	template <> struct less<Transformation*> {
		bool operator()(Transformation* const& t1, Transformation* const& t2){
			bool result;
			//result = (t1->eVdw > t2->eVdw);
			//result = (t1->frame_number <  t2->frame_number);
			result = (t1->eSolvation > t2->eSolvation);
			//result = (t1->eElectrostatic < t2->eElectrostatic);
			//result = (t1->eInterface < t2->eInterface);
			//result = (t1->eResiduepair > t2->eResiduepair);
			//result = ((t1->eVdw + t1->eSolvation + t1->eResiduepair) > (t2->eVdw + t2->eSolvation + t2->eResiduepair));
			//result = (t1->num_neighbors > t2->num_neighbors);
			return result;
		};
	};
	template <> struct less<MultiTransformation*> {
		bool operator()(MultiTransformation* const& mt1, MultiTransformation* const& mt2){
			//return (mt1->curvature_score/mt1->votes) > (mt2->curvature_score/mt2->votes);
			//return (mt1->cscore > mt2->cscore);
			return (mt1->zscore < mt2->zscore);
			//return (mt1->contact_energy < mt2->contact_energy);
			//return (mt1->vdw_energy < mt2->vdw_energy);
		};
	};
	template <> struct greater<TransformationAndTag*> {
		bool operator()(TransformationAndTag* const& t1, TransformationAndTag* const& t2){
			return less<Transformation*>() (t2->tr, t1->tr);
		};
	};
};

struct Transformation_Compare_Contacts{
	bool operator()(Transformation* const& t1, Transformation* const& t2){
		return t1->details->num_new_contacts > t2->details->num_new_contacts;
	}
};

struct Transformation_Compare_Rms{
	bool operator()(Transformation* const& t1, Transformation* const& t2){
		return t1->vmetrics->rmsd < t2->vmetrics->rmsd;
	}
};

#define FFT_GRID_SPACING 1.00

extern char* tmp_dir;
