/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "align_utilities.hpp"

hash_map<long, Alignment*, hash<long>, eqlong> seq_alignments, struct_alignments;

#define NUM_AA_TYPES 20
#define MAX_EVAL 0.01
#define MIN_MATCHES 30
#define GAP_WEIGHT 1

#define CE 1
#define TM 2

#define ONLY_READ 0
#ifndef KMEANS
#define KMEANS 1
#define DENSITY_CLUSTER 2
#endif

#define BUFSIZE 16384
char buf[BUFSIZE];

short blosum62[25][25] = {
 /*       A,  R,  N,  D,  C,  Q,  E,  G,  H,  I,  L,  K,  M,
             F,  P,  S,  T,  W,  Y,  V,  B,  J,  Z,  X,  *        */
    /*A*/    4, -1, -2, -2,  0, -1, -1,  0, -2, -1, -1, -1, -1,
            -2, -1,  1,  0, -3, -2,  0, -2, -1, -1, -1, -4,
    /*R*/   -1,  5,  0, -2, -3,  1,  0, -2,  0, -3, -2,  2, -1,
            -3, -2, -1, -1, -3, -2, -3, -1, -2,  0, -1, -4,
    /*N*/   -2,  0,  6,  1, -3,  0,  0,  0,  1, -3, -3,  0, -2,
            -3, -2,  1,  0, -4, -2, -3,  4, -3,  0, -1, -4,
    /*D*/   -2, -2,  1,  6, -3,  0,  2, -1, -1, -3, -4, -1, -3,
            -3, -1,  0, -1, -4, -3, -3,  4, -3,  1, -1, -4,
    /*C*/    0, -3, -3, -3,  9, -3, -4, -3, -3, -1, -1, -3, -1,
            -2, -3, -1, -1, -2, -2, -1, -3, -1, -3, -1, -4,  
    /*Q*/   -1,  1,  0,  0, -3,  5,  2, -2,  0, -3, -2,  1,  0,
            -3, -1,  0, -1, -2, -1, -2,  0, -2,  4, -1, -4, 
    /*E*/   -1,  0,  0,  2, -4,  2,  5, -2,  0, -3, -3,  1, -2,
            -3, -1,  0, -1, -3, -2, -2,  1, -3,  4, -1, -4, 
    /*G*/    0, -2,  0, -1, -3, -2, -2,  6, -2, -4, -4, -2, -3,
            -3, -2,  0, -2, -2, -3, -3, -1, -4, -2, -1, -4, 
    /*H*/   -2,  0,  1, -1, -3,  0,  0, -2,  8, -3, -3, -1, -2,
            -1, -2, -1, -2, -2,  2, -3,  0, -3,  0, -1, -4,  
    /*I*/   -1, -3, -3, -3, -1, -3, -3, -4, -3,  4,  2, -3,  1,
             0, -3, -2, -1, -3, -1,  3, -3,  3, -3, -1, -4,  
    /*L*/   -1, -2, -3, -4, -1, -2, -3, -4, -3,  2,  4, -2,  2,
             0, -3, -2, -1, -2, -1,  1, -4,  3, -3, -1, -4, 
    /*K*/   -1,  2,  0, -1, -3,  1,  1, -2, -1, -3, -2,  5, -1,
            -3, -1,  0, -1, -3, -2, -2,  0, -3,  1, -1, -4,  
    /*M*/   -1, -1, -2, -3, -1,  0, -2, -3, -2,  1,  2, -1,  5,
             0, -2, -1, -1, -1, -1,  1, -3,  2, -1, -1, -4,  
    /*F*/   -2, -3, -3, -3, -2, -3, -3, -3, -1,  0,  0, -3,  0,
             6, -4, -2, -2,  1,  3, -1, -3,  0, -3, -1, -4, 
    /*P*/   -1, -2, -2, -1, -3, -1, -1, -2, -2, -3, -3, -1, -2,
            -4,  7, -1, -1, -4, -3, -2, -2, -3, -1, -1, -4, 
    /*S*/    1, -1,  1,  0, -1,  0,  0,  0, -1, -2, -2,  0, -1,
            -2, -1,  4,  1, -3, -2, -2,  0, -2,  0, -1, -4, 
    /*T*/    0, -1,  0, -1, -1, -1, -1, -2, -2, -1, -1, -1, -1,
            -2, -1,  1,  5, -2, -2,  0, -1, -1, -1, -1, -4, 
    /*W*/   -3, -3, -4, -4, -2, -2, -3, -2, -2, -3, -2, -3, -1,
             1, -4, -3, -2, 11,  2, -3, -4, -2, -2, -1, -4, 
    /*Y*/   -2, -2, -2, -3, -2, -1, -2, -3,  2, -1, -1, -2, -1,
             3, -3, -2, -2,  2,  7, -1, -3, -1, -2, -1, -4,  
    /*V*/    0, -3, -3, -3, -1, -2, -2, -3, -3,  3,  1, -2,  1,
            -1, -2, -2,  0, -3, -1,  4, -3,  2, -2, -1, -4, 
    /*B*/   -2, -1,  4,  4, -3,  0,  1, -1,  0, -3, -4,  0, -3,
            -3, -2,  0, -1, -4, -3, -3,  4, -3,  0, -1, -4,
    /*J*/   -1, -2, -3, -3, -1, -2, -3, -4, -3,  3,  3, -3,  2,
             0, -3, -2, -1, -2, -1,  2, -3,  3, -3, -1, -4,
    /*Z*/   -1,  0,  0,  1, -3,  4,  4, -2,  0, -3, -3,  1, -1,
            -3, -1,  0, -1, -2, -2, -2,  0, -3,  4, -1, -4,
    /*X*/   -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -4,
    /***/   -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4,
            -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4,  1
};

float aminoacid_probabilities[20] = {0.0806435, 0.0517735, 0.0416625,0.0579148, 0.0137741, 0.0368867, 0.0695807, 0.0743653, 0.0232401, 
					0.0576009, 0.0923057, 0.0596095, 0.0217793, 0.0398862, 0.0456417, 0.0608419, 0.053907, 0.01325, 0.0341903, 0.0711463, 
};	

float blosum62_lambda = 0.250;
double blosum62_rates[21][21];

Alignment::Alignment(string a1, string a2,long index){
	//*out << a1.size() << " " << a2.size() << endl;
	aseq1 = *(new string(a1));
	aseq2 = *(new string(a2));
	this->index = index;
	
	positives_interface=0;
	identities_interface=0;
	gaps_interface=0;
	size = aseq1.size();
};

void Alignment::compute_identities(){
	const char *aseq1c = aseq1.c_str(), *aseq2c = aseq2.c_str();
	identities = 0;
	float len1nogaps = 0, len2nogaps = 0;
	for(int i = 0; i < aseq1.length(); i++){
		if(aseq1c[i] == aseq2c[i] && aseq1c[i] != '-')	identities += 1;
		if(aseq1c[i] != '-') len1nogaps += 1;
		if(aseq2c[i] != '-') len2nogaps += 1;	
		//cout << aseq1c[i] << " " << aseq2c[i] << " " << identities << endl;
	}
	//cout << "denom " << ((qend - qstart) + (send - sstart) + 2) << endl;
	identities = 2*identities / (len1nogaps + len2nogaps);
}

Sequence::Sequence(string seqtag){
	tag = *(new string(seqtag.c_str()));
	
	// get the database 
	database = seqtag.substr(0,seqtag.find("|"));
	bool isgeneraldb = false;
	if(database == "gnl"){
		isgeneraldb = true;
		seqtag = seqtag.substr(4,seqtag.length());
		database = seqtag.substr(0,seqtag.find("|"));
	}

	// get the id of the sequence within the database
	stringstream ss (stringstream::in | stringstream::out), ssl (stringstream::in | stringstream::out);
	string idtag;
	{
		stringstream ss (stringstream::in | stringstream::out);
		ss << seqtag;	ss >> idtag;
	}
	short num_bars = 0;
	for (int j=idtag.find("|"); j<idtag.length(); j++){
		if(idtag[j] == '|'){
			num_bars++;
		} else {
			if(num_bars <= 1){
				ss << ((char) idtag[j]);
				ssl << ((char) tolower(idtag[j]));
			}
		}
	}
	ss >> id;
	ssl >> id_lowercase;
	//id = id.substr(0,id.find("|"));
	
	chain = '-';
	if(database == "pdb" && seqtag.length() >9)
		chain = seqtag[9];
	
	// get the organism name
	organism = "";
	if(seqtag.find("[") != string::npos){
		stringstream ss (stringstream::in | stringstream::out);
		ss << seqtag.substr(seqtag.find("[")+1,seqtag.find("]")-(seqtag.find("[")+1));
		organism="";
		while(ss.good()){
			string s;
			ss >> s;
			organism = organism + s + " ";
		}
	}
	
	*out << database << " " << id << " " << id_lowercase << " " << chain << " " << organism << endl;

	aasequence = NULL;
	seq_alignment = NULL;
	struct_alignment = NULL;
	malignment_index = -1;
};

void Alignment::print_details(ostream *out){
	*out << size << " " << identities << " " << positives << " " << score << " " << eval << endl;
	*out << aseq1 << endl << aseq2 << endl;	
}

void Aminoacid::compute_evolutionary_pressure(float alpha){
	float sump=0, sumn=0;
	for(int i = 0; i < 20; i++){
		sump += profile_typecountsp[i];
		sumn += profile_typecountsn[i];
	}
	
	// avoid positions with too many gaps
	if(sump/(profile_typecountsp[20]+1) >=1.20 && sumn/(profile_typecountsn[20]+1) >=1.20){
		float p[20], n[20];
		for(int i = 0; i < 20; i++){
			p[i] = profile_typecountsp[i]/sump;
			n[i] = profile_typecountsn[i]/sumn;
			profile_probabilities_p[i] = 0;
			profile_probabilities_n[i] = 0;
		}
		//cout << cindex+1 << " " << get_symbol(type) << "\t";
		for(int i = 0; i < 20; i++){
			for(int j = 0; j < 20; j++){
				profile_probabilities_p[i] += blosum62_rates[j][i]*p[j];
				profile_probabilities_n[i] += blosum62_rates[j][i]*n[j];
				if(false)//cindex == 53 && i == 1)
					cout << "prob " << i << " " << j << " " << blosum62_rates[j][i] << " " << p[j] << " " << profile_probabilities_p[i]
						<< " " << n[j] << " " << profile_probabilities_n[i] << endl;
			}
			//cout << p[i] <<":"<< profile_probabilities_p[i] <<"|"<< n[i] <<":" << profile_probabilities_n[i] << "\t";
			profile_probabilities_p[i] = p[i]*(1-alpha) + alpha*profile_probabilities_p[i];
			profile_probabilities_n[i] = n[i]*(1-alpha) + alpha*profile_probabilities_n[i];
		}
		//cout << endl;
		
		//normalize
		sump=sumn=0;
		for(int i = 0; i < 20; i++){
			sump += profile_probabilities_p[i];
			sumn += profile_probabilities_n[i];
		}
		//cout << cindex+1 << " " << get_symbol(type) << "\t";
		for(int i = 0; i < 20; i++){
			//cout << profile_probabilities_p[i] << ":" << profile_probabilities_p[i]/sump<< "|" << profile_probabilities_n[i] 
			//	<< ":" << profile_probabilities_n[i]/sumn << "\t";
			profile_probabilities_p[i] /= sump;
			profile_probabilities_n[i] /= sumn;
		}
		
		//distance
		float dpp=0, dnn=0;
		interaction_evolutionary_pressure = 0;
		for(int i = 0; i < 20; i++){
			//interaction_evolutionary_pressure += profile_probabilities_p[i] * log(profile_probabilities_p[i]/profile_probabilities_n[i]);
			for(int j = 0; j < 20; j++){
				interaction_evolutionary_pressure += profile_probabilities_p[i] * blosum62[i][j] * profile_probabilities_n[j];	
			}
			int j=i;
			dpp += profile_probabilities_p[i] * blosum62[i][j] * profile_probabilities_p[j];
			dnn += profile_probabilities_n[i] * blosum62[i][j] * profile_probabilities_n[j];
		}
		interaction_evolutionary_pressure /= (ABS(dpp) + ABS(dnn) + 0.0001);
		//cout << interaction_evolutionary_pressure << endl;
	} else
		 interaction_evolutionary_pressure = 0;
}

Alignment *read_lalign_alignment(string* query, char *filename, unsigned int aindex){
	fstream fin(filename, fstream::in);
	*out << filename << " " << fin.is_open() << endl; out->flush();
	do{
		fin.getline(buf,BUFSIZE);
	}while((string(buf)).find("Waterman-Eggert") == string::npos && !fin.eof());
	if(fin.eof())	return NULL;
	string s = string(buf);
	float score = atof((s.substr(s.find("score:")+6,s.find(";")-(s.find("score:")+6))).c_str());
	
	fin.getline(buf,BUFSIZE);
	s = string(buf);
	short align_len = atoi((s.substr(s.find("similar) in")+11,s.find("aa overlap")-(s.find("similar) in")+11))).c_str());
	s = s.substr(s.find("aa overlap") + 10);
	int beginQ = atoi((s.substr(s.find("(")+1,s.find("-")-(s.find("(")+1))).c_str());
	int endQ = atoi((s.substr(s.find("-")+1,s.find(":")-(s.find("-")+1))).c_str());
	*out << "lalign " << s << "\t" << beginQ << " " << endQ << endl;
	s = s.substr(s.find(":")+1);
	int beginM = atoi((s.substr(0,s.find("-"))).c_str());
	int endM = atoi((s.substr(s.find("-")+1,s.find(")")-(s.find("-")+1))).c_str());
		
	fin.getline(buf,BUFSIZE);
	
	string seqQ="", seqM="";
	bool done = false;
	while(!done){
		do{
			fin.getline(buf,BUFSIZE);
			done = (buf[0] == '>');
		}while(!(done = fin.eof()));
		
		if(!done){
			fin.getline(buf,BUFSIZE);
			{
				stringstream line = stringstream(buf,stringstream::in);
				string s;	line >> s;
				line >> s;
				seqQ = seqQ + s;
				//*out << s << endl;
			} 
			fin.getline(buf,BUFSIZE);
			fin.getline(buf,BUFSIZE);
			{
				stringstream line = stringstream(buf,stringstream::in);
				string s;	line >> s;
				line >> s;
				seqM = seqM + s;
				//*out << s << endl;
			}
			fin.getline(buf,BUFSIZE);
			fin.getline(buf,BUFSIZE);
		}
	}
	fin.close();
		
	Alignment* a = new Alignment(seqQ,seqM,aindex);
	a->score = score;
	a->qstart = beginQ;
	a->qend = endQ;
	a->sstart = beginM;
	a->send = endM;
	
	return a;
}

/*
 * The second sequence in the loopp alignment corresponds to the protein with known structure
 */
void read_loopp_alignment(int alignno, const char* tag, Alignment **ga, Alignment** la){
	for(short ai=0; ai<2; ai++){
		stringstream ss (stringstream::in | stringstream::out);
		ss << string(tag) << "_" << ai << ".info";
		string filename;
		ss >> filename;
		fstream fin(filename.c_str(), fstream::in);
		*out << filename << " " << fin.is_open() << endl; out->flush();
		do{
			fin.getline(buf,BUFSIZE);
		}while((string(buf)).find("align_len") == string::npos);
		string s = string(buf);
		short align_len = atoi((s.substr(s.find("align_len")+10,s.find("ene=")-(s.find("align_len")+10))).c_str());
		float score = atof((s.substr(s.find("ene=")+4,s.length()-(s.find("ene=")+4))).c_str());
		
		do{
			fin.getline(buf,BUFSIZE);
		}while((string(buf)).find("begin1") == string::npos);
		s = string(buf);
		short sbegin1 = s.find("begin1");
		short sbegin2 = s.find("begin2");
		int beginX = atoi((s.substr(sbegin1+7,sbegin2-(sbegin1+7))).c_str());
		int beginS = atoi((s.substr(sbegin2+7,s.size()-(sbegin2+7))).c_str());
		
		int numsegments = align_len/50;
		if(align_len %50 != 0)	numsegments++;
		
		string seqX="", seqS="";
		for(int si=0; si<numsegments; si++){
			for(int i=0; i<4; i++)	fin.getline(buf,BUFSIZE);
			fin.getline(buf,BUFSIZE);
			stringstream line = stringstream(buf,stringstream::in);
			string s;	line >> s;
			seqS = seqS + s;
			*out << s << endl; 
			
			fin.getline(buf,BUFSIZE);
			fin.getline(buf,BUFSIZE);
			stringstream line2 = stringstream(buf,stringstream::in);
			line2 >> s;
			seqX = seqX + s;
			*out << s << endl; out->flush();
			
			if(si<numsegments-1){
				for(int i=0; i<5; i++)	fin.getline(buf,BUFSIZE);
			}
		}
		
		Alignment* a = new Alignment(seqX,seqS,ai);
		a->score = score;
		a->qstart = beginX+1;
		const char* seqXc = seqX.c_str();
		a->qend = a->qstart-1;
		for(int k = 0; k < seqX.size(); k++)
			if(seqXc[k] != '-')	(a->qend)++;
		a->compute_identities();
		if(ai == 0)	*la = a;
		else	*ga = a;
		*out << a << " " << alignno << " " << align_len << " " << a->size << " " << a->qstart << " " << a->qend << endl;
	}
}

void read_loopp_alignments(int numresiduesX, int speciesno, char chain, int chaininalign, int num_alignments, hash_map<int,Alignment*,hash<int>, eqint> *alignments){
	for(int i = 0; i < num_alignments; i++){
		stringstream ss (stringstream::in | stringstream::out);
		if(speciesno >= 0)
			ss << "../loopp/" << speciesno << "/chain" << chain << "/align" << i << "_" << chaininalign;
		else
			ss << "../loopp/neg/chain" << chain << "/" << i << "/align";
		string tag; ss >> tag;
		Alignment *ga,*la;	 
		read_loopp_alignment(i,tag.c_str(),&ga,&la);
		int local_align_length = la->size;
		*out << "ratio " << chaininalign << " " << la->size/((float)numresiduesX) << endl;
		if(la->size/((float)numresiduesX) >= 0.80)
			(*alignments)[i] = la;
	}
	*out << "#alignments " << num_alignments << " " << alignments->size() << endl;
}

/*
 * Process the output of psiblast and get the sequence alignments with scores
 */
void read_blast_hits(char chain, unsigned short db, string dir){
	stringstream ss (stringstream::in | stringstream::out);
	ss << dir << "/" << pdbcode << "_" << chain << ".";
	switch(db){
		case DB_PDBAA:
			ss << "matches";
		break;
		case DB_SWISSPROT:
			ss << "spmatches";
		break;
		case DB_NR:
			ss << "allmatches";
		break;
		case DB_STRING:
			ss << "stmatches";
		break;
	}
	string filename;
	ss >> filename;
	fstream fin(filename.c_str(), fstream::in);
	
	if(!fin.is_open()){
		*out << "Error opening file " << filename << endl;
		exit(1);
	}
	
	int round = 1;
	bool done = false;
	stringstream* line;
	string last_index;
	long aindex= 0;
	do{
		if(round == 1){
			do{
				fin.getline(buf,BUFSIZE);
			}while((string(buf)).find("letters)") == string::npos);
			line = new stringstream(buf,stringstream::in);
			string s;
			*line >> s;
			int start = s.find("(") + 1;
			int end = s.find("letter");
			int length = atoi(s.substr(start,end - start).c_str());
			
			sprintf(buf,"%d",length-1);
			last_index = *(new string(buf));
			*out << "seq length " << length << " " << last_index << endl;
		}
		
		do{
			fin.getline(buf,BUFSIZE);
			if(!fin.good()){
				*out << "no hits found" << endl;
				return;
			}
		}while((string(buf)).find("Results from round") == string::npos);
		
		if(round == 1){
			do{
				fin.getline(buf,BUFSIZE);
			}while((string(buf)).find("Sequences producing significant alignments") == string::npos);
			fin.getline(buf,BUFSIZE);
			//*out << "check " << buf << endl;
		} else {
			do{
				fin.getline(buf,BUFSIZE);
			}while((string(buf)).find("Sequences not found previously") == string::npos);
			fin.getline(buf,BUFSIZE);
		}
		
		bool round_done = false;
		while (fin.good() && buf[0] != '>')
			fin.getline(buf,BUFSIZE);
		if(!fin.good()){
			*out << "ERROR : Check file format " << filename << endl;
			return; 
		}
		
		*out << round << " read matching sequences" << endl;
		round_done = false;
		// get alignments and scores
		while (!round_done){
			while((string(buf)).size() == 0)
				fin.getline(buf,BUFSIZE);
			
			// additional alignments from previous match - 
			while((string(buf)).find("Score") != string::npos || (string(buf)).find("Query:") != string::npos){
				do{
					fin.getline(buf,BUFSIZE);
				}while((string(buf)).find("Sbjct") == string::npos);
				fin.getline(buf,BUFSIZE);
				while((string(buf)).size() == 0)
					fin.getline(buf,BUFSIZE);
			}
			//*out << "|" << buf << endl;
			
			done =  ((string(buf)).find("Database:") != string::npos);
			round_done = done || ((string(buf)).find("Searching") != string::npos && (string(buf)).find("done") != string::npos);
			
			if(!round_done){
				vector<string> current_seqids;
				bool reading_seqids = true, first_newline = true;
				string current_seqtag;
				while(reading_seqids){
					reading_seqids = ((string(buf)).find("Length =") == string::npos);
					if(reading_seqids){
						bool start_newline = ((string(buf)).find("|") != string::npos);
						if(start_newline){
							if(!first_newline){
								current_seqids.push_back(current_seqtag);
								//*out << current_seqtag << endl;
							} else	first_newline= false;
							
							current_seqtag = string(buf).substr(1);
						} else {
							current_seqtag += string(buf);
						}
						fin.getline(buf,BUFSIZE);
					}
				}
				current_seqids.push_back(current_seqtag);
				//*out << current_seqtag << endl;
				
				// am at Length =
				//*out << "check " << buf << endl;
				bool alignment_done = false;
				string aseq1 = "", aseq2 = "";
				int qstart, qend, sstart, send;
				bool read_scores = false;
				float score, eval, identities,positives;
				do{
					string s;
					if(!read_scores){
						do{
							fin.getline(buf,BUFSIZE);
						}while((string(buf)).find("Score") == string::npos);
						line = new stringstream(buf,stringstream::in);
						*line >> s; *line >> s; *line >> s;
						score = atof(s.c_str());
						*line >> s; *line >> s; *line >> s; *line >> s; *line >> s;
						eval = atof(s.substr(0,s.find(",")).c_str());
						//*out << buf << endl << "score " << score << " eval " << eval << endl;
						
						do{
							fin.getline(buf,BUFSIZE);
						}while((string(buf)).find("Identities") == string::npos);
						line = new stringstream(buf,stringstream::in);
						*line >> s; *line >> s; *line >> s; *line >> s;
						identities = atof(s.substr(1,s.find("%")).c_str());
						*line >> s; *line >> s; *line >> s; *line >> s;
						positives = atof(s.substr(1,s.find("%")).c_str());
						//*out << buf << endl << "identities " << identities << " positives " << positives << endl;
						
						read_scores = true;
						
						fin.getline(buf,BUFSIZE);
					}
					
					while((string(buf)).find("Query") == string::npos)
						fin.getline(buf,BUFSIZE);
					
					//*out << "q " << buf << endl;
					line = new stringstream(buf,stringstream::in);
					*line >> s; 
					if(aseq1 == "")
						*line >> qstart;
					else
						*line >> s; 
					*line >> s; *line >> qend;
					alignment_done = (s.size() < 60);
					aseq1 += s;
					//*out << s << " " << s.size() << " " <<  alignment_done << endl;
					//*out << buf << " " << (string(buf)).size() << " " <<  alignment_done << endl;
					
					do{
						fin.getline(buf,BUFSIZE);
						line = new stringstream(buf,stringstream::in);
						*line >> s; 
						if(aseq2 == "")
							*line >> sstart;
						else
							*line >> s; 
						*line >> s; *line >> send;
					}while((string(buf)).find("Sbjct") == string::npos);
					aseq2 += s;
					fin.getline(buf,BUFSIZE);
					fin.getline(buf,BUFSIZE);
					if(!alignment_done)
						alignment_done = ((string(buf)).size() == 0);
				}while(!alignment_done);
				
				//*out << aseq1 << endl << aseq2 << endl;
				Alignment* a = new Alignment(aseq1,aseq2,aindex++);
				a->score = score;
				a->eval = eval;
				a->identities = identities;
				a->positives = positives;
				a->qstart = qstart;
				a->qend = qend;
				a->sstart = sstart;
				a->send = send;
				//*out << astart << " " << aend << endl;
				//*out << a->index << " " << a->eval << endl;
				seq_alignments[aindex] = a;
				
				//*out << "size " << current_seqids.size() << endl;
				for(vector<string>::iterator sitr = current_seqids.begin(); sitr != current_seqids.end(); sitr++){
					string seqid = *sitr;
					//*out << seqid << endl;
					Sequence *s;
					if(matching_sequences.count(seqid.c_str()) == 0){
						matching_sequences[(new string(seqid))->c_str()] = new Sequence(seqid);	
					}
					s = matching_sequences[seqid.c_str()];
					/*if(s->id_lowercase == "zp_01773199.1"){
						cout << "READ alignment " << s->id << " " << a << " " << a->index << " " << a->identities << " " << a->aseq1 << endl;
					}*/
					s->seq_alignment = a;
					//*out << score << " " << identities << " " << positives << " " << qstart <<":"<<qend << " " << sstart <<":" << send <<endl;
					//a->print_details(out);
					//a->seqids.push_back(seqid);
					//if(a->identities >= 99 && ((float) aseq1.length())/aseq2.length() >= 0.95) *out << "mseq-" << seqid << endl;
					//*out << a->aseq1->size() << " " << a->aseq2->size() << endl;
				}
			}
		}
		*out << round << " read matching alignments" << endl;
		*out << "round " << round << " #matches " << matching_sequences.size() << " #alignments " << seq_alignments.size() << endl;
		round++;
	} while(!done);
	fin.close();

	*out << "#matching sequences " << matching_sequences.size() << " #alignments " << seq_alignments.size() << endl;
}

void read_optm_local_hits(char *filename){
	fstream fin(filename, fstream::in);
	
	if(!fin.is_open()){
		*out << "Error opening file " << filename << endl;
		exit(1);
	}
	
	stringstream* line;
	long aindex= 0;
	while(!fin.eof()){
		do{
			if(fin.eof())	return;
			fin.getline(buf,BUFSIZE);
		}while((string(buf)).find("seq2struc") == string::npos);
		line = new stringstream(buf,stringstream::in);
		string s;
		for(int i = 0; i < 5; i++)	*line >> s;
		string template_id;
		*line >> template_id;
		
		*line >> s;
		int align_len = atoi(s.substr(10,s.length()-10).c_str());
		
		*line >> s;
		float ene = atof(s.substr(4,s.length()-4).c_str());
			
		fin.getline(buf,BUFSIZE);
		line = new stringstream(buf,stringstream::in);
		
		*line >> s;
		float identities = atof(s.substr(9,s.length()-9).c_str());	
		
		do{
			*line >> s;
		}while(s.find("begin1") == string::npos);
		int sstart = atoi(s.substr(7,s.length()-7).c_str());
		
		*line >> s;
		int qstart = atoi(s.substr(7,s.length()-7).c_str());

		int numsegments = align_len/50;
		if(align_len %50 != 0)	numsegments++;
		
		string seqX="", seqQ="";
		for(int si=0; si<numsegments; si++){
			for(int i=0; i<4; i++)	fin.getline(buf,BUFSIZE);
			fin.getline(buf,BUFSIZE);
			stringstream line = stringstream(buf,stringstream::in);
			string s;	line >> s;
			seqQ = seqQ + s;
			*out << s << endl; 
			
			fin.getline(buf,BUFSIZE);
			fin.getline(buf,BUFSIZE);
			stringstream line2 = stringstream(buf,stringstream::in);
			line2 >> s;
			seqX = seqX + s;
			*out << s << endl; out->flush();
			
			if(si<numsegments-1){
				for(int i=0; i<5; i++)	fin.getline(buf,BUFSIZE);
			}
		}			
		
		Sequence *seq = new Sequence(template_id);
		if(matching_sequences.count(template_id.c_str()) == 0){
			matching_sequences[(new string(template_id))->c_str()] = seq;	
		}
		Alignment* a = new Alignment(seqQ,seqX,aindex++);
		a->score = ene;
		a->identities = identities;
		
		a->qstart = qstart+1;
		const char* seqQc = seqQ.c_str();
		a->qend = a->qstart-1;
		for(int k = 0; k < seqQ.size(); k++)
			if(seqQc[k] != '-')	(a->qend)++;
			
		a->sstart = sstart+1;
		const char* seqXc = seqX.c_str();
		a->send = a->sstart-1;
		for(int k = 0; k < seqX.size(); k++)
			if(seqXc[k] != '-')	(a->send)++;	
		
		seq->seq_alignment = a;
	}
}

/*
 * to fix CE
 */
void pairwise_struct_align(int algorithm, char chain){
	long aindex= 0;
	hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr = matching_sequences.begin(), send = matching_sequences.end();
	hash_map<const char*, Sequence*, hash<const char*>, eqstr> sequences_in_pdb;
	
	while(sitr != send){
		Sequence *s = sitr->second;
		
		// check if file in pdb
		stringstream ss (stringstream::in | stringstream::out);
		ss << PDB_DIR << "/pdb" << (s->id_lowercase) << ".ent";
		string filename;
		ss >> filename;
		//*out << filename << endl;
		fstream fp(filename.c_str(), fstream::in);
		if(fp.good()){
			fp.close();
			sequences_in_pdb[sitr->first] = s;
			stringstream ss (stringstream::in | stringstream::out);
			switch(algorithm){
				case CE:
					ss << getenv(string("HOME").c_str()) << "/" << string(RUN_CE).c_str() << " " << pdbcode << ".pdb " << chain << " \"" << PDB_DIR << "/pdb" << (s->id_lowercase) 
						<< ".ent\" " <<  (s->chain) << " > ./ce/" << (s->id_lowercase) << "_" << (s->chain) << ".ce";
				break;
				case TM:
					ss << getenv(string("HOME").c_str()) << "/" << string(RUN_TMALIGN).c_str() << " " << pdbcode << ".pdb " << chain << " \"" << PDB_DIR << "/pdb" << (s->id_lowercase)  
						<< ".ent\" " <<  (s->chain) << " " << pdbcode << chain << " " << (s->id_lowercase) << (s->chain)
						<< " > ./tm/" << (s->id_lowercase) << "_" << (s->chain) << ".tm";
				break;
			}
			ss.getline(buf,BUFSIZE);
			int ret = system(buf);
			//*out << buf << " " << ret << endl; 
			
			if(ret == 0){
				sequences_with_struct_alignment[sitr->first] = s;
				// read the structural alignment
				ss.clear();
				switch(algorithm){
					case CE:
						ss << "./ce/" << (s->id_lowercase) << "_" << (s->chain) << ".ce";
					break;
					case TM:
						ss << "./tm/" << (s->id_lowercase) << "_" << (s->chain) << ".tm";
					break;
				}
				ss >> filename;
				fstream alignin(filename.c_str(), fstream::in);
				//*out << "alignin " << filename << endl;
				
				stringstream *line;
				bool alignment_done = false;
				string aseq1="",aseq2="";
				switch(algorithm){
					case CE:
						do{
							alignin.getline(buf,BUFSIZE);
						}while((string(buf)).find("Alignment length =") == string::npos);
						
						do{
							string s;
							do{
								alignin.getline(buf,BUFSIZE);
							}while(((string(buf)).find("X2") == string::npos) && ((string(buf)).find("Chain") == string::npos));
							
							alignment_done = ((string(buf)).find("X2") != string::npos);
							if(!alignment_done){
								while((string(buf)).find("Chain 1:") == string::npos){
									alignin.getline(buf,BUFSIZE);
								}
								
								line = new stringstream(buf,stringstream::in);
								*line >> s; *line >> s; *line >> s; *line >> s;
								aseq1 += s;
								
								do{
									alignin.getline(buf,BUFSIZE);	
								}while((string(buf)).find("Chain 2:") == string::npos);
								
								line = new stringstream(buf,stringstream::in);
								*line >> s; *line >> s; *line >> s; *line >> s;
								aseq2 += s;
							}
						}while(!alignment_done);
					break;
					case TM:
						do{
							alignin.getline(buf,BUFSIZE);
						}while((string(buf)).find("Aligned length=") == string::npos);
						
						do{
							alignin.getline(buf,BUFSIZE);
						}while((string(buf)).find("denotes the residue") == string::npos);
						
						alignin.getline(buf,BUFSIZE);
						aseq1 = *(new string(buf));
						
						alignin.getline(buf,BUFSIZE);
						
						alignin.getline(buf,BUFSIZE);
						aseq2 = *(new string(buf));
					break;
				}
				alignin.close();
				
				//*out << aindex << endl << aseq1 << endl << aseq2 << endl;
				Alignment* a = new Alignment(aseq1,aseq2,aindex++);
				struct_alignments[aindex] = a;
				
				s->struct_alignment = a;
				//a->seqids.push_back(seqid);
			}
		}
		//*out << "done" << endl;
		sitr++;
	}
	
	matching_sequences_in_pdb = sequences_in_pdb;
	*out << "#matching sequences (in pdb) " << matching_sequences_in_pdb.size()
		<< " #matching sequences (ce success) " << sequences_with_struct_alignment.size() 
		<< " #structalignments " << struct_alignments.size() << endl;
}


/*
 * As of now, define homologues by sequence matches and presence in the pdb
 * structural alignment might not be available!
 */
void read_molecules(int type){
	hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr, send;
	switch(type){
		case SEQ_ALIGN:
			sitr = matching_sequences.begin();
			send = matching_sequences.end();
		break;
		case STRUCT_ALIGN:
			sitr = sequences_with_struct_alignment.begin();
			send = sequences_with_struct_alignment.end();
		break;
	}
	
	while(sitr != send){
		Sequence *s = sitr->second;
		
		// check if file in pdb
		stringstream ss (stringstream::in | stringstream::out);
		ss << getenv(string("HOME").c_str()) << "/" << PDB_DIR << "/pdb" << (s->id_lowercase) << ".ent";
		string filename;
		ss >> filename;
		//*out << filename << endl;
		fstream fp(filename.c_str(), fstream::in);
		if(fp.good()){
			fp.close();
			Protein *m = new Protein(NULL,s->id_lowercase,s->chain,PDB);
			homologues[sitr->first] = m;
			s->aasequence = new string((m->compute_aasequence()).c_str());
		}
		
		sitr++;
	}
	*out << "#homologues " << homologues.size() << endl;
}

void read_profile(Protein *m){
	stringstream ss (stringstream::in | stringstream::out);
	string filename;
	ss << m->pdbcode << "_" << m->chain << ".profile";
	ss >> filename;
	
	read_profile(m,((char*) filename.c_str()));
}

void read_profile(Protein *m, char *filename){
	Aminoacid* aacid[m->aminoacid.size()+1];
	int maaindex=0;
	for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = m->aminoacid.begin(); aaitr != m->aminoacid.end(); aaitr++)
		aacid[maaindex++] = ((Aminoacid*) aaitr->second);
	
	sort(aacid, aacid+m->aminoacid.size(),less<Aminoacid*>());	
	/*for(int i = 0; i < maaindex; i++)
		for(int j = i+1; j < maaindex; j++)
			if(less<Aminoacid*>()(aacid[j],aacid[i])){
				Aminoacid* aa = aacid[i];
				aacid[i] = aacid[j];
				aacid[j] = aa;
			}*/
	
	stringstream ss (stringstream::in | stringstream::out);
	fstream fin(filename, fstream::in);
	if(!fin.is_open()){
		*out << "ERROR: profile not present" << endl;
		out->flush(); exit(1);
	}
	
	char buf[8192];
	do {
		fin.getline(buf,8192);
	} while ((string(buf)).find("position") == string::npos);
	fin.getline(buf,8192);
	
	int aaindex = 0;
	float sum=0, sum_squares=0;
	int count=0;
	while(!fin.eof() && ((string(buf)).find("Lambda") == string::npos)){
		fin.getline(buf,8192);
		if(fin.gcount() > 150){
			Aminoacid* aa = aacid[aaindex];
	
			float entropy;
			{
				stringstream line(buf+150,stringstream::in);
				line >> entropy;
				line >> aa->blast_pseudocount;
			}
			
			{
				stringstream line(buf,stringstream::in);
				for(int j = 0; j < 22; j++){
					string tag;
					line >> tag;
				}
				for(int j = 0; j < 20; j++){
					line >> aa->profile_probabilities_p[j];
				}
			}
		
			aa->entropy_sequence = entropy;
			aaindex++;
			*out << aa->get_symbol() << " " << aa->entropy_sequence << endl;
			
			if(aa->sa > 0){
				sum += entropy;
				sum_squares += entropy*entropy;	
				count++;
			}
		}
	}
	fin.close();
}

void read_part_profile(Protein *m, int begin, int end, char *filename){
	Aminoacid* aacid[(end - begin)+1];
	int maaindex=0;
	for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = m->aminoacid.begin(); aaitr != m->aminoacid.end(); aaitr++){
		Aminoacid *aa = (Aminoacid*) aaitr->second;
		if(aa->cindex >= begin && aa->cindex < end)
			aacid[maaindex++] = aa;
	}
	
	sort(aacid, aacid+maaindex,less<Aminoacid*>());
	
	stringstream ss (stringstream::in | stringstream::out);
	fstream fin(filename, fstream::in);
	if(!fin.is_open()){
		*out << "ERROR: profile not present" << endl;
		out->flush(); exit(1);
	}
	
	char buf[8192];
	do {
		fin.getline(buf,8192);
	} while ((string(buf)).find("position") == string::npos);
	fin.getline(buf,8192);
	
	int aaindex = 0;
	while(!fin.eof() && ((string(buf)).find("Lambda") == string::npos)){
		fin.getline(buf,8192);
		if(fin.gcount() > 150){
			Aminoacid* aa = aacid[aaindex];
	
			float entropy;
			{
				stringstream line(buf+150,stringstream::in);
				line >> entropy;
			}
		
			aa->entropy_sequence = entropy;
			aaindex++;
			*out << aa->get_symbol() << " " << aa->entropy_sequence << endl;
		}
	}
	fin.close();
}


/*
 * Computing the star alignment from pairwise alignments to the query
 * 
 * Uses the aminoacid sequence of the matches - assumes homologues are read
 * 
 * return the conservation index for each residue
 * the output is written in PIR format
 */
void multiple_align(int type,char chain){
	int seqsize = sequence->size();
	const char* sequence_carray = sequence->c_str();
		
	stringstream ss (stringstream::in | stringstream::out);
	string filename;
	ss << pdbcode << "_" << chain << ".";
	switch(type){
		case SEQ_ALIGN:
			ss << "sequence";
		break;
		case STRUCT_ALIGN:
			ss << "struct";
		break;
	}
	ss << ".ali";
	ss >> filename;
	fstream fout(filename.c_str(), fstream::out);
	
	if(!fout.is_open()){
		*out << "Error opening file " << filename << endl;
		exit(1);
	}
	
	hash_map<long, Alignment*, hash<long>, eqlong> examined_alignment;
	
	int n = matching_sequences.size()+1;
	malignment = (char**) malloc(n*sizeof(char*));
	malignment_indices = (const char ***) malloc(n*sizeof(const char **));
	int m = seqsize; 
	for(int i = 0; i < n ; i++){
		malignment[i] = (char*) malloc((m+1)*sizeof(char));
		malignment_indices[i] = (const char **) malloc(m*sizeof(const char *));
		for(int j = 0; j < m ; j++){
			malignment[i][j] = '-';
			malignment_indices[i][j] = NULL;
		}
		malignment[i][m] = '\0';
	}

	*out << "sequence size " << seqsize << " #alignments " << seq_alignments.size() << endl;
	//fout << "query\t\t" << *sequence << endl;
	hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr, send; 
	switch(type){
		case SEQ_ALIGN:
			sitr = matching_sequences.begin();
			send = matching_sequences.end();
		break;
		case STRUCT_ALIGN:
			sitr = sequences_with_struct_alignment.begin();
			send = sequences_with_struct_alignment.end();
		break;
	}

	int mindex = 0;
	while(sitr != send){
		Sequence *s = sitr->second;
		Alignment *a;
		switch(type){
			case SEQ_ALIGN:
				a = s->seq_alignment;
			break;
			case STRUCT_ALIGN:
				a = s->struct_alignment;
			break;
		}
		
		bool toprocess_alignment = (a != NULL) && (examined_alignment.count(a->index) == 0);
		switch(type){
			case SEQ_ALIGN:
				toprocess_alignment = toprocess_alignment && (a->eval < MAX_EVAL);
			break;
			case STRUCT_ALIGN:
			break;
		}
		
		if(toprocess_alignment){
			examined_alignment[a->index] = a;
			//*out << a->index << " " //<< a->eval << " " << a->score << " " << a->positives << " "
			//	<< (a->aseq1).size() << " " << (a->aseq2).size() << endl;
			
			string s1,s2;
			//assuming aseq1 is the query
			s1 = a->aseq1;
			s2 = a->aseq2;
			
			char gapless_s2c[s2.size() + 1];
			const char* s2c = s2.c_str();
			int s2_vs_gapless_s2[s2.size() + 1];
			for(int i = 0 ; i < s2.size()+1; i++)
				s2_vs_gapless_s2[i] = -1;
				
			int gapless_index = 0;
			for(int i = 0 ; i < s2.size(); i++){
				if(s2c[i] != '-'){
					s2_vs_gapless_s2[i] = gapless_index;
					gapless_s2c[gapless_index++] = s2c[i];
				}
			} 
			gapless_s2c[gapless_index] = s2c[s2.size()];
			string gapless_s2 = string(gapless_s2c);
			
			*out << (s->id_lowercase) << "_" << (s->chain) << " gapless alignment string is substring? " << ((s->aasequence)->find(gapless_s2) == string::npos) << endl;
			*out << *(s->aasequence) << endl << gapless_s2 << endl;
			if( (s->aasequence)->find(gapless_s2) != string::npos){
				s->malignment_index = mindex;
			
				int s2start = (s->aasequence)->find(gapless_s2);
				int s2end = s2start + gapless_s2.size();
			
				*out << s2start << " " << s2end << " " << a->sstart << " " << a->send << "\t";
				// remove gaps from s1 and note the alignment
				char gapless_s1c[s1.size() + 1];
				int gapless_s1_vs_s2[s1.size() + 1];
				const char* s1c = s1.c_str();
				gapless_index = 0;
				for(int i = 0 ; i < s1.size(); i++){
					if(s1c[i] != '-'){
						gapless_s1_vs_s2[gapless_index] = i;
						gapless_s1c[gapless_index++] = s1c[i];
					}
				} 
				gapless_s1c[gapless_index] = s1c[s1.size()];
				string gapless_s1 = string(gapless_s1c);
				
				int s1start = sequence->find(gapless_s1);
				int s1end = s1start + gapless_s1.size();
				if(s1start == string::npos){
					*out << "ERROR: alignment not consistent with string" << endl;
					*out << *sequence << endl;
					*out << gapless_s1 << endl;
					*out << s1start << "\t" << s1end << "\t" << s1 << endl;
					out->flush(); exit(1);
				}
				*out << s1start << " " << s1end << endl;
				
				const char* s2c = s2.c_str();
				for(int i = s1start ; i < s1end; i++){
					int s2index = gapless_s1_vs_s2[i-s1start];
					malignment[mindex][i] = s2c[s2index];
					if(malignment[mindex][i] != '-'){
						stringstream ss (stringstream::in | stringstream::out);
						ss << s2start + s2_vs_gapless_s2[s2index];
						string s; ss >> s;
						malignment_indices[mindex][i] = (new string(s))->c_str();
						//*out << i << " " << s2index  << " " << s2_vs_gapless_s2[s2index] << endl;
					}
				}
				
				*out << mindex << " " << (s->id_lowercase) << "_" << (s->chain) << " ";
				//*out << *(s->aasequence) << endl;
				//*out << gapless_s2 << endl;
				//*out << s2start << "\t" << s2end << "\t" << s2 << endl;
				for(int i = 0 ; i < seqsize; i++)
					if(malignment_indices[mindex][i] != NULL)
						*out << malignment_indices[mindex][i] << " ";
				*out << endl;
				/**out << string(malignment[mindex]) << endl;
				const char* sc = (s->aasequence)->c_str();
				for(int i = 0 ; i < seqsize; i++)
					if(malignment_indices[mindex][i] != -1)
						*out << sc[malignment_indices[mindex][i]];
				*out << endl;*/
				
				// need to compute the start and end of the portion of the sequence
				// in the multiple alignment
				fout << ">P1;" << (s->id_lowercase) << endl << "structure:" << (s->id_lowercase) << ":" << (a->sstart) << ":";
				if(s->chain != '-')	fout << (s->chain);
				fout << ":" << (a->send) << ":";
				if(s->chain != '-')	fout << (s->chain);
				fout << "::::" << endl << string(malignment[mindex]) << "*" << endl << endl;
				
				mindex++;
			}
		}
		sitr++;
	}
	// output the original sequence
	fout << ">P1;" << pdbcode << endl << "sequence:" << pdbcode << ":" << 1 << ":";
	if(chain != '-')	fout << chain;
	fout << ":" << (sequence->length()) << ":";
	if(chain != '-')	fout << chain;
	fout << "::::" << endl << *sequence << "*" << endl << endl;
	fout.close();
	
	int num_sequences = mindex;
	*out << "#sequences " << mindex << endl;
	
	// compute the entropy of each column of the alignment
	float entropy[seqsize], entropy_with_gap[seqsize];
	int aa_frequencies[seqsize][NUM_AA_TYPES+1];
	for(int i = 0 ; i < seqsize; i++)
		for(int j = 0; j < NUM_AA_TYPES+1; j++)
			aa_frequencies[i][j] = 0;

	for(int i = 0 ; i < seqsize; i++){
		float frequency = 0;	
		for(int j = 0; j < num_sequences; j++){
			switch(malignment[j][i]){
				case 'A':
					aa_frequencies[i][0]++;
				break;
				case 'R':
					aa_frequencies[i][1]++; 
	 			break;
	 			case 'N': 
	 				aa_frequencies[i][2]++;
	 			break; 
	 			case 'D': 
	 				aa_frequencies[i][3]++;
	 			break; 
	 			case 'C': 
	 				aa_frequencies[i][4]++;
	 			break;
	 			case 'Q':
	 				aa_frequencies[i][5]++; 
	 			break; 
	 			case 'E': 
	 				aa_frequencies[i][6]++;
	 			break;
	 			case 'G': 
	 				aa_frequencies[i][7]++;
	 			break; 
	 			case 'H': 
	 				aa_frequencies[i][8]++;
	 			break; 
	 			case 'I': 
	 				aa_frequencies[i][9]++;
	 			break; 
	 			case 'L': 
	 				aa_frequencies[i][10]++;
	 			break; 
	 			case 'K': 
	 				aa_frequencies[i][11]++;
	 			break; 
	 			case 'M': 
	 				aa_frequencies[i][12]++;
	 			break; 
	 			case 'F': 
	 				aa_frequencies[i][13]++;
	 			break; 
	 			case 'P':
	 				aa_frequencies[i][14]++; 
	 			break; 
	 			case 'S': 
	 				aa_frequencies[i][15]++;
	 			break; 
	 			case 'T': 
	 				aa_frequencies[i][16]++;
	 			break; 
	 			case 'W': 
	 				aa_frequencies[i][17]++;
	 			break; 
	 			case 'Y': 
	 				aa_frequencies[i][18]++;
	 			break; 
	 			case 'V': 
	 				aa_frequencies[i][19]++;
	 			break;
	 			default:
	 				aa_frequencies[i][20]++;
	 			break;
			}
			if(malignment[j][i] == sequence_carray[i])
				frequency++;
		}
		int total_non_gaps = num_sequences - aa_frequencies[i][20];
		entropy[i] = 0;
		entropy_with_gap[i] = 0;
		//*out << i << " " << total_non_gaps << " ";
		if(total_non_gaps > 0){
			for(int j = 0; j < NUM_AA_TYPES; j++){
				frequency = ((float) aa_frequencies[i][j])/total_non_gaps;
				//*out << frequency << " ";
				if(frequency != 0) 	entropy[i] -= frequency * log(frequency);
			}
		}
		//*out << entropy[i] << endl;
		for(int j = 0; j < NUM_AA_TYPES+1; j++){
			if(total_non_gaps > 0){
				frequency = ((float) aa_frequencies[i][j])/num_sequences;
				if(frequency != 0)	entropy_with_gap[i] -= frequency * log(frequency);
			}
		}
	}
	/**out << "entropy_wth_gap " << endl;
	for(int i = 0 ; i < seqsize; i++)
		*out << entropy_with_gap[i] << " ";
	*out << endl;*/
	
	/**out << "entropy + w(#gaps) " << endl;
	for(int i = 0 ; i < seqsize; i++)
		*out << entropy[i] + GAP_WEIGHT*(aa_frequencies[i][GAP]) << " ";
	*out << endl;*/
}

