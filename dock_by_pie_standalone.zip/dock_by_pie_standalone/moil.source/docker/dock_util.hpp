/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

//#include "geometric_hash.hpp"
//#include "align_utilities.hpp"
#ifndef INCL_DOCKHPP
#include "dock.hpp"
#define INCL_DOCKHPP
#endif

int numprocs, procid;
bool masterprocessonnode;
MPI_Status mpistat; 

int filetype,docktype,start_state, end_state, state;
string rpdbcode, rchains, lpdbcode, lchains, refpdbcode, reflchains, refrchains;
char filename[1024], *tag, *transformations_file, local_transformations_file[512],
	*combinations_file, local_combinations_file[512], scratch_dir[512];
ostream *out;
string *host;
Object *receptor, *ligand;
Complex *reference, *referenceH;
short symmetry;

extern vector<Transformation*> node_transformations;
long generation_stats[NUM_GENERATION_STATS];
extern hash_map<unsigned int,long,hash<unsigned int>,eqint> pieces;
extern char* node_tmp_dir;
extern char buff[BUFSIZE], command[8192];
extern time_t start_time, current_time;

extern hash_map<long,vector<Transformation*>,hash<long>,eqlong> transformations_by_cell;
extern hash_map<const char*,MultiTransformation*,hash<const char*>,eqstr> combinations;
extern float cmr_rmax;
extern unsigned short num_cmr_x_divisions,num_cmr_y_divisions,num_cmr_z_divisions;
extern int box[6];
short success=1;

void preprocess();

vector<int*> split(int box[6], hash_map<long,int,hash<long>,eqlong> *frequencies, int stage, int total_stages);

void elect_leader_on_node();

void examine_transformations();

void read_transformations();

void filter_steric_clashes();

void cluster_combinations_by_sorting();

void collect_combinations();

void generate_models();

void read_combinations();

void score_models();

void filter_trans_basedon_info(ModelInfo *);

void collect_transformations_verify_trans(bool,bool);

void select_transformations();

void initialize_transformation_localneighbors();

bool chain_continuous(Complex *receptor,Complex *ligand,Reference_Frame *rf, bool rf_is_lig_vs_rec, unsigned short looplength);

void optimize_transformations();

void cluster_sorted_transformations(Object*, Object*, unsigned short);

void read_transformation_clusters();

void incremental_cluster_sorted_transformations();

void read_alignments();

Transformation* examine_reference();

void read_homologues(int);

void preprocess_homologues(int);

void read_symmetries();

void compute_entropy_approx1(Object* receptor, Object* ligand, string options_file);

void compute_entropy_approx2(Object* receptor, Object* ligand, string options_file);

void compute_feig_score(Complex* receptor, Complex* ligand, string options_file);

void compute_entropy();

void verify_transformations();

void verify_combinations();

void verify_models();

void write_trans_txt();

void collect_transformations(bool,int);

void pair_sequences_by_species();

