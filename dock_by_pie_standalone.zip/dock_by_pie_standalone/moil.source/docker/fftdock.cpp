/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "dock_util.hpp"

#define VDW_OPLS_APPROX

// checkft does not work when vdw attraction and repulsion are computed separately
//#define SEPARATE_VDW_ATTR_REPUL

//#define SPACED_ROTATIONS "232020.euler"
// the interior and intermediate clash penalties are very sensitive to grid_spacing used
//float grid_spacing=FFT_GRID_SPACING*1.2;

#define SPACED_ROTATIONS "68760.euler"
float grid_spacing=FFT_GRID_SPACING*1.6;

float **rot_angles;
int num_rotations;

#define NUM_FFT_ATOM_TYPES 18
//#define NUM_FFT_ATOM_TYPES 20
#define NUM_FFT_ATOM_EIGENVECTORS 10

#define NUM_FFT_RESIDUE_BKBN_EIGENVECTORS 12

MKL_Complex8 *rec_shape, *lig_shape, **rec_particlepfft, **lig_particlepgrid, *particlep_sum;

//#ifdef SEPARATE_VDW_ATTR_REPUL
//MKL_Complex8 *rec_shape_attr, *rec_shape_repul, *lig_shape_attr, *lig_shape_repul;
//#endif

// rec_particlepfft has the fourier transforms for atom neighbor grids (one each)
// lig_particlepgrid contains fft computed for pairs of atom types 
short looplength=0;
short num_particlep_arrays=0;

DFTI_DESCRIPTOR_HANDLE fft_desc_handle;
MKL_LONG mkl_status, gridsize[3], strides[4];
unsigned int size;
float sqrt_size;

// Shape complementarity scores can be cast as convolutions by either flipping the functions or by using ifts
bool flip=true;

extern string piedock_home;

//unsigned int max_transformations=1024*1024*4;
unsigned int max_transformations=1024*128*4;
typedef struct {
	float evdw, particlep, evdw_real, evdw_imag , score;

#ifdef SEPARATE_VDW_ATTR_REPUL
	float evdw_attr, evdw_repul_core;
#endif

	unsigned int index, rotindex;
} transformationscore;

transformationscore *rotation_scores,*node_result,*work0, *work1;
unsigned int merge_output_index=0;
unsigned int num_node_transforms=0;
bool symmetrictrimer=false;

bool transscore_bettervdw(transformationscore t1,transformationscore t2){
	//return(t1.index < t2.index);
#ifdef SEPARATE_VDW_ATTR_REPUL
	return(t1.evdw_attr > t2.evdw_attr);
#else
	return(t1.evdw > t2.evdw);
#endif
}

bool transscore_bettercontactp(transformationscore t1,transformationscore t2){
	return(t1.particlep > t2.particlep);
}

bool transscore_bettersum(transformationscore t1,transformationscore t2){
	return(t1.score > t2.score);
}

bool (*transscore_better)(transformationscore t1,transformationscore t2) = &transscore_bettervdw;

extern float **atom18_potential, **atom20_potential, vdw_weight;
extern void coarsen_atomtypesto18();
extern void coarsen_atomtypesto20();
float ***particle_potential, **atomp_eigen_vector, *atomp_eigen_value;
float **resbkbnp_eigen_vector, *resbkbnp_eigen_value;

void match_rotation(unsigned int, Transformation *);

/*
 * Matlab read is faster if the input files are fragmented
 */
void write_tofile(MKL_Complex8 *grid, string filename){
	fstream fout(filename.c_str(),fstream::out);

	for(int i =0; i < gridsize[0]; i++){
		for(int j =0; j < gridsize[1]; j++)
			for(int k =0; k < gridsize[2]; k++){
				unsigned int index = (i*gridsize[1] + j)*gridsize[2] + k;
				unsigned int invindex = ((gridsize[0] - 1 - i)*gridsize[1] + (gridsize[1] - 1 - j))*gridsize[2] + (gridsize[2] - 1 - k);
				fout << index << " " << grid[index].real << " " << grid[index].imag << "\t" << grid[invindex].real << " " << grid[invindex].imag << endl;
			}
	}
	
    fout.close();
}

void write_results_tofile(unsigned int rotation_index){
	fstream transout;
	char tfilename[512];
	int num_written=0;
	sprintf(tfilename, "%s/%s/%d/restrans%d",node_tmp_dir,refpdbcode.c_str(),procid,rotation_index);
	//sprintf(tfilename, "restrans%d",rotation_index);
	transout.open(tfilename,ios::binary|ios::out);
	//transout.setf(ios::fixed, ios::floatfield);
	for(unsigned int index = 0; index < size; index++){
		if(rotation_scores[index].evdw > -10000.0 && (ABS(rotation_scores[index].evdw_real) > 0.5 || ABS(rotation_scores[index].evdw_imag) > 0.5)){
			transout << rotation_scores[index].particlep << " " << rotation_scores[index].evdw
			/*<< " " << rotation_scores[index].evdw_real << " " << rotation_scores[index].evdw_imag*/ 
			<< " " << index << endl;
			//transout << rotation_scores[index].particlep << " " << rotation_scores[index].evdw << endl;
			num_written++;
		}
		
	}
	transout.close();
	
	char command[512];
	sprintf(command, "gzip %s",tfilename);
	int ret = system(command);
	*out << command << " " << ret << endl;
		
	sprintf(command, "cp %s.gz trans/",tfilename);
	ret = system(command);
	*out << command << " " << ret << endl;
	
	*out << "wrote results to file rotation " << rotation_index << " " << num_written << endl; out->flush();
	generation_stats[1] += num_written;
}

Vector get_translation(transformationscore *trscore, Transformation *tr){						
	float x = (int) (trscore->index/(gridsize[1]*gridsize[2]));
	float y = ((trscore->index/gridsize[2]) % gridsize[1]);
	float z = (trscore->index % gridsize[2]);

	if(x >= gridsize[0]/2)	x = x - gridsize[0];
	if(y >= gridsize[1]/2)	y = y - gridsize[1];
	if(z >= gridsize[2]/2)	z = z - gridsize[2];	
	
	bool printlog=false;
	if(printlog){
		*out << trscore->index << " " << x << "," << y << "," << z << " " << tr->translation->x << "," << tr->translation->y << "," << tr->translation->z << endl;
	
		Vector v = *(tr->translation) - *(ligand->c->center);
		*out << trscore->index << " v1 " << v.x << "," << v.y << "," << v.z << endl;
		
		v = tr->rotate(v);
		*out << trscore->index << " v2 " << v.x << "," << v.y << "," << v.z << endl;
		 
		v =  *(ligand->grid_origin) - (v + *(receptor->grid_origin) + *(receptor->c->center));
		*out << trscore->index << " v3 " << v.x << "," << v.y << "," << v.z << endl; 
	}
	
	Vector v = *(ligand->c->center) +tr->inverse_rotate(*(ligand->grid_origin) - (Vector(-x,-y,-z)*grid_spacing + *(receptor->grid_origin) + *(receptor->c->center)));

	return v;
}

void match_rotation(unsigned int rotation_index){
	*out << "match rotation " << rotation_index << endl; out->flush();
	Transformation *tr = new Transformation(rot_angles[rotation_index][0],rot_angles[rotation_index][1],rot_angles[rotation_index][2],rotation_index);

	match_rotation(rotation_index, tr);
}

void match_rotation(unsigned int rotation_index, Transformation *tr){
	*out << "rotationtr " << lig_shape << " "; tr->print_details(out,TN_BASIC);
	
	// build grid on the ligand
#ifdef VDW_OPLS_APPROX
	ligand->build_fft_opls_vdw_grid(grid_spacing,receptor->c->diameter, &lig_shape,gridsize, tr, false);
#else	
	ligand->build_fft_vdw_grid(grid_spacing, receptor->c->diameter,&lig_shape,gridsize, tr, false);
#endif	
	//write_tofile(lig_shape,"ligand");
	
	// fft
	mkl_status = DftiComputeForward(fft_desc_handle, lig_shape);
	if(mkl_status != DFTI_NO_ERROR){
		*out << rotation_index << " fft " << DftiErrorMessage(mkl_status) << endl; out->flush();
	}
	
	//cout << "state " << state << endl;
	if(state==FFT_GENERATE_MATCHES_ATOMP || state==FFT_GENERATE_MATCHES_EVATOMP || state==FFT_GENERATE_MATCHES_RESIDUEP 
	 || state==FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP
	 || state==FFT_GENERATE_MATCHES_RESIDUE_BKBNP || state==FFT_GENERATE_MATCHES_EVRESIDUE_BKBNP
	){
		switch(state){
			case FFT_GENERATE_MATCHES_ATOMP:
			case FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP:
				ligand->build_fft_atomcontact_grid(grid_spacing, lig_particlepgrid,NUM_FFT_ATOM_TYPES,gridsize, tr, false);
				break;
			case FFT_GENERATE_MATCHES_EVATOMP:
				ligand->build_fft_eigen_atomp_grid(grid_spacing, lig_particlepgrid,NUM_FFT_ATOM_TYPES,NUM_FFT_ATOM_EIGENVECTORS,atomp_eigen_vector,gridsize, tr, false);
				break;
			case FFT_GENERATE_MATCHES_RESIDUEP:
				ligand->build_fft_residue_centroid_centroid_contact_grid(grid_spacing, lig_particlepgrid,20,gridsize, tr, false);
				break;
			case FFT_GENERATE_MATCHES_RESIDUE_BKBNP:
				ligand->build_fft_residue_bkbn_centroid_bkbn_centroid_contact_potential_grid(grid_spacing, lig_particlepgrid,22,*particle_potential,gridsize, tr, false);
				break;
			case FFT_GENERATE_MATCHES_EVRESIDUE_BKBNP:
				ligand->build_fft_eigen_residue_bkbnp_grid(grid_spacing, lig_particlepgrid,22,NUM_FFT_RESIDUE_BKBN_EIGENVECTORS,resbkbnp_eigen_vector,gridsize, tr, false);
				break;
		}
		
		for(int ti = 0; ti < num_particlep_arrays; ti++){
			mkl_status = DftiComputeForward(fft_desc_handle, lig_particlepgrid[ti]);
			if(mkl_status != DFTI_NO_ERROR)
				*out << rotation_index << " fft " << ti << " " << DftiErrorMessage(mkl_status) << endl;
		}
	}
	//write_tofile(lig_shape,"ligandfft");

	float real_fourier, imag_fourier;
		
#ifdef SEPARATE_VDW_ATTR_REPUL
	for(int i = 0; i < size; i++){
		// separating attractive and repulsive parts of vdw interaction
		{
			int z = (i % gridsize[2]);
			int y = ((i / gridsize[2]) % gridsize[1]) ;
			int x = i/(gridsize[2] * gridsize[1]) ;
			
			int xi = (gridsize[0] - x) % gridsize[0];
			int yi = (gridsize[1] - y) % gridsize[1];
			int zi = (gridsize[2] - z) % gridsize[2];
			
			unsigned int iinv = (xi*gridsize[1] + yi)*gridsize[2] + zi;
//			lig_shape_attr[i].real = (lig_shape[i].real + lig_shape[iinv].real)/2;
//			lig_shape_attr[i].imag = (lig_shape[i].imag - lig_shape[iinv].imag)/2;
		//	if(ABS(lig_shape[i].real - lig_shape_attr[i].real) > 0.01 || ABS(lig_shape[i].imag - lig_shape_attr[i].imag) > 0.01)
		//		cout << "grid fts different " << i << " (" << lig_shape[i].real << "," << lig_shape[i].imag << ") (" << lig_shape_attr[i].real << "," << lig_shape_attr[i].imag << ")\n";
			{
				float a,b;
				a = (lig_shape[i].real - lig_shape[iinv].real)/2;
				b = (lig_shape[i].imag + lig_shape[iinv].imag)/2;
						
				// need to multiply by -sqrt(-1) or divide by i
				lig_shape_repul[i].real = b;
				lig_shape_repul[i].imag = -a;
			}
			
			real_fourier = rec_shape_attr[i].real*lig_shape_attr[i].real - rec_shape_attr[i].imag*lig_shape_attr[i].imag;
			imag_fourier = rec_shape_attr[i].real*lig_shape_attr[i].imag + rec_shape_attr[i].imag*lig_shape_attr[i].real;
			lig_shape_attr[i].real = real_fourier;
			lig_shape_attr[i].imag = imag_fourier;
			
			real_fourier = rec_shape_repul[i].real*lig_shape_repul[i].real - rec_shape_repul[i].imag*lig_shape_repul[i].imag;
			imag_fourier = rec_shape_repul[i].real*lig_shape_repul[i].imag + rec_shape_repul[i].imag*lig_shape_repul[i].real;
			lig_shape_repul[i].real = real_fourier;
			lig_shape_repul[i].imag = imag_fourier;
		}
	}
#endif
	
	// product
	//*out << "computing product " << endl; out->flush();
	for(int i = 0; i < size; i++){
		// combined attractive and repulsive parts of vdw interaction
		{
			real_fourier = rec_shape[i].real*lig_shape[i].real - rec_shape[i].imag*lig_shape[i].imag;
			imag_fourier = rec_shape[i].real*lig_shape[i].imag + rec_shape[i].imag*lig_shape[i].real;
			lig_shape[i].real = real_fourier;
			lig_shape[i].imag = imag_fourier;
		}
			
		if(state==FFT_GENERATE_MATCHES_ATOMP || state==FFT_GENERATE_MATCHES_EVATOMP || state==FFT_GENERATE_MATCHES_RESIDUEP 
		|| state==FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP || state==FFT_GENERATE_MATCHES_RESIDUE_BKBNP){
			short n=0;
			switch(state){
				case FFT_GENERATE_MATCHES_ATOMP:
				case FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP:
					n=NUM_FFT_ATOM_TYPES;
					break;
				case FFT_GENERATE_MATCHES_EVATOMP:
					n=NUM_FFT_ATOM_EIGENVECTORS;
					break;
				case FFT_GENERATE_MATCHES_RESIDUEP:
					n=20;
					break;
				case FFT_GENERATE_MATCHES_RESIDUE_BKBNP:
					n=22;
					break;
				case FFT_GENERATE_MATCHES_EVRESIDUE_BKBNP:
					n=NUM_FFT_RESIDUE_BKBN_EIGENVECTORS;
					break;
			}
			
			MKL_Complex8 lig[n];
			
			int z = (i % gridsize[2]) ;
			int y = ((i / gridsize[2]) % gridsize[1]) ;
			int x = i/(gridsize[2] * gridsize[1]) ;
			
			int xi = (gridsize[0] - x) % gridsize[0];
			int yi = (gridsize[1] - y) % gridsize[1];
			int zi = (gridsize[2] - z) % gridsize[2];
			
			unsigned int iinv = (xi*gridsize[1] + yi)*gridsize[2] + zi;
			
			for(int j=0; j< n; j++){
				if(j%2 == 0){
					lig[j].real = (lig_particlepgrid[j/2][i].real + lig_particlepgrid[j/2][iinv].real)/2;
					lig[j].imag = (lig_particlepgrid[j/2][i].imag - lig_particlepgrid[j/2][iinv].imag)/2;
				} else {
					float a,b;
					a = (lig_particlepgrid[j/2][i].real - lig_particlepgrid[j/2][iinv].real)/2;
					b = (lig_particlepgrid[j/2][i].imag + lig_particlepgrid[j/2][iinv].imag)/2;
					
					// need to multiply by -sqrt(-1) or divide by i
					lig[j].real = b;
					lig[j].imag = -a;
				}
			}
		
			float rsum=0,isum=0;
			if(state==FFT_GENERATE_MATCHES_ATOMP || state==FFT_GENERATE_MATCHES_RESIDUEP || state==FFT_GENERATE_MATCHES_RESIDUE_BKBNP
			 || state==FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP){
				/*/ if computing contacts
				for(int j=0; j< n; j++)
					for(int k=0; k< n; k++){
						rsum += (rec_particlepfft[j][i].real*lig[k].real - rec_particlepfft[j][i].imag*lig[k].imag)*(*particle_potential)[j][k];
						isum += (rec_particlepfft[j][i].imag*lig[k].real + rec_particlepfft[j][i].real*lig[k].imag)*(*particle_potential)[j][k];
					}*/
					
				// if computing potentials
				for(int j=0; j< n; j++){
					rsum += (rec_particlepfft[j][i].real*lig[j].real - rec_particlepfft[j][i].imag*lig[j].imag);
					isum += (rec_particlepfft[j][i].imag*lig[j].real + rec_particlepfft[j][i].real*lig[j].imag);
				}
			} else if(state==FFT_GENERATE_MATCHES_EVATOMP){
				for(int j=0; j< NUM_FFT_ATOM_EIGENVECTORS; j++){
					rsum += (rec_particlepfft[j][i].real*lig[j].real - rec_particlepfft[j][i].imag*lig[j].imag)*atomp_eigen_value[j];
					isum += (rec_particlepfft[j][i].imag*lig[j].real + rec_particlepfft[j][i].real*lig[j].imag)*atomp_eigen_value[j];
				}
			} else if(state==FFT_GENERATE_MATCHES_EVRESIDUE_BKBNP){
				for(int j=0; j< NUM_FFT_RESIDUE_BKBN_EIGENVECTORS; j++){
					rsum += (rec_particlepfft[j][i].real*lig[j].real - rec_particlepfft[j][i].imag*lig[j].imag)*resbkbnp_eigen_value[j];
					isum += (rec_particlepfft[j][i].imag*lig[j].real + rec_particlepfft[j][i].real*lig[j].imag)*resbkbnp_eigen_value[j];
				}
			}
			
			particlep_sum[i].real = rsum;
			particlep_sum[i].imag = isum;
		}
	}
	//*out << "computed product " << endl; out->flush();
	//write_tofile(lig_shape,"convfft");
				
	// ift
	mkl_status = DftiComputeBackward(fft_desc_handle, lig_shape);
	if(mkl_status != DFTI_NO_ERROR)
		*out << rotation_index << " ift " << DftiErrorMessage(mkl_status) << endl;

#ifdef SEPARATE_VDW_ATTR_REPUL
	mkl_status = DftiComputeBackward(fft_desc_handle, lig_shape_attr);
	if(mkl_status != DFTI_NO_ERROR)
		*out << rotation_index << " ift " << DftiErrorMessage(mkl_status) << endl;
//	mkl_status = DftiComputeBackward(fft_desc_handle, lig_shape_repul);
//	if(mkl_status != DFTI_NO_ERROR)
//		*out << rotation_index << " ift " << DftiErrorMessage(mkl_status) << endl;
#endif
	
	if(state==FFT_GENERATE_MATCHES_ATOMP || state==FFT_GENERATE_MATCHES_EVATOMP || state==FFT_GENERATE_MATCHES_RESIDUEP 
	 || state==FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP
	 || state==FFT_GENERATE_MATCHES_RESIDUE_BKBNP || state==FFT_GENERATE_MATCHES_EVRESIDUE_BKBNP
	){
		mkl_status = DftiComputeBackward(fft_desc_handle, particlep_sum);
		if(mkl_status != DFTI_NO_ERROR)
			*out << rotation_index << " ift particlep " << DftiErrorMessage(mkl_status) << endl;
	}
	//write_tofile(lig_shape,"conv");
	
	// collect scores
	float grid_spacing_cubed = grid_spacing*grid_spacing*grid_spacing;
	float size_inv = 1.0/size;
	for(unsigned int index = 0; index < size; index++){
		rotation_scores[index].index = index;
#ifdef VDW_OPLS_APPROX	
		rotation_scores[index].evdw_real = lig_shape[index].real*size_inv;	
		rotation_scores[index].evdw = lig_shape[index].real*size_inv + lig_shape[index].imag*size_inv;
		rotation_scores[index].evdw_imag = lig_shape[index].imag*size_inv;
#else
		rotation_scores[index].evdw_real = lig_shape[index].real*grid_spacing_cubed*size_inv;
		rotation_scores[index].evdw = (lig_shape[index].real - lig_shape[index].imag)*grid_spacing_cubed*size_inv;
		rotation_scores[index].evdw_imag = (0-lig_shape[index].imag)*grid_spacing_cubed*size_inv;
#endif		
		
		// the separation does not work with vdw_opls_approx
#ifdef SEPARATE_VDW_ATTR_REPUL
		rotation_scores[index].evdw_attr = lig_shape_attr[index].real*grid_spacing_cubed*size_inv;
		rotation_scores[index].evdw_repul_core = lig_shape_repul[index].real*grid_spacing_cubed*size_inv;
		//if(rotation_index == num_rotations + 1)
		//	cout << index << " " << rotation_scores[index].evdw_attr << " " << rotation_scores[index].evdw_repul_core << " " << rotation_scores[index].evdw << endl;
#endif
		rotation_scores[index].rotindex = rotation_index;
		
		if(state==FFT_GENERATE_MATCHES_ATOMP || state==FFT_GENERATE_MATCHES_EVATOMP || state==FFT_GENERATE_MATCHES_RESIDUEP 
		 || state==FFT_GENERATE_MATCHES_RESIDUE_BKBNP || state==FFT_GENERATE_MATCHES_EVRESIDUE_BKBNP
		){
			rotation_scores[index].particlep = particlep_sum[index].real * size_inv;
			rotation_scores[index].score = rotation_scores[index].particlep + rotation_scores[index].evdw*vdw_weight;
			
			//cout << rotation_index << " " << index << " " << rotation_scores[index].particlep << " " << rotation_scores[index].evdw << endl;
			
			/*/ do a spatial averaging of pairwise potential to reduce noise
			{
				rotation_scores[index].particlep = 0;
				int tz = (index % gridsize[2]);
				int ty = ((index / gridsize[2]) % gridsize[1]);
				int tx = index/(gridsize[2] * gridsize[1]);
				for(short x = (tx-1)%gridsize[0]; x <= (tx+1)%gridsize[0]; x++)
					for(short y = (ty-1)%gridsize[1]; y <= (ty+1)%gridsize[1]; y++)
						for(short z = (tz-1)%gridsize[2]; z <= (tz+1)%gridsize[2]; z++){
							unsigned int nindex = (x*gridsize[1] + y)*gridsize[2] + z;
							rotation_scores[index].particlep += particlep_sum[index].real;
						}
				rotation_scores[index].particlep = rotation_scores[index].particlep/(27.0*size);
			}//*/
		} else if(state==FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP){
			rotation_scores[index].particlep = particlep_sum[index].real * size_inv;
			rotation_scores[index].score = rotation_scores[index].particlep;
		}
	}
	
	/* this setting is very important in docking */
	float min_vdw_repulsion;
	// when grid_spacing is 1 INTERIOR_ATOM_SPREAD=1, INTERMEDIATE_IMAG=3 and INTERIOR_IMAG=8 and the factor is 140 the max clashes is 30 and average is around 8
	//min_vdw_repulsion = -(0.75*160 + 20)*INTERMEDIATE_IMAG*INTERMEDIATE_IMAG;
	
	// when grid_spacing is 1 and the factor is 320 the max clashes is 60 and the average is around 20
	min_vdw_repulsion = -(320)*INTERMEDIATE_IMAG*INTERMEDIATE_IMAG;
	//min_vdw_repulsion = -(120)*INTERMEDIATE_IMAG*INTERMEDIATE_IMAG;
	
#ifdef CHECKFT	
	{
	  //bool checkvdw=false, checkparticlep=true;
	  //if(checkvdw){
	  	Transformation *tr_rec = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
		receptor->build_fft_vdw_grid(grid_spacing, ligand->c->diameter,&rec_shape,gridsize, tr_rec, true);
		ligand->build_fft_vdw_grid(grid_spacing, receptor->c->diameter,&lig_shape,gridsize, tr, false);	
		
		if(state==FFT_GENERATE_MATCHES_ATOMP){	
			write_tofile(particlep_sum,"particlep_sum");
			
		  	// check if the fourier transforms for particlep are correct
		  	if(flip)
		  		mkl_status = DftiComputeBackward(fft_desc_handle, rec_particlepfft[0]);
		  	else
		  		mkl_status = DftiComputeForward(fft_desc_handle, rec_particlepfft[0]);
		  	*out << DftiErrorMessage(mkl_status) << endl;
		  	//write_tofile(rec_particlepfft[0],"recatomtype0fi");
			
			receptor->build_fft_atomcontact_grid(grid_spacing, ligand->c->diameter,rec_particlepfft,NUM_FFT_ATOM_TYPES,gridsize, tr_rec, true);
			//write_tofile(rec_particlepfft[0],"recatomtype0");
			ligand->build_fft_atomcontact_grid(grid_spacing, receptor->c->diameter,lig_particlepgrid,NUM_FFT_ATOM_TYPES,gridsize, tr, false);
		}
		
		hash_set<int,hash<int>,eqint> trials;
		unsigned int translation;
		for(int trial = 0; trial < 3; trial++){
			if(trial == 0)	translation=0;
			else if(trial == 1) translation=170416;
			else if (trial %2 == 1)
				do{ translation = rand() % size; } while(trials.count(translation) == 1);
			else	translation = size - translation;
			trials.insert(translation);
		
		//for(translation=0; translation<size; translation++){
		//	int trial = translation;
			
			int tz = (translation % gridsize[2]);
			int ty = ((translation / gridsize[2]) % gridsize[1]);
			int tx = translation/(gridsize[2] * gridsize[1]);
			
			float score = 0, score_real=0, score_imag=0, particlepscoregrid = 0;
			int ligi,ligj,ligk;
			for(int i =0; i < gridsize[0]; i++){
				//ligi = (i + gridsize[0] - tx) % gridsize[0];
				ligi = (i + tx) % gridsize[0]; 
				for(int j =0; j < gridsize[1]; j++){
					//ligj = (j + gridsize[1] - ty) % gridsize[1];
					ligj = (j + ty) % gridsize[1]; 
					for(int k =0; k < gridsize[2]; k++){
						//ligk = (k + gridsize[2] - tz) % gridsize[2];
						ligk = (k + tz) % gridsize[2];
						 
						unsigned int index = (i*gridsize[1] + j)*gridsize[2] + k;
						//unsigned int ligindex = (index+translation)%size;
						unsigned int ligindex = (ligi*gridsize[1] + ligj)*gridsize[2] + ligk;
					
						float vrl, vim;
						vrl  = rec_shape[index].real*lig_shape[ligindex].real - rec_shape[index].imag*lig_shape[ligindex].imag;
						vim  = rec_shape[index].real*lig_shape[ligindex].imag + rec_shape[index].imag*lig_shape[ligindex].real;
						score += (vrl - vim);
						score_real += vrl;
						score_imag = score_imag - vim;
						
						if(state == FFT_GENERATE_MATCHES_ATOMP)
							for(int ai=0; ai< num_particlep_arrays; ai++)
								for(int aj=0; aj< num_particlep_arrays; aj++){
									particlepscoregrid += (rec_particlepfft[ai][index].real*lig_particlepgrid[aj][ligindex].real)*(*particle_potential)[2*ai][2*aj];
									particlepscoregrid += (rec_particlepfft[ai][index].real*lig_particlepgrid[aj][ligindex].imag)*(*particle_potential)[2*ai][2*aj+1];
									particlepscoregrid += (rec_particlepfft[ai][index].imag*lig_particlepgrid[aj][ligindex].real)*(*particle_potential)[2*ai+1][2*aj];
									particlepscoregrid += (rec_particlepfft[ai][index].imag*lig_particlepgrid[aj][ligindex].imag)*(*particle_potential)[2*ai+1][2*aj+1];
								}
					}
				}
			}
			
			//compute particlepscore directly
			float particlepscore=0,particlep_sqwell_score=0;
			
			if(tx > gridsize[0]/2)	tx = tx - gridsize[0];
			if(ty > gridsize[1]/2)	ty = ty - gridsize[1];
			if(tz > gridsize[2]/2)	tz = tz - gridsize[2];
		
			if(trial == 0){
				Vector v1 = tr->rotate(*(ligand->c->center)) + *(ligand->grid_origin);
				Vector v2 = *(receptor->grid_origin) + *(receptor->c->center);
				Vector vdiff = v2 - v1;
				cout << "vdiff (" << vdiff.x << "," << vdiff.y << "," << vdiff.z << ")" << endl; 
				Vector t0 = *(ligand->c->center) +tr->inverse_rotate(*(ligand->grid_origin) - (*(receptor->grid_origin) + *(receptor->c->center)));
				cout << "t0 (" << t0.x << "," << t0.y << "," << t0.z << ")" << endl;
				t0 = tr->inverse_rotate(t0);
				cout << "trinv_t0 (" << t0.x << "," << t0.y << "," << t0.z << ")" << endl;
				tr->print_details(&cout,TN_BASIC);
				cout << "ez (" << tr->ez->x << "," << tr->ez->y << "," << tr->ez->z << ")" << endl;
				*(tr->translation) = Vector(0,0,0);
				tr->write_as_pdb(ligand->c, ligand->c->chains, true , "zerotranslation.pdb", true);
				*(tr->translation) = *(ligand->c->center) +tr->inverse_rotate(*(ligand->grid_origin));
				tr->write_as_pdb(ligand->c, ligand->c->chains, true , "trlig_centered.pdb", true);
				*(tr_rec->translation) =  *(receptor->c->center)  + *(receptor->grid_origin);
				tr_rec->write_as_pdb(receptor->c, receptor->c->chains, true , "rec_centered.pdb", true);
			} 
			
			*(tr->translation) = *(ligand->c->center) +tr->inverse_rotate(*(ligand->grid_origin) - (Vector(-tx,-ty,-tz)*grid_spacing + *(receptor->grid_origin) + *(receptor->c->center)));
		
			if(state == FFT_GENERATE_MATCHES_ATOMP)
				for(int j=0; j < ligand->c->num_atoms; j++){
					Atom *al = ligand->c->atom[j];
		  			short aj = al->atom_type;
		  			if(aj >= 0 && aj < NUM_FFT_ATOM_TYPES){
		  				Vector v = tr->transform(*(al->position));
		  				for(int i=0; i < receptor->c->num_atoms; i++){
				  			Atom *ar = receptor->c->atom[i];
		  					short ai = ar->atom_type;
		  					if(ai >= 0 && ai < NUM_FFT_ATOM_TYPES){
		  						float d2 = Vector::distance_squared(v,*(ar->position));
		  						if(d2 >= ATOM_CONTACT_CUTOFF_MIN_SQUARED && d2 < ATOM_CONTACT_CUTOFF_MAX_SQUARED){
		  							particlep_sqwell_score += (*particle_potential)[ai][aj];
		  						}
		  						if(d2 <= ATOM_STEPP_DCUTOFF_SQUARED){
		  							particlepscore += (*particle_potential)[ai][aj];
		  						}
		  					}
						}
		  			}
				}
			
			sprintf(buff,"checktr%d.pdb",trial);
			if(trial<=2)	tr->write_as_pdb(ligand->c, ligand->c->chains, true , buff, true);
			Reference_Frame *invrf = Reference_Frame::invert(tr);
			cout << trial << " " << tx << "," << ty << "," << tz << " " << score << ":" << rotation_scores[translation].evdw/(grid_spacing*grid_spacing*grid_spacing) << "\t"
				<<  score_real << ":" << rotation_scores[translation].evdw_real/(grid_spacing*grid_spacing*grid_spacing) << "\t"
				<<  score_imag << ":" << rotation_scores[translation].evdw_imag/(grid_spacing*grid_spacing*grid_spacing) << "\t" 
				<< particlep_sqwell_score << ":" << particlepscore << ":" << particlepscoregrid << ":" << rotation_scores[translation].particlep << "\t" 
				<< translation << "\t" << invrf->translation->x << "," << invrf->translation->y << "," << invrf->translation->z << endl; cout.flush();
		}
	}
#endif
	
	/* remove structures that do not touch or form heavy clashes
	 * 	doing this by setting the particlepscore to a very low value for filtered transforms */
	unsigned int num_removed=0, num_filtered=0;
	vector<transformationscore> filtered_transformations;
	
	//{
		for(unsigned int i = 0; i < size; i++){
			bool remove=false;
#ifdef VDW_OPLS_APPROX
			if(!(rotation_scores[i].evdw > 0 && (ABS(rotation_scores[i].evdw_real) > 0.5 || ABS(rotation_scores[i].evdw_imag) > 0.5)))
#else
			if(!(rotation_scores[i].evdw > min_vdw_repulsion && (ABS(rotation_scores[i].evdw_real) > 0.5 || ABS(rotation_scores[i].evdw_imag) > 0.5)))
#endif
			{
				rotation_scores[i].score = rotation_scores[i].evdw = rotation_scores[i].particlep = -1000000.0;
				remove=true;
#ifdef LOOP_CONSTRAINT
			} else if(looplength>0){
				*(tr->translation) = get_translation(&(rotation_scores[i]), tr);
				if(!chain_continuous(receptor->c,ligand->c,tr,true,looplength)){
					rotation_scores[i].score = rotation_scores[i].evdw = rotation_scores[i].particlep = -1000000.0;
					remove=true;
				} else {
					// get an improved lower bound on obstacle avoiding distance
					
				}
#endif							
			}
			if(state==FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP){
				if(rotation_scores[i].evdw < -40){
					rotation_scores[i].score = rotation_scores[i].evdw = rotation_scores[i].particlep = -1000000.0;
					remove=true;
				}
			}
			if(remove)	num_removed++;
			else {
				filtered_transformations.push_back(rotation_scores[i]);
				num_filtered++;
			}
		}
	//}
		
	//sort(&rotation_scores[0], &rotation_scores[0] + size, transscore_better);
	sort(filtered_transformations.begin(),filtered_transformations.end(),transscore_better);
	
	transformationscore *current_inputarray,*current_outputarray;
	if(merge_output_index %2 == 0){
		current_outputarray = work0;
		current_inputarray = work1;
	} else {
		current_outputarray = work1;
		current_inputarray = work0;
	}
	merge_output_index++;
	//*out << work0 << " " << work1 << " " << current_inputarray << " " << current_outputarray << endl;
	
	merge( &(current_inputarray)[0], &(current_inputarray)[0] + min(max_transformations,num_node_transforms), 
		filtered_transformations.begin(),filtered_transformations.end(), &(current_outputarray)[0], transscore_better);
		
	/*merge( &(current_inputarray)[0], &(current_inputarray)[0] + min(max_transformations,num_node_transforms), 
		&rotation_scores[0], &rotation_scores[0] + size, &(current_outputarray)[0], transscore_better);
	/*int size1 = min(max_transformations,num_node_transforms);
	int index1=0,index2=0;
	while(index1<size1 && index2<size){
		if(transscore_better(current_inputarray[index1],rotation_scores[index2])){
			current_outputarray[index1+index2]=current_inputarray[index1];
			index1++;
		} else {
			current_outputarray[index1+index2]=rotation_scores[index2];
			index2++;
		}
	}
	if(index1==size1)
		while(index2<size){
			current_outputarray[index1+index2]=rotation_scores[index2];
			index2++;
		}
	else	while(index1<size1){
			current_outputarray[index1+index2]=current_inputarray[index1];
			index1++;
		}*/
	
	num_node_transforms = min(num_node_transforms+num_filtered,max_transformations);
	node_result = current_outputarray;
	
	/*count=0;
	int fullcount=0;
	for(int i = 0; i < size1+size; i++){
		if(current_outputarray[i].particlep > -100000){
			fullcount++;
			if(i<num_node_transforms)	count++;
		}
	}
	*out << "merge output " << count << " " << fullcount << " "<< num_node_transforms << " " << max_transformations << endl;
	if(count != fullcount){
		for(int i = 0; i < num_node_transforms-1; i++)
			if(transscore_better(current_outputarray[i+1],current_outputarray[i]))
				*out << "error " << i << " " << current_outputarray[i].particlep << " " << current_outputarray[i+1].particlep << endl;
	}*/
	
	generation_stats[0] += size;
	generation_stats[1] += num_filtered;
	*out << "done rotation " << rotation_index << " " << num_removed << " " << num_filtered << " " << num_node_transforms << endl;
}

Transformation *convert_transformation(unsigned int translation, unsigned int rotindex){
	Transformation *tr = new Transformation(rot_angles[rotindex][0],rot_angles[rotindex][1], rot_angles[rotindex][2],0);
	
	float x = translation/(gridsize[1]*gridsize[2]);
	float y = ((translation/gridsize[2]) % gridsize[1]);
	float z = (translation % gridsize[2]);
		
	if(x >= gridsize[0]/2)	x = x - gridsize[0];
	if(y >= gridsize[1]/2)	y = y - gridsize[1];
	if(z >= gridsize[2]/2)	z = z - gridsize[2];	
	
	*(tr->translation) = *(ligand->c->center) +tr->inverse_transform(*(ligand->grid_origin) - (Vector(-x,-y,-z)*grid_spacing + *(receptor->grid_origin) + *(receptor->c->center)));
	Reference_Frame* rf_invtr = Reference_Frame::invert(tr);
	
	Transformation *invtr = new Transformation(new Vector(rf_invtr->translation), new Vector(rf_invtr->ex), new Vector(rf_invtr->ey), 1.0, 0, 0);	

	delete tr;
	delete rf_invtr;
	return invtr;
}

Transformation *read_transformation(char* buf){
	char *current = buf;
	float particlep, evdw;
	unsigned int translation, rotation;
	memcpy(&particlep,current,sizeof(float));
	current += sizeof(float);
	memcpy(&evdw,current,sizeof(float));
	current += sizeof(float);
	memcpy(&translation,current,sizeof(unsigned int));
	current += sizeof(unsigned int);
	memcpy(&rotation,current,sizeof(unsigned int));
	current += sizeof(unsigned int);
	
	Transformation *tr = convert_transformation(translation, rotation);
	tr->eSolvation = particlep;
	tr->eVdw = evdw;
	//tr->votes = rotation;
	//tr->frame_number = translation;
	//*out << particlep << " " << evdw << " " << translation << " " << rotation << endl;
	//tr->print_details(out,TN_BASIC);
	return tr;
}

/*
*       transformations as stored are to be applied on the receptor
*/
void checkgridscores(){
	Transformation *identity = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
	receptor->build_fft_vdw_grid(grid_spacing, ligand->c->diameter,&rec_shape,gridsize, identity, true);
	if(state==FFT_GENERATE_MATCHES_ATOMP)
		receptor->build_fft_atomcontact_grid(grid_spacing, rec_particlepfft,NUM_FFT_ATOM_TYPES,gridsize, identity, true);
	*out << gridsize[0] << " " << gridsize[1] << " " << gridsize[2] << endl; out->flush();
	
	bool printgrid=false;//true;
	if(printgrid && procid == 0){
		float** sphere = (float **) malloc(sizeof(float*)*(receptor->c->num_atoms));
		for(int i = 0; i < receptor->c->num_atoms; i++){
			Atom *a = receptor->c->atom[i];
			Vector v = (*(a->position) - *(receptor->c->center)) - *(receptor->grid_origin);
			sphere[i] = (float *) malloc(sizeof(float)*4);
			sphere[i][0] = v.x;
			sphere[i][1] = v.y;
			sphere[i][2] = v.z;
			sphere[i][3] = a->radius;
		}
		print_spheres(sphere, receptor->c->num_atoms, "recspheres", VRML1);
		receptor->print_fft_vdwgrid(grid_spacing,&rec_shape, gridsize, 0, 0, 0, "recshape");
		//receptor->print_fft_atompgrid(grid_spacing,rec_particlepfft,NUM_FFT_ATOM_TYPES, gridsize, 0, 0, 0, "recparticlep");
	}
	
	Transformation *prevtr = NULL;
	for(vector<Transformation*>::iterator titr = node_transformations.begin(); titr != node_transformations.end(); titr++){
		Transformation *tr = (Transformation *) *titr;
	  //if(tr->frame_number <=40){
	//{	Transformation *tr = identity;
		tr->print_details(&cout,TN_BASIC);
		Reference_Frame *invrf = Reference_Frame::invert(tr);
		
		Vector trv = *(invrf->translation);

		*(invrf->translation) = Vector(0,0,0);
		
		float Ud; 
		if(prevtr != NULL)	tr->distance(&Ud,prevtr);
		if(prevtr == NULL || Ud > 0.01){ 
			ligand->build_fft_vdw_grid(grid_spacing, receptor->c->diameter,&lig_shape,gridsize, invrf, false);
			if(state==FFT_GENERATE_MATCHES_ATOMP)
				ligand->build_fft_atomcontact_grid(grid_spacing, lig_particlepgrid,NUM_FFT_ATOM_TYPES,gridsize, invrf, false);
		} else
			*out << tr->frame_number << " " << Ud << endl;
		
		/*out << tr->frame_number << " " << trv.x << "," << trv.y << "," << trv.z << endl;
		Vector v = trv - *(ligand->c->center);
		*out << tr->frame_number << " v1 " << v.x << "," << v.y << "," << v.z << endl;
		
		v = tr->inverse_rotate(v);
		*out << tr->frame_number << " v2 " << v.x << "," << v.y << "," << v.z << endl;
				
		v =  *(ligand->grid_origin) - (v + *(receptor->grid_origin) + *(receptor->c->center));
		*out <<  tr->frame_number << " v3 " << v.x << "," << v.y << "," << v.z << endl;
		
		v = invrf->rotate(trv - *(ligand->c->center));
		*out <<  tr->frame_number << " v4 " << v.x << "," << v.y << "," << v.z << endl;*/
		
		Vector v = *(ligand->grid_origin) - (*(receptor->grid_origin) + *(receptor->c->center) + invrf->rotate(trv - *(ligand->c->center)));
		
		float epsilon = 0.001;
		int tx,ty,tz;
		if(v.x > 0)	tx = (v.x + epsilon) / grid_spacing;
		else	tx = -(-v.x + epsilon) / grid_spacing;
		if(v.y > 0)	ty = (v.y + epsilon) / grid_spacing;
		else	ty = -(-v.y + epsilon) / grid_spacing;
		if(v.z > 0)	tz = (v.z + epsilon) / grid_spacing;
		else	tz = -(-v.z + epsilon) / grid_spacing;
		*out << tr->frame_number << " " << v.x << "," << v.y << "," << v.z << " " << tx << "," << ty << "," << tz << "\t"; out->flush();
		
		if(printgrid && tr->frame_number == 5){
			float** sphere = (float **) malloc(sizeof(float*)*(ligand->c->num_atoms));
			for(int i = 0; i < ligand->c->num_atoms; i++){
				Atom *a = ligand->c->atom[i];
				Vector v = invrf->transform(*(a->position) - *(ligand->c->center)) - *(ligand->grid_origin) + Vector(tx,ty,tz)*grid_spacing;
				sphere[i] = (float *) malloc(sizeof(float)*4);
				sphere[i][0] = v.x;
				sphere[i][1] = v.y;
				sphere[i][2] = v.z;
				sphere[i][3] = a->radius;
			}
			print_spheres(sphere, ligand->c->num_atoms, "ligspheres", VRML1);
			ligand->print_fft_vdwgrid(grid_spacing,&lig_shape, gridsize, tx,ty,tz, "ligshape");
			if(state==FFT_GENERATE_MATCHES_ATOMP)
				ligand->print_fft_atompgrid(grid_spacing,lig_particlepgrid, NUM_FFT_ATOM_TYPES,gridsize, tx,ty,tz, "ligparticlep");
		}
			
		if(tx < 0)      tx = (tx + gridsize[0]);
		if(ty < 0)      ty = (ty + gridsize[1]);
		if(tz < 0)      tz = (tz + gridsize[2]);
		*out << "adjusted translation " << tx << "," << ty << "," << tz << endl; out->flush();
		
		float score = 0, particlepscore = 0, numatompcontacts = 0;
		float oss, osi, osc, oii, oic, occ;
		oss = osi = osc = oii = oic = occ = 0;
		for(int i =0; i < gridsize[0]; i++){
	        int ligi = (i + gridsize[0] - tx) % gridsize[0];
	        for(int j =0; j < gridsize[1]; j++){
                int ligj = (j + gridsize[1] - ty) % gridsize[1];
                for(int k =0; k < gridsize[2]; k++){
                    int ligk = (k + gridsize[2] - tz) % gridsize[2];
                    unsigned int index = (i*gridsize[1] + j)*gridsize[2] + k;
                    unsigned int lindex = (ligi*gridsize[1] + ligj)*gridsize[2] + ligk;

                    float real_fourier, imag_fourier;
                    real_fourier = rec_shape[index].real*lig_shape[lindex].real - rec_shape[index].imag*lig_shape[lindex].imag;
                    imag_fourier = rec_shape[index].real*lig_shape[lindex].imag + rec_shape[index].imag*lig_shape[lindex].real;
                    score += (real_fourier - imag_fourier);
                    if(rec_shape[index].real == 1.0){
                    	if(lig_shape[lindex].real == 1.0)	oss++;
                    	else if(lig_shape[lindex].imag == INTERMEDIATE_IMAG)	osi++;
                    	else if(lig_shape[lindex].imag == INTERIOR_IMAG)	osc++;
                    } else if(rec_shape[index].imag == INTERMEDIATE_IMAG){
                    	if(lig_shape[lindex].real == 1.0)	osi++;
                    	else if(lig_shape[lindex].imag == INTERMEDIATE_IMAG)	oii++;
                    	else if(lig_shape[lindex].imag == INTERIOR_IMAG)	oic++;
                    } else if(rec_shape[index].imag == INTERIOR_IMAG){
                    	if(lig_shape[lindex].real == 1.0)	osc++;
                    	else if(lig_shape[lindex].imag == INTERMEDIATE_IMAG)	oic++;
                    	else if(lig_shape[lindex].imag == INTERIOR_IMAG)	occ++;
                    	//if(tr->frame_number == 5)
                    	//	*out << "# " << index << " " << lindex << " " << i<<","<<j<<","<<k<< " " << lig_shape[lindex].real << " " << lig_shape[lindex].imag << endl;
                    }

                    if(state==FFT_GENERATE_MATCHES_ATOMP){
                    	float delta[4];
						for(int di=0; di<4; di++)	delta[di] = 0;
	                    for(int ai=0; ai< NUM_FFT_ATOM_TYPES/2; ai++)
							for(int aj=0; aj< NUM_FFT_ATOM_TYPES/2; aj++){
								float cnts;
								delta[0] += (cnts = rec_particlepfft[ai][index].real*lig_particlepgrid[aj][lindex].real);
								particlepscore += cnts * (*particle_potential)[2*ai][2*aj];
								delta[1] += (cnts = rec_particlepfft[ai][index].imag*lig_particlepgrid[aj][lindex].real);
								particlepscore += cnts * (*particle_potential)[2*ai+1][2*aj];
								delta[2] += (cnts = rec_particlepfft[ai][index].real*lig_particlepgrid[aj][lindex].imag);
								particlepscore += cnts * (*particle_potential)[2*ai][2*aj+1];
								delta[3] += (cnts = rec_particlepfft[ai][index].imag*lig_particlepgrid[aj][lindex].imag);
								particlepscore += cnts * (*particle_potential)[2*ai+1][2*aj+1];
								  
							}
						float cnts = 0;
						for(int di=0; di<4; di++)
							cnts += ABS(delta[di]);
						if(false && tr->frame_number == 5 && cnts > 0)
								*out << delta[0] << " " << delta[1] << " " << delta[2] << " " << delta[3] << endl;
						
						numatompcontacts += cnts;
					}
	        	} 
	        }
		}
		
		float particlepscorebf=0, numacontacts=0, d;
		if(state==FFT_GENERATE_MATCHES_ATOMP)
			for(int j=0; j < ligand->c->num_atoms; j++){
				Atom *al = ligand->c->atom[j];
	  			short aj = al->atom_type;
	  			if(aj >= 0 && aj < NUM_FFT_ATOM_TYPES){
	  				Vector v = tr->inverse_transform(*(al->position));
	  				for(int i=0; i < receptor->c->num_atoms; i++){
			  			Atom *ar = receptor->c->atom[i];
	  					short ai = ar->atom_type;
	  					if(ai >= 0 && ai < NUM_FFT_ATOM_TYPES){
	  						if((d=Vector::distance(v,*(ar->position))) <= ATOM_STEPP_DCUTOFF+2.0){
	  							particlepscorebf += (*particle_potential)[ai][aj];
	  							if(d <= ATOM_STEPP_DCUTOFF+2.0-sqrt(3)*0.5*grid_spacing)
									numacontacts++;
	  						}
	  					}
					}
	  			}
			}

		*out << tr->frame_number << " " << tx << "," << ty << "," << tz << " score " << score << ":" << oss-(INTERMEDIATE_IMAG*osi+INTERMEDIATE_IMAG*INTERMEDIATE_IMAG*oii+INTERIOR_IMAG*osc+
			INTERIOR_IMAG*(INTERMEDIATE_IMAG*oic+INTERIOR_IMAG*occ)) << ":" << tr->eVdw/(grid_spacing*grid_spacing*grid_spacing) << "\t"
			<< oss << " " << osi << " " << osc << " " << oii << " " << oic << " " << occ << "\t" 
			<< particlepscore << ":" << particlepscorebf << ":" << tr->eSolvation << " " << numatompcontacts << " " << numacontacts << endl; out->flush();
	  //}
	  
	  if(prevtr == NULL)	prevtr = tr;
	}
}

void write_nodetransforms_tofile(Transformation *reftr){
	// delete arrays to create space
	if(reftr==NULL){
		delete(rec_shape);	delete(lig_shape);
		delete(rotation_scores);
		if(state==FFT_GENERATE_MATCHES_ATOMP){
			delete(particlep_sum);
			for(int ti = 0; ti < num_particlep_arrays; ti++){	delete(rec_particlepfft[ti]);	delete(lig_particlepgrid[ti]); }
		}
	} 
	
	*out << node_result << endl; out->flush();
	fstream transout;
	char tfilename[512];
	sprintf(tfilename, "%s/%s/%d/trans%d",node_tmp_dir,refpdbcode.c_str(),procid,0);
	transout.open(tfilename,ios::binary|ios::out);
	
	Transformation *tr, *invtr;
	Reference_Frame *rf_invtr;
	vector<Transformation *> tr_trace, invtr_trace;
	vector<Reference_Frame *> rf_invtr_trace;
	for(int i = 0; i < num_node_transforms; i++){
		transformationscore trscore = node_result[i];
		if(i<10)	*out << trscore.evdw << " " << trscore.evdw_real << " " << trscore.evdw_imag << endl;
		
		/* meaning of a transformation as generated
		 * 	translate the ligand such that its center is the origin
		 * 	rotate using euler angles
		 * 	translate such that coordinates are positive
		 * 	translate as specified by the result of fft
		 * 
		 * the receptor was translated such that its center was the origin and again translated such that the coordinates were positive
		 */
		
		if(reftr == NULL)
			tr = new Transformation(rot_angles[trscore.rotindex][0],rot_angles[trscore.rotindex][1], rot_angles[trscore.rotindex][2],i);
		else
			tr = new Transformation(new Vector(0,0,0), new Vector(*(reftr->ex)), new Vector(*(reftr->ey)), 1.0, 0, 0);
			
		// write the pdbfiles for inspection
		if(false && trscore.index == 809962){
			//*out << "check" << endl; out->flush();
			float x = trscore.index/(gridsize[1]*gridsize[2]);
			float y = ((trscore.index/gridsize[2]) % gridsize[1]);
			float z = (trscore.index % gridsize[2]);
			
			if(x >= gridsize[0]/2)	x = x - gridsize[0];
			if(y >= gridsize[1]/2)	y = y - gridsize[1];
			if(z >= gridsize[2]/2)	z = z - gridsize[2];	
			
			Transformation *id = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
			*(id->translation) = *(receptor->c->center) + *(receptor->grid_origin);
			id->write_as_pdb(receptor->c, receptor->c->chains, true, "rec_check.pdb", true);
			
			*(id->translation) = *(ligand->c->center) +*(ligand->grid_origin);
			id->write_as_pdb(ligand->c, ligand->c->chains, true, "idlig_check.pdb",true);
			
			*(tr->translation) = Vector(0,0,0);
			*(tr->translation) = *(ligand->c->center) +tr->inverse_transform(*(ligand->grid_origin));
			tr->write_as_pdb(ligand->c, ligand->c->chains, true, "trlig_check.pdb",true);
			
			*(tr->translation) = Vector(0,0,0);
			*(tr->translation) = *(ligand->c->center) +tr->inverse_transform(*(ligand->grid_origin)-Vector(-x,-y,-z)*grid_spacing);
			tr->write_as_pdb(ligand->c, ligand->c->chains, true, "trlig_vs_rec_check.pdb",true);
			
			*(tr->translation) = Vector(0,0,0);
			*(tr->translation) = *(ligand->c->center) +tr->inverse_transform(*(ligand->grid_origin)-Vector(-x,-y,-z)*grid_spacing - *(receptor->grid_origin) - *(receptor->c->center));
			tr->write_as_pdb(ligand->c, ligand->c->chains, true, "trlig_vs_rec.pdb",true);
			
			*(tr->translation) = Vector(0,0,0);
		}
		
		*(tr->translation) = get_translation(&trscore,tr);
				
		//*out << "before invert" << endl; out->flush();
		rf_invtr = Reference_Frame::invert(tr);
		//*out << "after invert" << endl; out->flush();
		invtr = new Transformation(rf_invtr->translation, rf_invtr->ex, rf_invtr->ey, 1.0, 0, i);
		invtr->eVdw = trscore.evdw;
#ifdef SEPARATE_VDW_ATTR_REPUL
		invtr->sEvolution_interface = trscore.evdw_attr;		
#endif
		invtr->votes = trscore.rotindex;
		invtr->eResiduepair = trscore.index;
		
		if(state==FFT_GENERATE_MATCHES_VDW)
			invtr->eSolvation = trscore.evdw;
		else {
			invtr->eSolvation = trscore.score;
			invtr->eElectrostatic = trscore.particlep;
		}
		
		invtr->frame_number = trscore.index;
		invtr->num_contacts = 0;
		
		invtr->write_binary(&transout,TN_BASIC);
		if(i<10) invtr->print_details(out,TN_BASIC); out->flush();
		
		delete tr;
		delete rf_invtr;
		//delete invtr;
		//invtr_trace.push_back(invtr);
	}
	transout.close();
	
	// delete - deletion in the loop is causing crashes
	for(vector<Transformation*>::iterator itr = tr_trace.begin(); itr != tr_trace.end(); itr++)
		delete ((Transformation*) *itr);
	for(vector<Transformation*>::iterator itr = invtr_trace.begin(); itr != invtr_trace.end(); itr++)
		delete ((Transformation*) *itr);
	for(vector<Reference_Frame*>::iterator itr = rf_invtr_trace.begin(); itr != rf_invtr_trace.end(); itr++)
		delete ((Reference_Frame*) *itr);
	
	char command[512];
	//write to file to not lose work if things crash
	/*sprintf(command, "gzip %s",tfilename);
	int ret = system(command);
	*out << command << " " << ret << endl;
		
	sprintf(command, "cp %s.gz trans/",tfilename,refpdbcode.c_str());
	ret = system(command);
	*out << command << " " << ret << endl;
	
	// collect transforms assumes unzipped file
	sprintf(command, "gunzip %s",tfilename);
	ret = system(command);
	*out << command << " " << ret << endl;
	*/
	
	// delete restrans 
	sprintf(command , "rm %s/%s/%d/restrans*",node_tmp_dir,refpdbcode.c_str(),procid);
	int ret = system(command);
	*out << command << " " << ret << endl;
}

void read_rotations(){
	string filename = piedock_home + "/" + string(DOCK_DIR) + string(SPACED_ROTATIONS);
	char buf[8192];
	num_rotations = 0;
	fstream frotations(filename.c_str(), ios::in);
    while(frotations.good()){
    	frotations.getline(buf,8192);
    	if(frotations.gcount() > 0)
    		num_rotations++;
    }
	rot_angles = (float**) malloc(sizeof(float*)*num_rotations);
	for(int i = 0 ; i < num_rotations; i++)	rot_angles[i] = (float*) malloc(sizeof(float)*3);
    
    num_rotations = 0;
    frotations.clear();
    frotations.seekg(ios_base::beg);
    while(frotations.good()){
    	frotations.getline(buf,8192);
    	if(frotations.gcount() > 0){
    		stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
			ss >> rot_angles[num_rotations][0];
			ss >> rot_angles[num_rotations][1];
			ss >> rot_angles[num_rotations][2];
			num_rotations++;
    	}
    }
    frotations.close();
}

/*
 * node 0 arbitrates the distribution, no semaphores for now
 * 1 proc, it generates everything, > 1, node 0 does not generate anything
 */
void generate_transformations(int rotstart, int rotend){
    hash_set<int,hash<int>,eqint> missing;
    /*fstream fmissing("presentbitmap");
    while(fmissing.good()){
    	fmissing.getline(buf,8192);
    	if(fmissing.gcount() > 0){
    		stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
			int rotation, present;
			ss >> rotation;
			ss >> present;
			if(present == 0)	missing.insert(rotation);
    	}
    }
    fmissing.close();*/
	
	int start;
	node_transformations.clear();
	
	for(int i = 0; i < NUM_GENERATION_STATS; i++)	generation_stats[i] = 0;
	
	rotstart = max(rotstart,0);
	rotend = min(rotend,num_rotations);
	
	if(procid == 0){
		int nummissing=0;
		for(int i = rotstart; i < rotend; i++)
			if(missing.count(i) > 0)	nummissing++;
		cout << "total# missing rotations " << missing.size() << " in range " << nummissing << endl;
		
		if(numprocs == 1){
			for(int i=rotstart; i< rotend; i++){
				match_rotation( i );
			}
			
			// write node transforms to file
			write_nodetransforms_tofile(NULL);
			pieces[0] = num_node_transforms;
		} else {
			cout << "rotstart " << rotstart << " rotend " << rotend << endl;
			int current = rotstart;
			bool node_done[numprocs];
			for(int i = 1; i < numprocs; i++)	node_done[i] = false;
			bool done = false;
						
			while(!done){
				// receive a token and send work
				MPI_Recv(buff, BUFSIZE, MPI_CHAR, MPI_ANY_SOURCE, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
				int node = atoi(buff);
				
				sprintf(buff, "%d", current);
				MPI_Ssend(buff, 256, MPI_CHAR, node, GENERATE_TAG, MPI_COMM_WORLD);
				
				// ended the computation at the node
				if(current >= rotend)	node_done[node] = true;
				
				*out << "node " << node << " working on " << current << " " << node_done[node] << endl; out->flush();
				
				current = current + 1;
				if(current %1000 == 0){
					time(&current_time);
					cout << "at rotation " << current << " time " <<  difftime(current_time,start_time) << endl; cout.flush();
				}
				
				done = true;
				for(int i = 1; i < numprocs; i++)	done &= node_done[i];
			}
			
			cout << "finished assigning ids for matching" << endl;
		}
	} else {
		bool done = false;
		while(!done){
			sprintf(buff, "%d",procid);
			MPI_Ssend(buff, 256, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD);
			MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
			start = atoi(buff);
			if(start >= rotend){
				done = true;
				break;
			} else {
			  //if(missing.count(start) > 0)
				match_rotation( start );
			}
		}
		write_nodetransforms_tofile(NULL);
		pieces[0] = num_node_transforms;
	}
	
	time(&current_time);
	*out << "node " << procid << " generated transformations # " << num_node_transforms << "\t time:"
		<< difftime(current_time,start_time) << "s" << endl; out->flush();
}


void process_receptor(){
	// what is the target grid size
	rec_shape = NULL;
	gridsize[0] = gridsize[1] = gridsize[2] = 0;
	Transformation *identity = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);

#ifdef VDW_OPLS_APPROX
	receptor->build_fft_opls_vdw_grid(grid_spacing,  ligand->c->diameter,&rec_shape,gridsize, identity, true);
	//if(procid == 0)	
	//	receptor->fft_check_opls_vdw_accuracy(grid_spacing, rec_shape_attr, gridsize);
#else
	receptor->build_fft_vdw_grid(grid_spacing, ligand->c->diameter,&rec_shape,gridsize, identity, true);
#endif	
		
	size = gridsize[0] * gridsize[1] * gridsize[2];
	*out << "gridsize " << gridsize[0] << "," << gridsize[1] << "," << gridsize[2] << " " << rec_shape << endl;
	if(procid == 0)	cout << "grid spacing used " << grid_spacing << " size " << size << endl;
	
	if(flip){
		float tmpgrid[gridsize[0]][gridsize[1]][gridsize[2]][2];
		for(int i =0; i < gridsize[0]; i++)
			for(int j =0; j < gridsize[1]; j++)
				for(int k =0; k < gridsize[2]; k++){
					unsigned int index = (i*gridsize[1] + j)*gridsize[2] + k;
					tmpgrid[i][j][k][0] = rec_shape[index].real;
					tmpgrid[i][j][k][1] = rec_shape[index].imag;
				}
		
		for(int i =0; i < gridsize[0]; i++)
			for(int j =0; j < gridsize[1]; j++)
				for(int k =0; k < gridsize[2]; k++){
					int xi = (gridsize[0] - i) % gridsize[0];
					int yi = (gridsize[1] - j) % gridsize[1];
					int zi = (gridsize[2] - k) % gridsize[2];
					
					unsigned int index = (xi*gridsize[1] + yi)*gridsize[2] + zi;
					rec_shape[index].real = tmpgrid[i][j][k][0];
					rec_shape[index].imag = tmpgrid[i][j][k][1];
				}
	}
	
	mkl_status = DftiCreateDescriptor( &fft_desc_handle, DFTI_SINGLE, DFTI_COMPLEX, 3, gridsize );
	*out << DftiErrorMessage(mkl_status) << endl;
	mkl_status = DftiSetValue( fft_desc_handle, DFTI_PLACEMENT, DFTI_INPLACE );
	*out << DftiErrorMessage(mkl_status) << endl;
	
	strides[0]=0;
	strides[1]=gridsize[1]*gridsize[2];
	strides[2]=gridsize[2];
	strides[3]=1;
	/*mkl_status = DftiSetValue( fft_desc_handle, DFTI_INPUT_STRIDES, strides);
	*out << DftiErrorMessage(mkl_status) << endl;*/
	
	mkl_status = DftiCommitDescriptor(fft_desc_handle);
	*out << DftiErrorMessage(mkl_status) << endl;
	if(flip){
		//write_tofile(rec_shape,"recshape");
		mkl_status = DftiComputeForward(fft_desc_handle, rec_shape);
		*out << "receptor flip fft " << DftiErrorMessage(mkl_status) << endl;
		/*write_tofile(rec_shape,"recshapei");
		DftiComputeBackward(fft_desc_handle, rec_shape);
		write_tofile(rec_shape,"recshapefi");*/
	} else {
		mkl_status = DftiComputeBackward(fft_desc_handle, rec_shape);
		*out << "receptor ift " << DftiErrorMessage(mkl_status) << endl;
	}
	
	/*write_tofile(rec_shape,"receptorrift");
	mkl_status = DftiComputeForward(fft_desc_handle, rec_shape);
	*out << DftiErrorMessage(mkl_status) << endl;
	write_tofile(rec_shape,"receptorrfi");
	receptor->build_fft_vdw_grid(grid_spacing, ligand->c->diameter,&rec_shape,gridsize, identity, true);
	mkl_status = DftiComputeBackward(fft_desc_handle, rec_shape);
	*out << DftiErrorMessage(mkl_status) << endl;*/
	
	sqrt_size = sqrt(size);
	if(state==FFT_GENERATE_MATCHES_ATOMP || state==FFT_GENERATE_MATCHES_EVATOMP || state ==FFT_GENERATE_MATCHES_RESIDUEP
	|| state == FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP  
	|| start_state == FFT_GENERATE_MATCHES_RESIDUE_BKBNP || start_state == FFT_GENERATE_MATCHES_EVRESIDUE_BKBNP
	){
		switch(state){
			case FFT_GENERATE_MATCHES_ATOMP:
			case FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP:
				num_particlep_arrays = (NUM_FFT_ATOM_TYPES+1)/2;
				break;
			case FFT_GENERATE_MATCHES_EVATOMP:
				num_particlep_arrays = (NUM_FFT_ATOM_EIGENVECTORS+1)/2;
				break;
			case FFT_GENERATE_MATCHES_RESIDUEP:
				num_particlep_arrays = 10;
				break;
			case FFT_GENERATE_MATCHES_RESIDUE_BKBNP:
				num_particlep_arrays = 11;
				break;
			case FFT_GENERATE_MATCHES_EVRESIDUE_BKBNP:
				num_particlep_arrays = (NUM_FFT_RESIDUE_BKBN_EIGENVECTORS+1)/2;
				break;
		}
			
		*out << "num_particlep_arrays " << num_particlep_arrays << endl;
		lig_particlepgrid = (MKL_Complex8 **) malloc(sizeof(MKL_Complex8 *) * num_particlep_arrays);
		for(int ti = 0; ti < num_particlep_arrays; ti++)
			lig_particlepgrid[ti] = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
		*out << "allocated space " << endl; out->flush();
		*out << "state " << state << endl;
		
		// use the ligand grid for computation
		switch(state){
			case FFT_GENERATE_MATCHES_ATOMP:
			case FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP:
				receptor->build_fft_atomcontact_grid(grid_spacing, lig_particlepgrid,NUM_FFT_ATOM_TYPES,gridsize, identity, true);
				if(procid == 0)	{
					receptor->fft_check_potential_accuracy(grid_spacing, lig_particlepgrid,NUM_FFT_ATOM_TYPES,*particle_potential,gridsize);
					for(int ai = 0; ai < NUM_FFT_ATOM_TYPES; ai++)
						for(int aj = 0; aj < NUM_FFT_ATOM_TYPES; aj++)
							cout << "potential " << ai << " " << aj << " " << (*particle_potential)[ai][aj] << endl;
				}
				receptor->build_fft_contact_potential_grid(lig_particlepgrid,NUM_FFT_ATOM_TYPES,*particle_potential,gridsize);
				break;
			case FFT_GENERATE_MATCHES_EVATOMP:
				{
					//read eigenvalues and eigenvectors
					atomp_eigen_value = (float*) malloc(NUM_FFT_ATOM_TYPES*sizeof(float));
					atomp_eigen_vector = (float**) malloc(NUM_FFT_ATOM_TYPES*sizeof(float*));
					for(int j = 0 ; j < NUM_FFT_ATOM_TYPES; j++)
						atomp_eigen_vector[j] = (float*) malloc(NUM_FFT_ATOM_TYPES*sizeof(float));
					string filename;
					switch(NUM_FFT_ATOM_TYPES){
						case 20:
							filename = piedock_home + "/" + string(DOCK_DIR) + "atom20.eigen";
							break;
						case 18:
							filename = piedock_home +  "/" + string(DOCK_DIR) + "iterative_learn/vdw_atom18_contacts5/slack_weight_100/atom18.eigen";
							break;
					}
					fstream fatom(filename.c_str());
					int lineno=0;
					while(fatom.good()){
				    	fatom.getline(buff,8192);
				    	if(fatom.gcount() > 0){
					    	stringstream ss (stringstream::in | stringstream::out);
					    	ss << buff;
					    	if(lineno==0){
					    		for(int j = 0 ; j < NUM_FFT_ATOM_TYPES; j++)
									ss >> atomp_eigen_value[j];
					    	} else {
					    		for(int j = 0 ; j < NUM_FFT_ATOM_TYPES; j++)
									ss >> atomp_eigen_vector[lineno-1][j];
					    	}
					    	lineno++;
				    	}
				    }
				    fatom.close();
				    
				    // sort eigenvectors by value
				    float abs_eigen_value[NUM_FFT_ATOM_TYPES];
				    for(int j = 0 ; j < NUM_FFT_ATOM_TYPES; j++)
						abs_eigen_value[j] = ABS( atomp_eigen_value[j]);
				    for(int j = 0 ; j < NUM_FFT_ATOM_TYPES; j++)
				    	for(int k = j+1 ; k < NUM_FFT_ATOM_TYPES; k++){
				    		if(abs_eigen_value[j] < abs_eigen_value[k]){
				    			float tv = abs_eigen_value[j];
				    			abs_eigen_value[j] = abs_eigen_value[k];
				    			abs_eigen_value[k] = tv;
				    			
				    			tv = atomp_eigen_value[j];
				    			atomp_eigen_value[j] = atomp_eigen_value[k];
				    			atomp_eigen_value[k] = tv;
				    			
				    			float *tp = atomp_eigen_vector[j];
				    			atomp_eigen_vector[j] = atomp_eigen_vector[k];
				    			atomp_eigen_vector[k] = tp;
				    		}
				    	}
				    if(procid==0)
					    for(int j = 0 ; j < NUM_FFT_ATOM_TYPES; j++){
					    	*out << "eigenvalue " << j << " " << atomp_eigen_value[j] << " vector: (";
					    	for(int k = 0 ; k < NUM_FFT_ATOM_TYPES; k++)	*out << atomp_eigen_vector[j][k] << ",";
					    	*out << ")" << endl;
					    }
		    
					receptor->build_fft_eigen_atomp_grid(grid_spacing, lig_particlepgrid,NUM_FFT_ATOM_TYPES,NUM_FFT_ATOM_EIGENVECTORS,atomp_eigen_vector,gridsize, identity, true);
				}
				break;
			case FFT_GENERATE_MATCHES_RESIDUEP:
				receptor->build_fft_residue_centroid_centroid_contact_grid(grid_spacing, lig_particlepgrid,20,gridsize, identity, true);
				receptor->build_fft_contact_potential_grid(lig_particlepgrid,20,*particle_potential,gridsize);
				break;
			case FFT_GENERATE_MATCHES_RESIDUE_BKBNP:
				receptor->build_fft_residue_bkbn_centroid_bkbn_centroid_contact_potential_grid(grid_spacing, lig_particlepgrid,22, *particle_potential,gridsize,identity, true);
				break;
			case FFT_GENERATE_MATCHES_EVRESIDUE_BKBNP:
				{
					//read eigenvalues and eigenvectors
					int num_residue_types = 22;
					resbkbnp_eigen_value = (float*) malloc(num_residue_types*sizeof(float));
					resbkbnp_eigen_vector = (float**) malloc(num_residue_types*sizeof(float*));
					for(int j = 0 ; j < num_residue_types; j++)
						resbkbnp_eigen_vector[j] = (float*) malloc(num_residue_types*sizeof(float));
					string filename= piedock_home +  "/" + string(DOCK_DIR) + "iterative_learn/vdw_res_bkbn7/resbkbn.eigen";
					fstream fresidue(filename.c_str());
					*out << filename << " " << fresidue.good() << endl; out->flush();
					int lineno=0;
					while(fresidue.good()){
				    	fresidue.getline(buff,8192);
				    	if(fresidue.gcount() > 0){
					    	stringstream ss (stringstream::in | stringstream::out);
					    	ss << buff;
					    	if(lineno==0){
					    		for(int j = 0 ; j < num_residue_types; j++)
									ss >> resbkbnp_eigen_value[j];
					    	} else {
					    		for(int j = 0 ; j < num_residue_types; j++)
									ss >> resbkbnp_eigen_vector[lineno-1][j];
					    	}
					    	lineno++;
				    	}
				    }
				    fresidue.close();
				    
				    // sort eigenvectors by value
				    float abs_eigen_value[num_residue_types];
				    for(int j = 0 ; j < num_residue_types; j++)
						abs_eigen_value[j] = ABS( resbkbnp_eigen_value[j]);
				    for(int j = 0 ; j < num_residue_types; j++)
				    	for(int k = j+1 ; k < num_residue_types; k++){
				    		if(abs_eigen_value[j] < abs_eigen_value[k]){
				    			float tv = abs_eigen_value[j];
				    			abs_eigen_value[j] = abs_eigen_value[k];
				    			abs_eigen_value[k] = tv;
				    			
				    			tv = resbkbnp_eigen_value[j];
				    			resbkbnp_eigen_value[j] = resbkbnp_eigen_value[k];
				    			resbkbnp_eigen_value[k] = tv;
				    			
				    			float *tp = resbkbnp_eigen_vector[j];
				    			resbkbnp_eigen_vector[j] = resbkbnp_eigen_vector[k];
				    			resbkbnp_eigen_vector[k] = tp;
				    		}
				    	}
				    if(procid==0)
					    for(int j = 0 ; j < num_residue_types; j++){
					    	*out << "eigenvalue " << j << " " << resbkbnp_eigen_value[j] << " vector: (";
					    	for(int k = 0 ; k < num_residue_types; k++)	*out << resbkbnp_eigen_vector[j][k] << ",";
					    	*out << ")" << endl; out->flush();
					    }
		    		//while(1);
					receptor->build_fft_eigen_residue_bkbnp_grid(grid_spacing, lig_particlepgrid,num_residue_types,NUM_FFT_RESIDUE_BKBN_EIGENVECTORS,resbkbnp_eigen_vector,gridsize, identity, true);
				}
				break;
		}
		
		bool checkparticlepfft=false;
		if(checkparticlepfft)	write_tofile(lig_particlepgrid[0],"recatomtype0_initial");
		
		if(flip){
			float tmpgrid[gridsize[0]][gridsize[1]][gridsize[2]][2];
			for(int ti = 0; ti < num_particlep_arrays; ti++){
				for(int i =0; i < gridsize[0]; i++)
					for(int j =0; j < gridsize[1]; j++)
						for(int k =0; k < gridsize[2]; k++){
							unsigned int index = (i*gridsize[1] + j)*gridsize[2] + k;
							tmpgrid[i][j][k][0] = lig_particlepgrid[ti][index].real;
							tmpgrid[i][j][k][1] = lig_particlepgrid[ti][index].imag;
						}
				
				for(int i =0; i < gridsize[0]; i++)
					for(int j =0; j < gridsize[1]; j++)
						for(int k =0; k < gridsize[2]; k++){
							int xi = (gridsize[0] - i) % gridsize[0];
							int yi = (gridsize[1] - j) % gridsize[1];
							int zi = (gridsize[2] - k) % gridsize[2];
							
							unsigned int index = (xi*gridsize[1] + yi)*gridsize[2] + zi;
							lig_particlepgrid[ti][index].real = tmpgrid[i][j][k][0];
							lig_particlepgrid[ti][index].imag = tmpgrid[i][j][k][1];
						}
			}
		}
		
		// debug particlep fourier transforms
		if(checkparticlepfft && flip)	{
			/*DFTI_DESCRIPTOR_HANDLE real_input_ffthandle;
			mkl_status = DftiCreateDescriptor( &real_input_ffthandle, DFTI_SINGLE, DFTI_REAL, 3, gridsize );
			*out << "1 " << DftiErrorMessage(mkl_status) << endl;
			mkl_status = DftiSetValue(real_input_ffthandle , DFTI_PLACEMENT, DFTI_NOT_INPLACE );
			*out << "2 " << DftiErrorMessage(mkl_status) << endl;
			mkl_status = DftiCommitDescriptor(real_input_ffthandle);
			*out << "3 " << DftiErrorMessage(mkl_status) << endl;
			DftiSetValue(real_input_ffthandle, DFTI_CONJUGATE_EVEN_STORAGE, DFTI_COMPLEX_COMPLEX);
			
			float real_input[size];
			MKL_Complex8 out_real_inp[gridsize[0]][gridsize[0]][(gridsize[0]+1)/2];
			for(int i =0; i < size; i++)
				real_input[i] = lig_particlepgrid[0][i].real;
			mkl_status = DftiComputeForward(real_input_ffthandle, real_input, out_real_inp);
			*out << "4 " << DftiErrorMessage(mkl_status) << endl;*/
			
			MKL_Complex8 *output = (MKL_Complex8* ) malloc(sizeof(MKL_Complex8)*size);
			for(int i =0; i < gridsize[0]; i++)
				for(int j =0; j < gridsize[1]; j++)
					for(int k =0; k < gridsize[2]; k++){
						unsigned int index = (i*gridsize[1] + j)*gridsize[2] + k;
						output[index].real =lig_particlepgrid[0][index].real;
						output[index].imag = 0;
					}
			write_tofile(output,"recatomtype0");
			DftiComputeForward(fft_desc_handle, output);
			write_tofile(output,"recatomtype0idirect");
			
			DftiComputeBackward(fft_desc_handle, output);
			write_tofile(output,"recatomtype0_f_idirect");
			for(int index = 0; index < size; index++){
				if(abs((int) (lig_particlepgrid[0][index].real - output[index].real/size)) > 0.01)
					cout << "fft diff " << index << lig_particlepgrid[0][index].real << " " << output[index].real/size << endl;
			}
			delete(output);
		}
		
		for(int ti = 0; ti < num_particlep_arrays; ti++){
			if(flip){
				mkl_status = DftiComputeForward(fft_desc_handle, lig_particlepgrid[ti]);
				*out << "particlep flipped fft " << ti << " " << DftiErrorMessage(mkl_status) << endl;
			} else {
				mkl_status = DftiComputeBackward(fft_desc_handle, lig_particlepgrid[ti]);
				*out << "particlep ift " << ti << " " << DftiErrorMessage(mkl_status) << endl;
			}
		}
		
		int n=0;
		switch(state){
			case FFT_GENERATE_MATCHES_ATOMP:
			case FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP:
				n = NUM_FFT_ATOM_TYPES;
				break;
			case FFT_GENERATE_MATCHES_EVATOMP:
				n = NUM_FFT_ATOM_EIGENVECTORS;
				break;
			case FFT_GENERATE_MATCHES_RESIDUEP:
				n =20;
				break;
			case FFT_GENERATE_MATCHES_RESIDUE_BKBNP:
				n =22;
				break;
			case FFT_GENERATE_MATCHES_EVRESIDUE_BKBNP:
				n = NUM_FFT_RESIDUE_BKBN_EIGENVECTORS;
				break;
		}
			
		rec_particlepfft = (MKL_Complex8 **) malloc(sizeof(MKL_Complex8 *) * n);
		for(int ti = 0; ti < n; ti++)
			rec_particlepfft[ti] = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
		
		for(int i = 0; i < size; i++){
			MKL_Complex8 rec[n];
			
			int z = (i % gridsize[2]);
			int y = ((i / gridsize[2]) % gridsize[1]) ;
			int x = i/(gridsize[2] * gridsize[1]) ;
			
			int xi = (gridsize[0] - x) % gridsize[0];
			int yi = (gridsize[1] - y) % gridsize[1];
			int zi = (gridsize[2] - z) % gridsize[2];
			
			unsigned int iinv = (xi*gridsize[1] + yi)*gridsize[2] + zi;
			for(int j=0; j< n; j++){
				if(j%2 == 0){
					rec_particlepfft[j][i].real = (lig_particlepgrid[j/2][i].real + lig_particlepgrid[j/2][iinv].real)/2;
					rec_particlepfft[j][i].imag = (lig_particlepgrid[j/2][i].imag - lig_particlepgrid[j/2][iinv].imag)/2;
				} else {
					float a,b;
					a = (lig_particlepgrid[j/2][i].real - lig_particlepgrid[j/2][iinv].real)/2;
					b = (lig_particlepgrid[j/2][i].imag + lig_particlepgrid[j/2][iinv].imag)/2;
					
					// need to multiply by -sqrt(-1) or divide by i
					rec_particlepfft[j][i].real = b;
					rec_particlepfft[j][i].imag = -a;
				}
			}
		}
		
		if(checkparticlepfft) {
			write_tofile(rec_particlepfft[0],"recatomtype0i");
		}
		
		*out << "computed particlep ifts for receptor" << endl; out->flush();
	}
	
	lig_shape = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);

#ifdef SEPARATE_VDW_ATTR_REPUL
	// compute fourier transform for the attractive part of vdw and repulsive part of vdw separately
	rec_shape_attr = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
	rec_shape_repul = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
	for(int i = 0; i < size; i++){
		int z = (i % gridsize[2]);
		int y = ((i / gridsize[2]) % gridsize[1]) ;
		int x = i/(gridsize[2] * gridsize[1]) ;
		
		int xi = (gridsize[0] - x) % gridsize[0];
		int yi = (gridsize[1] - y) % gridsize[1];
		int zi = (gridsize[2] - z) % gridsize[2];
		
		unsigned int iinv = (xi*gridsize[1] + yi)*gridsize[2] + zi;
		rec_shape_attr[i].real = (rec_shape[i].real + rec_shape[iinv].real)/2;
		rec_shape_attr[i].imag = (rec_shape[i].imag - rec_shape[iinv].imag)/2;
		
	//	if(ABS(rec_shape[i].real - rec_shape_attr[i].real) > 0.01 || ABS(rec_shape[i].imag - rec_shape_attr[i].imag) > 0.01)
	//		cout << "grid fts different " << i << " (" << rec_shape[i].real << "," << rec_shape[i].imag << ") (" << rec_shape_attr[i].real << "," << rec_shape_attr[i].imag << ")\n";   
		{
			float a,b;
			a = (rec_shape[i].real - rec_shape[iinv].real)/2;
			b = (rec_shape[i].imag + rec_shape[iinv].imag)/2;
					
			// need to multiply by -sqrt(-1) or divide by i
			rec_shape_repul[i].real = b;
			rec_shape_repul[i].imag = -a;
		}
	}
	
	lig_shape_attr = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
	lig_shape_repul = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
#endif
	
	particlep_sum = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
	rotation_scores = (transformationscore *) malloc(sizeof(transformationscore) * size);
	work0 = (transformationscore *) malloc(sizeof(transformationscore) * (size+max_transformations));
	work1 = (transformationscore *) malloc(sizeof(transformationscore) * (size+max_transformations));
}

int main(int argc, char *argv[]){
	time(&start_time);
	int ret = MPI_Init(&argc,&argv);
	if(ret == MPI_SUCCESS){
		MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
		MPI_Comm_rank(MPI_COMM_WORLD,&procid);
				
		if(procid == 0){
			cout << "Job running on " << numprocs << " processors" << endl;
			cout << "#args " << argc << endl;
			cout.flush();
		}
		
		read_molecule_config();
		float atomp_vdw_weight;
		if(NUM_FFT_ATOM_TYPES == 18){
			coarsen_atomtypesto18();
			particle_potential = &atom18_potential;
			atomp_vdw_weight = vdw_weight;
		} else if(NUM_FFT_ATOM_TYPES == 20){
			coarsen_atomtypesto20();
			particle_potential = &atom20_potential;
			atomp_vdw_weight = vdw_weight;
		}
		read_dock_config();
		node_tmp_dir = (char*) (new string(string(tmp_dir)+"/"+string(getenv(string("JOB_ID").c_str()))))->c_str();
		
		elect_leader_on_node();
		
		//initialize
		refpdbcode = string(argv[9]);
		sprintf(command, "%s/cluster_scripts/setup.sh %s %d %s %d",piedock_home,getenv(string("JOB_ID").c_str()),procid, refpdbcode.c_str(), masterprocessonnode);
		ret = system(command);
		
		sprintf(scratch_dir, "%s/%s/%d",node_tmp_dir,refpdbcode.c_str(),procid);
		sprintf(filename, "%s/%s/%sout%d",node_tmp_dir,refpdbcode.c_str(),refpdbcode.c_str(),procid);
		//cout << filename << endl; cout.flush();
		fstream outstream;
		outstream.open(filename,ios::out);
		if(!outstream.good()){
			cout << "ERROR: could not open file " << filename << " " << errno << "\n"; cout.flush();
			exit(-1);
		}
		out = &outstream;
		
		*out << procid << " " << *host << " am_master " << masterprocessonnode << endl;
		*out << "setup " << command << " " << ret << endl;
		
		filetype = atoi(argv[1]);
		docktype = atoi(argv[2]);
		start_state = atoi(argv[3]);
		end_state = atoi(argv[4]);
		*out << "start " << start_state << " end " << end_state << endl;out->flush();
		
		stringstream ss (stringstream::in | stringstream::out);
		string s;
		ss << argv[5] << "_" << argv[6] << "_vs_" << argv[7] << "_" << argv[8] << "fft";
		ss >> s;
		tag = (char*) (new string(s.c_str()))->c_str();
		
		ss.clear();
		string ts;
		ss << s << ".trans";
		ss >> ts;
		transformations_file = (char*) (new string(ts.c_str()))->c_str();
		sprintf(local_transformations_file,"%s/%s",scratch_dir,transformations_file);
		
		rpdbcode = string(argv[5]);
		rchains = string(argv[6]);
		lpdbcode = string(argv[7]);
		lchains = string(argv[8]);
		refrchains = string(argv[10]);
		reflchains = string(argv[11]);
		
		Complex* cr = new Complex(("../"+rpdbcode).c_str(),rchains.c_str(), filetype);
		Complex* crH =cr;// new Complex(("../"+rpdbcode).c_str(),rchains.c_str(), PQR);
		out->flush();
		receptor = new Object(cr,crH);
		
		Complex* cl = new Complex(("../"+lpdbcode).c_str(),lchains.c_str(), filetype);
		Complex* clH = cl;//new Complex(("../"+lpdbcode).c_str(),lchains.c_str(), PQR);
		ligand = new Object(cl, clH);
		
		if(start_state == FFT_GENERATE_MATCHES_VDW || start_state == FFT_GENERATE_MATCHES_ATOMP || start_state == FFT_GENERATE_MATCHES_EVATOMP
		 || start_state == FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP
		 || start_state == FFT_GENERATE_MATCHES_RESIDUEP || start_state == FFT_GENERATE_MATCHES_RESIDUE_BKBNP || start_state == FFT_GENERATE_MATCHES_EVRESIDUE_BKBNP
		 ){
			if(start_state != FFT_GENERATE_MATCHES_VDW){
				//transscore_better = &transscore_bettercontactp;
				transscore_better = &transscore_bettersum;
			}
			if(start_state == FFT_GENERATE_MATCHES_RESIDUEP)
				particle_potential = &residue_potential;
			if(start_state == FFT_GENERATE_MATCHES_RESIDUE_BKBNP)
				particle_potential = &residue_bkbn_potential;
			
			if(start_state == FFT_GENERATE_MATCHES_ATOMP || start_state == FFT_GENERATE_MATCHES_EVATOMP || start_state == FFT_GENERATE_MATCHES_VDW_REPUL_FILTER_ATOMP)
				vdw_weight = atomp_vdw_weight;
			
			state=start_state;
			process_receptor();
			pieces.clear();
			
			//*out << "generating " << endl;
			read_rotations();

#ifdef LOOP_CONSTRAINT
			if(argc>13)	looplength = atoi(argv[14]);
#endif
	
    		generate_transformations(atoi(argv[12]),atoi(argv[13]));
    		
    		state = GENERATE_MATCHES;
			collect_transformations(true,max_transformations);
			if(procid == 0)	cout << "grid spacing used " << grid_spacing << " size " << size << " start state " << start_state << " vdw_weight " << vdw_weight << endl;
		}
		
		if(start_state == CHECK_GRIDSCORE){
			state = CHECK_GRIDSCORE;
			if(numprocs==1)	out=&cout;
			state=FFT_GENERATE_MATCHES_VDW;
			process_receptor();
			examine_transformations();
			read_transformations();
			cout << " #trans " << node_transformations.size() << endl;
			checkgridscores();
		}
		
		// use the reference rotation for retrospective examination
		if(start_state == FFT_USE_REF_ROTATION){
			receptor->preprocess_receptor();
			ligand->preprocess_ligand();
			receptor->build_contact_grid(ligand->max_grid_point_distance + sqrt(3)*GRID_SPACING/2.0);
			ligand->build_contact_grid(receptor->max_grid_point_distance + sqrt(3)*GRID_SPACING/2.0);
			
			preprocess();
			reference = new Complex(("../"+refpdbcode).c_str(),(refrchains+reflchains).c_str(),PDB);
			referenceH = reference; //new Complex(("../"+refpdbcode).c_str(),(refrchains+reflchains).c_str(),PQR);
			read_alignments();
			
			Transformation *reference_tr = examine_reference();
			Reference_Frame *rf_invtr = Reference_Frame::invert(reference_tr);
			Transformation *invtr = new Transformation(new Vector(rf_invtr->translation), rf_invtr->ex, rf_invtr->ey, 1.0, 0, 0);
			cout << "reftr "; reference_tr->print_details(&cout,TN_BASIC);
			cout << "inverted "; invtr->print_details(&cout,TN_BASIC);
			*(invtr->translation) = Vector(0,0,0);
		
			// what is the closest rotation to the reference rotation in the discrete set?
			vector<int> neighbor_rotationids;
			read_rotations();
			float Ud, minUd = 3.0;
			int closest_rotation=-1;
			for(int i=0; i< num_rotations; i++){
				Transformation *rtr = new Transformation(rot_angles[i][0],rot_angles[i][1],rot_angles[i][2],i);
				invtr->distance(&Ud,rtr);
				if(Ud<minUd){
					minUd = Ud;
					closest_rotation = i;
				}
				if(Ud<=0.2)	neighbor_rotationids.push_back(i);
				float alpha, beta, gamma;
				rtr->eulerangles(&alpha, &beta, &gamma);
				float eps=0.001;
				if(ABS(alpha - rot_angles[i][0]) > eps || ABS(beta - rot_angles[i][1]) > eps || ABS(gamma - rot_angles[i][2]) > eps)
					*out << "euler " << rot_angles[i][0] << ","<<rot_angles[i][1]<<","<<rot_angles[i][2]<<
						"\t" << alpha << "," << beta << "," << gamma << endl;
				delete rtr;
			}
			cout << "min Ud " << minUd << " closest rotation " << closest_rotation << " #neighbors " << neighbor_rotationids.size() << endl;
			
			//state=FFT_GENERATE_MATCHES_EVATOMP;
			state=FFT_GENERATE_MATCHES_RESIDUEP;
			//transscore_better = &transscore_bettersolvnE;
			
			state=FFT_GENERATE_MATCHES_VDW;
			
			process_receptor();
			match_rotation(num_rotations+1,invtr);
			
			int num_refpositives=0;
#ifdef FILTER_POSITIVES_DURING_REFDOCK			
			// mark transforms that are definitely not correct
			for(int i = 0; i < num_node_transforms; i++){
				transformationscore *trscore = &(node_result[i]);
				if(trscore->particlep > -1000000.0){
					Transformation *tr = invtr;
					Vector v = get_translation(trscore, tr);
					//double df2 = Vector::distance_squared(&v,reference_tr->translation);
					double dr2 = Vector::distance_squared(v,*(rf_invtr->translation));
					if(dr2>=100.0){
						trscore->particlep = -100000.0;
					} else {
						//cout << "particlep " << trscore->particlep << " " << trscore->index << " " << trscore->rotindex << endl;
						num_refpositives++;
					}
					//cout << trscore->index << " (" << v.x << "," << v.y << "," << v.z << ") (" << rf_invtr->translation->x
					//	<< "," << rf_invtr->translation->y << "," << rf_invtr->translation->z << ") " << dr2 << " " << trscore->particlep << endl;
				}
			}
			
			sort(&node_result[0], &node_result[0] + num_node_transforms, transscore_better);
			num_node_transforms=num_refpositives;
#else
			num_refpositives=num_node_transforms;			
#endif
			
			write_nodetransforms_tofile(invtr);
			pieces[0] = num_node_transforms;
			
			// match other rotations close to the reference rotation
			num_node_transforms=0;
			int num_neigh_positives=0;
			for(vector<int>::iterator itr = neighbor_rotationids.begin(); itr != neighbor_rotationids.end(); itr++){
				int rotationid = (int) *itr;
				match_rotation(rotationid);
				
				int num_positives=0,count=0;
#ifdef FILTER_POSITIVES_DURING_REFDOCK
				Transformation *rtr = new Transformation(rot_angles[rotationid][0],rot_angles[rotationid][1],rot_angles[rotationid][2],rotationid);
				for(int i = 0; i < num_node_transforms; i++){
					transformationscore *trscore = &(node_result[i]);
					if(trscore->rotindex == rotationid && trscore->particlep > -1000000.0){
						Transformation *tr = rtr;
						Vector v = get_translation(trscore, tr);
						//double df2 = Vector::distance_squared(&v,reference_tr->translation);
						double dr2 = Vector::distance_squared(v,*(rf_invtr->translation));
						if(dr2>=100){
							trscore->particlep = -100000.0;
						} else{
							//cout << "particlep " << trscore->particlep << " " << trscore->index << " " << trscore->rotindex << endl;
							num_positives++;
						}
					}
					if(trscore->particlep > -100000.0)	count++;
				}			
#endif
				num_neigh_positives += num_positives;
				sort(&node_result[0], &node_result[0] + num_node_transforms, transscore_better);
				*out << "rotation " << rotationid << " #positives " << num_positives << " " << count << endl;
			}
			pieces[1] = pieces[0];
			sprintf(command,"mv %s/%s/%d/trans0 %s/%s/%d/trans1",node_tmp_dir,refpdbcode.c_str(),procid,node_tmp_dir,refpdbcode.c_str(),procid);
			ret = system(command);
			cout << command << " " << ret << endl;
			
#ifdef FILTER_POSITIVES_DURING_REFDOCK			 
			num_node_transforms=num_neigh_positives;
#else
			num_neigh_positives = num_node_transforms;
#endif
			
			write_nodetransforms_tofile(NULL);
			pieces[0] = num_node_transforms;
			
			state = GENERATE_MATCHES;
			collect_transformations(true,num_refpositives+num_neigh_positives+1);//pieces[0]+pieces[1]);
		}
		
		if(start_state == FFT_SYMMETRIC_DIMER){
			state=FFT_GENERATE_MATCHES_EVATOMP;
			transscore_better = &transscore_bettersum;
			process_receptor();
			pieces.clear();
			read_rotations();
			
			//select symmetric rotations
			float **allrot_angles = rot_angles;
			rot_angles = (float**) malloc(sizeof(float*)*num_rotations);
			
		    int count = 0;
		    for(int i=0; i< num_rotations; i++){
				Transformation *rtr = new Transformation(allrot_angles[i][0],allrot_angles[i][1],allrot_angles[i][2],i);
				float trace = rtr->ex->x + rtr->ey->y + rtr->ez->z;
				float theta = acos((trace-1.0)/2.0);
				if(ABS(theta-PI) <= 0.10){
					//if(procid==0)	cout << i << " " << theta << endl;
					rot_angles[count] = allrot_angles[i];
					count++;
				}
				delete rtr;
		    }
		    num_rotations=count;
		    if(procid==0)	cout << "num symm rotations " << count << endl;
		    
		    symmetrictrimer=false;
    		generate_transformations(0,num_rotations);
    		
    		state = GENERATE_MATCHES;
			collect_transformations(true,max_transformations);
			if(procid == 0)	cout << "grid spacing used " << grid_spacing << endl;
		}
		
		if(start_state == FFT_SYMMETRIC_TRIMER){
			state=FFT_GENERATE_MATCHES_ATOMP;
			transscore_better = &transscore_bettersum;
			process_receptor();
			pieces.clear();
			state = GENERATE_MATCHES;
			read_rotations();
			
			//select symmetric rotations
			float **allrot_angles = rot_angles;
			rot_angles = (float**) malloc(sizeof(float*)*num_rotations);
			
		    int count = 0;
		    for(int i=0; i< num_rotations; i++){
				Transformation *rtr = new Transformation(allrot_angles[i][0],allrot_angles[i][1],allrot_angles[i][2],i);
				float trace = rtr->ex->x + rtr->ey->y + rtr->ez->z;
				float theta = acos((trace-1.0)/2.0);
				if(ABS(theta-2*PI/3) <= 0.10){
					//if(procid==0)	cout << i << " " << theta << endl;
					rot_angles[count] = allrot_angles[i];
					count++;
				}
				delete rtr;
		    }
		    num_rotations=count;
		    if(procid==0)	cout << "num symm rotations " << count << endl;
		    
		    symmetrictrimer=true;
    		generate_transformations(0,num_rotations);
			collect_transformations(true,max_transformations);
			if(procid == 0)	cout << "grid spacing used " << grid_spacing << endl;
		}
		
		// exploration
		if(start_state == 9999){
			fstream fexposedA, fburiedA, *pdbout;
			fexposedA.open("Aexposed.pdb", fstream::out);
			fburiedA.open("Aburied.pdb", fstream::out);
			for( int i = 0; i < cr->num_atoms; i++){
				Atom *a = cr->atom[i];
				Aminoacid *aa = cr->aminoacid[a->monocindex];
				if(a->is_buried)	pdbout=&fburiedA;
				else	pdbout=&fexposedA;
				if((a->name).size() <= 3){
					float coord[3];
					Vector v =*(a->position);
					coord[0] = v.x;
					coord[1] = v.y;
					coord[2] = v.z;
					int ci[3];
					char cf[3][7];
					for(int i=0;i<3;i++){
						ci[i] = (int) coord[i];
						float d = coord[i] - ci[i];
						sprintf(cf[i],"%6.3f",d);
					}
					
					char buf[80];
					sprintf(buf,"ATOM  %5d  %-3s %-4s%c%4s    %4d.%s%4d.%s%4d.%s  1.00  0.00",
					 (a->cindex)+1,(a->name).c_str(),(aa->name).c_str(),aa->chain,(aa->index).c_str(),
					 ci[0],&cf[0][3],ci[1],&cf[1][3],ci[2],&cf[2][3]); 
					*pdbout << buf << endl;
				}
			}
			fexposedA.close();
			fburiedA.close();
		}
		
		// convert selected transforms to correct notation
		if(start_state == 600){
			process_receptor();
			
			read_rotations();
			
		    // read selected transforms
		    char buf[8192];
		    fstream transin("selecttrans1");
		    fstream transout("transout",fstream::out);
		    int lineno=0;
		    while(transin.good()){
		    	transin.getline(buf,8192);
		    	if(transin.gcount() > 0){
		    		stringstream ss (stringstream::in | stringstream::out);
					ss << buf;
					unsigned int rotindex, tindex;
					float particlep, vdw;
					ss >> rotindex;
					ss >> particlep;ss >> vdw;
					ss >> tindex;
					
					Transformation *tr = new Transformation(rot_angles[rotindex][0],rot_angles[rotindex][1], rot_angles[rotindex][2],0);
					float x =tindex/(gridsize[1]*gridsize[2]);
					float y = ((tindex/gridsize[2]) % gridsize[1]);
					float z = (tindex % gridsize[2]);
					if(x > gridsize[0]/2)	x = gridsize[0] - 1 - x;
					if(y > gridsize[1]/2)	y = gridsize[0] - 1 - y;
					if(z > gridsize[2]/2)	z = gridsize[0] - 1 - z;
					*(tr->translation) = *(ligand->c->center) +tr->inverse_transform(*(ligand->grid_origin) - Vector(x,y,z)*grid_spacing - *(receptor->grid_origin) - *(receptor->c->center));
					Reference_Frame *rf_invtr = Reference_Frame::invert(tr);
					//delete tr;
					Transformation *invtr = new Transformation(rf_invtr->translation, rf_invtr->ex, rf_invtr->ey, 1.0, 0, lineno++);
					//delete rf_invtr;
					invtr->eVdw = vdw;
					invtr->votes = rotindex;
					invtr->eResiduepair = tindex;
					invtr->eElectrostatic = particlep;
					invtr->write_binary(&transout,TN_BASIC);
		    	}
		    }
		    transin.close();
		    transout.close();
		}
		
		MPI_Finalize();
		//outstream.close();
		
		if(procid == 0){
			time(&current_time);
			cout << "done" << " " << success << "\t time:" << difftime(current_time,start_time) << "s" << endl;
		}
		
		return 0;
	} else {
		cout << "init failed" << endl;
		return 1;
	}
}
