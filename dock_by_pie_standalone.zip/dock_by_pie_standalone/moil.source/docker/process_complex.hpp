/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "align_utilities.hpp"
#include <time.h>

const char* pdbcode;
string* chains;
int filetype;

ostream *out;

string* sequence;

hash_map<const char*, Sequence*, hash<const char*>, eqstr> matching_sequences, matching_sequences_in_pdb, sequences_with_struct_alignment;
	
hash_map<const char*, Molecule*, hash<const char*>, eqstr> homologues;

char **malignment;
const char ***malignment_indices;

