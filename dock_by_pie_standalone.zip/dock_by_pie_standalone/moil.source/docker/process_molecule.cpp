/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

//#include "molecule.hpp"
#include "process_molecule.hpp"

int representation;
Complex *cmplx;

extern string piedock_home;

/*
 * Using custom code for triangulating surface - also compute burial of atoms
 * When using MSMS for triangulating the surface, no information on burial of atoms
 */
void generate_surface(){
	switch(representation){
		case KMEANS: case DENSITY_CLUSTER:
			cmplx->compute_volume_sasa(false,false);
			cout << "SASA is " << cmplx->sa << " A^2." << endl;
			
			/*{
				cmplx->compute_surface();
				cmplx->eliminate_faces_in_holes();
				cmplx->triangulate_surface();	
				cout << "triangulated surface " << endl;
			
				vector<Triangle*> exposed_triangles;
				for(vector<Triangle*>::iterator titr = cmplx->triangles.begin(); titr != cmplx->triangles.end(); titr++){
					Triangle *t = *titr;
					if(!t->is_buried)
						exposed_triangles.push_back(t);
				}
				print_triangles(exposed_triangles, (char*) (string("triangles.wrl")).c_str(), VRML1);
			
				cmplx->compute_points(representation);
			}*/
			
			{
				Object *obj = new Object(cmplx,cmplx);
				obj->build_grid();
				cmplx->compute_points_msms(obj->grid_origin,obj->grid_num_xdivisions,obj->grid_num_ydivisions,obj->grid_num_zdivisions,obj->grid,representation);
				cout << "probe radius " << probe_radius <<  " sasa " << cmplx->sa << " #points " << cmplx->clusters.size() << endl;  
			}
			
			int num_buried=0;
			for(int i = 0; i < cmplx->num_atoms; i++){
				*out << cmplx->atom[i]->is_buried << " " << cmplx->atom[i]->sasa << endl; 
				cmplx->atom[i]->is_buried = (cmplx->atom[i]->sasa <= 0.1*PI*cmplx->atom[i]->radius*cmplx->atom[i]->radius) || cmplx->atom[i]->is_buried;
				if(cmplx->atom[i]->is_buried)	num_buried++;
			}
			cout << "#buried " << num_buried << endl;

			//print_triangles(cmplx->triangles, (char*) (string("triangles.wrl")).c_str(), VRML1);			
			//print_points(&(cmplx->clusters), (char*) (string("clusters.wrl")).c_str(),VRML1);
			
			//print surface atoms
			/*{
				unsigned int num_spheres=0;
				for(int i = 0; i < cmplx->num_atoms; i++)
					if(!cmplx->atom[i]->is_buried)	num_spheres++;
				float **sphere = (float**) malloc(sizeof(float*)*(num_spheres+1));
				for(int i = 0; i < num_spheres; i++)
					sphere[i] = (float*) malloc(sizeof(float)*4);
				int sphere_index=0;
				for(int i = 0; i < cmplx->num_atoms; i++){
					if(!cmplx->atom[i]->is_buried){
						sphere[sphere_index][0] = cmplx->atom[i]->position->x;
						sphere[sphere_index][1] = cmplx->atom[i]->position->y;
						sphere[sphere_index][2] = cmplx->atom[i]->position->z;
						sphere[sphere_index][3] = cmplx->atom[i]->radius;
						sphere_index++;
					}
				}
				print_spheres(sphere,num_spheres,(char*) (string("surfaceatoms.wrl")).c_str(),VRML1);
			}*/
		break;
	}
}

void output(){
	char filename[512];
	// output the details to a file
	fstream fout;
	sprintf(filename,"%s_%s.surface",pdbcode,chains->c_str());
	fout.open(filename,fstream::out);
	cmplx->print_details(&fout);
	fout.close();
}

/*
 * uses information from structures of homologues
 * 
 * have to use the residue numbering in the pdb file, not your own numbering
 */
void compute_constraints(char chain, int type){
	Protein *m = (Protein*) cmplx->molecules[chain];
	cout << "computing constraints" << endl;
	Aminoacid *m_aa[m->aminoacid.size()];
	int m_numaa = 0;
	for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator itr = m->aminoacid.begin(); itr != m->aminoacid.end(); itr++)
		m_aa[m_numaa++] = itr->second;
	hash_map<long, vector<float>, hash<long>, eqlong> distances; 	// index = i*maxatoms + j where i < j
	for(int i = 0 ; i < m_numaa; i++){ 
		Aminoacid* aa = m_aa[i];
		for(int j = i+1 ; j < m_numaa; j++){ 
			Aminoacid* aa2 = m_aa[j];
			long index = i*MAX_ATOMS + j;
			vector<float> aadistances = *(new vector<float>);
			aadistances.push_back(aa->distance(aa2));
			distances[index] = aadistances;
		}	
	}
	
	int seqsize = sequence->size();
	for(hash_map<const char*, Molecule*, hash<const char*>, eqstr>::iterator hitr = homologues.begin(); hitr != homologues.end(); hitr++){
		Protein* hm = (Protein*) (hitr->second);
		Sequence *s;
		switch(type){
			case SEQ_ALIGN:
				s = matching_sequences[hitr->first];
			break;
			case STRUCT_ALIGN:
				s = sequences_with_struct_alignment[hitr->first];
			break;
		}
		
		int mindex = s->malignment_index;
		cout << "mbegin" << endl; 
		if(mindex != -1){
			cout << mindex << " " << hm->pdbcode << "_" << hm->chain << " " << (hm == NULL) << " "; 
			cout << hm->aminoacid.size() << " ";
			bool have_all_centroids = true;
			for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = hm->aminoacid.begin(); aaitr != hm->aminoacid.end(); aaitr++){
				Aminoacid *aa = aaitr->second;
				if(aa->centroid == NULL)
					have_all_centroids = false;
				//cout << aaitr->first << "-" << "-" << (aa->atoms.size()) << "-" << (aa->centroid != NULL) << "|";
				//cout.flush();
			}
			cout << have_all_centroids << " ";
			if(have_all_centroids){
				cout << " constraints ";
				cout.flush();
				for(int i = 0 ; i < seqsize ; i++){
					const char* aaindex = malignment_indices[mindex][i];
					if(aaindex != NULL){
						Aminoacid* aa = hm->aminoacid[aaindex];
						for(int j = i+1 ; j < seqsize ; j++){
							const char* aaindex2 = malignment_indices[mindex][j];
							if(aaindex2 != NULL){
								Aminoacid* aa2 = hm->aminoacid[aaindex2];
								//cout << aa2->index << "-" << (aa2->centroid != NULL) << " ";
								//cout.flush();
								if(j-i == (atoi(aaindex2) - atoi(aaindex))){
									long index = i*MAX_ATOMS + j;
									distances[index].push_back(aa->distance(aa2));
								}
							}
						}
					}
				}
			}
			cout << endl;
		}
		cout << "mdone" << endl;
	}
	
	cout << "computed constraints" << endl;
	
	stringstream ss (stringstream::in | stringstream::out);
	string filename;
	ss << *pdbcode << "_" << chain << ".";
	/*switch(type){
		case SEQ_ALIGN:
			ss << "sequence";
		break;
		case STRUCT_ALIGN:
			ss << "struct";
		break;
	}*/
	ss << "constraints";
	ss >> filename;
	fstream fout(filename.c_str(), fstream::out);
	
	if(!fout.is_open()){
		cout << "Error opening file " << filename << endl;
		exit(1);
	}
	
	for(hash_map<long, vector<float>, hash<long>, eqlong>::iterator ditr = distances.begin(); ditr != distances.end(); ditr++){
		long index = ditr->first;
		int aa1 = index/MAX_ATOMS;
		int aa2 = index % MAX_ATOMS;
		vector<float> pair_distances = (vector<float>) ditr->second;
		
		// only adding restraints between residues close to each other on the chain (abs(aa2-aa1) != 1
		if(pair_distances.size() > 0){
			float sum = 0, mean, sum_squares = 0, sigma;
			for(vector<float>::iterator pditr = pair_distances.begin(); pditr != pair_distances.end(); pditr++){
				float d = *pditr;
				sum += d;
				sum_squares += d*d;
			}
			
			mean = sum/pair_distances.size();
			sigma = sqrt((sum_squares/pair_distances.size()) - mean*mean);
			if(mean <= 9.0){ //abs(aa2-aa1) <= 3
				fout <<  "R 3 1 1 9 2 2 1 "
					<< (aa1+1) << " " 
					<< (aa2+1) << " " << mean << " " << sigma << endl;
				cout << Vector::distance(m_aa[aa1]->centroid, m_aa[aa2]->centroid)
					<< " " << mean << " " << sigma << endl;
			}
		}
	}
	fout.close();		
}	

/*
void prepare_for_puth(){
	stringstream ss (stringstream::in | stringstream::out);
	ss << pdbcode << ".pdb";
	string filename;
	ss >> filename;
	fstream fout(filename.c_str(), fstream::out);
	*out << filename << " " << fout.is_open() << endl;
	  	
	ss.clear();
	ss << PDB_DIR << "/pdb" << pdbcode << ".ent";
	ss >> filename;
	fstream fin(filename.c_str(), fstream::in);
  	*out << filename << " " << fin.is_open() << endl;
	
	char buf[8192];
	string format;
	bool new_chain = true;
	while (!fin.eof()){
		fin.getline(buf,8192);
		stringstream ss(buf,stringstream::in);
		ss >> format;
		if(format == "ATOM" || format == "HETATM"){
			//*out << "|" << buf << endl;
			{
				stringstream line(buf,stringstream::in);
			    line >> format;
			    int position;
			    line >> position;
			}
		    string atom_name;
			{
				stringstream line(buf+13*sizeof(char),stringstream::in);
				line >> atom_name;
				

		    if(atom_name.length() > 3){
		    	string s = string(atom_name.c_str());
		    	atom_name = s.substr(0,3);
		    	amino_acid = s.substr(3,s.length());
		    } else
		    string amino_acid;
		    	*line >> amino_acid;
		    char chain = buf[21];
		    if(amino_acid.length() > 4){
		    	string s = string(atom_name.c_str());
		    	amino_acid = s.substr(0,4);
		    } else if(chain != ' ')
			    *line >> chain;
			string aaindex;
			*line >> aaindex;
						
			float x,y,z;
			*line >> x;
			*line >> y;
			*line >> z;
			if(new_chain){
				if(amino_acid != "NTER"){
					fout << "ATOM      0  HX2 NTER"  << "   0    9999.9999999.9999999.999  1.00 00.00" << endl;
				}
				if(atom_name == "OXT"){
					
				} else {
					fout << "ATOM      0  OX2 CTER";
				}
				new_chain = false;
			} else {
				if(amino_acid.find("GLN") != string::npos){
					if(atom_name == "AE1")
						atom_name = "OE1"
					else if(atom_name == "AE2")
						atom_name = "NE2";
				} else if(amino_acid.find("ASN") != string::npos){
					if(atom_name == "AE1")
						atom_name = "OD1"
					else if(atom_name == "AE2")
						atom_name = "ND2";
				} else if(amino_acid.find("HOH") != string::npos){
					amino_acid = "TIP3";
					if(atom_name == "O")
						atom_name = "OH2"
					else if(atom_name == "AE2")
						atom_name = "NE2";
				}
			}
		} else if(format != "TER" && format != "CONNECT"){
			fout << buf << endl;
		}
	}
}*/

void getsstructure(){
	stringstream ss (stringstream::in | stringstream::out);
	string filename;
	ss << pdbcode << ".pdb";
	ss >> filename;
	fstream fin(filename.c_str(), fstream::in);
	if(!fin.is_open()){
		ss.clear();
		ss << piedock_home << "/" << PDB_DIR << "/pdb" << pdbcode << ".ent";
		ss >> filename;
	} else
		fin.close();
	// select chains
	ss.clear();
	ss << pdbcode << "_" << *chains << "." << "pdb";
	string scoutfile; ss >> scoutfile;
	char command[8192];
	sprintf(command,"%s/%s %s %s > %s",piedock_home,string(SELECT_CHAIN).c_str(), chains->c_str(), filename.c_str(), scoutfile.c_str());
	*out << command << " "; out->flush();
	int ret = system(command);
	*out << ret << endl; out->flush();

	ss.clear();
	ss << pdbcode << "_" << *chains << "." << "dssp";
	string dsspoutfile; ss >> dsspoutfile;
	sprintf(command,"%s/%s %s %s",piedock_home,string(DSSP_EXECUTABLE).c_str(), scoutfile.c_str(), dsspoutfile.c_str());
	*out << command << " "; out->flush();
	ret = system(command);
	*out << command << " " << ret << endl; out->flush();
	
	fstream dsspin(dsspoutfile.c_str(), fstream::in);
	char buf[8192];
	do {
		dsspin.getline(buf,8192);
	} while (((string(buf)).find("STRUCTURE") == string::npos) && !dsspin.eof());
	while(!dsspin.eof()){
		dsspin.getline(buf,8192);
		char chain = buf[11];
		if(*chains == "-")
			chain = '-';
		if((chains->find(chain) != string::npos) && (buf[13] != '!')){
			string aacid_index;
			{
				stringstream line(buf+5,stringstream::in);
				line >> aacid_index;
			}
			if(buf[10] != ' '){
				//*out << aacid_index << " " << aacid_index.find(buf[10]) << endl;
				aacid_index = aacid_index.substr(0,aacid_index.find(buf[10])+1);
			}
			char sstructure = buf[16];
			((Protein*) cmplx->molecules[chain])->aminoacid[aacid_index.c_str()]->sstructure = sstructure;
			//*out << aacid_index << " " << sstructure << endl;
		}
	}
	dsspin.close();
}

/*
 * Preprocess the molecule
 * Compute the representation of the molecule
 */
int main(int argc, char *argv[]){
	out = &cout;
	read_molecule_config();
	read_dock_config();
	
	filetype = atoi(argv[1]);
	representation = atoi(argv[2]);
	pdbcode = argv[3];
	chains = new string(argv[4]);
	int num_chains = chains->length();	
	cout << "pdbcode " << pdbcode << " chains " << *chains << " # " << num_chains << endl; cout.flush();
	
	cmplx = new Complex(argv[3], argv[4], filetype);
	
	if(filetype != PROCESSED){
		getsstructure();
		generate_surface();

		string *seq[num_chains];
		stringstream ss (stringstream::in | stringstream::out);
		int poly_num_aacids = 0;
		// added false since compute_aasequence was crashing, to fix
		for(int i = 0; false && i < num_chains; i++){
			char chain = argv[4][i];
			Protein *m = (Protein*) cmplx->molecules[chain];
			seq[i] = sequence = new string((m->compute_aasequence()).c_str());
			poly_num_aacids += (sequence->size() + 2);
			
			ss.clear();
			ss << pdbcode << "_" << m->chain << "." << "seq";
			string filename; ss >> filename;
			fstream fout(filename.c_str(), fstream::out);
			fout << *sequence;
			fout.close();
			
			{
				stringstream ss (stringstream::in | stringstream::out);
				ss << piedock_home << "/blast/runblast.sh " << pdbcode << "_" << m->chain << " > " << pdbcode << "_" << chain << ".blastout";
				char buf[2048];
				ss.getline(buf,2048);
				int ret;// = system(buf);
				*out << buf << " " << ret << endl;
			}
			//read_profile(m);
		}
		
		output();
	}
	
	/*for(int i = 0; i < num_chains; i++){
		char chain = argv[4][i];		
		/*read_blast_hits(chain);
		//pairwise_struct_align(TM,chain);
		read_molecules(SEQ_ALIGN);
		multiple_align(SEQ_ALIGN,chain);
		//multiple_align(STRUCT_ALIGN,chain);
		//compute_constraints(SEQ_ALIGN,chain);*
	}*/
	
	/*ss.clear();
	ss << pdbcode << "_" << *chains << "." << "poly";
	ss >> filename;
	fstream polyout(filename.c_str(), fstream::out);
	*out << filename << " " << polyout.is_open() << endl;
	polyout << "MOLC=(" << pdbcode << ") #mon=" << poly_num_aacids;
	int count = 0;
	for(int i = 0; i < num_chains; i++){
		if(count++ % 10 == 0) polyout << endl;
		polyout << "NTER ";
		sequence = seq[i];
		const char* sc = sequence->c_str();
		for(int j = 0 ; j < sequence->size(); j++){
			if(count++ % 10 == 0) polyout << endl;
			polyout << get_aaname(sc[j]) << " ";
		}
		if(count++ % 10 == 0) polyout << endl;
		polyout << "CTER ";
	}
	if(count % 10 != 1) polyout << endl;
	polyout << "*EOD" << endl;
	polyout.close();*/
	
	cout << "done" << endl;
	return 0;
}
