/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * This code is for verfication purposes only not for distribution    */

#include "object.hpp"

#define HASH_MIN_NORMAL_COARSE_NORMAL_DOT 0.4
#define HASH_MIN_DISTANCE 2 
#define HASH_MAX_DISTANCE 8 
#define HASH_MIN_NORMAL_DOT 0.7 //0
#define HASH_MIN_TORSION 0.3 //0.5

#define HASH_TARGET_MIN_NORMAL_COARSE_NORMAL_DOT 0.3
#define HASH_TARGET_MAX_DISTANCE 10 // 18
#define HASH_TARGET_MIN_NORMAL_DOT 0.2 // 0.5

Reference_Frame_Point_Tuple::Reference_Frame_Point_Tuple(Reference_Frame*rf,int point){
	this->rf = rf;
	point_index = point;
};

Reference_Frame_Point_Tuple_List::Reference_Frame_Point_Tuple_List(){
	rflist.clear();
}

//prune reference frames - check if the pair of points satisfy certain constraints so that the reference frame defined is stable
bool Object::can_build_reference_frame(int pi, int qi){
	Vector *p = face[pi]->point, *pn = face[pi]->coarser_normal,*q = face[qi]->point, *qn = face[qi]->coarser_normal;
	bool conditions_satisfied = true;
	
	// stable normal constraint
	if(face[pi]->normal->dot(face[pi]->coarser_normal) < HASH_MIN_NORMAL_COARSE_NORMAL_DOT ||
	  face[qi]->normal->dot(face[qi]->coarser_normal) < HASH_MIN_NORMAL_COARSE_NORMAL_DOT)
	 	conditions_satisfied = false;
	 	
	//distance constraint
	float distance = Vector::distance(p,q);
	if( distance < HASH_MIN_DISTANCE || distance > HASH_MAX_DISTANCE )
		conditions_satisfied = false;

	/*/ similar curvature constraint
	if(face[pi]->curvature * face[qi]->curvature <= 0)
		conditions_satisfied = false;*/
		
	//angle between normals
	if( pn->dot(*qn) < HASH_MIN_NORMAL_DOT)
		conditions_satisfied = false;
	
	/*/torsion angle
	Vector vp = p->cross(*pn);
	vp.normalize();
	Vector vq = q->cross(*qn);
	vq.normalize();
	if(vp.dot(vq) < HASH_MIN_TORSION)
		conditions_satisfied = false;*/

	//angle between each normal and the vector ab
	float d_pq_pn = (*q - *p).dot(*pn)/((*q - *p).norm() * pn->norm());
	if(d_pq_pn > 0.7 || d_pq_pn < -0.7)	conditions_satisfied = false;
	float d_qp_qn = (*p - *q).dot(*qn)/((*q - *p).norm() * qn->norm());
	if(d_qp_qn > 0.7 || d_qp_qn < -0.7)	conditions_satisfied = false;

	return conditions_satisfied;
}

bool Object::can_process_point(int pi, int qi, int ri){
	bool conditions_satisfied = true;
	if(pi != ri && qi != ri){
		Vector *p = face[pi]->point, *q = face[qi]->point, *r = face[ri]->point;
		if( Vector::distance(p,r) >= HASH_TARGET_MAX_DISTANCE || Vector::distance(q,r) >= HASH_TARGET_MAX_DISTANCE)
			conditions_satisfied = false;

		/*Vector *pn = face[pi]->coarser_normal, *qn = face[qi]->coarser_normal, *rn = face[ri]->coarser_normal;
		// stable normal constraint -- assume that condition checked for p and q
		// for small ligands and loop regions, there are holes in surface and the normal is not stable
		if(face[ri]->normal->dot(face[ri]->coarser_normal) < HASH_TARGET_MIN_NORMAL_COARSE_NORMAL_DOT)
		 	conditions_satisfied = false;
		 	
		if( pn->dot(*rn) < HASH_TARGET_MIN_NORMAL_DOT
		 || qn->dot(*rn) < HASH_TARGET_MIN_NORMAL_DOT)
		 	conditions_satisfied = false;*/
	}
		 	
	return conditions_satisfied;
}

Hash_Table::Hash_Table(float extent){
	this->extent = extent;
	maxindex = ((int) ceil(extent/INCREMENT)) + 2;
	//cout << extent << " " << maxindex << endl; cout.flush();
	lists = (Reference_Frame_Point_Tuple_List **) malloc(sizeof(Reference_Frame_Point_Tuple_List*)*8*maxindex*maxindex*maxindex);
	for(unsigned int i = 0; i < 8*maxindex*maxindex*maxindex; i++)
		lists[i] = NULL;
}

void Hash_Table::insert(Vector *p, int pindex, Reference_Frame *rf){
	Vector v = rf->transform(*p);
	float vx = v.x, vy = v.y, vz = v.z;
	if((vx + extent > 0) && (vx < extent) && (vy + extent > 0) && (vy < extent) && (vz + extent > 0) && (vz < extent)){
		unsigned int index = (unsigned int) (vx/INCREMENT + maxindex);
		index = index*2*maxindex + (unsigned int) (vy/INCREMENT + maxindex);
		index = index*2*maxindex + (unsigned int) (vz/INCREMENT + maxindex);
		
		//cout << vx << " " << vy << " " << vz << " " << maxindex << " " << index << endl; cout.flush();
		if(lists[index] == NULL)
			lists[index] = new Reference_Frame_Point_Tuple_List();
		(lists[index]->rflist).push_back(new Reference_Frame_Point_Tuple(rf,pindex));
	} else {
		*out << "ERROR - failed to insert (" << vx << "," << vy << "," << vz << ") point "
			<< p->x << " " << p->y << " " << p->z << endl; out->flush();
	}
}

/*
 * updates votes for matching frame
 */
void Hash_Table::retrieve(Face *f, Reference_Frame *rf, Face **lface, unsigned short *match_size){
	unsigned int base_index, index;
	Vector v = rf->transform(*(f->point));
	Vector vn = Vector(((Cluster*)f)->coarser_normal->dot(rf->ex),((Cluster*)f)->coarser_normal->dot(rf->ey),((Cluster*)f)->coarser_normal->dot(rf->ez));
	//vn.normalize();
	float vx = v.x, vy = v.y, vz = v.z;
	if((vx + extent > 0) && (vx < extent) && (vy + extent > 0) && (vy < extent) && (vz + extent > 0) && (vz < extent)){
		base_index = (unsigned int) (vx/INCREMENT + maxindex);
		base_index = base_index*2*maxindex + (unsigned int) (vy/INCREMENT + maxindex);
		base_index = base_index*2*maxindex + (unsigned int) (vz/INCREMENT + maxindex);

		list<Reference_Frame_Point_Tuple*> matching_reference_frames;
		int llx, ulx, lly, uly, llz, ulz;
		llx = minimum( (int) ((vx + extent)/INCREMENT), NUM_ADJACENT_CELLS_EXAMINED);
		llx = 0 - llx;
		ulx = minimum( (int) ((extent - vx)/INCREMENT), NUM_ADJACENT_CELLS_EXAMINED);
		for(int i = llx; i <= ulx; i++){
			lly = minimum( (int) ((vy + extent)/INCREMENT), NUM_ADJACENT_CELLS_EXAMINED);
			lly = 0 - lly;
			uly = minimum( (int) ((extent - vy)/INCREMENT), NUM_ADJACENT_CELLS_EXAMINED);
			for(int j = lly; j <= uly; j++){
				llz = minimum( (int) ((vz + extent)/INCREMENT), NUM_ADJACENT_CELLS_EXAMINED);
				llz = 0 - llz;
				ulz = minimum( (int) ((extent - vz)/INCREMENT), NUM_ADJACENT_CELLS_EXAMINED);
				for(int k = llz; k <= ulz; k++){
					index = i*2*maxindex;
					index = (index + j)*2*maxindex;
					index = index + k;
					index = base_index + index;

					if(lists[index] != NULL){
						matching_reference_frames = lists[index]->rflist;
						for(list<Reference_Frame_Point_Tuple*>::iterator itr = matching_reference_frames.begin(); itr != matching_reference_frames.end(); itr++){
							Reference_Frame_Point_Tuple* rpt = *itr;
							Reference_Frame *ref_frame = rpt->rf;
							// check if the points are close
							Vector w = ref_frame->transform(*(lface[rpt->point_index]->point));
							
							// update votes - match points as well as normals -- the normals are not in the same reference frame
							/*float dot = 0 - face[rindex]->coarser_normal->dot(n);
							//*out << current_votes << " " << dot << endl; out->flush();						
							if(//face[rindex]->normal->dot(face[rindex]->coarser_normal) < HASH_MIN_NORMAL_COARSE_NORMAL_DOT || ligand->face[lindex]->normal->dot(ligand->face[lindex]->coarser_normal) < HASH_MIN_NORMAL_COARSE_NORMAL_DOT
								//&&(dot > MIN_NORMAL_DOT && face[rindex]->curvature * ligand->face[lindex]->curvature <= 0 
								//&& face[rindex]->area*c1 + ligand->face[lindex]->area*c2 >= 6.0
								(trv - *(face[rindex])).dot(face[index]->coarse_normal) > 0
							  )){
								current_votes++;
							}*/
							
							if(Vector::distance(v,w)< MAX_MATCH_DISTANCE
								//&& (w-v).dot(vn) > 0
							){
								unsigned int frame_number = (unsigned int) ref_frame->frame_number;
								(match_size[frame_number])++;
							}
						}
					}
				}
			}
		}
	}
}

/*
 * Compute domain and range for matches
 */
void Hash_Table::retrieve(Face *f, int rindex, Reference_Frame *rf, Face **lface, unsigned int **match_domain, unsigned int **match_range){
	unsigned int base_index, index;
	Vector v = rf->transform(*(f->point));
	Vector vn = Vector(((Cluster*)f)->coarser_normal->dot(rf->ex),((Cluster*)f)->coarser_normal->dot(rf->ey),((Cluster*)f)->coarser_normal->dot(rf->ez));
	//vn.normalize();
	float vx = v.x, vy = v.y, vz = v.z;
	if((vx + extent > 0) && (vx < extent) && (vy + extent > 0) && (vy < extent) && (vz + extent > 0) && (vz < extent)){
		base_index = (unsigned int) (vx/INCREMENT + maxindex);
		base_index = base_index*2*maxindex + (unsigned int) (vy/INCREMENT + maxindex);
		base_index = base_index*2*maxindex + (unsigned int) (vz/INCREMENT + maxindex);

		list<Reference_Frame_Point_Tuple*> matching_reference_frames;
		int llx, ulx, lly, uly, llz, ulz;
		llx = minimum( (int) ((vx + extent)/INCREMENT), NUM_ADJACENT_CELLS_EXAMINED);
		llx = 0 - llx;
		ulx = minimum( (int) ((extent - vx)/INCREMENT), NUM_ADJACENT_CELLS_EXAMINED);
		for(int i = llx; i <= ulx; i++){
			lly = minimum( (int) ((vy + extent)/INCREMENT), NUM_ADJACENT_CELLS_EXAMINED);
			lly = 0 - lly;
			uly = minimum( (int) ((extent - vy)/INCREMENT), NUM_ADJACENT_CELLS_EXAMINED);
			for(int j = lly; j <= uly; j++){
				llz = minimum( (int) ((vz + extent)/INCREMENT), NUM_ADJACENT_CELLS_EXAMINED);
				llz = 0 - llz;
				ulz = minimum( (int) ((extent - vz)/INCREMENT), NUM_ADJACENT_CELLS_EXAMINED);
				for(int k = llz; k <= ulz; k++){
					index = i*2*maxindex;
					index = (index + j)*2*maxindex;
					index = index + k;
					index = base_index + index;

					if(lists[index] != NULL){
						matching_reference_frames = lists[index]->rflist;
						for(list<Reference_Frame_Point_Tuple*>::iterator itr = matching_reference_frames.begin(); itr != matching_reference_frames.end(); itr++){
							Reference_Frame_Point_Tuple* rpt = *itr;
							Reference_Frame *ref_frame = rpt->rf;
							// check if the points are close
							Vector w = ref_frame->transform(*(lface[rpt->point_index]->point));
							
							// update votes - match points as well as normals -- the normals are not in the same reference frame
							/*float dot = 0 - face[rindex]->coarser_normal->dot(n);
							//*out << current_votes << " " << dot << endl; out->flush();						
							if(//face[rindex]->normal->dot(face[rindex]->coarser_normal) < HASH_MIN_NORMAL_COARSE_NORMAL_DOT || ligand->face[lindex]->normal->dot(ligand->face[lindex]->coarser_normal) < HASH_MIN_NORMAL_COARSE_NORMAL_DOT
								//&&(dot > MIN_NORMAL_DOT && face[rindex]->curvature * ligand->face[lindex]->curvature <= 0 
								//&& face[rindex]->area*c1 + ligand->face[lindex]->area*c2 >= 6.0
								(trv - *(face[rindex])).dot(face[index]->coarse_normal) > 0
							  )){
								current_votes++;
							}*/
							
							if(Vector::distance(v,w)< MAX_MATCH_DISTANCE
								//&& (w-v).dot(vn) > 0
							){
								unsigned int frame_number = (unsigned int) ref_frame->frame_number;
								match_range[frame_number][rpt->point_index/(sizeof(unsigned int)*8)] |= (0x1u<<((rpt->point_index)%(sizeof(unsigned int)*8)));
								match_domain[frame_number][rindex/(sizeof(unsigned int)*8)] |= (0x1u<<((rindex)%(sizeof(unsigned int)*8)));
								//cout << frame_number << " " << rindex/(sizeof(unsigned int)*8) << "\t"; cout.flush();
								//cout << match_domain[frame_number][rindex/(sizeof(unsigned int)*8)] << endl; cout.flush();
								//*out << frame_number << " retrieved " << (*result)[frame_number].size() << " points " << endl; out->flush();
							}
						}
					}
				}
			}
		}
	}
}

vector<Reference_Frame*> Object::build_reference_frames(int pi, int qi, bool isligand){
	vector<Reference_Frame*> frames;
	float scale = 1.0;
	Vector t[3], v1[2], v2[6];
	t[0] = Vector(face[pi]->point);
	t[1] = Vector(face[qi]->point);
	t[2] = (*(face[pi]->point) + *(face[qi]->point))*0.5;
	
	v1[0] = *(face[qi]->point) - *(face[pi]->point);
	v1[1] = *(face[pi]->point) - *(face[qi]->point);
	for(int i1 = 0; i1 < 2; i1++)
		v1[i1].normalize();
		
	v2[0] = Vector(face[pi]->coarser_normal);
	v2[1] = Vector(face[qi]->coarser_normal);
	v2[2] = (*(face[pi]->coarser_normal) + *(face[qi]->coarser_normal)) * 0.5;
	v2[3] = Vector(face[pi]->normal);
	v2[4] = Vector(face[qi]->normal);
	v2[5] = (*(face[pi]->normal) + *(face[qi]->normal)) * 0.5;
	for(int i2 = 0; i2 < 6; i2++){
		v2[i2].normalize();
		// normals point out of the surface, curvature takes care of convex vs concave, normal points out for receptor, inward for ligand
		if(isligand)	v2[i2] = Vector(0,0,0) - v2[i2];
	}
		
	for(int i1 = 0; (isligand && i1 < 1) || (!isligand && i1 < 2); i1++){
		Vector *ex = new Vector(v1[i1]);
		for(int i2 = 0; i2 < 6; i2++){
			//if(i2%3 != (1-i1)){
			if(i2 == 2){
				Vector v3 = v1[i1].cross(v2[i2]);
				v3.normalize();
				Vector *ey = new Vector(v3);
		
				Reference_Frame *rf = new Reference_Frame(new Vector(t[i2%3]), ex, ey, scale, 0);
				frames.push_back(rf);
			}
		}
	}
	return frames;
}

/*
 * Building hash table mostly for convex regions
 */
void Object::build_hash_table(){
	*out << "building hash table " << c->diameter << endl; out->flush();
	
	hash_table = new Hash_Table(c->diameter);
	int num_points=0;
	long reference_frame_index = 0;
	for(int i = 0 ; i < num_faces; i++){
		for(int j = i+1 ; j < num_faces; j++){
			if(can_build_reference_frame(i,j)){
				vector<Reference_Frame*> frames = build_reference_frames(i,j,true);
				for(vector<Reference_Frame*>::iterator fitr = frames.begin(); fitr != frames.end(); fitr++){
					Reference_Frame *rf = *fitr;
					rf->frame_number = reference_frame_index++;
					reference_frame[rf->frame_number] = rf;
	
					for(int k = 0 ; k < num_faces; k++){
						if(can_process_point(i,j,k)){
							hash_table->insert(face[k]->point , k, rf);
							num_points++;
						}
					}
				}
			}
		}
	}
	
	num_frames = reference_frame_index;

	*out << "# frames " << num_frames << endl;
	*out << "# points " << num_points << endl;

}



/*
 * this object is matched(docked) against the object ligand, object ligand has its hash table ready
 * atom indexing starts at 0
 * 	mostly looking for matches for pits on the receptor
*/
void Object::match_surfaces(Object* ligand, int i_start, int i_end, vector<Transformation*> *mframes, bool filter_on_fly, long *generation_stats){
	long reference_frame_index = 0;
	long num_matches_generated = 0;
	long num_matches_with_votes = 0;
	int num_matches_filtered0 = 0;
	int num_matches_filtered1 = 0;
	int num_matches_filtered2 = 0;
	int num_matches_filtered3 = 0;

	long total_vote_count[2*num_faces+1];
	for(int i = 0 ; i <= 2*num_faces; i++)
		total_vote_count[i] = 0;
	int max_votes = 0;

	int vote_cutoff = MIN_VOTES(num_faces, ligand->num_faces);
	*out << "start " << i_start << " end " << i_end << " vote cutoff " << vote_cutoff << endl;
	
	unsigned short rnfacemasks = num_faces/(sizeof(unsigned int)*8);
	if(num_faces % (sizeof(unsigned int)*8) != 0)	rnfacemasks++;
	unsigned short lnfacemasks = ligand->num_faces/(sizeof(unsigned int)*8);
	if(ligand->num_faces % (sizeof(unsigned int)*8) != 0)	lnfacemasks++;
	*out << num_faces << " rnfacemasks " << rnfacemasks << " " <<  ligand->num_faces << " lnfacemasks " << lnfacemasks << endl;
	
	if(match_size == NULL){
		match_size = (unsigned short*) malloc(sizeof(unsigned short)*ligand->num_frames);
		for(int fri = 0 ; fri < ligand->num_frames; fri++)	match_size[fri]=0;
	}
	
	/*if(match_domain == NULL){
		match_domain = (unsigned int **) malloc(sizeof(unsigned int *) * ligand->num_frames);
		for(int fri = 0 ; fri < ligand->num_frames; fri++){
			match_domain[fri] = (unsigned int *) malloc(sizeof(unsigned int)*rnfacemasks);
			for(int m=0; m < rnfacemasks; m++)	match_domain[fri][m]=0;
		}
	}
		
	if(match_range == NULL){	
		match_range = (unsigned int **) malloc(sizeof(unsigned int *) * ligand->num_frames);
		for(int fri = 0 ; fri < ligand->num_frames; fri++){
			match_range[fri] = (unsigned int *) malloc(sizeof(unsigned int)*lnfacemasks);
			for(int m=0; m < lnfacemasks; m++)	match_range[fri][m]=0;
		}
	}*/
	
	unsigned short bits_in_bytes[256];
	for(unsigned short i = 0; i < 256; i++){
		unsigned short count=0, n=i;    
		while (n) {
			count += n & 0x1u ;
			n >>= 1 ;
		}
		bits_in_bytes[i] = count;
		//*out << i << " "<< count << endl;
	}
	*out << "start matching" << endl; out->flush();
					
	for(int i = i_start ; i < i_end; i++){
		for(int j = i+1 ; j < num_faces; j++){
			if(can_build_reference_frame(i,j)){
				//*out << i << " " << j << "\t";out->flush();
				vector<Reference_Frame*> frames = build_reference_frames(i,j,false);
				for(vector<Reference_Frame*>::iterator fitr = frames.begin(); fitr != frames.end(); fitr++){
					Reference_Frame *rf = *fitr;
					rf->frame_number = reference_frame_index++;
					reference_frame[rf->frame_number] = rf;
					
					for(int k = 0 ; k < num_faces; k++){
						if(can_process_point(i,j,k)){
							(ligand->hash_table)->retrieve(face[k],rf,(Face**) ligand->face, match_size);
							//(ligand->hash_table)->retrieve(face[k],k,rf,(Face**) ligand->face, match_domain, match_range);
						}
					}
					//*out << "retrieved\t";
					for(int fi = 0 ; fi < ligand->num_frames; fi++){
						float current_votes = 0;
						// assume sizeof(unsigned int) = 4
						/*for(int m = 0; m < rnfacemasks; m++){
							current_votes += (bits_in_bytes[match_domain[fi][m]&0x000000ff]+bits_in_bytes[match_domain[fi][m]>>8&0x000000ff]
								+bits_in_bytes[match_domain[fi][m]>>16&0x000000ff]+bits_in_bytes[match_domain[fi][m]>>24&0x000000ff]);
							match_domain[fi][m]=0;
						}
						for(int m = 0; m < lnfacemasks; m++){
							current_votes += (bits_in_bytes[match_range[fi][m]&0x000000ff]+bits_in_bytes[match_range[fi][m]>>8&0x000000ff]
								+bits_in_bytes[match_range[fi][m]>>16&0x000000ff]+bits_in_bytes[match_range[fi][m]>>24&0x000000ff]);
							match_range[fi][m]=0;
						}
						current_votes /= 2;*/
						current_votes = match_size[fi];
						match_size[fi] = 0;
						
						//*out << rf << " " << fi << " " << current_votes << endl; out->flush();
						num_matches_generated++;
						if(current_votes >= vote_cutoff){
							num_matches_with_votes++;
							if(num_matches_with_votes % 1000 == 0)	*out << num_matches_with_votes << " " << i << " " << j << "\t"; out->flush();
							
							Reference_Frame *receptor_rf = rf;
							Reference_Frame *ligand_rf = ligand->reference_frame[fi];
							Transformation *tr = generate_transformation(this,receptor_rf,ligand,ligand_rf, current_votes);
							
							bool passed=true;
							if(filter_on_fly){
								//*out << "0 "; out->flush();
								passed = filter1(ligand,tr);
								//*out << "1 "; out->flush();
								if(passed){
									num_matches_filtered1++;
									//passed = filter2(ligand,tr);
									//*out << "2 "; out->flush();
									if(passed){
										num_matches_filtered2++;
										//*out << "3 "; out->flush();
										//filter3(ligand,tr);
									}
								}
							}
							if(!filter_on_fly || (filter_on_fly && passed)){
								num_matches_filtered3++;
								//tr->compute_references();
								//compute_electrostatic_energy_approx1(this,ligand,tr);
								mframes->push_back(tr);
							} else
								delete tr;
						}
					}
					delete rf;	
				}
			}
		}
		*out << endl;
		*out << i << " #matches generated " << num_matches_generated << " #matches with votes " << num_matches_with_votes << " #matches filtered0 " << num_matches_filtered0 <<
		" #matches filtered1 " << num_matches_filtered1 << " #matches_filtered2 " << num_matches_filtered2 << " #matches_filtered3 " << num_matches_filtered3 << endl;
		out->flush();
		generation_stats[0] += num_matches_generated;
		generation_stats[1] += num_matches_with_votes;
		generation_stats[2] += num_matches_filtered0;
		generation_stats[3] += num_matches_filtered1;
		generation_stats[4] += num_matches_filtered2;
		generation_stats[5] += num_matches_filtered3;
	}
}

/*
 * Match the parts of the surface that are part of the interface
 */
void Object::match_surfaces_at_interface(Object* o, vector<Transformation*> *){
	
}
