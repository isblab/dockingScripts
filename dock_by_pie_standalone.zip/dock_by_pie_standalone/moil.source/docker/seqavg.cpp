/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"

extern char scratch_dir[512];
extern int num_species;
extern Species **species;

void pair_sequences_by_species(){
	// get Biogrid id for each sequence
	hash_map<long , long , hash<long> , eqlong> rec_biogrid_id, lig_biogrid_id;
	char command[5024], buf[8192];
	int max_sequences = 10000;
	for(int i = 0; i < num_species; i++){
		Species *sp = species[i];
		if(sp->num_sequences[0] == 1 && sp->num_sequences[1] == 1){
		} else {
			for(int ci=0; ci<2; ci++){
				for(int si=0; si < sp->num_sequences[ci]; si++){
					Sequence *seq = sp->sequences[ci][si];
					string tag = seq->id;
					if(seq->id.find(".") != string::npos)
						tag = seq->id.substr(0,seq->id.length()-2);
					sprintf(command, "grep -i %s  /share/work/ravid/biogrid/split_identifiers/%s | awk '{ if(tolower($2)==tolower(\"%s\")) print }' > %s/biogrid_id",tag,seq->id_lowercase.substr(0,2),tag,scratch_dir);
					int ret = system(command);
					if(ret > 0)	
						cout << ret << " " << string(command) << endl;
					char filename[512];
					sprintf(filename,"%s/biogrid_id",scratch_dir);
					fstream idin(filename, ios::in);
					while (!idin.eof()){
						idin.getline(buf,8192);
						//cout << string(buf) << endl;
						if(idin.gcount() > 0){
							stringstream line(buf,stringstream::in);
							string s;
							line >> s;
							long biogrid_id = atol(s.c_str());
							long index = i*10000 + si;
							cout << index << " " << biogrid_id << endl;
							if(ci==0)
								rec_biogrid_id[index] = biogrid_id;
							else
								lig_biogrid_id[index] = biogrid_id;
							break;
						}
					}
					idin.close();
				}
			}
		}
	}
	
	// get pair annotations for each pair of biogrid ids
	hash_set<long, hash<long>, eqlong> to_check_biogrid_pairs;
	int max_biogrid_id = 1024*1024*128;
	for(int i = 0; i < num_species; i++){
		Species *sp = species[i];
		/*if(sp->num_sequences[0] > 1 || sp->num_sequences[1] > 1)*/{
			for(int si=0; si < sp->num_sequences[0]; si++){
				long siindex = i*10000 + si;
				if(rec_biogrid_id.count(siindex) > 0)
					for(int sj=0; sj < sp->num_sequences[1]; sj++){
						long sjindex = i*10000 + sj;
						if(lig_biogrid_id.count(sjindex) > 0){
							to_check_biogrid_pairs.insert(rec_biogrid_id[siindex] * max_biogrid_id + lig_biogrid_id[sjindex]);
						}
					}
			}
		}
	}
	hash_set<long, hash<long>, eqlong> biogrid_pairs;
	for(hash_set<long, hash<long>, eqlong>::iterator itr = to_check_biogrid_pairs.begin(); itr != to_check_biogrid_pairs.end(); itr++){
		long index = *itr;
		int rec_bindex = index / max_biogrid_id;
		int lig_bindex = index % max_biogrid_id;
		
		bool interact = false;
		char filename[512];
		sprintf(filename,"%s/%d.names",scratch_dir,rec_bindex);
		fstream rfin(filename, ios::in);
		if(!rfin.good()){
			int rstart = (int) rec_bindex/100000;
			sprintf(command,"cat /share/work/ravid/biogrid/split_biogridid/%d00k_to_%d00k | awk '{ if($1==\"%ld\" && $2!=\"%ld\") print }' > %s/%d.names",
				 rstart, rstart+1 , rec_bindex, rec_bindex, scratch_dir, rec_bindex);
			int ret = system(command);
			if(ret > 0)	
				cout << ret << " " << string(command) << endl;
		}
		rfin.close();
		
		sprintf(filename,"%s/%d.names",scratch_dir,lig_bindex);
		fstream lfin(filename, ios::in);
		if(!lfin.good()){
			int lstart = (int) lig_bindex/100000;
			sprintf(command,"cat /share/work/ravid/biogrid/split_biogridid/%d00k_to_%d00k | awk '{ if($1==\"%ld\" && $2!=\"%ld\") print }' > %s/%d.names",
				 lstart, lstart+1 , lig_bindex, lig_bindex, scratch_dir, lig_bindex);
			int ret = system(command);
			if(ret > 0)	
				cout << ret << " " << string(command) << endl;
		}
		lfin.close();
		
		sprintf(filename,"%s/%d.interactions",scratch_dir,rec_bindex);
		fstream rifin(filename, ios::in);
		if(!rifin.good()){
			sprintf(command, "cat %s/%d.names | awk '{ print \"grep -i \"$2\" /share/work/ravid/biogrid/split_interactions/*\"tolower(substr($2,1,4))\"*\" }' | sh > %s/%d.interactions",
				 scratch_dir, rec_bindex , scratch_dir, rec_bindex );
			int ret = system(command);
			//if(ret > 0)	
				cout << ret << " " << string(command) << endl;
		}
		rifin.close();
		
		sprintf(command, "cat %s/%d.names | awk '{ print \"grep -i \"$2\" %s/%d.interactions\" }' | sh > %s/%d_%d.interactions",
			 scratch_dir, lig_bindex , scratch_dir, rec_bindex , scratch_dir, rec_bindex , lig_bindex );
		int ret = system(command);
		//if(ret > 0)	
			cout << ret << " " << string(command) << endl;
		
		sprintf(filename,"%s/%d_%d.interactions",scratch_dir,rec_bindex,lig_bindex);
		fstream ifin(filename, ios::in);
		if(ifin.good()){
			ifin.getline(buf,8192);
			cout << string(buf) << endl;
			if(ifin.gcount() > 0){
				interact = true;
			}
		}
		ifin.close();	
		
		cout << "check pair " << rec_bindex << " " << lig_bindex << " " << interact << endl;
		if(interact){
			biogrid_pairs.insert(index);
		}
	}
	
	// get paired sequences
	for(int i = 0; i < num_species; i++){
		Species *sp = species[i];
		/*if(sp->num_sequences[0] == 1 && sp->num_sequences[1] == 1){
			
		} else*/ {
			for(int si=0; si < sp->num_sequences[0]; si++){
				long siindex = i*10000 + si;
				if(rec_biogrid_id.count(siindex) > 0)
					for(int sj=0; sj < sp->num_sequences[1]; sj++){
						long sjindex = i*10000 + sj;
						if(lig_biogrid_id.count(sjindex) > 0){
							long bindex = rec_biogrid_id[siindex] * max_biogrid_id + lig_biogrid_id[sjindex];
							if(biogrid_pairs.count(bindex) > 0){
								cout << "interacting pair " << i << " " << si << " " << sj << "\t";
								Sequence *rseq = sp->sequences[0][si], *lseq = sp->sequences[1][sj];
								rseq->loopp_alignment->compute_identities();
								lseq->loopp_alignment->compute_identities();
								cout << rseq->loopp_alignment->identities << " " << lseq->loopp_alignment->identities << endl;
								cout << rseq->loopp_alignment->aseq1 << endl << rseq->loopp_alignment->aseq2 << endl;
								cout << lseq->loopp_alignment->aseq1 << endl << lseq->loopp_alignment->aseq2 << endl;
							}
						}
					}
			}
		}
	}
	
}

void Object::compute_detailed_seqavg_energy(Object *receptor, Object *ligand, Transformation *tr, hash_map<long, long, hash<long>, eqlong>*receptor_vs_reference, hash_map<long, long, hash<long>, eqlong>*ligand_vs_reference, 
  Species **species, int num_species, ProtProtDetailedScoringMetrics ***homdetails){
  	float **points_vs_distancer=NULL,**points_vs_distancel=NULL;
  	unsigned short **atoms_vs_distancer=NULL, **atoms_vs_distancel=NULL;
	/*points_vs_distancer = (float **) malloc(sizeof(float*)*receptor->c->num_aminoacids);
	points_vs_distancel = (float **) malloc(sizeof(float*)*ligand->c->num_aminoacids);
	atoms_vs_distancer = (unsigned short **)  malloc(sizeof(unsigned short *)*receptor->c->num_aminoacids);
	atoms_vs_distancel = (unsigned short **)  malloc(sizeof(unsigned short *)*ligand->c->num_aminoacids);
	for(int i = 0; i < receptor->c->num_aminoacids; i++){
		points_vs_distancer[i] = (float *) malloc(sizeof(float)*NUM_DTRANSFORM_DIVISIONS);
		atoms_vs_distancer[i] = (unsigned short *)  malloc(sizeof(unsigned short)*NUM_DTRANSFORM_DIVISIONS);
	}
	for(int i = 0; i < ligand->c->num_aminoacids; i++){
		points_vs_distancel[i] = (float *) malloc(sizeof(float)*NUM_DTRANSFORM_DIVISIONS);
		atoms_vs_distancel[i] = (unsigned short *)  malloc(sizeof(unsigned short)*NUM_DTRANSFORM_DIVISIONS);
	}*/
	float *delta_sasar, *delta_sasal, *delta_vdwsar, *delta_vdwsal;
	delta_sasar = (float *) malloc(sizeof(float)*receptor->c->num_aminoacids);
	delta_sasal = (float *) malloc(sizeof(float)*ligand->c->num_aminoacids);
	delta_vdwsar = (float *) malloc(sizeof(float)*receptor->c->num_aminoacids);
	delta_vdwsal = (float *) malloc(sizeof(float)*ligand->c->num_aminoacids);
	
	compute_detailed_scores(ligand,tr);
	tr->compute_coordinates((void *)this, (void *)ligand);
	tr->print_details(out,TN_PROTPROT_DETAILED_SCORE_VERIFY);
	*out << "evolscore " << tr->frame_number << " 0 0 0 " << tr->compute_score(VDW_RES_BKBN_SPLINE) << endl;
	
	compute_seqavg_spline_energy(receptor,ligand,tr,delta_sasar,delta_sasal,delta_vdwsar, delta_vdwsal,
	 receptor_vs_reference,ligand_vs_reference,species, num_species, homdetails);
	
	delete delta_sasar;
	delete delta_sasal;
}

extern bool **aacontact_core, **aacontact_rim, *aarcontact, *aalcontact;
extern float *avgexposedarea;

void Object::compute_seqavg_spline_energy(Object *receptor, Object *ligand, Transformation *tr, float *delta_sasar, float *delta_sasal, float *delta_vdwsar, float *delta_vdwsal,
  hash_map<long, long, hash<long>, eqlong>*receptor_vs_reference, hash_map<long, long, hash<long>, eqlong>*ligand_vs_reference,
  Species **species, int num_species, ProtProtDetailedScoringMetrics ***homdetails){
	Vector zero = Vector(0,0,0);
	GridCell *cell;
	
	if(ligand->transformed_atom_position == NULL)
		ligand->transformed_atom_position = (Vector*) malloc(sizeof(Vector)*ligand->c->num_atoms);
	if(ligand->partner_cell_of_atom == NULL)	
		ligand->partner_cell_of_atom = (GridCell **) malloc(sizeof(GridCell *)*ligand->c->num_atoms);
		
	ligand->num_atoms_in_contact=0;
	for(int li = 0; li < ligand->c->num_atoms; li++){
		Atom * al = ligand->c->atom[li];
		ligand->transformed_atom_position[li] = tr->inverse_transform(*(al->position));
		
		//if(al->sasa > 0 || al->vdwsa > 0){
		if((al->name).c_str()[0] != 'H'){
			GridCell *cell = receptor->access_point_in_grid(&(ligand->transformed_atom_position[li]),&zero);
			Vector v = (ligand->transformed_atom_position[li]) - *(receptor->grid_origin);
			int cellx = (int) (v.x/GRID_SPACING);
			int celly = (int) (v.y/GRID_SPACING);
			int cellz = (int) (v.z/GRID_SPACING);
	
			if(cellx >= 0 && cellx < receptor->grid_num_xdivisions && celly >= 0 && celly < receptor->grid_num_ydivisions && cellz >= 0 && cellz < receptor->grid_num_zdivisions){
				unsigned int index = (ATOM_NEIGHBOR_GS_BY_GS*(cellx/ATOM_NEIGHBOR_GS_BY_GS)*receptor->grid_num_ydivisions + ATOM_NEIGHBOR_GS_BY_GS*(celly/ATOM_NEIGHBOR_GS_BY_GS))*receptor->grid_num_zdivisions + ATOM_NEIGHBOR_GS_BY_GS*(cellz/ATOM_NEIGHBOR_GS_BY_GS);
		
				if(receptor->grid[index] != NULL){
					GridCell *coarse_cell = receptor->grid[index];
					if(coarse_cell->atom_overlap_neighbors != NULL){
						ligand->partner_cell_of_atom[li] = coarse_cell;
						ligand->atoms_in_contact[ligand->num_atoms_in_contact++] = li;
					}
				}
			}
		}
	}
	
	compute_deltasa_byresidue(receptor,ligand,ligand->transformed_atom_position,ligand->atoms_in_contact,ligand->num_atoms_in_contact,ligand->partner_cell_of_atom,tr,
		delta_sasar,delta_sasal,delta_vdwsar,delta_vdwsal);
	
	ProtProtDetailedScoringMetrics *ahom_details = new ProtProtDetailedScoringMetrics();
	
	// compute residue contacts			
	hash_map<long,float,hash<long>,eqlong> aminoacid_contact_factor;
	float bkbn_contact_factorl[ligand->c->num_aminoacids][2], bkbn_contact_factorr[receptor->c->num_aminoacids][2], bkbn_contacts[2][2];
	for(int i = 0 ; i < 2; i++)
		for(int j = 0 ; j < 2; j++)
			bkbn_contacts[i][j] = 0;
	for(int laindex = 0; laindex < ligand->c->num_aminoacids; laindex++){
		Aminoacid *al = ligand->c->aminoacid[laindex];
		
		if(al->type >= 0 && al->centroid != NULL){
			Vector vl = tr->inverse_transform(*(al->centroid));
			for(int raindex = 0; raindex < receptor->c->num_aminoacids; raindex++){
				Aminoacid *ar = receptor->c->aminoacid[raindex];
				float d, d2, factor=0,nfactor;
				bool contact=false;
				
				// residue contacts (centroid centroid)
				if(ar->type >= 0 && ar->centroid != NULL){
					d2 = Vector::distance_squared(vl,*(ar->centroid));
#ifdef 	STEP_POTENTIAL 			
					if(d2 < AA_CUTOFF_SQUARED)
#endif
#ifdef LINEAR_SPLINE_POTENTIAL										 			
					if(d2 < AA_SMTHP_CUTOFF_SQUARED)
#endif												
					{	
						contact=true;								
#ifdef 	STEP_POTENTIAL 	
						factor = 1.0;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL	 									
				 		if(d2 < AA_CUTOFF_SQUARED)	factor = 1.0;
						else{ float d=sqrt(d2);	factor = AA_SMTHP_FACTOR(d); }
						//cout << ar->index << " " << al->index << " " << d2 << " factor " << factor << endl;
#endif						
					}
				}//*/
					
				if(contact){
					aminoacid_contact_factor[laindex*MAX_ATOMS + raindex] = factor;
	 			}
			}
	 	}
		 	
	 	// backbone centroid and backbone backbone contacts
	 	{
	 		Vector *vaa[3];
			vaa[0] = al->centroid;
			vaa[1] = (al->amide_nitrogen == NULL) ? NULL : al->amide_nitrogen->position;
			vaa[2] = (al->carbonyl_oxygen == NULL) ? NULL : al->carbonyl_oxygen->position;
			for(int aapi = 0; aapi < 3; aapi++) 
			 	if(vaa[aapi]  != NULL){
					Vector vl = tr->inverse_transform(*(vaa[aapi]));
					for(int raindex = 0; raindex < receptor->c->num_aminoacids; raindex++){
						Aminoacid *ra = receptor->c->aminoacid[raindex];
					  if(ra->type >= 0)	
						for(int aapj = 0; aapj < 3; aapj++){  
							float d, d2, factor=0;
							if((aapi == 0 && aapj != 0 && al->type >= 0) || 
							 (aapi != 0 && aapj == 0 && ra->centroid != NULL)) {
							 	bool computefactor=false;
							 	if(aapi == 0 && aapj == 1 && ra->amide_nitrogen != NULL){
							 		computefactor=true;
									d2=Vector::distance_squared(vl,*(ra->amide_nitrogen->position));
							 	}
								if(aapi == 0 && aapj == 2 && ra->carbonyl_oxygen != NULL){
									computefactor=true;
									d2=Vector::distance_squared(vl,*(ra->carbonyl_oxygen->position));
								}
								if(aapi != 0){
									computefactor=true;
									d2=Vector::distance_squared(vl,*(ra->centroid));
								}
								
								if(computefactor)
#ifdef 	STEP_POTENTIAL 			
										if(d2 < BS_CUTOFF_SQUARED)
#endif
#ifdef LINEAR_SPLINE_POTENTIAL										 			
										if(d2 < BS_SMTHP_CUTOFF_SQUARED)
#endif												
										{	
#ifdef 	STEP_POTENTIAL 	
											factor = 1.0;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL	 									
				 							if(d2 < BS_CUTOFF_SQUARED)	factor = 1.0;
											else{ float d=sqrt(d2);	factor = BS_SMTHP_FACTOR(d); }
#endif						
										}
								if(aapi == 0 && aapj != 0 && al->type >= 0){
									bkbn_contact_factorl[laindex][aapj-1] = factor;
								} else if(aapi > 0){
									bkbn_contact_factorr[raindex][aapi-1] = factor;
								}
							}
					
							if(aapi > 0 && aapj > 0){
								bool computefactor=false;
							 	if(aapj == 1 && ra->amide_nitrogen != NULL){
							 		computefactor=true;
									d2=Vector::distance_squared(vl,*(ra->amide_nitrogen->position));
							 	}
								if(aapj == 2 && ra->carbonyl_oxygen != NULL){
									computefactor=true;
									d2=Vector::distance_squared(vl,*(ra->carbonyl_oxygen->position));
								}
								
								if(computefactor)
#ifdef 	STEP_POTENTIAL 			
										if(d2 < BB_CUTOFF_SQUARED)
#endif
#ifdef LINEAR_SPLINE_POTENTIAL										 			
										if(d2 < BB_SMTHP_CUTOFF_SQUARED)
#endif												
										{	
#ifdef 	STEP_POTENTIAL 	
											factor = 1.0;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL	 									
				 							if(d2 < BB_CUTOFF_SQUARED)	factor = 1.0;
											else{ float d=sqrt(d2);	factor = BB_SMTHP_FACTOR(d); }
#endif		
									}
								bkbn_contacts[aapi-1][aapj-1] += factor;
								if(aapi != aapj)	bkbn_contacts[aapj-1][aapi-1] += factor;											
							}
						} // aapj
					}
				}
	 	}
	}
	tr->num_contacts = aminoacid_contact_factor.size();
	
	float relative_delta_sasa_gap=0;
	// scale change in surface area by the averages for the corresponding types
	
	// compute details per species
	for(int sj = 0; sj <= num_species; sj++){
		Species *sp = species[sj];
		//ProtProtDetailedScoringMetrics **hom_details = (*homdetails) = (ProtProtDetailedScoringMetrics**) malloc(sizeof(ProtProtDetailedScoringMetrics*) *(sp->num_sequences[0] * sp->num_sequences[1] + 1));
	
		for(short s1 = 0; s1 < sp->num_sequences[0]; s1++)
			for(short s2 = 0; s2 < sp->num_sequences[1]; s2++){
				int si = s1*(sp->num_sequences[1])+s2;
				//ahom_details = hom_details[si] = new ProtProtDetailedScoringMetrics();
				//cout << si << " " << hom_details[si] << " " << hom_details[si]->residue_contacts << endl; cout.flush();
				for(int i = 0 ; i < NUM_RESIDUE_TYPES; i++)	ahom_details->delta_sasa[i] = ahom_details->delta_vdwsa[i] = 0;
				int num_residue_types = NUM_RESIDUE_TYPES;
				float residue_contacts_gap[num_residue_types], residue_contacts_gap_vs_gap=0;
				for(int i = 0; i < num_residue_types; i++){
					for(int j = 0 ; j < num_residue_types; j++){
						ahom_details->residue_contacts_core[i][j] = ahom_details->residue_contacts_rim[i][j] = 0;
					}
					residue_contacts_gap[i] = 0;
				}
				num_residue_types = NUM_COARSE_RTYPES;
				for(int i = 0; i < num_residue_types; i++)
					for(int j = 0 ; j < num_residue_types; j++)
						for(int k = 0 ; k < num_residue_types; k++)
							ahom_details->threebody_contacts[i][j][k] = 0;
					
				unsigned int delta_sasar_numgaps=0,delta_sasal_numgaps=0,contacts_numgaps=0;
				
				for(hash_map<long,float,hash<long>,eqlong>::iterator itr = aminoacid_contact_factor.begin(); itr != aminoacid_contact_factor.end(); itr++){
					long index = itr->first;
					float factor = itr->second;
					int laindex = index / MAX_ATOMS;
					int raindex = index % MAX_ATOMS;
					
					short ratype, latype;
					ratype = sp->homologues_aatypes[0][s1][raindex];
					latype = sp->homologues_aatypes[1][s2][laindex];
								
					if(latype != GAP && ratype != GAP){
						if(ratype <= latype)
							ahom_details->residue_contacts_core[ratype][latype] += factor;
						else
							ahom_details->residue_contacts_core[latype][ratype] += factor;
					} else {
						if(latype == GAP && ratype == GAP){
							residue_contacts_gap_vs_gap += factor;
						} else if(latype != GAP && ratype == GAP){
							residue_contacts_gap[latype] += factor;
						} else if(latype == GAP && ratype != GAP){
							residue_contacts_gap[ratype] += factor;
						}
						contacts_numgaps++;
					}
					ahom_details->atom_vdw_repulsion[0] = contacts_numgaps;
				}
				
				for(int laindex = 0; laindex < ligand->c->num_aminoacids; laindex++){
					short latype = sp->homologues_aatypes[1][s2][laindex];
					if(latype != GAP){
						ahom_details->residue_contacts_core[latype][20] += bkbn_contact_factorl[laindex][0];
						ahom_details->residue_contacts_core[latype][21] += bkbn_contact_factorl[laindex][1];
					}
				}
				for(int raindex = 0; raindex < receptor->c->num_aminoacids; raindex++){
					short ratype = sp->homologues_aatypes[0][s1][raindex];
					if(ratype != GAP){
						ahom_details->residue_contacts_core[ratype][20] += bkbn_contact_factorr[raindex][0];
						ahom_details->residue_contacts_core[ratype][21] += bkbn_contact_factorr[raindex][1];
					}
				}
				
				for(int i = 0 ; i < 2; i++)
					for(int j = 0 ; j < 2; j++)
						ahom_details->residue_contacts_core[20+i][20+j] = bkbn_contacts[i][j];
				
				*out << "gaps " << tr->frame_number << " hom " << si << " " << delta_sasar_numgaps << " " << delta_sasal_numgaps << " " << contacts_numgaps << endl;
				ProtProtDetailedScoringMetrics *tdetails = (ProtProtDetailedScoringMetrics*) tr->detailed_scores;
				tr->detailed_scores = ahom_details;
				float score = tr->compute_score(VDW_RES_BKBN_SPLINE);
				*out << "evolscore " << tr->frame_number << " " << sj+1 << " " << s1 << " " << s2 << " " << score << endl;
				tr->detailed_scores = tdetails;
			}
	}
}

/*
 * Average over sequence space
 * Using pairs of sequences from same organism
 */
void Object::compute_seqavg_energy(Object *receptor, Object *ligand, Transformation *tr, float **points_vs_distancer,float **points_vs_distancel,
  unsigned short **atoms_vs_distancer, unsigned short **atoms_vs_distancel, float *delta_sasar, float *delta_sasal, float *delta_vdwsar, float *delta_vdwsal,
  hash_map<long, long, hash<long>, eqlong>*receptor_vs_reference, hash_map<long, long, hash<long>, eqlong>*ligand_vs_reference,
  Species **species, int num_species, ProtProtDetailedScoringMetrics ***homdetails){
	Vector zero = Vector(0,0,0);
	GridCell *cell;
	
	if(ligand->transformed_atom_position == NULL)
		ligand->transformed_atom_position = (Vector*) malloc(sizeof(Vector)*ligand->c->num_atoms);
	if(ligand->partner_cell_of_atom == NULL)	
		ligand->partner_cell_of_atom = (GridCell **) malloc(sizeof(GridCell *)*ligand->c->num_atoms);
		
	ligand->num_atoms_in_contact=0;
	for(int li = 0; li < ligand->c->num_atoms; li++){
		Atom * al = ligand->c->atom[li];
		ligand->transformed_atom_position[li] = tr->inverse_transform(*(al->position));
		
		//if(al->sasa > 0 || al->vdwsa > 0){
		if((al->name).c_str()[0] != 'H'){
			GridCell *cell = receptor->access_point_in_grid(&(ligand->transformed_atom_position[li]),&zero);
			Vector v = (ligand->transformed_atom_position[li]) - *(receptor->grid_origin);
			int cellx = (int) (v.x/GRID_SPACING);
			int celly = (int) (v.y/GRID_SPACING);
			int cellz = (int) (v.z/GRID_SPACING);
	
			if(cellx >= 0 && cellx < receptor->grid_num_xdivisions && celly >= 0 && celly < receptor->grid_num_ydivisions && cellz >= 0 && cellz < receptor->grid_num_zdivisions){
				unsigned int index = (ATOM_NEIGHBOR_GS_BY_GS*(cellx/ATOM_NEIGHBOR_GS_BY_GS)*receptor->grid_num_ydivisions + ATOM_NEIGHBOR_GS_BY_GS*(celly/ATOM_NEIGHBOR_GS_BY_GS))*receptor->grid_num_zdivisions + ATOM_NEIGHBOR_GS_BY_GS*(cellz/ATOM_NEIGHBOR_GS_BY_GS);
		
				if(receptor->grid[index] != NULL){
					GridCell *coarse_cell = receptor->grid[index];
					if(coarse_cell->atom_overlap_neighbors != NULL){
						ligand->partner_cell_of_atom[li] = coarse_cell;
						ligand->atoms_in_contact[ligand->num_atoms_in_contact++] = li;
					}
				}
			}
		}
	}
	
	compute_deltasa_byresidue(receptor,ligand,ligand->transformed_atom_position,ligand->atoms_in_contact,ligand->num_atoms_in_contact,ligand->partner_cell_of_atom,tr,
		delta_sasar,delta_sasal,delta_vdwsar,delta_vdwsal);
	
	hash_map<long,unsigned short,hash<long>,eqlong> pair_d[4];
	compute_dpp_contacts(receptor,ligand,tr,pair_d);
	
	bool computeFreadyE=false;
	if(computeFreadyE){
		tr->eResiduepair = 0;
		for(int i=0; i<4; i++){
			for(hash_map<long,unsigned short,hash<long>,eqlong>::iterator itr = pair_d[i].begin(); itr != pair_d[i].end(); itr++){
				long index = itr->first;
				unsigned short d = itr->second;
				int laindex = index / MAX_ATOMS;
				int raindex = index % MAX_ATOMS;
				Aminoacid *ra = receptor->c->aminoacid[raindex], *la = ligand->c->aminoacid[laindex];
				int ratype=ra->type,latype=la->type;
				if(ratype >= 0 && latype >= 0 && ratype < 20 && latype < 20){
					float delta;
					switch(i){
						case 0:
							if(ratype <= latype)	delta = cacar_potential[ratype][latype][d];
							else	delta = cacar_potential[latype][ratype][d];
							break;
						case 3:
							if(ratype <= latype)	delta = cmcmr_potential[ratype][latype][d];
							else	delta = cmcmr_potential[latype][ratype][d];
							break;
						case 1:
							delta = cmcar_potential[ratype][latype][d];
							break;
						case 2:
							delta = cmcar_potential[latype][ratype][d];
							break;
					}
					//*out << latype << " " << ratype << " " << d << " " << delta << endl;
					tr->eResiduepair += delta;
				}
			}
		}
	}
	
	ProtProtDetailedScoringMetrics *ahom_details = new ProtProtDetailedScoringMetrics();
	// compute aminoacids in contact, aacontact_* are computed here
	compute_energy_approx2(this,ligand,tr,ahom_details);
	
	vector<long> aminoacid_contacts;
	vector<int> aalcontactv, aarcontactv;
	for(unsigned short i = 0; i < ligand->c->num_aminoacids; i++)
		if(aalcontact[i])	aalcontactv.push_back(i);
	for(unsigned short i = 0; i < receptor->c->num_aminoacids; i++)
		if(aarcontact[i]){
			aarcontactv.push_back(i);
			for(vector<int>::iterator itr = aalcontactv.begin(); itr != aalcontactv.end(); itr++){
				int lindex = *itr;
				if(aacontact_core[lindex][i] || aacontact_rim[lindex][i])	aminoacid_contacts.push_back(lindex*MAX_ATOMS + i); 
			}
		}
	tr->num_contacts = aminoacid_contacts.size();
	
	float relative_delta_sasa_gap=0;
	// scale change in surface area by the averages for the corresponding types
	
	// compute details per species
	for(int sj = 0; sj <= num_species; sj++){
		Species *sp = species[sj];
		//ProtProtDetailedScoringMetrics **hom_details = (*homdetails) = (ProtProtDetailedScoringMetrics**) malloc(sizeof(ProtProtDetailedScoringMetrics*) *(sp->num_sequences[0] * sp->num_sequences[1] + 1));
	
		for(short s1 = 0; s1 < sp->num_sequences[0]; s1++)
			for(short s2 = 0; s2 < sp->num_sequences[1]; s2++){
				int si = s1*(sp->num_sequences[1])+s2;
				//ahom_details = hom_details[si] = new ProtProtDetailedScoringMetrics();
				//cout << si << " " << hom_details[si] << " " << hom_details[si]->residue_contacts << endl; cout.flush();
				for(int i = 0 ; i < NUM_RESIDUE_TYPES; i++)	ahom_details->delta_sasa[i] = ahom_details->delta_vdwsa[i] = 0;
				int num_residue_types = NUM_RESIDUE_TYPES;
				unsigned int residue_contacts_gap[num_residue_types], residue_contacts_gap_vs_gap=0;
				for(int i = 0; i < num_residue_types; i++){
					for(int j = 0 ; j < num_residue_types; j++){
						ahom_details->residue_contacts_core[i][j] = ahom_details->residue_contacts_rim[i][j] = 0;
					}
					residue_contacts_gap[i] = 0;
				}
				num_residue_types = NUM_COARSE_RTYPES;
				for(int i = 0; i < num_residue_types; i++)
					for(int j = 0 ; j < num_residue_types; j++)
						for(int k = 0 ; k < num_residue_types; k++)
							ahom_details->threebody_contacts[i][j][k] = 0;
					
				unsigned int delta_sasar_numgaps=0,delta_sasal_numgaps=0,contacts_numgaps=0;
				
				// compute changes in rsa for receptor	
				for(int j = 0; j < receptor->c->num_aminoacids; j++){
					short type = sp->homologues_aatypes[0][s1][j];
					if(type != GAP){
						ahom_details->delta_sasa[type] += (delta_sasar[j]*avgexposedarea[type]/avgexposedarea[receptor->c->aminoacid[j]->type]);
						//ahom_details->delta_vdwsa[type] += delta_vdwsar[j]; // how to scale?
					} else {
						relative_delta_sasa_gap += (delta_sasar[j]/avgexposedarea[receptor->c->aminoacid[j]->type]);
						delta_sasar_numgaps++;
					}
					if(receptor->c->aminoacid[j]->type != GAP)
						ahom_details->delta_vdwsa[receptor->c->aminoacid[j]->type] += delta_vdwsar[j];
					//if(si==0 && delta_vdwsar[j]>0)	*out << "rvdwsa " << j <<  
				}
			
				// compute changes in rsa for ligand 	
				for(int j = 0; j < ligand->c->num_aminoacids; j++){
					short type = sp->homologues_aatypes[1][s2][j];
					if(type != GAP){
						ahom_details->delta_sasa[type] += (delta_sasal[j]*avgexposedarea[type]/avgexposedarea[ligand->c->aminoacid[j]->type]);
					} else {
						relative_delta_sasa_gap += (delta_sasal[j]/avgexposedarea[ligand->c->aminoacid[j]->type]);
						delta_sasal_numgaps++;
					}
					if(ligand->c->aminoacid[j]->type != GAP)
						ahom_details->delta_vdwsa[ligand->c->aminoacid[j]->type] += delta_vdwsal[j]; 
				}
		
				// compute residue contacts
				for(vector<long>::iterator itr = aminoacid_contacts.begin(); itr != aminoacid_contacts.end(); itr++){
					long index = *itr;
					int laindex = index / MAX_ATOMS;
					int raindex = index % MAX_ATOMS;
					
					short ratype, latype;
					ratype = sp->homologues_aatypes[0][s1][raindex];
					latype = sp->homologues_aatypes[1][s2][laindex];
								
					if(latype != GAP && ratype != GAP){
						if(ratype <= latype)
							if(aacontact_core[laindex][raindex])	ahom_details->residue_contacts_core[ratype][latype]++;
							else	ahom_details->residue_contacts_rim[ratype][latype]++;
						else
							if(aacontact_core[laindex][raindex])	ahom_details->residue_contacts_core[latype][ratype]++;
							else	ahom_details->residue_contacts_rim[latype][ratype]++;
					} else {
						if(latype == GAP && ratype == GAP){
							residue_contacts_gap_vs_gap++;
						} else if(latype != GAP && ratype == GAP){
							residue_contacts_gap[latype]++;
						} else if(latype == GAP && ratype != GAP){
							residue_contacts_gap[ratype]++;
						}
						contacts_numgaps++;
					}
					ahom_details->atom_vdw_repulsion[0] = contacts_numgaps;
				
					// 3 body term
					if(latype != GAP && ratype != GAP){
						for(vector<int>::iterator itr = aalcontactv.begin(); itr != aalcontactv.end(); itr++){
							int aa3index = (int) *itr;
							if(aa3index > laindex && ligand->c->aacontact[laindex][aa3index] && (aacontact_core[aa3index][raindex]||aacontact_rim[aa3index][raindex])){
								short aa3type = sp->homologues_aatypes[1][s2][aa3index]; 
								if(aa3type != GAP){
									aa3type = RTYPE(aa3type);
						
									if(ratype >= 0 && latype >= 0 && aa3type >= 0){
										short type[3];
										type[0] = ratype; type[1] = latype; type[2] = aa3type;
										for(short i = 0; i < 3; i++)
											for(short j = i+1; j < 3; j++)
												if(type[j] < type[i]){
													short t = type[i];
													type[i] = type[j];
													type[j] = t;
												}
										ahom_details->threebody_contacts[type[0]][type[1]][type[2]]++;
									}
								}
							}
						}
						for(vector<int>::iterator itr = aarcontactv.begin(); itr != aarcontactv.end(); itr++){
							int aa3index = (int) *itr;
							if(aa3index > raindex && receptor->c->aacontact[raindex][aa3index] && (aacontact_core[laindex][aa3index]||aacontact_rim[laindex][aa3index])){
								short aa3type =  sp->homologues_aatypes[0][s1][aa3index]; 
								if(aa3type != GAP){ 
									aa3type = RTYPE(aa3type);
									if(ratype >= 0 && latype >= 0 && aa3type >= 0){
										short type[3];
										type[0] = ratype; type[1] = latype; type[2] = aa3type;
										for(short i = 0; i < 3; i++)
											for(short j = i+1; j < 3; j++)
												if(type[j] < type[i]){
													short t = type[i];
													type[i] = type[j];
													type[j] = t;
												}
										ahom_details->threebody_contacts[type[0]][type[1]][type[2]]++;
									}
								}
							}
						}
					}
				}
				
				*out << "gaps " << tr->frame_number << " hom " << si << " " << delta_sasar_numgaps << " " << delta_sasal_numgaps << " " << contacts_numgaps << endl;
				ProtProtDetailedScoringMetrics *tdetails = (ProtProtDetailedScoringMetrics*) tr->detailed_scores;
				tr->detailed_scores = ahom_details;
				float score = tr->compute_score(RESIDUE_CONTACT_3B);
				*out << "evolscore " << tr->frame_number << " " << sj+1 << " " << s1 << " " << s2 << " " << score << endl;
				tr->detailed_scores = tdetails;
			}
	}
	
	// clean up global variables
	for(vector<long>::iterator itr = aminoacid_contacts.begin(); itr != aminoacid_contacts.end(); itr++){
		long index = *itr;
		int laindex = index / MAX_ATOMS;
		int raindex = index % MAX_ATOMS;
		aacontact_core[laindex][raindex] = aacontact_rim[laindex][raindex] = false;
		aarcontact[raindex] = false; aalcontact[laindex] = false;
	}
}

void Object::compute_seqavg_dpp_energy(Object *receptor, Object *ligand, Transformation *tr,
  hash_map<long, long, hash<long>, eqlong>*receptor_vs_reference, hash_map<long, long, hash<long>, eqlong>*ligand_vs_reference,
  hash_map<const char*, Sequence*, hash<const char*>, eqstr> *rhomologue_sequences, hash_map<const char*, Sequence*, hash<const char*>, eqstr> *lhomologue_sequences,
  int raacidcindexstart, int laacidcindexstart){
  	hash_map<long,unsigned short,hash<long>,eqlong> pair_d[4];
	compute_dpp_contacts(receptor,ligand,tr,pair_d);
	
	int num_residue_types = 20;
	unsigned int residue_contacts_gap[4][num_residue_types][135], residue_contacts_gap_vs_gap[4][135];
	for(int i=0;i<4;i++){
		for(int k=0; k < 135; k++){
			for(int j = 0 ; j < num_residue_types; j++){
				residue_contacts_gap[i][j][k] = 0;
			}
			residue_contacts_gap_vs_gap[i][k] = 0;
		}
	}
	tr->eResiduepair = 0;

	for(int i=0; i<4; i++){
		for(hash_map<long,unsigned short,hash<long>,eqlong>::iterator itr = pair_d[i].begin(); itr != pair_d[i].end(); itr++){
			long index = itr->first;
			unsigned short d = itr->second;
			int laindex = index / MAX_ATOMS;
			int raindex = index % MAX_ATOMS;
			Aminoacid *ra = receptor->c->aminoacid[raindex], *la = ligand->c->aminoacid[laindex];
			short ratype=ra->type,latype=la->type;
			if(ratype >= 0 && latype >= 0 && ratype < 20 && latype < 20){
				float delta;
				switch(i){
					case 0:
						if(ratype <= latype)	delta = cacar_potential[ratype][latype][d];
						else	delta = cacar_potential[latype][ratype][d];
						break;
					case 3:
						if(ratype <= latype)	delta = cmcmr_potential[ratype][latype][d];
						else	delta = cmcmr_potential[latype][ratype][d];
						break;
					case 1:
						delta = cmcar_potential[ratype][latype][d];
						break;
					case 2:
						delta = cmcar_potential[latype][ratype][d];
						break;
				}
				//*out << latype << " " << ratype << " " << d << " " << delta << endl;
				tr->eResiduepair += delta;
			}
		}
	}
	
	int numrhomologues = rhomologue_sequences->size(),numlhomologues = lhomologue_sequences->size();
	if(rhomologue_sequences->count(receptor->c->pdbcode.c_str())==0)	numrhomologues++;
	if(lhomologue_sequences->count(ligand->c->pdbcode.c_str())==0)	numlhomologues++;
	
	for(int dppi=0; dppi<4; dppi++){
		for(hash_map<long,unsigned short,hash<long>,eqlong>::iterator itr = pair_d[dppi].begin(); itr != pair_d[dppi].end(); itr++){
			long index = itr->first;
			unsigned short d = itr->second;
			int laindex = index / MAX_ATOMS;
			int raindex = index % MAX_ATOMS;
			Aminoacid *ra = receptor->c->aminoacid[raindex], *la = ligand->c->aminoacid[laindex];

			short ratype, latype;
			for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator rhitr = rhomologue_sequences->begin(); rhitr != rhomologue_sequences->end(); rhitr++){
				if(string((const char*) rhitr->first) != receptor->c->pdbcode){
					Sequence *rs = (Sequence *) rhitr->second;
					Alignment *ra = rs->seq_alignment;
					int rn = ra->aseq1.size();
					const char* raseq1c = ra->aseq1.c_str();
					const char* raseq2c = ra->aseq2.c_str();
				
					if(receptor_vs_reference->count(raindex) > 0){
						int index = (*receptor_vs_reference)[raindex] - raacidcindexstart;
						if(index >= ra->qstart && index < ra->qend){
							char qc='-',sc='-';
							int qindex = ra->qstart-1, i;
							for(i = 0 ; i < rn ; i++){
								if(raseq1c[i] != '-'){
									qindex++;
									if(qindex == index+1) {
										qc=raseq1c[i];
										sc=raseq2c[i];
										break;
									}
								}
							}
							//*out << index << "-" << i << " " << qc << sc << " ";
							if(sc != '-'){
								ratype = get_aatype(sc);
							} else	ratype = GAP;
						} else	ratype = GAP;
					} else	ratype = GAP;
					//*out << ratype << " ";
				
					for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator lhitr = lhomologue_sequences->begin(); lhitr != lhomologue_sequences->end(); lhitr++){
						if(string((const char*) lhitr->first) != ligand->c->pdbcode){
							Sequence *ls = (Sequence *) lhitr->second;
							Alignment *la = ls->seq_alignment;
							int ln = la->aseq1.size();
							const char* laseq1c = la->aseq1.c_str();
							const char* laseq2c = la->aseq2.c_str();
				
							//*out << laindex << "|";
							if(ligand_vs_reference->count(laindex) > 0){
								int index = (*ligand_vs_reference)[laindex] - laacidcindexstart;
								//*out << index << "|" << la->qstart << "|" << la->qend << " ";
								if(index >= la->qstart && index < la->qend){
									char qc='-',sc='-';
									int qindex = la->qstart-1, i;
									for(i = 0 ; i < ln ; i++){
										if(laseq1c[i] != '-'){
											qindex++;
											if(qindex == index+1) {
												qc=laseq1c[i];
												sc=laseq2c[i];
												break;
											}
										}
									}
									//*out << index << "--" << i << " " << qc << sc << " ";
									if(sc != '-'){
										latype = get_aatype(sc);
									} else	latype = GAP;
								} else	latype = GAP;
							} else	latype = GAP;
							
							if(latype != GAP && ratype != GAP && ratype < 20 && latype < 20){
								//*out << "-";
								float delta;
								switch(dppi){
									case 0:
										if(ratype <= latype)	delta = cacar_potential[ratype][latype][d];
										else	delta = cacar_potential[latype][ratype][d];
										break;
									case 3:
										if(ratype <= latype)	delta = cmcmr_potential[ratype][latype][d];
										else	delta = cmcmr_potential[latype][ratype][d];
										break;
									case 1:
										delta = cmcar_potential[ratype][latype][d];
										break;
									case 2:
										delta = cmcar_potential[latype][ratype][d];
										break;
								}
								tr->eResiduepair += delta;
							} else {
								if((latype == GAP || latype >= 20) && (ratype == GAP || ratype >= 20)){
									residue_contacts_gap_vs_gap[dppi][d]++;
								} else if(latype != GAP && latype < 20){
									residue_contacts_gap[dppi][latype][d]++;
								} else if(ratype != GAP && ratype < 20){
									residue_contacts_gap[dppi][ratype][d]++;
								}
							}
						}
					}
				}
			}
		}
	}
	
	for(int i=0;i<4;i++){
		for(int k=0; k < 135; k++){
			float gap_vs_gap_potential=0, avg_pp=0,avg_pp_squared=0, min_pp=0;
			for(int n = 0; n < num_residue_types; n++){
				float gap_potential=0, avg_ppi=0,avg_ppi_squared=0, min_ppi=0;
				for(int m = 0 ; m < num_residue_types; m++){
					float delta;
					switch(i){
						case 0:
							if(n <= m)	delta = cacar_potential[n][m][k];
							else	delta = cacar_potential[m][n][k];
							break;
						case 3:
							if(n <= m)	delta = cmcmr_potential[n][m][k];
							else	delta = cmcmr_potential[m][n][k];
							break;
						case 1:
							delta = cmcar_potential[n][m][k];
							break;
						case 2:
							delta = cmcar_potential[n][m][k];
							break;
					}
					
					
					avg_ppi += delta;
					avg_ppi_squared += delta*delta;
					min_ppi = min(min_ppi,delta);
				}
				avg_ppi /= num_residue_types;
				avg_ppi_squared /= num_residue_types;
				float sigma_ppi_squared = (avg_ppi_squared - avg_ppi*avg_ppi);
				if(sigma_ppi_squared < 0)	sigma_ppi_squared=0-sigma_ppi_squared;
				float sigma_ppi = sqrt(sigma_ppi_squared);
				gap_potential = min_ppi - sigma_ppi;
				
				//*out <<i<<"-"<<n<<"-"<<k<<" "<< residue_contacts_gap[i][n][k] << " " << min_ppi << "|" << (avg_ppi_squared - avg_ppi*avg_ppi) << " ";
				tr->eResiduepair += residue_contacts_gap[i][n][k] * (gap_potential);
				
				avg_pp += avg_ppi;
				avg_pp_squared += avg_ppi_squared;
				min_pp = min(min_pp,min_ppi);
			}
			avg_pp /= num_residue_types;
			avg_pp_squared /= num_residue_types;
			float sigma_pp_squared = (avg_pp_squared - avg_pp*avg_pp);
			if(sigma_pp_squared < 0)	sigma_pp_squared=0-sigma_pp_squared;
			float sigma_pp = sqrt(sigma_pp_squared);
			gap_vs_gap_potential = min_pp - sigma_pp;
				
			//*out << residue_contacts_gap_vs_gap[i][k] << " " << min_pp << "!" << (avg_pp_squared - avg_pp*avg_pp) << endl;
			tr->eResiduepair += residue_contacts_gap_vs_gap[i][k]*(gap_vs_gap_potential);
		}
	}
	
	tr->eResiduepair /= ((numrhomologues-1)*(numlhomologues-1)+ 1);
}

