/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "utilities.hpp"

/*
 * Solve for the approximate closest neeighbors for each grid cell on the unit sphere
 */
int main(int argc, char *argv[]){
	int divisions = atoi(argv[1]);
	float spread = PI/divisions;
	
	int n = 2*divisions*divisions;
	Vector *point[n][5];
	float max_dcell[n];
	for(int i = 0; i < divisions; i++){
		float phi = (2*i+1)*spread/2;
		for(int j = 0; j < 2*divisions; j++){
			float theta = (2*j+1)*spread/2;
			int index = j*divisions+i;
			point[index][0] = new Vector(sin(phi)*cos(theta), sin(phi)*sin(theta), cos(phi));
			float t,p;
			p = i*spread;
			t = j*spread;
			point[index][1] = new Vector(sin(p)*cos(t), sin(p)*sin(t), cos(p));
			float d = Vector::distance(point[index][1],point[index][0]);
			float md = d;
			t = (j+1)*spread;
			point[index][2] = new Vector(sin(p)*cos(t), sin(p)*sin(t), cos(p));
			d = Vector::distance(point[index][2],point[index][0]);
			md = min(d,md);
			p = (i+1)*spread;
			point[index][3] = new Vector(sin(p)*cos(t), sin(p)*sin(t), cos(p));
			d = Vector::distance(point[index][3],point[index][0]);
			md = min(d,md);
			t = j*spread;
			point[index][4] = new Vector(sin(p)*cos(t), sin(p)*sin(t), cos(p));
			d = Vector::distance(point[index][4],point[index][0]);
			md = min(d,md);
			max_dcell[index] = md; //is this correct?
		}
	}
	
	float d[n][n];
	for(int i = 0; i < n; i++){
		for(int j = i; j < n; j++){
			float maxd = 0;
			for(int k = 0 ; k < 5; k++)
				for(int l = 0 ; l < 5; l++){
					float dis = Vector::distance(point[i][k],point[j][l]);
					maxd = max(dis,maxd);
				}	
			float dis = maxd - (max_dcell[i] + max_dcell[j]);
			dis = max(dis,(float) 0);
			d[i][j] = d[j][i] = dis;
		}
	}
	
	for(int i = 0; i < n; i++){
		int sorted[n];
		float di[n];
		for(int m = 0 ; m < n ; m++){
			sorted[m] = m;
			di[m] = d[i][m];
		}
		for(int j = 0 ; j < n ; j++)
			for(int k = j+1 ; k < n ; k++)
				if(di[j] > di[k]){
					float t = di[j];
					di[j] = di[k];
					di[k] = t;
					t = sorted[j];
					sorted[j] = sorted[k];
					sorted[k] = t;
				}
		cout << i << "\t";
		for(int m = 0 ; m < n ; m++)
			cout << sorted[m] << " ";
		cout << endl;
		cout << "\t";
		for(int m = 0 ; m < n ; m++)
			cout << di[m] << " ";
		cout << endl;
	}
	
	return 0;
}
