/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#ifndef INCL_DOCKHPP
#include "dock.hpp"
#define INCL_DOCKHPP
#endif

extern float **rot_angles;
extern int num_rotations;

#ifndef FFT_TRANS_SCORE
typedef struct {
	float evdw, particlep, evdw_real, evdw_imag , score;

#ifdef SEPARATE_VDW_ATTR_REPUL
	float evdw_attr, evdw_repul_core;
#endif

	unsigned int index, rotindex;
} transformationscore;
#define FFT_TRANS_SCORE
#endif

extern long generation_stats[NUM_GENERATION_STATS];
extern int numprocs, procid;
extern char* node_tmp_dir;
extern Object *receptor, *ligand;
extern string rpdbcode, rchains, lpdbcode, lchains, refpdbcode, reflchains, refrchains;

extern transformationscore *node_result,*rotation_scores;
extern MKL_LONG gridsize[3];
extern unsigned int size;
extern float sqrt_size;
extern string SPACED_ROTATIONS;

extern short num_particlep_arrays;
extern MKL_Complex8 *rec_shape, *lig_shape, **rec_particlepfft, **lig_particlepgrid, *particlep_sum;
extern float grid_spacing;
extern unsigned int num_node_transforms;

extern void match_rotation(unsigned int rotation_index, Transformation *tr);

void write_results_tofile(unsigned int rotation_index){
	fstream transout;
	char tfilename[512];
	int num_written=0;
	sprintf(tfilename, "%s/%s/%d/restrans%d",node_tmp_dir,refpdbcode.c_str(),procid,rotation_index);
	//sprintf(tfilename, "restrans%d",rotation_index);
	transout.open(tfilename,ios::binary|ios::out);
	//transout.setf(ios::fixed, ios::floatfield);
	for(unsigned int index = 0; index < size; index++){
		if(rotation_scores[index].evdw > -10000.0 && (ABS(rotation_scores[index].evdw_real) > 0.5 || ABS(rotation_scores[index].evdw_imag) > 0.5)){
			transout << rotation_scores[index].particlep << " " << rotation_scores[index].evdw
			/*<< " " << rotation_scores[index].evdw_real << " " << rotation_scores[index].evdw_imag*/
			<< " " << index << endl;
			//transout << rotation_scores[index].particlep << " " << rotation_scores[index].evdw << endl;
			num_written++;
		}

	}
	transout.close();

	char command[512];
	sprintf(command, "gzip %s",tfilename);
	int ret = system(command);
	*out << command << " " << ret << endl;

	sprintf(command, "cp %s.gz trans/",tfilename);
	ret = system(command);
	*out << command << " " << ret << endl;

	*out << "wrote results to file rotation " << rotation_index << " " << num_written << endl; out->flush();
	generation_stats[1] += num_written;
}

Vector get_translation(transformationscore *trscore, Transformation *tr){
	float x = (int) (trscore->index/(gridsize[1]*gridsize[2]));
	float y = ((trscore->index/gridsize[2]) % gridsize[1]);
	float z = (trscore->index % gridsize[2]);

	if(x >= gridsize[0]/2)	x = x - gridsize[0];
	if(y >= gridsize[1]/2)	y = y - gridsize[1];
	if(z >= gridsize[2]/2)	z = z - gridsize[2];

	bool printlog=false;
	if(printlog){
		*out << trscore->index << " " << x << "," << y << "," << z << " " << tr->translation->x << "," << tr->translation->y << "," << tr->translation->z << endl;

		Vector v = *(tr->translation) - *(ligand->c->center);
		*out << trscore->index << " v1 " << v.x << "," << v.y << "," << v.z << endl;

		v = tr->rotate(v);
		*out << trscore->index << " v2 " << v.x << "," << v.y << "," << v.z << endl;

		v =  *(ligand->grid_origin) - (v + *(receptor->grid_origin) + *(receptor->c->center));
		*out << trscore->index << " v3 " << v.x << "," << v.y << "," << v.z << endl;
	}

	Vector v = *(ligand->c->center) +tr->inverse_rotate(*(ligand->grid_origin) - (Vector(-x,-y,-z)*grid_spacing + *(receptor->grid_origin) + *(receptor->c->center)));

	return v;
}

/*
 * Matlab read is faster if the input files are fragmented
 */
void write_tofile(MKL_Complex8 *grid, string filename){
	fstream fout(filename.c_str(),fstream::out);

	for(int i =0; i < gridsize[0]; i++){
		for(int j =0; j < gridsize[1]; j++)
			for(int k =0; k < gridsize[2]; k++){
				unsigned int index = (i*gridsize[1] + j)*gridsize[2] + k;
				unsigned int invindex = ((gridsize[0] - 1 - i)*gridsize[1] + (gridsize[1] - 1 - j))*gridsize[2] + (gridsize[2] - 1 - k);
				fout << index << " " << grid[index].real << " " << grid[index].imag << "\t" << grid[invindex].real << " " << grid[invindex].imag << endl;
			}
	}

    fout.close();
}

void read_rotations(){
	string filename = string(getenv(string("HOME").c_str())) + "/" + string(DOCK_DIR) + string(SPACED_ROTATIONS);
	char buf[8192];
	num_rotations = 0;
	fstream frotations(filename.c_str());
    while(frotations.good()){
    	frotations.getline(buf,8192);
    	if(frotations.gcount() > 0)
    		num_rotations++;
    }
	rot_angles = (float**) malloc(sizeof(float*)*num_rotations);
	for(int i = 0 ; i < num_rotations; i++)	rot_angles[i] = (float*) malloc(sizeof(float)*3);

    num_rotations = 0;
    frotations.clear();
    frotations.seekg(ios_base::beg);
    while(frotations.good()){
    	frotations.getline(buf,8192);
    	if(frotations.gcount() > 0){
    		stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
			ss >> rot_angles[num_rotations][0];
			ss >> rot_angles[num_rotations][1];
			ss >> rot_angles[num_rotations][2];
			num_rotations++;
    	}
    }
    frotations.close();
}

void match_rotation(unsigned int rotation_index){
	*out << "match rotation " << rotation_index << endl; out->flush();
	Transformation *tr = new Transformation(rot_angles[rotation_index][0],rot_angles[rotation_index][1],rot_angles[rotation_index][2],rotation_index);

	match_rotation(rotation_index, tr);
}

Transformation *convert_transformation(unsigned int translation, unsigned int rotindex){
	Transformation *tr = new Transformation(rot_angles[rotindex][0],rot_angles[rotindex][1], rot_angles[rotindex][2],0);

	float x = translation/(gridsize[1]*gridsize[2]);
	float y = ((translation/gridsize[2]) % gridsize[1]);
	float z = (translation % gridsize[2]);

	if(x >= gridsize[0]/2)	x = x - gridsize[0];
	if(y >= gridsize[1]/2)	y = y - gridsize[1];
	if(z >= gridsize[2]/2)	z = z - gridsize[2];

	*(tr->translation) = *(ligand->c->center) +tr->inverse_transform(*(ligand->grid_origin) - (Vector(-x,-y,-z)*grid_spacing + *(receptor->grid_origin) + *(receptor->c->center)));
	Reference_Frame* rf_invtr = Reference_Frame::invert(tr);

	Transformation *invtr = new Transformation(new Vector(rf_invtr->translation), new Vector(rf_invtr->ex), new Vector(rf_invtr->ey), 1.0, 0, 0);

	delete tr;
	delete rf_invtr;
	return invtr;
}


Transformation *read_transformation(char* buf){
	char *current = buf;
	float particlep, evdw;
	unsigned int translation, rotation;
	memcpy(&particlep,current,sizeof(float));
	current += sizeof(float);
	memcpy(&evdw,current,sizeof(float));
	current += sizeof(float);
	memcpy(&translation,current,sizeof(unsigned int));
	current += sizeof(unsigned int);
	memcpy(&rotation,current,sizeof(unsigned int));
	current += sizeof(unsigned int);

	Transformation *tr = convert_transformation(translation, rotation);
	tr->eSolvation = particlep;
	tr->eVdw = evdw;
	//tr->votes = rotation;
	//tr->frame_number = translation;
	//*out << particlep << " " << evdw << " " << translation << " " << rotation << endl;
	//tr->print_details(out,TN_BASIC);
	return tr;
}

void write_nodetransforms_tofile(int state, Transformation *reftr){
	// delete arrays to create space
	if(reftr==NULL){
		delete(rec_shape);	delete(lig_shape);
		delete(rotation_scores);
		if(state==FFT_GENERATE_MATCHES_ATOMP){
			delete(particlep_sum);
			for(int ti = 0; ti < num_particlep_arrays; ti++){	delete(rec_particlepfft[ti]);	delete(lig_particlepgrid[ti]); }
		}
	}

	*out << node_result << endl; out->flush();
	fstream transout;
	char tfilename[512];
	sprintf(tfilename, "%s/%s/%d/trans%d",node_tmp_dir,refpdbcode.c_str(),procid,0);
	transout.open(tfilename,ios::binary|ios::out);

	Transformation *tr, *invtr;
	Reference_Frame *rf_invtr;
	vector<Transformation *> tr_trace, invtr_trace;
	vector<Reference_Frame *> rf_invtr_trace;
	for(int i = 0; i < num_node_transforms; i++){
		transformationscore trscore = node_result[i];
		if(i<10)	*out << trscore.evdw << " " << trscore.evdw_real << " " << trscore.evdw_imag << endl;

		/* meaning of a transformation as generated
		 * 	translate the ligand such that its center is the origin
		 * 	rotate using euler angles
		 * 	translate such that coordinates are positive
		 * 	translate as specified by the result of fft
		 *
		 * the receptor was translated such that its center was the origin and again translated such that the coordinates were positive
		 */

		if(reftr == NULL)
			tr = new Transformation(rot_angles[trscore.rotindex][0],rot_angles[trscore.rotindex][1], rot_angles[trscore.rotindex][2],i);
		else
			tr = new Transformation(new Vector(0,0,0), new Vector(*(reftr->ex)), new Vector(*(reftr->ey)), 1.0, 0, 0);

		// write the pdbfiles for inspection
		if(false && trscore.index == 809962){
			//*out << "check" << endl; out->flush();
			float x = trscore.index/(gridsize[1]*gridsize[2]);
			float y = ((trscore.index/gridsize[2]) % gridsize[1]);
			float z = (trscore.index % gridsize[2]);

			if(x >= gridsize[0]/2)	x = x - gridsize[0];
			if(y >= gridsize[1]/2)	y = y - gridsize[1];
			if(z >= gridsize[2]/2)	z = z - gridsize[2];

			Transformation *id = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
			*(id->translation) = *(receptor->c->center) + *(receptor->grid_origin);
			id->write_as_pdb(receptor->c, receptor->c->chains, true, "rec_check.pdb", true);

			*(id->translation) = *(ligand->c->center) +*(ligand->grid_origin);
			id->write_as_pdb(ligand->c, ligand->c->chains, true, "idlig_check.pdb",true);

			*(tr->translation) = Vector(0,0,0);
			*(tr->translation) = *(ligand->c->center) +tr->inverse_transform(*(ligand->grid_origin));
			tr->write_as_pdb(ligand->c, ligand->c->chains, true, "trlig_check.pdb",true);

			*(tr->translation) = Vector(0,0,0);
			*(tr->translation) = *(ligand->c->center) +tr->inverse_transform(*(ligand->grid_origin)-Vector(-x,-y,-z)*grid_spacing);
			tr->write_as_pdb(ligand->c, ligand->c->chains, true, "trlig_vs_rec_check.pdb",true);

			*(tr->translation) = Vector(0,0,0);
			*(tr->translation) = *(ligand->c->center) +tr->inverse_transform(*(ligand->grid_origin)-Vector(-x,-y,-z)*grid_spacing - *(receptor->grid_origin) - *(receptor->c->center));
			tr->write_as_pdb(ligand->c, ligand->c->chains, true, "trlig_vs_rec.pdb",true);

			*(tr->translation) = Vector(0,0,0);
		}

		*(tr->translation) = get_translation(&trscore,tr);

		//*out << "before invert" << endl; out->flush();
		rf_invtr = Reference_Frame::invert(tr);
		//*out << "after invert" << endl; out->flush();
		invtr = new Transformation(rf_invtr->translation, rf_invtr->ex, rf_invtr->ey, 1.0, 0, i);
		invtr->eVdw = trscore.evdw;
#ifdef SEPARATE_VDW_ATTR_REPUL
		invtr->sEvolution_interface = trscore.evdw_attr;
#endif
		invtr->votes = trscore.rotindex;
		invtr->eResiduepair = trscore.index;

		if(state==FFT_GENERATE_MATCHES_VDW)
			invtr->eSolvation = trscore.evdw;
		else {
			invtr->eSolvation = trscore.score;
			invtr->eElectrostatic = trscore.particlep;
		}

		invtr->frame_number = trscore.index;
		invtr->num_contacts = 0;

		invtr->write_binary(&transout,TN_BASIC);
		if(i<10) invtr->print_details(out,TN_BASIC); out->flush();

		delete tr;
		delete rf_invtr;
		//delete invtr;
		//invtr_trace.push_back(invtr);
	}
	transout.close();

	// delete - deletion in the loop is causing crashes
	for(vector<Transformation*>::iterator itr = tr_trace.begin(); itr != tr_trace.end(); itr++)
		delete ((Transformation*) *itr);
	for(vector<Transformation*>::iterator itr = invtr_trace.begin(); itr != invtr_trace.end(); itr++)
		delete ((Transformation*) *itr);
	for(vector<Reference_Frame*>::iterator itr = rf_invtr_trace.begin(); itr != rf_invtr_trace.end(); itr++)
		delete ((Reference_Frame*) *itr);

	char command[512];
	//write to file to not lose work if things crash
	/*sprintf(command, "gzip %s",tfilename);
	int ret = system(command);
	*out << command << " " << ret << endl;

	sprintf(command, "cp %s.gz trans/",tfilename,refpdbcode.c_str());
	ret = system(command);
	*out << command << " " << ret << endl;

	// collect transforms assumes unzipped file
	sprintf(command, "gunzip %s",tfilename);
	ret = system(command);
	*out << command << " " << ret << endl;
	*/

	// delete restrans
	sprintf(command , "rm %s/%s/%d/restrans*",node_tmp_dir,refpdbcode.c_str(),procid);
	int ret = system(command);
	*out << command << " " << ret << endl;
}


