/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#ifndef INCL_DOCKHPP
#include "dock.hpp"
#define INCL_DOCKHPP
#endif

vector<Transformation*> node_transformations;
extern long generation_stats[NUM_GENERATION_STATS];
hash_map<unsigned int,long,hash<unsigned int>,eqint> pieces;

float cmr_rmax;
unsigned short num_cmr_x_divisions,num_cmr_y_divisions,num_cmr_z_divisions;
hash_map<long,int,hash<long>,eqlong> cmr_frequencies;
hash_map<long,vector<Transformation*>,hash<long>,eqlong> transformations_by_cell;

int cell_max_frequency=0;
int box[6];

hash_map<long,Transformation*,hash<long>,eqlong> hashed_transformations;
hash_map<const char*,MultiTransformation*,hash<const char*>,eqstr> combinations;
vector<MultiTransformation*> clustered_combinations;

vector<string> model_ids;

hash_map<long, long, hash<long>, eqlong> receptor_vs_reference, ligand_vs_reference, reference_vs_receptor, reference_vs_ligand;
//hash_map<long, long, hash<long>, eqlong> refreceptor_vs_refligand, refligand_vs_refreceptor;
vector<Transformation*> receptor_symmetry, ligand_symmetry, ligand_vs_receptor_symmetry;

hash_map<const char* ,hash_map<char, vector<Sequence*>, hash<char>, eqint>,hash<const char*>,eqstr> homologue_sequences;

short raacidcindexstart, laacidcindexstart;
int num_species=0;
Species **species;

string **hosts;
extern string *host;
int num_processes_on_node;
char buff[BUFSIZE], command[8192];
char* node_tmp_dir;
extern short success;

time_t start_time, current_time;

extern int numprocs, procid;
extern bool masterprocessonnode;
extern MPI_Status mpistat; 
extern bool **aacontact_core, **aacontact_rim, *aarcontact, *aalcontact;
extern float **sas_b, **sas_bprime, **sas_fraclost;
extern int state;
extern char *tag,*transformations_file, local_transformations_file[512],	*combinations_file, local_combinations_file[512], scratch_dir[512];
extern ostream *out;
extern Object *receptor, *ligand;
extern Complex *reference, *referenceH;
extern short symmetry;
extern string rpdbcode, rchains, lpdbcode, lchains, refpdbcode, reflchains, refrchains;

extern short blosum62[25][25];
extern float blosum62_lambda;
extern double blosum62_rates[21][21];

TransformationAndTag::TransformationAndTag(Transformation*tr,unsigned int n){
	this->tr = tr;
	tag = n;
}

TransformationAndTag::~TransformationAndTag(){
	delete tr;
}

extern Vector* sasa_samplepoints;

extern string piedock_home;

/*
 * Center the object and padd zeros on the sides upto the padding_diameter/2
 * Assume that the transformation provided is just a rotation
 * 
 * R o L (t) = Integral R(x) L (t-x) = Integral R(t-x) L(x)
 * we need Integral R(x) L(x-t) = Integral R(x-t) L(x)
 * so we need to flip one of R or L, we are flippping the receptor
 * 
 */
void Object::build_fft_vdw_grid(float grid_spacing, float padding_diameter, MKL_Complex8 **fftgrid, MKL_LONG *gridsize, Reference_Frame *tr, bool isreceptor){
	float minx, maxx, miny, maxy, minz, maxz, maxr;
			
	// rotations keep the center invariant
	Vector center = Vector(c->center);
	
	int aindex = 0;
	for(int i = 0 ; i < c->num_atoms; i++){
		Atom *a = c->atom[i];
		Vector v = *(a->position) - center;	// set grid_origin such that it is independent of rotation
		//Vector v = tr->transform(*(a->position) - center);
		if(aindex++ == 0){
			minx = maxx = v.x;
			miny = maxy = v.y;
			minz = maxz = v.z;
			maxr = a->radius;
		}
		
		maxx = (v.x > maxx)? v.x : maxx;
		minx = (v.x < minx)? v.x : minx;
		maxy = (v.y > maxy)? v.y : maxy;
		miny = (v.y < miny)? v.y : miny;
		maxz = (v.z > maxz)? v.z : maxz;
		minz = (v.z < minz)? v.z : minz;
		maxr = (a->radius > maxr) ? a->radius : maxr;
		
		a->is_buried = (a->sasa <= 0.32*PI*a->radius*a->radius) || a->is_buried;
	}

	float spread = 2*maxr + 2*probe_radius + padding_diameter + 10.0;	// assume range of atomic potentials/electrostatics less than 10
	float xextent = maxx - minx, yextent = maxy - miny, zextent = maxz - minz;
	*out << "extent " << xextent << " " << yextent << " " << zextent << " max r " << maxr << endl; out->flush();
	
	unsigned int size;
	if(gridsize[0] == 0){
		float maxextent = max(xextent, (max(yextent,zextent)));
		gridsize[0] = ceil((spread+xextent)/grid_spacing);
		gridsize[1] = ceil((spread+yextent)/grid_spacing);
		gridsize[2] = ceil((spread+zextent)/grid_spacing);
		int maxsize = ceil((spread+maxextent)/grid_spacing); // I think cubic grids lead to higher numerical stability in fft computations
		if(maxsize%2 == 1)	maxsize++;
		gridsize[0] = gridsize[1] = gridsize[2] = maxsize; 
		
		size = gridsize[0] * gridsize[1] * gridsize[2];
		(*fftgrid) = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
		*out << "size " << size << " " << sizeof(MKL_Complex8) << " " << (*fftgrid) << endl;
	}
	size = gridsize[0] * gridsize[1] * gridsize[2];
	for(int i = 0; i < size; i++)
		((*fftgrid)[i]).real = ((*fftgrid)[i]).imag = 0.0;
	
	grid_origin = new Vector(minx-spread/2.0,miny-spread/2.0,minz-spread/2.0);
	
  for(short iter = 0; iter < 2; iter++){			
	for(int i = 0 ; i < c->num_atoms; i++){
		Atom *a = c->atom[i];
		Vector taposition = tr->transform(*(a->position) - center) - *grid_origin;
		int vx = (int) (taposition.x/grid_spacing);
		int vy = (int) (taposition.y/grid_spacing);
		int vz = (int) (taposition.z/grid_spacing);

		unsigned int index;
		float radius = a->radius;
		if(iter == 0){
			if(!a->is_buried)
				radius += probe_radius;
		} else {
			if(a->is_buried)
				radius = radius + INTERIOR_ATOM_SPREAD;
		}

		int minx,maxx,miny,maxy,minz,maxz;
		minx = maxx = vx;
		miny = maxy = vy;
		minz = maxz = vz;

	  if((iter == 0 && !a->is_buried) || (iter == 1)){
		int level = 0;
		float d=0;
		bool intersects_surface = true;
		while(intersects_surface){
			intersects_surface = false;
			bool intersectsxmin,intersectsxmax,intersectsymin,intersectsymax,intersectszmin,intersectszmax;
			for(int x = minx; x <= maxx; x++){
				for(int y = miny; y <= maxy; y++){
					for(int z = minz; z <= maxz; z++){
						Vector grid_center = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) + 0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing);
						bool intersects_cell = false;
						if( x == minx || x == maxx || y == miny || y == maxy || z == minz || z == maxz ){
							d = Vector::distance(taposition,grid_center);
							intersects_cell = (d <= radius) || (level == 0);
							if(isreceptor && !intersects_cell && d < radius +grid_spacing){
								short num_subcells_insersect=0, cutoff=90;
								for(int ci =-2; ci <=2 && !intersects_cell; ci++)
									for(int cj =-2; cj <=2 && !intersects_cell; cj++)
										for(int ck =-2; ck <=2 && !intersects_cell; ck++){
											float dp;
											Vector v = Vector( (((float) x) + (ci+2)/4.0)*grid_spacing, (((float) y) + (cj+2)/4)*grid_spacing, (((float) z) + (ck+2)/4)*grid_spacing);
											if((dp = Vector::distance(taposition,v)) <= radius)	num_subcells_insersect++;
											if(a->is_buried || a->isbbatom)
												intersects_cell = intersects_cell || (dp <= radius);
											else
												intersects_cell = intersects_cell || (num_subcells_insersect>=cutoff);
											d = minimum(d,dp);
										}
							}
							intersects_surface = intersects_surface || intersects_cell;

							if(intersects_cell){
								unsigned int index = (x*gridsize[1] + y)*gridsize[2] + z;
								if(level == 0)	d = 0;
								if(iter == 0){
									if(!a->is_buried)
										(*fftgrid)[index].real = SURFACE;
								} else { 
									/*if(a->is_buried){
										if(d <= 0.9*a->radius)
											(*fftgrid)[index].real = INTERIOR;
										else 
											(*fftgrid)[index].real = INTERMEDIATE;
									} else {
										if(a->isbbatom && d <= 0.6*a->radius)
											(*fftgrid)[index].real = INTERIOR_BB;
										if(!a->isbbatom && (d < 0.4*a->radius) && ((*fftgrid)[index].real != INTERIOR_BB) && ((*fftgrid)[index].real != INTERIOR))
											(*fftgrid)[index].real = INTERMEDIATE;
									}*/
									if(a->is_buried){
										if(d <= 0.6*a->radius || ((*fftgrid)[index].real != INTERMEDIATE && (*fftgrid)[i].real != -1))
											(*fftgrid)[index].real = INTERIOR;
									} else {
										if(a->isbbatom){
											if(d <= 0.6*a->radius)
												(*fftgrid)[index].real = INTERIOR_BB;
											else if((*fftgrid)[index].real != INTERIOR_BB){
												if(((*fftgrid)[index].real == SURFACE) && (d > 0.8*radius))
													(*fftgrid)[index].real = -1;
												else
													(*fftgrid)[index].real = INTERMEDIATE;
											}
										}
									}
								}

								if( x == minx)
									intersectsxmin = true;
								if( x == maxx)
									intersectsxmax = true;
								if( y == miny)
									intersectsymin = true;
								if( y == maxy)
									intersectsymax = true;
								if( z == minz)
									intersectszmin = true;
								if( z == maxz)
									intersectszmax = true;
							}
						}
					}
				}
			}
			if(intersectsxmin && minx > 0)
				minx--;
			if(intersectsxmax && maxx < gridsize[0] - 1)
				maxx++;
			if(intersectsymin && miny > 0)
				miny--;
			if(intersectsymax && maxy < gridsize[1] - 1)
				maxy++;
			if(intersectszmin && minz > 0)
				minz--;
			if(intersectszmax && maxz < gridsize[2] - 1)
				maxz++;

			level++;
			//*out << a->index << " radius " << radius << " " << minx << ":" << maxx << " " << miny << ":" << maxy << " " << minz << ":" << maxz << " level " << level << endl;
		}
	  }
		//*out << a->index << " level " << level << endl;
	}
  }
	
	// SURFACE cells
	// MSMS might have mistakes in detecting voids inside protein	
	/*for(int i = 0 ; i < num_faces; i++){
		Vector v = tr->transform(*(face[i]->point) - center) - *grid_origin;
		unsigned short vx = (unsigned short) (v.x/grid_spacing);
		unsigned short vy = (unsigned short) (v.y/grid_spacing);
		unsigned short vz = (unsigned short) (v.z/grid_spacing);
		unsigned int index = (vx*gridsize[1] + vy)*gridsize[2] + vz;
		(*fftgrid)[index].real = SURFACE;
	}
	
	for(vector<Vector *>::iterator citr =  c->triangle_centroids.begin(); citr != c->triangle_centroids.end(); citr++){
		Vector v = tr->transform(*((Vector*) *citr) - center) - *grid_origin;
		unsigned short vx = (unsigned short) (v.x/grid_spacing);
		unsigned short vy = (unsigned short) (v.y/grid_spacing);
		unsigned short vz = (unsigned short) (v.z/grid_spacing);
		unsigned int index = (vx*gridsize[1] + vy)*gridsize[2] + vz;
		(*fftgrid)[index].real = SURFACE;
	}*/
	
  // build a more extensive grid on the receptor
  if(isreceptor){
	//use the atom exposure flags computed in surface area calculation to mark solvent accessible surface
	for(int i = 0 ; i < c->num_atoms; i++){
		Atom *a = c->atom[i];
		if(a->sasa > 0 && !a->is_buried){
			for(int j = 0; j < 8; j++)
				for(int k = 0; k < 32; k++)
					if((a->pmask[j]>>k)&0x00000001 >0){
						Vector v = tr->transform(*(a->position) + sasa_samplepoints[j]*(a->radius+probe_radius) - center) - *grid_origin;
						unsigned short vx = (unsigned short) (v.x/grid_spacing);
						unsigned short vy = (unsigned short) (v.y/grid_spacing);
						unsigned short vz = (unsigned short) (v.z/grid_spacing);
						unsigned int index = (vx*gridsize[1] + vy)*gridsize[2] + vz;
						(*fftgrid)[index].real = SURFACE;
					}
		}
	}
  }
  
	// set up the grid
	unsigned int num_surface_cells=0, num_intermediate_cells=0, num_interior_cells=0;
	for(int i = 0; i < size; i++){
		if((*fftgrid)[i].real == SURFACE){
			(*fftgrid)[i].real = 1.0;
			(*fftgrid)[i].imag = 0.0;
			num_surface_cells++;
		} else if((*fftgrid)[i].real == INTERMEDIATE){
			(*fftgrid)[i].real = 0.0;
			(*fftgrid)[i].imag = INTERMEDIATE_IMAG;
			num_intermediate_cells++;
		} else if((*fftgrid)[i].real == INTERIOR || (*fftgrid)[i].real == INTERIOR_BB){
			(*fftgrid)[i].real = 0.0;
			(*fftgrid)[i].imag = INTERIOR_IMAG;
			num_interior_cells++;
		} else if((*fftgrid)[i].real == -1)
			(*fftgrid)[i].real = 0;
	}
	*out << "# cells interior " << num_interior_cells << " " << num_intermediate_cells << " " << num_surface_cells << endl;
}

/*
 * The value in a cell is the vdw attraction experienced by target particle at the corner of the cell
 * for convenience, the sigma of the target particle is taken to be sqrt(3.2*sigma) in the 12 part of the potential  
 */
void Object::build_fft_opls_vdw_grid(float grid_spacing, float padding_diameter, MKL_Complex8 **fftgrid, MKL_LONG *gridsize, Reference_Frame *tr, bool isreceptor){
	float minx, maxx, miny, maxy, minz, maxz, maxr;
			
	// rotations keep the center invariant
	Vector center = Vector(c->center);
	
	int aindex = 0;
	for(int i = 0 ; i < c->num_atoms; i++){
		Atom *a = c->atom[i];
		Vector v = *(a->position) - center;	// set grid_origin such that it is independent of rotation
		//Vector v = tr->transform(*(a->position) - center);
		if(aindex++ == 0){
			minx = maxx = v.x;
			miny = maxy = v.y;
			minz = maxz = v.z;
			maxr = a->radius;
		}
		
		maxx = (v.x > maxx)? v.x : maxx;
		minx = (v.x < minx)? v.x : minx;
		maxy = (v.y > maxy)? v.y : maxy;
		miny = (v.y < miny)? v.y : miny;
		maxz = (v.z > maxz)? v.z : maxz;
		minz = (v.z < minz)? v.z : minz;
		maxr = (a->radius > maxr) ? a->radius : maxr;
		
		a->is_buried = (a->sasa <= 0.32*PI*a->radius*a->radius) || a->is_buried;
	}

	float spread = 2*maxr + 2*probe_radius + padding_diameter + 10.0;	// assume range of atomic potentials/electrostatics less than 10
	float xextent = maxx - minx, yextent = maxy - miny, zextent = maxz - minz;
	*out << "extent " << xextent << " " << yextent << " " << zextent << " max r " << maxr << endl; out->flush();
	
	unsigned int size;
	if(gridsize[0] == 0){
		float maxextent = max(xextent, (max(yextent,zextent)));
		gridsize[0] = ceil((spread+xextent)/grid_spacing);
		gridsize[1] = ceil((spread+yextent)/grid_spacing);
		gridsize[2] = ceil((spread+zextent)/grid_spacing);
		int maxsize = ceil((spread+maxextent)/grid_spacing); // I think cubic grids lead to higher numerical stability in fft computations
		if(maxsize%2 == 1)	maxsize++;
		gridsize[0] = gridsize[1] = gridsize[2] = maxsize; 
		
		size = gridsize[0] * gridsize[1] * gridsize[2];
		(*fftgrid) = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
		*out << "size " << size << " " << sizeof(MKL_Complex8) << " " << (*fftgrid) << endl;
	}
	size = gridsize[0] * gridsize[1] * gridsize[2];
	for(int i = 0; i < size; i++)
		((*fftgrid)[i]).real = ((*fftgrid)[i]).imag = 0.0;
	
	grid_origin = new Vector(minx-spread/2.0,miny-spread/2.0,minz-spread/2.0);
	
	int nummarkings=0;	
	for(int i = 0 ; i < c->num_atoms; i++){
		Atom *a = c->atom[i];
		Vector taposition = tr->transform(*(a->position) - center) - *grid_origin;
		int vx = (int) (taposition.x/grid_spacing);
		int vy = (int) (taposition.y/grid_spacing);
		int vz = (int) (taposition.z/grid_spacing);

		float radius = 1.8*a->sigma;
		// ligand just label the cells containing the center of the atom
		if(!isreceptor)	radius=0;
		float radius_squared = radius*radius;
		
		int minx,maxx,miny,maxy,minz,maxz;
		minx = maxx = vx;
		miny = maxy = vy;
		minz = maxz = vz;

		int level = 0;
		bool intersects_surface = true;
		while(intersects_surface){
			intersects_surface = false;
			bool intersectsxmin,intersectsxmax,intersectsymin,intersectsymax,intersectszmin,intersectszmax;
			for(int x = minx; x <= maxx; x++){
				for(int y = miny; y <= maxy; y++){
					for(int z = minz; z <= maxz; z++){
						Vector corner_000 = Vector( (((float) x) )*grid_spacing, (((float) y) )*grid_spacing, (((float) z) )*grid_spacing);
						Vector grid_center = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) + 0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing);
						bool intersects_cell = false;
						if( x == minx || x == maxx || y == miny || y == maxy || z == minz || z == maxz ){
							float d,d2,d_2;
							intersects_cell = ((d2 = Vector::distance_squared(taposition,corner_000)) <= radius_squared) || (level == 0);
							intersects_surface = intersects_surface || intersects_cell;

							if(intersects_cell){
								unsigned int index = (x*gridsize[1] + y)*gridsize[2] + z;
								float factor = 0;								

								// trilinear interpolate
								if(!isreceptor){
									factor = a->sqrt_eps;
									Vector v = taposition * (1.0/grid_spacing);
									float wx[2],wy[2],wz[2];
									wx[0] = x+1.0 - v.x;
									wx[1] = v.x - x;
									wy[0] = y+1.0 - v.y;
									wy[1] = v.y - y;
									wz[0] = z+1.0 - v.z;
									wz[1] = v.z - z;
									
									for(int cci =0; cci <=1; cci++)
										for(int ccj =0; ccj <=1; ccj++)
											for(int cck =0; cck <=1; cck++){
												int nx = (x+cci)% gridsize[0];
												int ny = (y+ccj)% gridsize[1];
												int nz = (z+cck)% gridsize[2];
												unsigned int nindex = (nx*gridsize[1] + ny)*gridsize[2] + nz;
												float nfactor = factor *wx[cci]*wy[ccj]*wz[cck];
												((*fftgrid)[nindex]).real += nfactor;
											}
								} else {
									//float d6_inv = 1.0/(d2 * d2 * d2);
									//factor = (1.0 - 32.768 * a->sigma_cubed * d6_inv)* d6_inv;
									float d_scaled = sqrt(d2/(3.2*a->sigma));
 									factor = VDW_ATTR(d_scaled);
 									//if(a->cindex < 5)	cout << sqrt(d2) << " build_sigma " << a->sigma << " d scaled " << d_scaled <<  " vdw factor " << VDW_ATTR(d_scaled) << " " << VDW_REPUL(d_scaled) << endl;
									if(factor > 0){
										// 6-12 factor = 4 * a->sqrt_eps * a->sigma_cubed * factor;
										factor = 4 * a->sqrt_eps * factor;
										((*fftgrid)[index]).real += factor;
									} else {
										factor = VDW_REPUL(d_scaled);
										factor = 4 * a->sqrt_eps * factor;
										((*fftgrid)[index]).imag += -9.0*factor;
									}
								}

								nummarkings++;

								if( x == minx)
									intersectsxmin = true;
								if( x == maxx)
									intersectsxmax = true;
								if( y == miny)
									intersectsymin = true;
								if( y == maxy)
									intersectsymax = true;
								if( z == minz)
									intersectszmin = true;
								if( z == maxz)
									intersectszmax = true;
							}
						}
					}
				}
			}
			if(intersectsxmin && minx > 0)
				minx--;
			if(intersectsxmax && maxx < gridsize[0] - 1)
				maxx++;
			if(intersectsymin && miny > 0)
				miny--;
			if(intersectsymax && maxy < gridsize[1] - 1)
				maxy++;
			if(intersectszmin && minz > 0)
				minz--;
			if(intersectszmax && maxz < gridsize[2] - 1)
				maxz++;

			level++;
		}							
	}
	*out << "build fft opls_vdw_attr grid #markings " << nummarkings << endl; 
}

/* Evaluate the accuracy of an interpolation scheme; the input grids are the number of contacts per cell
*/
void Object::fft_check_opls_vdw_accuracy(float grid_spacing, MKL_Complex8 *fftgrid, MKL_LONG *gridsize){
	Vector fft_grid_origin = Vector(grid_origin);
	Vector center = Vector(c->center);
	Vector zero = Vector(0,0,0);
	
	preprocess_receptor();
	// grid_origin is now with respect to the atom contact grid
	
	unsigned int size = gridsize[0] * gridsize[1] * gridsize[2];
	float max_error = 0;
	
	cout << "atom neighbor grid " << grid_num_xdivisions << "," << grid_num_ydivisions << "," << grid_num_zdivisions << endl;
	for(int i = 0; i < size; i++){
		float cell_potential = (fftgrid[i]).real;
		float corner_potential[2][2][2];
		
		float avg_potential=0;
		for(int ci =0; ci <=1; ci++)
			for(int cj =0; cj <=1; cj++)
				for(int ck =0; ck <=1; ck++){
					int z = (i % gridsize[2]) + ck;
					int y = ((i / gridsize[2]) % gridsize[1]) + cj;
					int x = i/(gridsize[2] * gridsize[1]) + ci;
					if(x == gridsize[0])	x--;
					if(y == gridsize[1])	y--;
					if(z == gridsize[2])	z--;
					unsigned int index = (x*gridsize[1] + y)*gridsize[2] + z;
					
					corner_potential[ci][cj][ck] = (fftgrid[index]).real;
					avg_potential = (fftgrid[index]).real * 0.125;
				}//*/
				
		if(ABS(avg_potential) > 0){
			int z = (i % gridsize[2]) ;
			int y = ((i / gridsize[2]) % gridsize[1]) ;
			int x = i/(gridsize[2] * gridsize[1]) ;
			Vector gv = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) +0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing );
			
			gv = (gv + (center + fft_grid_origin));
			unsigned short* atom_neighbors[2];
			atom_neighbors[0] = atom_neighbors[1] = NULL;
			int num_atom_neighbors[2];
			unsigned int index = 0;
			
			gv = gv - *grid_origin;
			int cellx = (int) (gv.x/GRID_SPACING);
			int celly = (int) (gv.y/GRID_SPACING);
			int cellz = (int) (gv.z/GRID_SPACING);
	
			if(cellx >= 0 && cellx < grid_num_xdivisions && celly >= 0 && celly < grid_num_ydivisions && cellz >= 0 && cellz < grid_num_zdivisions){
				index = (ATOM_NEIGHBOR_GS_BY_GS*(cellx/ATOM_NEIGHBOR_GS_BY_GS)*grid_num_ydivisions + ATOM_NEIGHBOR_GS_BY_GS*(celly/ATOM_NEIGHBOR_GS_BY_GS))*grid_num_zdivisions + ATOM_NEIGHBOR_GS_BY_GS*(cellz/ATOM_NEIGHBOR_GS_BY_GS);
				
				if(grid[index] != NULL){
					GridCell *coarse_cell = grid[index]; 
						
					atom_neighbors[0] = coarse_cell->atom_overlap_neighbors;
					atom_neighbors[1] = coarse_cell->atom_contact_neighbors;
			
					num_atom_neighbors[0] = coarse_cell->num_atom_overlap_neighbors;
					num_atom_neighbors[1] = coarse_cell->num_atom_contact_neighbors;
				}
			}
			if(atom_neighbors[0] == NULL && atom_neighbors[1] == NULL)
				cout << gv.x << "," << gv.y << "," << gv.z << " " << " missing cell " << cellx << "," << celly << "," << cellz << " index " << (cellx*grid_num_ydivisions + celly)*grid_num_zdivisions + cellz << endl;
			
			// for almost each point in the cell find the potential
			for(int ci =-2; ci <=2; ci++)
				for(int cj =-2; cj <=2; cj++)
					for(int ck =-2; ck <=2; ck++){
						float point_potential = 0;
					
						//cout << i << " " << index << " " << ci << "," << cj << "," << ck << "\t";
						Vector v = Vector( (((float) x) + (ci+2)/4.0)*grid_spacing, (((float) y) + (cj+2)/4.0)*grid_spacing, (((float) z) + (ck+2)/4.0)*grid_spacing);
						
						for(unsigned short anli = 0; anli < 2; anli++)
							if(atom_neighbors[anli] != NULL)
								for(int ani = 0; ani < num_atom_neighbors[anli]; ani++){
									int racindex = atom_neighbors[anli][ani];
									Atom *a = c->atom[racindex];
									
									Vector taposition = (*(a->position) - center) - fft_grid_origin;
									float d2 = Vector::distance_squared(taposition,v);
									if(d2 <= 3.24*a->sigma*a->sigma){
										//float d6_inv = 1.0/(d2 * d2 * d2);
										//float factor = (1.0 - 32.768 * a->sigma_cubed * d6_inv)* d6_inv ;
										float d_scaled = sqrt(d2/(3.2*a->sigma));
 										float factor = VDW_ATTR(d_scaled);
 										//if(a->cindex < 5)	cout << sqrt(d2) << " sigma " << a->sigma << " d scaled " << d_scaled <<  " vdw factor " << factor << endl;
										if(factor >= 0){
											// 6-12 factor = 4 * a->sqrt_eps * a->sigma_cubed * factor;
											factor = 4 * a->sqrt_eps * factor;
											point_potential += factor;
										}
									}
								}
						
						float interpolated_potential = 0;
						// trilinear interpolation
						{
							float wx[2],wy[2],wz[2];
							wx[0] = (2.0-ci)/4.0;
							wx[1] = (2.0+ci)/4.0;
							wy[0] = (2.0-cj)/4.0;
							wy[1] = (2.0+cj)/4.0;
							wz[0] = (2.0-ck)/4.0;
							wz[1] = (2.0+ck)/4.0;
							
							for(int cci =0; cci <=1; cci++)
								for(int ccj =0; ccj <=1; ccj++)
									for(int cck =0; cck <=1; cck++){
										interpolated_potential += corner_potential[cci][ccj][cck]*wx[cci]*wy[ccj]*wz[cck]; 
									}
						}
						
						float error = point_potential - interpolated_potential;
						error = ABS(error);
						if(error > max_error){
							max_error = error;
							cout << "cell " << i << " max_error till now " << max_error << endl; 
						}
		  			}
		}
	}
	*grid_origin = fft_grid_origin;
}

void Object::build_fft_elec_grid(float grid_spacing, MKL_Complex8 **fftgrid, MKL_LONG *gridsize, Reference_Frame *tr, bool isreceptor){
	
}

/*
 * A residue aal of the ligand is in contact with a residue aar of the receptor if the centroid of aal is within contact of a heavy atom of aar 
 */
void Object::build_fft_residue_heavyatom_centroid_contact_grid(float grid_spacing, MKL_Complex8 **fftgrid, unsigned short num_residue_types, MKL_LONG *gridsize, Reference_Frame *tr, bool isreceptor){
	unsigned int size = gridsize[0] * gridsize[1] * gridsize[2];
	for(int ti = 0; ti < (num_residue_types+1)/2; ti++)
		for(int i = 0; i < size; i++)
			(fftgrid[ti][i]).real = (fftgrid[ti][i]).imag = 0.0;
	
	Vector center = Vector(c->center);
	
	int nummarkings=0;	
	for(int i = 0 ; i < c->num_aminoacids; i++){
		Aminoacid *aa = c->aminoacid[i];
		short particle_type = aa->type;
		if(isreceptor){
			if(particle_type >=0 && particle_type < num_residue_types){
			 	hash_map<unsigned int, float, hash<int>, eqint> contact_cells;
				for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = aa->atom.begin(); aitr != aa->atom.end(); aitr++){
					Atom *a = (Atom *) aitr->second;	
					Vector taposition = tr->transform(*(a->position) - center) - *grid_origin;
					int vx = (int) (taposition.x/grid_spacing);
					int vy = (int) (taposition.y/grid_spacing);
					int vz = (int) (taposition.z/grid_spacing);
			
					float radius;
#ifdef 	STEP_POTENTIAL 
					radius = AA_CUTOFF;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL
					radius = AA_SMTHP_CUTOFF;
#endif
		
					if(!isreceptor)	radius=0;
					float radius_squared = radius*radius;
		
					int minx,maxx,miny,maxy,minz,maxz;
					minx = maxx = vx;
					miny = maxy = vy;
					minz = maxz = vz;
			
					int level = 0;
					bool intersects_surface = true;
					while(intersects_surface){
						intersects_surface = false;
						bool intersectsxmin,intersectsxmax,intersectsymin,intersectsymax,intersectszmin,intersectszmax;
						for(int x = minx; x <= maxx; x++){
							for(int y = miny; y <= maxy; y++){
								for(int z = minz; z <= maxz; z++){
									Vector corner_000 = Vector( (((float) x) )*grid_spacing, (((float) y) )*grid_spacing, (((float) z) )*grid_spacing);
									bool intersects_cell = false;
									if( x == minx || x == maxx || y == miny || y == maxy || z == minz || z == maxz ){
										float d,d2,d_2;
										intersects_cell = ((d2 = Vector::distance_squared(taposition,corner_000)) <= radius_squared) || (level == 0);
										intersects_surface = intersects_surface || intersects_cell;
			
										if(intersects_cell){
											unsigned int index = (x*gridsize[1] + y)*gridsize[2] + z;
											float factor = 0;										
#ifdef 	STEP_POTENTIAL 			
											factor = 1.0;									
#endif
#ifdef LINEAR_SPLINE_POTENTIAL										 			
											if(d2 < AA_CUTOFF_SQUARED)	factor = 1.0;
											else{ float d=sqrt(d2);	factor = AA_SMTHP_FACTOR(d); }
#endif							
											if(contact_cells.count(index) == 0 || contact_cells[index] < factor)
												contact_cells[index] = factor;
											
											if( x == minx)
												intersectsxmin = true;
											if( x == maxx)
												intersectsxmax = true;
											if( y == miny)
												intersectsymin = true;
											if( y == maxy)
												intersectsymax = true;
											if( z == minz)
												intersectszmin = true;
											if( z == maxz)
												intersectszmax = true;
										}
									}
								}
							}
						}
						if(intersectsxmin && minx > 0)
							minx--;
						if(intersectsxmax && maxx < gridsize[0] - 1)
							maxx++;
						if(intersectsymin && miny > 0)
							miny--;
						if(intersectsymax && maxy < gridsize[1] - 1)
							maxy++;
						if(intersectszmin && minz > 0)
							minz--;
						if(intersectszmax && maxz < gridsize[2] - 1)
							maxz++;
			
						level++;
					}
				}
				
				for(hash_map<unsigned int, float, hash<int>, eqint>::iterator citr = contact_cells.begin(); citr != contact_cells.end(); citr++){
					unsigned int index = citr->first;
					float factor = citr->second;
					if(particle_type %2 == 0)
						fftgrid[particle_type/2][index].real += factor;
					else
						fftgrid[particle_type/2][index].imag += factor;

					nummarkings++;
				}					
			}
		} else if(aa->centroid != NULL){
			Vector taposition = tr->transform(*(aa->centroid) - center) - *grid_origin;
			int vx = (int) (taposition.x/grid_spacing);
			int vy = (int) (taposition.y/grid_spacing);
			int vz = (int) (taposition.z/grid_spacing);
			
			unsigned int index = (vx*gridsize[1] + vy)*gridsize[2] + vz;
			if(particle_type >=0 && particle_type < num_residue_types){
				float factor = 1.0;									
						
				// trilinear interpolate
				Vector v = taposition * (1.0/grid_spacing);
				float wx[2],wy[2],wz[2];
				wx[0] = vx+1.0 - v.x;
				wx[1] = v.x - vx;
				wy[0] = vy+1.0 - v.y;
				wy[1] = v.y - vy;
				wz[0] = vz+1.0 - v.z;
				wz[1] = v.z - vz;
				
				for(int cci =0; cci <=1; cci++)
					for(int ccj =0; ccj <=1; ccj++)
						for(int cck =0; cck <=1; cck++){
							int nx = (vx+cci)% gridsize[0];
							int ny = (vy+ccj)% gridsize[1];
							int nz = (vz+cck)% gridsize[2];
							unsigned int nindex = (nx*gridsize[1] + ny)*gridsize[2] + nz;
							float nfactor = factor *wx[cci]*wy[ccj]*wz[cck];
							if(particle_type %2 == 0)
								fftgrid[particle_type/2][nindex].real += nfactor;
							else
								fftgrid[particle_type/2][nindex].imag += nfactor; 
						}

				nummarkings++;
			}
		}
	}
	*out << "build fft residue heavyatom centroid contact grid #markings " << nummarkings << endl;
}

void Object::build_fft_residue_centroid_centroid_contact_grid(float grid_spacing, MKL_Complex8 **fftgrid, unsigned short num_residue_types, MKL_LONG *gridsize, Reference_Frame *tr, bool isreceptor){
	unsigned int size = gridsize[0] * gridsize[1] * gridsize[2];
	for(int ti = 0; ti < (num_residue_types+1)/2; ti++)
		for(int i = 0; i < size; i++)
			(fftgrid[ti][i]).real = (fftgrid[ti][i]).imag = 0.0;
	
	Vector center = Vector(c->center);
	
	int nummarkings=0;	
	for(int i = 0 ; i < c->num_aminoacids; i++){
	  Aminoacid *aa = c->aminoacid[i];
	  short particle_type = aa->type;
	  if(particle_type >= 0 && particle_type < num_residue_types && aa->centroid != NULL){
		Vector taposition = tr->transform(*(aa->centroid) - center) - *grid_origin;
		int vx = (int) (taposition.x/grid_spacing);
		int vy = (int) (taposition.y/grid_spacing);
		int vz = (int) (taposition.z/grid_spacing);

		float radius;
#ifdef 	STEP_POTENTIAL 
		radius = AA_CUTOFF;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL
		radius = AA_SMTHP_CUTOFF;
#endif
		
		if(!isreceptor)	radius=0;
		float radius_squared = radius*radius;
		
		int minx,maxx,miny,maxy,minz,maxz;
		minx = maxx = vx;
		miny = maxy = vy;
		minz = maxz = vz;

		int level = 0;
		bool intersects_surface = true;
		while(intersects_surface){
			intersects_surface = false;
			bool intersectsxmin,intersectsxmax,intersectsymin,intersectsymax,intersectszmin,intersectszmax;
			for(int x = minx; x <= maxx; x++){
				for(int y = miny; y <= maxy; y++){
					for(int z = minz; z <= maxz; z++){
						Vector corner_000 = Vector( (((float) x) )*grid_spacing, (((float) y) )*grid_spacing, (((float) z) )*grid_spacing);
					//	Vector grid_center = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) + 0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing);
						bool intersects_cell = false;
						if( x == minx || x == maxx || y == miny || y == maxy || z == minz || z == maxz ){
							float d,d2,d_2;
							intersects_cell = ((d2 = Vector::distance_squared(taposition,corner_000)) <= radius_squared) || (level == 0);
							intersects_surface = intersects_surface || intersects_cell;

							if(intersects_cell){
								unsigned int index = (x*gridsize[1] + y)*gridsize[2] + z;
								float factor = 0;								
#ifdef 	STEP_POTENTIAL 			
								factor = 1.0;									
#endif
#ifdef LINEAR_SPLINE_POTENTIAL										 			
								if(d2 < AA_CUTOFF_SQUARED)	factor = 1.0;
								else{ float d=sqrt(d2);	factor = AA_SMTHP_FACTOR(d); }
#endif							
								// trilinear interpolate
								if(!isreceptor){
									Vector v = taposition * (1.0/grid_spacing);
									float wx[2],wy[2],wz[2];
									wx[0] = x+1.0 - v.x;
									wx[1] = v.x - x;
									wy[0] = y+1.0 - v.y;
									wy[1] = v.y - y;
									wz[0] = z+1.0 - v.z;
									wz[1] = v.z - z;
									
									for(int cci =0; cci <=1; cci++)
										for(int ccj =0; ccj <=1; ccj++)
											for(int cck =0; cck <=1; cck++){
												int nx = (x+cci)% gridsize[0];
												int ny = (y+ccj)% gridsize[1];
												int nz = (z+cck)% gridsize[2];
												unsigned int nindex = (nx*gridsize[1] + ny)*gridsize[2] + nz;
												float nfactor = factor *wx[cci]*wy[ccj]*wz[cck];
												if(particle_type %2 == 0)
													fftgrid[particle_type/2][nindex].real += nfactor;
												else
													fftgrid[particle_type/2][nindex].imag += nfactor; 
											}
								} else {
									if(particle_type %2 == 0)
										fftgrid[particle_type/2][index].real += factor;
									else
										fftgrid[particle_type/2][index].imag += factor;
								}

								nummarkings++;

								if( x == minx)
									intersectsxmin = true;
								if( x == maxx)
									intersectsxmax = true;
								if( y == miny)
									intersectsymin = true;
								if( y == maxy)
									intersectsymax = true;
								if( z == minz)
									intersectszmin = true;
								if( z == maxz)
									intersectszmax = true;
							}
						}
					}
				}
			}
			if(intersectsxmin && minx > 0)
				minx--;
			if(intersectsxmax && maxx < gridsize[0] - 1)
				maxx++;
			if(intersectsymin && miny > 0)
				miny--;
			if(intersectsymax && maxy < gridsize[1] - 1)
				maxy++;
			if(intersectszmin && minz > 0)
				minz--;
			if(intersectszmax && maxz < gridsize[2] - 1)
				maxz++;

			level++;
		}
	  }							
	}
	*out << "build fft residue centroid centroid contact grid #markings " << nummarkings << endl;
}

/*
 * The extent for defining contact is different for centroid_centroid, bb_centroid and bb_bb, the number of contacts 
 * an amide group experiences at a position is different from a glutamate centroid, 
 * should double the number of arrays for storing the contacts
 * whereas potential does not require the doubling of space
 */
void Object::build_fft_residue_bkbn_centroid_bkbn_centroid_contact_potential_grid(float grid_spacing, MKL_Complex8 **fftgrid, unsigned short num_particle_types, float **potential, MKL_LONG *gridsize, 
 Reference_Frame *tr, bool isreceptor){
	unsigned int size = gridsize[0] * gridsize[1] * gridsize[2];
	for(int ti = 0; ti < (num_particle_types+1)/2; ti++)
		for(int i = 0; i < size; i++)
			(fftgrid[ti][i]).real = (fftgrid[ti][i]).imag = 0.0;
	
	Vector center = Vector(c->center);
	
	int nummarkings=0;	
	for(int i = 0 ; i < c->num_aminoacids; i++){
		Aminoacid *aa = c->aminoacid[i];
	   
	   //*out << "check aa " << aa->index << endl; out->flush();
		for(int aapi = 0; aapi < 3; aapi++){
			Vector *v = NULL;
			short particle_type;
			switch(aapi){
				case 0 :
					v = (aa->centroid);
					particle_type = aa->type;
					break;
				case 1 :
					if(aa->amide_nitrogen != NULL)
						v = aa->amide_nitrogen->position;
					particle_type = 20;
					break;
				case 2:
					if(aa->carbonyl_oxygen != NULL)
						v = aa->carbonyl_oxygen->position;
					particle_type = 21;
					break;
			}
			if(particle_type >= 0 && particle_type < num_particle_types && v != NULL){
				Vector taposition = tr->transform(*v - center) - *grid_origin;
				int vx = (int) (taposition.x/grid_spacing);
				int vy = (int) (taposition.y/grid_spacing);
				int vz = (int) (taposition.z/grid_spacing);
		
				float radius;
#ifdef 	STEP_POTENTIAL
				radius = AA_CUTOFF;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL
				radius = AA_SMTHP_CUTOFF;
#endif
		
				if(!isreceptor)	radius=0;
				float radius_squared = radius*radius;
		
				int minx,maxx,miny,maxy,minz,maxz;
				minx = maxx = vx;
				miny = maxy = vy;
				minz = maxz = vz;
		
				int level = 0;
				bool intersects_surface = true;
				while(intersects_surface){
					intersects_surface = false;
					bool intersectsxmin,intersectsxmax,intersectsymin,intersectsymax,intersectszmin,intersectszmax;
					for(int x = minx; x <= maxx; x++){
						for(int y = miny; y <= maxy; y++){
							for(int z = minz; z <= maxz; z++){
								Vector corner_000 = Vector( (((float) x) )*grid_spacing, (((float) y) )*grid_spacing, (((float) z) )*grid_spacing);
							//	Vector grid_center = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) + 0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing);
								bool intersects_cell = false;
								if( x == minx || x == maxx || y == miny || y == maxy || z == minz || z == maxz ){
									float d,d2,d_2;
									intersects_cell = ((d2 = Vector::distance_squared(taposition,corner_000)) <= radius_squared) || (level == 0);
									intersects_surface = intersects_surface || intersects_cell;
		
									if(intersects_cell){
										unsigned int index = (x*gridsize[1] + y)*gridsize[2] + z;
										float factor = 1.0;					

										// trilinear interpolate
										if(!isreceptor){
											Vector v = taposition * (1.0/grid_spacing);
											float wx[2],wy[2],wz[2];
											wx[0] = x+1.0 - v.x;
											wx[1] = v.x - x;
											wy[0] = y+1.0 - v.y;
											wy[1] = v.y - y;
											wz[0] = z+1.0 - v.z;
											wz[1] = v.z - z;
											
											for(int cci =0; cci <=1; cci++)
												for(int ccj =0; ccj <=1; ccj++)
													for(int cck =0; cck <=1; cck++){
														int nx = (x+cci)% gridsize[0];
														int ny = (y+ccj)% gridsize[1];
														int nz = (z+cck)% gridsize[2];
														unsigned int nindex = (nx*gridsize[1] + ny)*gridsize[2] + nz;
														float nfactor = factor *wx[cci]*wy[ccj]*wz[cck];
														if(particle_type %2 == 0)
															fftgrid[particle_type/2][nindex].real += nfactor;
														else
															fftgrid[particle_type/2][nindex].imag += nfactor; 
													}
										} else {
											for(int tj = 0; tj < num_particle_types; tj++){
												factor = 0.0;
#ifdef 	STEP_POTENTIAL 			
												if(particle_type < 20 && tj < 20)	factor = 1.0;
												else if((particle_type < 20 && tj >= 20) || (particle_type >= 20 && tj < 20)){
													if(d2 < BS_CUTOFF_SQUARED)	factor = 1.0;
												} else {
													if(d2 < BB_CUTOFF_SQUARED)	factor = 1.0;
												}
#endif
#ifdef LINEAR_SPLINE_POTENTIAL										 			
												{	
													float d=sqrt(d2);	
													if(particle_type < 20 && tj < 20)	factor = AA_SMTHP_FACTOR(d); 
													else if((particle_type < 20 && tj >= 20) || (particle_type >= 20 && tj < 20)){
														factor = BS_SMTHP_FACTOR(d);
													} else {
														factor = BB_SMTHP_FACTOR(d);
													}
												}
#endif																			
												float score_contributed = potential[tj][particle_type] * factor;
												if(tj%2 == 0)
													fftgrid[tj/2][index].real += score_contributed;
												else
													fftgrid[tj/2][index].imag += score_contributed;
											}
										}
		
										nummarkings++;
		
										if( x == minx)
											intersectsxmin = true;
										if( x == maxx)
											intersectsxmax = true;
										if( y == miny)
											intersectsymin = true;
										if( y == maxy)
											intersectsymax = true;
										if( z == minz)
											intersectszmin = true;
										if( z == maxz)
											intersectszmax = true;
									}
								}
							}
						}
					}
					if(intersectsxmin && minx > 0)
						minx--;
					if(intersectsxmax && maxx < gridsize[0] - 1)
						maxx++;
					if(intersectsymin && miny > 0)
						miny--;
					if(intersectsymax && maxy < gridsize[1] - 1)
						maxy++;
					if(intersectszmin && minz > 0)
						minz--;
					if(intersectszmax && maxz < gridsize[2] - 1)
						maxz++;
		
					level++;
				}
			}
		}						
	}
	*out << "build fft residue bckbn centroid bckbn centroid contact grid #additional markings " << nummarkings << endl;
}

void Object::build_fft_eigen_residue_bkbnp_grid(float grid_spacing, MKL_Complex8 **fftgrid, unsigned short num_particle_types, unsigned short num_eigen_vectors, 
 float **eigen_vector, MKL_LONG *gridsize, Reference_Frame *tr, bool isreceptor){ 
	unsigned int size = gridsize[0] * gridsize[1] * gridsize[2];
	for(int ti = 0; ti < (num_eigen_vectors+1)/2; ti++)
		for(int i = 0; i < size; i++)
			(fftgrid[ti][i]).real = (fftgrid[ti][i]).imag = 0.0;
			
	Vector center = Vector(c->center);
	
	int nummarkings=0;	
	for(int i = 0 ; i < c->num_aminoacids; i++){
		Aminoacid *aa = c->aminoacid[i];
	   
	   //*out << "check aa " << aa->index << endl; out->flush();
		for(int aapi = 0; aapi < 3; aapi++){
			Vector *v = NULL;
			short particle_type;
			switch(aapi){
				case 0 :
					v = (aa->centroid);
					particle_type = aa->type;
					break;
				case 1 :
					if(aa->amide_nitrogen != NULL)
						v = aa->amide_nitrogen->position;
					particle_type = 20;
					break;
				case 2:
					if(aa->carbonyl_oxygen != NULL)
						v = aa->carbonyl_oxygen->position;
					particle_type = 21;
					break;
			}
			if(particle_type >= 0 && particle_type < num_particle_types && v != NULL){
				Vector taposition = tr->transform(*v - center) - *grid_origin;
				int vx = (int) (taposition.x/grid_spacing);
				int vy = (int) (taposition.y/grid_spacing);
				int vz = (int) (taposition.z/grid_spacing);
		
				float radius;
#ifdef 	STEP_POTENTIAL
				radius = AA_CUTOFF;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL
				radius = AA_SMTHP_CUTOFF;
#endif
		
				if(!isreceptor)	radius=0;
				float radius_squared = radius*radius;
		
				int minx,maxx,miny,maxy,minz,maxz;
				minx = maxx = vx;
				miny = maxy = vy;
				minz = maxz = vz;
		
				int level = 0;
				bool intersects_surface = true;
				while(intersects_surface){
					intersects_surface = false;
					bool intersectsxmin,intersectsxmax,intersectsymin,intersectsymax,intersectszmin,intersectszmax;
					for(int x = minx; x <= maxx; x++){
						for(int y = miny; y <= maxy; y++){
							for(int z = minz; z <= maxz; z++){
								Vector corner_000 = Vector( (((float) x) )*grid_spacing, (((float) y) )*grid_spacing, (((float) z) )*grid_spacing);
							//	Vector grid_center = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) + 0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing);
								bool intersects_cell = false;
								if( x == minx || x == maxx || y == miny || y == maxy || z == minz || z == maxz ){
									float d,d2,d_2;
									intersects_cell = ((d2 = Vector::distance_squared(taposition,corner_000)) <= radius_squared) || (level == 0);
									intersects_surface = intersects_surface || intersects_cell;
		
									if(intersects_cell){
										unsigned int index = (x*gridsize[1] + y)*gridsize[2] + z;
										float factor = 1.0;					

										// trilinear interpolate
										if(!isreceptor){
											Vector v = taposition * (1.0/grid_spacing);
											float wx[2],wy[2],wz[2];
											wx[0] = x+1.0 - v.x;
											wx[1] = v.x - x;
											wy[0] = y+1.0 - v.y;
											wy[1] = v.y - y;
											wz[0] = z+1.0 - v.z;
											wz[1] = v.z - z;
											
											for(int cci =0; cci <=1; cci++)
												for(int ccj =0; ccj <=1; ccj++)
													for(int cck =0; cck <=1; cck++){
														int nx = (x+cci)% gridsize[0];
														int ny = (y+ccj)% gridsize[1];
														int nz = (z+cck)% gridsize[2];
														unsigned int nindex = (nx*gridsize[1] + ny)*gridsize[2] + nz;
														float nfactor = factor *wx[cci]*wy[ccj]*wz[cck];
														for(unsigned short ei=0; ei < num_eigen_vectors; ei++){
															if(ei %2 == 0){
																fftgrid[ei/2][index].real += nfactor*eigen_vector[ei][particle_type];
															} else {
																fftgrid[ei/2][index].imag += nfactor*eigen_vector[ei][particle_type];
															}
														}
													}
										} else {
											// using uniform cutoff, not distinguishing into bkon-bkbn , bkbn-centroid, centroid-centroid contacts
												factor = 0.0;
#ifdef 	STEP_POTENTIAL 			
												if(particle_type < 20)	factor = 1.0;
												else if(d2 < BS_CUTOFF_SQUARED)	factor = 1.0;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL										 			
												{
													float d=sqrt(d2);	
													if(particle_type < 20)	factor = AA_SMTHP_FACTOR(d); 
													else 	factor = BS_SMTHP_FACTOR(d);
												}
#endif											
												for(unsigned short ei=0; ei < num_eigen_vectors; ei++){
													if(ei %2 == 0){
														fftgrid[ei/2][index].real += factor*eigen_vector[ei][particle_type];
													} else {
														fftgrid[ei/2][index].imag += factor*eigen_vector[ei][particle_type];
													}
												}
										}
		
										nummarkings++;

										if( x == minx)
											intersectsxmin = true;
										if( x == maxx)
											intersectsxmax = true;
										if( y == miny)
											intersectsymin = true;
										if( y == maxy)
											intersectsymax = true;
										if( z == minz)
											intersectszmin = true;
										if( z == maxz)
											intersectszmax = true;
									}
								}
							}
						}
					}
					if(intersectsxmin && minx > 0)
						minx--;
					if(intersectsxmax && maxx < gridsize[0] - 1)
						maxx++;
					if(intersectsymin && miny > 0)
						miny--;
					if(intersectsymax && maxy < gridsize[1] - 1)
						maxy++;
					if(intersectszmin && minz > 0)
						minz--;
					if(intersectszmax && maxz < gridsize[2] - 1)
						maxz++;
		
					level++;
				}
	  		}							
		}
	}
										
	*out << "build fft eigen residue bkbn potential grid #markings " << nummarkings << endl;
}

void Object::build_fft_eigen_atomp_grid(float grid_spacing, MKL_Complex8 **fftgrid, unsigned short num_atom_types, unsigned short num_eigen_vectors, 
 float **eigen_vector, MKL_LONG *gridsize, Reference_Frame *tr, bool isreceptor){
	unsigned int size = gridsize[0] * gridsize[1] * gridsize[2];
	for(int ti = 0; ti < (num_eigen_vectors+1)/2; ti++)
		for(int i = 0; i < size; i++)
			(fftgrid[ti][i]).real = (fftgrid[ti][i]).imag = 0.0;
			
	Vector center = Vector(c->center);
	
	int nummarkings=0;	
	for(int i = 0 ; i < c->num_atoms; i++){
	  Atom *a = c->atom[i];
	  short atom_type = a->atom_type;
	  if(atom_type >= 0 && atom_type < num_atom_types){
		Vector taposition = tr->transform(*(a->position) - center) - *grid_origin;
		int vx = (int) (taposition.x/grid_spacing);
		int vy = (int) (taposition.y/grid_spacing);
		int vz = (int) (taposition.z/grid_spacing);

		float radius;
#ifdef  STEP_POTENTIAL 
		radius = ATOM_STEPP_DCUTOFF;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL
		radius = ATOM_SMTHP_DCUTOFF;
#endif
		
		if(!isreceptor)	radius=0;
		float radius_squared = radius*radius;
				
		int minx,maxx,miny,maxy,minz,maxz;
		minx = maxx = vx;
		miny = maxy = vy;
		minz = maxz = vz;

		int level = 0;
		bool intersects_surface = true;
		while(intersects_surface){
			intersects_surface = false;
			bool intersectsxmin,intersectsxmax,intersectsymin,intersectsymax,intersectszmin,intersectszmax;
			for(int x = minx; x <= maxx; x++){
				for(int y = miny; y <= maxy; y++){
					for(int z = minz; z <= maxz; z++){
						Vector corner_000 = Vector( (((float) x) )*grid_spacing, (((float) y) )*grid_spacing, (((float) z) )*grid_spacing);
						Vector grid_center = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) + 0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing);
						bool intersects_cell = false;
						if( x == minx || x == maxx || y == miny || y == maxy || z == minz || z == maxz ){
							float d,d2;
							intersects_cell = ((d2 = Vector::distance_squared(taposition,corner_000)) <= radius_squared) || (level == 0);
							
							/*/intersects_cell = ((d = Vector::distance(taposition,grid_center)) <= radius) || (level == 0);
							// for the receptor, also consider the corners of the cell for inclusion 
							if(isreceptor && !intersects_cell && d < radius +grid_spacing){
								short num_subcells_insersect=0, cutoff=90;
								for(int ci =-2; ci <=2 && !intersects_cell; ci++)
									for(int cj =-2; cj <=2 && !intersects_cell; cj++)
										for(int ck =-2; ck <=2 && !intersects_cell; ck++){
											Vector v = Vector( (((float) x) + (ci+2)/4.0)*grid_spacing, (((float) y) + (cj+2)/4)*grid_spacing, (((float) z) + (ck+2)/4)*grid_spacing);
											if((d = Vector::distance(taposition,v)) <= radius)	num_subcells_insersect++;
											intersects_cell = intersects_cell || (num_subcells_insersect>=cutoff);
										}
							}*/
							intersects_surface = intersects_surface || intersects_cell;

							if(intersects_cell){
								unsigned int index = (x*gridsize[1] + y)*gridsize[2] + z;
								float factor = 0;
#ifdef  STEP_POTENTIAL                  
								factor = 1.0;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL                                                                                                  
								if(d2 < ATOM_STEPP_DCUTOFF_SQUARED)     factor = 1.0;
								else{ float d=sqrt(d2); factor = ATOM_SMTHP_FACTOR(d); }
#endif
								 // trilinear interpolate
								if(!isreceptor){
								        Vector v = taposition * (1.0/grid_spacing);
								        float wx[2],wy[2],wz[2];
								        wx[0] = x+1.0 - v.x;
								        wx[1] = v.x - x;
								        wy[0] = y+1.0 - v.y;
								        wy[1] = v.y - y;
								        wz[0] = z+1.0 - v.z;
								        wz[1] = v.z - z;
								
								        for(int cci =0; cci <=1; cci++)
								                for(int ccj =0; ccj <=1; ccj++)
								                        for(int cck =0; cck <=1; cck++){
								                                int nx = (x+cci)% gridsize[0];
								                                int ny = (y+ccj)% gridsize[1];
								                                int nz = (z+cck)% gridsize[2];
								                                unsigned int nindex = (nx*gridsize[1] + ny)*gridsize[2] + nz;
								                                float nfactor = factor *wx[cci]*wy[ccj]*wz[cck];
								                                for(unsigned short ei=0; ei < num_eigen_vectors; ei++){
																	if(ei %2 == 0){
																		fftgrid[ei/2][index].real += nfactor*eigen_vector[ei][atom_type];
																	} else {
																		fftgrid[ei/2][index].imag += nfactor*eigen_vector[ei][atom_type];
																	}
																}
								                        }
								} else {
								        for(unsigned short ei=0; ei < num_eigen_vectors; ei++){
											if(ei %2 == 0){
												fftgrid[ei/2][index].real += factor*eigen_vector[ei][atom_type];
											} else {
												fftgrid[ei/2][index].imag += factor*eigen_vector[ei][atom_type];
											}
										}
								}

								nummarkings++;

								if( x == minx)
									intersectsxmin = true;
								if( x == maxx)
									intersectsxmax = true;
								if( y == miny)
									intersectsymin = true;
								if( y == maxy)
									intersectsymax = true;
								if( z == minz)
									intersectszmin = true;
								if( z == maxz)
									intersectszmax = true;
							}
						}
					}
				}
			}
			if(intersectsxmin && minx > 0)
				minx--;
			if(intersectsxmax && maxx < gridsize[0] - 1)
				maxx++;
			if(intersectsymin && miny > 0)
				miny--;
			if(intersectsymax && maxy < gridsize[1] - 1)
				maxy++;
			if(intersectszmin && minz > 0)
				minz--;
			if(intersectszmax && maxz < gridsize[2] - 1)
				maxz++;

			level++;
		}
	  }							
	}
	*out << "build fft eigen atomp grid #markings " << nummarkings << endl;
}

void Object::build_fft_atomcontact_grid(float grid_spacing, MKL_Complex8 **fftgrid, unsigned short num_atom_types, MKL_LONG *gridsize, Reference_Frame *tr, bool isreceptor){
	unsigned int size = gridsize[0] * gridsize[1] * gridsize[2];
	for(int ti = 0; ti < (num_atom_types+1)/2; ti++)
		for(int i = 0; i < size; i++)
			(fftgrid[ti][i]).real = (fftgrid[ti][i]).imag = 0.0;
	
	Vector center = Vector(c->center);
	
	int nummarkings=0;	
	for(int i = 0 ; i < c->num_atoms; i++){
	  Atom *a = c->atom[i];
	  short atom_type = a->atom_type;
	  if(atom_type >= 0 && atom_type < num_atom_types){
		Vector taposition = tr->transform(*(a->position) - center) - *grid_origin;
		int vx = (int) (taposition.x/grid_spacing);
		int vy = (int) (taposition.y/grid_spacing);
		int vz = (int) (taposition.z/grid_spacing);

		//cout << "atom " << i << " " << a->position->x << "," << a->position->y << "," << a->position->z << " cell " << vx << "," << vy << "," << vz << " index " << (vx*gridsize[1] + vy)*gridsize[2] + vz << endl;
		float radius;
#ifdef 	STEP_POTENTIAL 
		radius = ATOM_STEPP_DCUTOFF;
#endif
#ifdef LINEAR_SPLINE_POTENTIAL
		radius = ATOM_SMTHP_DCUTOFF;
#endif
		
		// ligand just label the cells containing the center of the atom
		if(!isreceptor)	radius=0;
		float radius_squared = radius*radius;
		
		int minx,maxx,miny,maxy,minz,maxz;
		minx = maxx = vx;
		miny = maxy = vy;
		minz = maxz = vz;

		int level = 0;
		bool intersects_surface = true;
		while(intersects_surface){
			intersects_surface = false;
			bool intersectsxmin,intersectsxmax,intersectsymin,intersectsymax,intersectszmin,intersectszmax;
			for(int x = minx; x <= maxx; x++){
				for(int y = miny; y <= maxy; y++){
					for(int z = minz; z <= maxz; z++){
						Vector corner_000 = Vector( (((float) x) )*grid_spacing, (((float) y) )*grid_spacing, (((float) z) )*grid_spacing);
						Vector grid_center = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) + 0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing);
						bool intersects_cell = false;
						if( x == minx || x == maxx || y == miny || y == maxy || z == minz || z == maxz ){
							float d,d2,d_2;
							intersects_cell = ((d2 = Vector::distance_squared(taposition,corner_000)) <= radius_squared) || (level == 0);
							// for the receptor, also consider the corners of the cell for inclusion 
#ifdef 	STEP_POTENTIAL 
							/*if(isreceptor && !intersects_cell && ((d=sqrt(d2)) < radius +grid_spacing)){
								short num_subcells_insersect=0, cutoff=90;
								for(int ci =-2; ci <=2 && !intersects_cell; ci++)
									for(int cj =-2; cj <=2 && !intersects_cell; cj++)
										for(int ck =-2; ck <=2 && !intersects_cell; ck++){
											Vector v = Vector( (((float) x) + (ci+2)/4.0)*grid_spacing, (((float) y) + (cj+2)/4)*grid_spacing, (((float) z) + (ck+2)/4)*grid_spacing);
											if((d_2 = Vector::distance_squared(taposition,v)) <= radius_squared)	num_subcells_insersect++;
											intersects_cell = intersects_cell || (num_subcells_insersect>=cutoff);
										}
							}*/
#endif							
							intersects_surface = intersects_surface || intersects_cell;

							if(intersects_cell){
								unsigned int index = (x*gridsize[1] + y)*gridsize[2] + z;
								float factor = 0;								
#ifdef 	STEP_POTENTIAL 			
								factor = 1.0;									
#endif
#ifdef LINEAR_SPLINE_POTENTIAL										 			
								if(d2 < ATOM_STEPP_DCUTOFF_SQUARED)	factor = 1.0;
								else{ float d=sqrt(d2);	factor = ATOM_SMTHP_FACTOR(d); }
#endif							
								// trilinear interpolate
								if(!isreceptor){
									Vector v = taposition * (1.0/grid_spacing);
									float wx[2],wy[2],wz[2];
									wx[0] = x+1.0 - v.x;
									wx[1] = v.x - x;
									wy[0] = y+1.0 - v.y;
									wy[1] = v.y - y;
									wz[0] = z+1.0 - v.z;
									wz[1] = v.z - z;
									
									for(int cci =0; cci <=1; cci++)
										for(int ccj =0; ccj <=1; ccj++)
											for(int cck =0; cck <=1; cck++){
												int nx = (x+cci)% gridsize[0];
												int ny = (y+ccj)% gridsize[1];
												int nz = (z+cck)% gridsize[2];
												unsigned int nindex = (nx*gridsize[1] + ny)*gridsize[2] + nz;
												float nfactor = factor *wx[cci]*wy[ccj]*wz[cck];
												if(atom_type %2 == 0)
													fftgrid[atom_type/2][nindex].real += nfactor;
												else
													fftgrid[atom_type/2][nindex].imag += nfactor; 
											}
								} else {
									if(atom_type %2 == 0)
										fftgrid[atom_type/2][index].real += factor;
									else
										fftgrid[atom_type/2][index].imag += factor;
								}

								nummarkings++;

								if( x == minx)
									intersectsxmin = true;
								if( x == maxx)
									intersectsxmax = true;
								if( y == miny)
									intersectsymin = true;
								if( y == maxy)
									intersectsymax = true;
								if( z == minz)
									intersectszmin = true;
								if( z == maxz)
									intersectszmax = true;
							}
						}
					}
				}
			}
			if(intersectsxmin && minx > 0)
				minx--;
			if(intersectsxmax && maxx < gridsize[0] - 1)
				maxx++;
			if(intersectsymin && miny > 0)
				miny--;
			if(intersectsymax && maxy < gridsize[1] - 1)
				maxy++;
			if(intersectszmin && minz > 0)
				minz--;
			if(intersectszmax && maxz < gridsize[2] - 1)
				maxz++;

			level++;
		}
	  }							
	}
	*out << "build fft atomcontact grid #markings " << nummarkings << endl;
}

/*
 * Assume contacts have been computed using build_fft_*contact_grid()
 * the value in the grid is the potential felt by a particle of a given type in the cell
 */
void Object::build_fft_contact_potential_grid(MKL_Complex8 **fftgrid, unsigned short num_particle_types, float **potential, MKL_LONG *gridsize){
	unsigned int size = gridsize[0] * gridsize[1] * gridsize[2];
	for(int i = 0; i < size; i++){
		float neighbor_count[num_particle_types+2];
		for(int ti = 0; ti < (num_particle_types+1)/2; ti++){
			neighbor_count[2*ti] = (fftgrid[ti][i]).real;
			neighbor_count[2*ti+1] = (fftgrid[ti][i]).imag;
		}
		for(int ti = 0; ti < num_particle_types; ti++){
			float cell_potential=0;
			for(int tj = 0; tj < num_particle_types; tj++)
				cell_potential += potential[tj][ti] * neighbor_count[tj];
			if(ti%2 == 0)
				fftgrid[ti/2][i].real = cell_potential;
			else
				fftgrid[ti/2][i].imag = cell_potential;
		}
	}
}

/* Evaluate the accuracy of an interpolation scheme; the input grids are the number of contacts per cell
*/
void Object::fft_check_potential_accuracy(float grid_spacing, MKL_Complex8 **fftgrid, unsigned short num_particle_types, float **potential, MKL_LONG *gridsize){
	Vector fft_grid_origin = Vector(grid_origin);
	Vector center = Vector(c->center);
	Vector zero = Vector(0,0,0);
	
	preprocess_receptor();
	// grid_origin is now with respect to the atom contact grid
	
	unsigned int size = gridsize[0] * gridsize[1] * gridsize[2];
	float max_error = 0;
	float maxError[num_particle_types];
	for(int ti = 0; ti < num_particle_types; ti++)	maxError[ti]=0;
	
	/*/ check atom neighbor grid
	{
		for(int anj = 0; anj < c->num_atoms; anj++){
			Atom *aj = c->atom[anj];
			short atom_type = aj->atom_type;
			
			if(atom_type >= 0 && atom_type < num_particle_types){
				cout << anj << "\tgrid ";
				GridCell *rcell = access_point_in_grid(aj->position,&zero);
				unsigned short* atom_neighbors[2];
				atom_neighbors[0] = atom_neighbors[1] = NULL;
				int num_atom_neighbors[2];
							
				if(rcell != NULL){
					Vector gv = *(aj->position) - *grid_origin;
					int cellx = (int) (gv.x/GRID_SPACING);
					int celly = (int) (gv.y/GRID_SPACING);
					int cellz = (int) (gv.z/GRID_SPACING);
		
					if(cellx >= 0 && cellx < grid_num_xdivisions && celly >= 0 && celly < grid_num_ydivisions && cellz >= 0 && cellz < grid_num_zdivisions){
						unsigned int index = (ATOM_NEIGHBOR_GS_BY_GS*(cellx/ATOM_NEIGHBOR_GS_BY_GS)*grid_num_ydivisions + ATOM_NEIGHBOR_GS_BY_GS*(celly/ATOM_NEIGHBOR_GS_BY_GS))*grid_num_zdivisions + ATOM_NEIGHBOR_GS_BY_GS*(cellz/ATOM_NEIGHBOR_GS_BY_GS);
			
						if(grid[index] != NULL){
							GridCell *coarse_cell = grid[index]; 
							
							atom_neighbors[0] = coarse_cell->atom_overlap_neighbors;
							atom_neighbors[1] = coarse_cell->atom_contact_neighbors;
				
							num_atom_neighbors[0] = coarse_cell->num_atom_overlap_neighbors;
							num_atom_neighbors[1] = coarse_cell->num_atom_contact_neighbors;
						}
					}
				}
				
				for(unsigned short anli = 0; anli < 2; anli++)
					if(atom_neighbors[anli] != NULL)
						for(int ani = 0; ani < num_atom_neighbors[anli]; ani++){
							int racindex = atom_neighbors[anli][ani];
							Atom *a = c->atom[racindex];
									
							short atom_type = a->atom_type;
				  			if(atom_type >= 0 && atom_type < num_particle_types){
								float d2 = Vector::distance_squared(a->position,aj->position);
								if(d2 <= ATOM_STEPP_DCUTOFF_SQUARED){
									cout << racindex << ":" << d2 << "\t";
								}
				  			}	
						}
				cout << endl << "bf ";
						
				for(int ani = 0; ani < c->num_atoms; ani++){
					Atom *a = c->atom[ani];
					short atom_type = a->atom_type;
		  			if(atom_type >= 0 && atom_type < num_particle_types){
						float d2 = Vector::distance_squared(a->position,aj->position);
						if(d2 <= ATOM_STEPP_DCUTOFF_SQUARED){
							cout << ani << ":" << d2 << "\t";
						}
		  			}
				}
				cout << endl;
			}
		}
	}*/
	
	cout << "atom neighbor grid " << grid_num_xdivisions << "," << grid_num_ydivisions << "," << grid_num_zdivisions << endl;
	for(int i = 0; i < size; i++){
		float neighbor_count[num_particle_types+2];
		for(int ti = 0; ti < (num_particle_types+1)/2; ti++){
			neighbor_count[2*ti] = (fftgrid[ti][i]).real;
			neighbor_count[2*ti+1] = (fftgrid[ti][i]).imag;
		}
		
		// take average of all corners
		float corner_neighbor_count[2][2][2][num_particle_types+1];
		for(int ti = 0; ti < num_particle_types; ti++){
			neighbor_count[ti] = 0;
		}
		for(int ci =0; ci <=1; ci++)
			for(int cj =0; cj <=1; cj++)
				for(int ck =0; ck <=1; ck++){
					int z = (i % gridsize[2]) + ck;
					int y = ((i / gridsize[2]) % gridsize[1]) + cj;
					int x = i/(gridsize[2] * gridsize[1]) + ci;
					if(x == gridsize[0])	x--;
					if(y == gridsize[1])	y--;
					if(z == gridsize[2])	z--;
					unsigned int index = (x*gridsize[1] + y)*gridsize[2] + z;
					for(int ti = 0; ti < (num_particle_types+1)/2; ti++){
						// compute average
						neighbor_count[2*ti] += (fftgrid[ti][index]).real * 0.125;
						neighbor_count[2*ti+1] += (fftgrid[ti][index]).imag * 0.125;///
						corner_neighbor_count[ci][cj][ck][2*ti] = (fftgrid[ti][index]).real;
						corner_neighbor_count[ci][cj][ck][2*ti+1] = (fftgrid[ti][index]).imag;
					}
				}//*/
				
		float cell_potential[num_particle_types];
		float total_neighbor_count = 0;
		for(int ti = 0; ti < num_particle_types; ti++){
			cell_potential[ti]=0;
			for(int tj = 0; tj < num_particle_types; tj++)
				cell_potential[ti] += potential[tj][ti] * neighbor_count[tj];
			total_neighbor_count += neighbor_count[ti];
		}
		
		if(total_neighbor_count > 0){
			int z = (i % gridsize[2]) ;
			int y = ((i / gridsize[2]) % gridsize[1]) ;
			int x = i/(gridsize[2] * gridsize[1]) ;
			Vector gv = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) +0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing );
			
			gv = (gv + (center + fft_grid_origin));
			unsigned short* atom_neighbors[2];
			atom_neighbors[0] = atom_neighbors[1] = NULL;
			int num_atom_neighbors[2];
			unsigned int index = 0;
			
			/*cout << "cell " << x << "," << y << "," << z << " " << i << " ";
			for(int ti = 0; ti < num_particle_types; ti++)	cout << ti << ":" << cell_potential[ti] << " ";
			cout << endl;*/ 
						
			gv = gv - *grid_origin;
			int cellx = (int) (gv.x/GRID_SPACING);
			int celly = (int) (gv.y/GRID_SPACING);
			int cellz = (int) (gv.z/GRID_SPACING);
	
			if(cellx >= 0 && cellx < grid_num_xdivisions && celly >= 0 && celly < grid_num_ydivisions && cellz >= 0 && cellz < grid_num_zdivisions){
				index = (ATOM_NEIGHBOR_GS_BY_GS*(cellx/ATOM_NEIGHBOR_GS_BY_GS)*grid_num_ydivisions + ATOM_NEIGHBOR_GS_BY_GS*(celly/ATOM_NEIGHBOR_GS_BY_GS))*grid_num_zdivisions + ATOM_NEIGHBOR_GS_BY_GS*(cellz/ATOM_NEIGHBOR_GS_BY_GS);
				
				if(grid[index] != NULL){
					GridCell *coarse_cell = grid[index]; 
						
					atom_neighbors[0] = coarse_cell->atom_overlap_neighbors;
					atom_neighbors[1] = coarse_cell->atom_contact_neighbors;
			
					num_atom_neighbors[0] = coarse_cell->num_atom_overlap_neighbors;
					num_atom_neighbors[1] = coarse_cell->num_atom_contact_neighbors;
				}
			}
			if(atom_neighbors[0] == NULL && atom_neighbors[1] == NULL)
				cout << gv.x << "," << gv.y << "," << gv.z << " " << " missing cell " << cellx << "," << celly << "," << cellz << " index " << (cellx*grid_num_ydivisions + celly)*grid_num_zdivisions + cellz << endl;
			
			// for almost each point in the cell find the potential
			for(int ci =-2; ci <=2; ci++)
				for(int cj =-2; cj <=2; cj++)
					for(int ck =-2; ck <=2; ck++){
						float neighbor_count[num_particle_types];
						for(int j = 0; j < num_particle_types; j++)	neighbor_count[j] = 0;
					
						//cout << i << " " << index << " " << ci << "," << cj << "," << ck << "\t";
						Vector v = Vector( (((float) x) + (ci+2)/4.0)*grid_spacing, (((float) y) + (cj+2)/4.0)*grid_spacing, (((float) z) + (ck+2)/4.0)*grid_spacing);
						
						for(unsigned short anli = 0; anli < 2; anli++)
							if(atom_neighbors[anli] != NULL)
								for(int ani = 0; ani < num_atom_neighbors[anli]; ani++){
									int racindex = atom_neighbors[anli][ani];
									Atom *a = c->atom[racindex];
									
									short atom_type = a->atom_type;
				  					if(atom_type >= 0 && atom_type < num_particle_types){
										Vector taposition = (*(a->position) - center) - fft_grid_origin;
										float d2 = Vector::distance_squared(taposition,v);
										float factor = 0;
#ifdef 	STEP_POTENTIAL 			
										if(d2 < ATOM_STEPP_DCUTOFF_SQUARED)	factor = 1.0;			
#endif
#ifdef LINEAR_SPLINE_POTENTIAL										 			
										if(d2 < ATOM_STEPP_DCUTOFF_SQUARED)	factor = 1.0;
										else if(d2 < ATOM_SMTHP_DCUTOFF_SQUARED) { float d=sqrt(d2);	factor = ATOM_SMTHP_FACTOR(d); }
#endif																				
										neighbor_count[atom_type] += factor;
										//if(d2 <= ATOM_STEPP_DCUTOFF_SQUARED)	cout << racindex << ":" << d2 << "\t";
				  					}	
								}
						/*/cout << atom_neighbors[0] << " " << atom_neighbors[1] << endl << "bf ";
						
						float neighbor_countbf[num_particle_types];
						for(int j = 0; j < num_particle_types; j++)	neighbor_countbf[j] = 0;
						for(int ani = 0; ani < c->num_atoms; ani++){
							Atom *a = c->atom[ani];
							
							short atom_type = a->atom_type;
		  					if(atom_type >= 0 && atom_type < num_particle_types){
								Vector taposition = (*(a->position) - center) - fft_grid_origin;
								float d2 = Vector::distance_squared(taposition,v);
								if(d2 <= ATOM_STEPP_DCUTOFF_SQUARED){
									cout << ani << ":" << d2 << "\t";
									neighbor_countbf[atom_type] += 1;
								}
		  					}
						}
						cout << endl;*/
						
						// trilinear interpolation
						{
							float wx[2],wy[2],wz[2];
							wx[0] = (2.0-ci)/4.0;
							wx[1] = (2.0+ci)/4.0;
							wy[0] = (2.0-cj)/4.0;
							wy[1] = (2.0+cj)/4.0;
							wz[0] = (2.0-ck)/4.0;
							wz[1] = (2.0+ck)/4.0;
							
							float interpolated_neighbor_count[num_particle_types];
							
							for(int tj = 0; tj < num_particle_types; tj++){
								interpolated_neighbor_count[tj] = 0;
								for(int cci =0; cci <=1; cci++)
									for(int ccj =0; ccj <=1; ccj++)
										for(int cck =0; cck <=1; cck++){
											interpolated_neighbor_count[tj] += corner_neighbor_count[cci][ccj][cck][tj]*wx[cci]*wy[ccj]*wz[cck]; 
										}
							}
							
							for(int ti = 0; ti < num_particle_types; ti++){
								cell_potential[ti]=0;
								for(int tj = 0; tj < num_particle_types; tj++)
									cell_potential[ti] += potential[tj][ti] * interpolated_neighbor_count[tj];
							}
						}//*/
						
						float point_potential[num_particle_types];
						for(int ti = 0; ti < num_particle_types; ti++){
							point_potential[ti]=0;
							for(int tj = 0; tj < num_particle_types; tj++)
								point_potential[ti] += potential[tj][ti] * neighbor_count[tj];
							
							float error = point_potential[ti] - cell_potential[ti];
							error = ABS(error);
							if(error > maxError[ti]){
								maxError[ti] = error;
								if(error > max_error){
									max_error = error;
									cout << "cell " << i << " max_error till now " << max_error << " particle type " << ti << endl; 
								}
							}
						}
		  			}
		}
	}
	cout << "Max_error by particle type ";
	for(int ti = 0; ti < num_particle_types; ti++)	cout << ti << ":" << maxError[ti] << " ";
	cout << endl;
	
	*grid_origin = fft_grid_origin;
}


void preprocess(){
	aacontact_core = (bool **) malloc(sizeof(bool*) * (ligand->c->num_aminoacids + 1));
	aacontact_rim = (bool **) malloc(sizeof(bool*) * (ligand->c->num_aminoacids + 1));
	for(int i = 0 ; i < ligand->c->num_aminoacids; i++){
		aacontact_core[i] = (bool *) malloc(sizeof(bool) * (receptor->c->num_aminoacids + 1));
		aacontact_rim[i] = (bool *) malloc(sizeof(bool) * (receptor->c->num_aminoacids + 1));
		for(int j = 0 ; j < receptor->c->num_aminoacids; j++)
			aacontact_core[i][j] = aacontact_rim[i][j] = false;
	}
	aarcontact = (bool *) malloc(sizeof(bool) * (receptor->c->num_aminoacids + 1));
	for(int j = 0 ; j < receptor->c->num_aminoacids; j++)	aarcontact[j] = false;
	aalcontact = (bool *) malloc(sizeof(bool) * (ligand->c->num_aminoacids + 1));
	for(int j = 0 ; j < ligand->c->num_aminoacids; j++)	aalcontact[j] = false;
		
	/*sas_b = (float **) malloc(sizeof(float*) * (ligand->c->num_atoms + 1));
	sas_bprime = (float **) malloc(sizeof(float*) * (ligand->c->num_atoms + 1));
	sas_fraclost = (float **) malloc(sizeof(float*) * (ligand->c->num_atoms + 1));
	for(int i = 0 ; i < ligand->c->num_atoms; i++){
		sas_b[i] = (float*) malloc(sizeof(float) * (receptor->c->num_atoms + 1));
		sas_bprime[i] = (float*) malloc(sizeof(float) * (receptor->c->num_atoms + 1));
		sas_fraclost[i] = (float*) malloc(sizeof(float) * (receptor->c->num_atoms + 1));
	}*/
}

/* saving combinations to file
 * if not the master node, send candidates to master node
 * master node merges the combinations from all candidates and writes them in sorted order
 */
void collect_combinations(){
	int *num_combinations;
	int num_node_combinations = clustered_combinations.size();
	
	if(procid == 0){
		num_combinations = new int[numprocs];
		num_combinations[0] = num_node_combinations;
		int total_combinations = num_node_combinations;
		for(int i=1;i<numprocs;i++){
			MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
			int n = atoi(buff);
			num_combinations[i] = n;
			total_combinations += n;
		}
		cout << "#combinations " << total_combinations << endl;
		cout.flush();

		fstream combiout;
		if(state == VERIFY_COMBINATIONS){
			combiout.open(local_combinations_file,ios::out);
			combiout << "|r-r0|\t" << "rmsd\t"<<"lrmsd\t"<<"irmsd\t"<<"#+cnts\t"<<"#cnts\t"<<"E\t"<<"details"<<endl;
			combiout << setiosflags(ios::fixed) << setprecision(3);
		} else{
			combiout.open(local_combinations_file,ios::binary|ios::out);
			combiout << total_combinations << endl;
		}
		
		//merge combinations from different nodes on the basis of less<MultiTransformation*>
		int *combinations_read = new int[numprocs];
		int *combinations_written = new int[numprocs];
		MultiTransformation *current[numprocs];
		
		vector<MultiTransformation*>::iterator citr = clustered_combinations.begin(), cend = clustered_combinations.end();
		
		for(int i = 0 ; i < numprocs ; i++){
			combinations_read[i] = 0;
			combinations_written[i] = 0;
		}
		int count = 0;
		while(count < total_combinations){
			if(count == 0){
				if(citr != cend){
					current[0] = *citr;
					citr++;
					combinations_read[0]++;
				}
				for(int i=1;i<numprocs;i++){
					if(combinations_read[i] < num_combinations[i]){
						//cout << "reading candidate from node " << i << endl;
						MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
						combinations_read[i]++;
						current[i] = new MultiTransformation(buff);
					}
				}
			}
			
			int list_picked = -1;
			MultiTransformation *min = NULL;
			for(int i=0;i<numprocs;i++){
				if(combinations_written[i] < num_combinations[i]){
					if(min == NULL || less<MultiTransformation*>()(current[i],min)){
						//cout << i << " " << (current[i] < min) << endl;
						min = current[i];
						list_picked = i;
					}
				}
			}
			
			//cout << list_picked << " " << current[list_picked]->vdw_energy << endl;
			if(state == VERIFY_COMBINATIONS)
				current[list_picked]->print_results(&combiout);
			else
				current[list_picked]->print_details(&combiout);
				
			delete current[list_picked];
			combinations_written[list_picked]++;
			count++;
			
			if(list_picked == 0){
				if(citr != cend){
					current[0] = *citr;
					citr++;
					combinations_read[0]++;
				}
			} else{
				if(combinations_read[list_picked] < num_combinations[list_picked]){
					//cout << "reading candidate from node " << i << endl;
					MPI_Recv(buff, BUFSIZE, MPI_CHAR, list_picked, TAG, MPI_COMM_WORLD, &mpistat);
					combinations_read[list_picked]++;
					current[list_picked] = new MultiTransformation(buff);
				}
			}
		}

		combiout.close();
		cout << "done saving combinations " << total_combinations << endl;
		char command[512];
		switch(state){
			case VERIFY_COMBINATIONS:
				sprintf(command, "cp %s %s.results",local_combinations_file,tag);
			break;
			default:
				sprintf(command, "cp %s %s",local_combinations_file,combinations_file);
			break;
		}
		int ret = system(command);
		cout << command << " " << ret << endl;
	} else {	
		sprintf(buff, "%d", num_node_combinations);
		MPI_Ssend(buff, BUFSIZE, MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
		*out << "done sending #combinations " << num_node_combinations << endl;
	
		for(vector<MultiTransformation*>::iterator citr = clustered_combinations.begin(); citr != clustered_combinations.end(); citr++){
			MultiTransformation* mtr = *citr;
			stringstream ss (stringstream::in | stringstream::out);
			mtr->print_details(&ss);
			ss.getline(buff,BUFSIZE);
			//*out << buff << endl;
			MPI_Ssend(buff, BUFSIZE, MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
		}
		*out << "sent candidates to node 0" << endl;
	}
}

/* 
 * already generated combinations can read from file
 * copy to scratch directory before reading
 * save NFS! reading in a round robin fashion 
 */
void read_combinations(){
	if(procid > 0){
		MPI_Recv(buff, BUFSIZE, MPI_CHAR, procid-1, TAG, MPI_COMM_WORLD, &mpistat);
		*out << buff << endl;
	}
	
	sprintf(command, "cp %s %s",combinations_file,local_combinations_file);
	int ret = system(command);
	*out << command << " " << ret << endl;
	sprintf(command, "cp %s %s",transformations_file,local_transformations_file);	
	ret = system(command);
	*out << command << " " << ret << endl;
	
	sprintf(buff, "node-%d: finished reading file",procid);
	if(procid < numprocs-1) {
		MPI_Ssend(buff, BUFSIZE, MPI_CHAR, procid+1, TAG, MPI_COMM_WORLD);
	}
	
	*out << "reading combinations from file" << endl;
	fstream combiin(local_combinations_file,ios::binary|ios::in);
	combiin.getline(buff,BUFSIZE);
	int num_combinations = atoi(buff);
	*out << local_combinations_file << " " << combiin.good() << 
		" total #combinations " << num_combinations << endl;
	
	hash_set<long, hash<long>, eqlong> transformations_to_read;
	int count = 0;
	int num_to_model = NUM_CANDIDATES_MODELLED/numprocs;
	int num_models = 0;
	clustered_combinations.clear();
	while(combiin.good() && num_models < num_to_model){
		combiin.getline(buff,BUFSIZE);
		if(count % numprocs == procid && combiin.gcount() > 0){
			MultiTransformation *mtr = new MultiTransformation(buff);
			clustered_combinations.push_back(mtr);
			num_models++;
			for(vector<long>::iterator itr = mtr->transformation_ids.begin(); 
			 itr != mtr->transformation_ids.end(); itr++){
			 	long tid = *itr;
			 	transformations_to_read.insert(tid);
			}
			//*out << mtr->id << " ";
			//*out << mtr->num_contacts << " " << mtr->vdw_repulsion << endl;
		}
		count++;
	}
	combiin.close();
	*out << "#node combinations " << clustered_combinations.size() << endl;
	*out << "#transformations to be read " << transformations_to_read.size() << endl;
	
	fstream transin(local_transformations_file,ios::binary|ios::in);
	*out << local_transformations_file << " " << transin.good() << endl;
	out->flush();
	
	while(transin.good()){
		transin.getline(buff,BUFSIZE);
		if(transin.gcount() > 0){	
			Transformation *tr = new Transformation(buff,TN_BASIC);
			if(transformations_to_read.count(tr->frame_number) > 0)
				hashed_transformations[tr->frame_number] = tr;
			else
				delete tr;
		}
	}
	transin.close();
	
	*out << "updating combinations " << hashed_transformations.size() << endl;
	out->flush();
	for(vector<MultiTransformation*>::iterator mitr = clustered_combinations.begin(); mitr != clustered_combinations.end(); mitr++){
		MultiTransformation *mtr = *mitr;
		for(vector<long>::iterator itr = mtr->transformation_ids.begin(); itr != mtr->transformation_ids.end(); itr++){
		 	long tid = *itr;
		 	mtr->transformations.push_back(hashed_transformations[tid]);
		}
		//*out << mtr->id << " " << mtr->transformations.size() << endl;
	}
}


void examine_combinations(){
	if(procid > 0){
		MPI_Recv(buff, BUFSIZE, MPI_CHAR, procid-1, TAG, MPI_COMM_WORLD, &mpistat);
		*out << buff << endl;
	}
	
	sprintf(command, "cp %s %s",combinations_file,local_combinations_file);
	int ret = system(command);
	*out << command << " " << ret << endl;
	sprintf(command, "cp %s %s",transformations_file,local_transformations_file);	
	ret = system(command);
	*out << command << " " << ret << endl;
	
	sprintf(buff, "node-%d: finished reading file",procid);
	if(procid < numprocs-1) {
		MPI_Ssend(buff, BUFSIZE, MPI_CHAR, procid+1, TAG, MPI_COMM_WORLD);
	}
	
	*out << "reading combinations from file" << endl;
	fstream combiin(local_combinations_file,ios::binary|ios::in);
	combiin.getline(buff,BUFSIZE);
	int num_combinations = atoi(buff);
	*out << local_combinations_file << " " << combiin.good() << 
		" total #combinations " << num_combinations << endl;
	
	int max_contacts = 0;
	hash_map<int,int,hash<int>,eqint> contact_distribution;
	hash_map<int,float,hash<int>,eqint> min_vdw, min_pair;
	clustered_combinations.clear();
	while(combiin.good()){
		combiin.getline(buff,BUFSIZE);
		MultiTransformation mtr = MultiTransformation(buff);
		int num_contacts = (int) mtr.num_contacts; 
		if(num_contacts > max_contacts)
			max_contacts++;
		if(contact_distribution.count(num_contacts) == 0){
			contact_distribution[num_contacts] = 0;
			min_vdw[num_contacts] = mtr.vdw_energy;
			min_pair[num_contacts] = mtr.eResiduepair;
		}
		contact_distribution[num_contacts]++;
		min_vdw[num_contacts] = min(mtr.vdw_energy,min_vdw[num_contacts]);
		min_pair[num_contacts] = min(mtr.eResiduepair,min_pair[num_contacts]);
	}
	combiin.close();
	
	if(procid == 0){
		cout << "contact distribution" << endl << "#contacts frequency minvdw minpairenergy" << endl;
		for(int i = 0 ; i < max_contacts; i++){
			if(contact_distribution.count(i) == 0)
				cout << i << "\t0\t0\t0";
			else
				cout << i << "\t" << contact_distribution[i] << "\t" << min_vdw[i] << "\t" << min_pair[i];
			cout << endl;
		}
		cout << endl;
	}
}

void read_combinations_modelled(){
	if(procid > 0){
		MPI_Recv(buff, BUFSIZE, MPI_CHAR, procid-1, TAG, MPI_COMM_WORLD, &mpistat);
		*out << buff << endl;
	}
	
	sprintf(command, "cp %s %s",combinations_file,local_combinations_file);
	int ret = system(command);
	*out << command << " " << ret << endl;
	
	sprintf(buff, "node-%d: finished reading file",procid);
	if(procid < numprocs-1) {
		MPI_Ssend(buff, BUFSIZE, MPI_CHAR, procid+1, TAG, MPI_COMM_WORLD);
	}
	
	*out << "reading combinations from file" << endl;
	fstream combiin(local_combinations_file,ios::binary|ios::in);
	combiin.getline(buff,BUFSIZE);
	int num_combinations = atoi(buff);
	*out << local_combinations_file << " " << combiin.good() << 
		" total #combinations " << num_combinations << endl;
	
	hash_set<long, hash<long>, eqlong> transformations_to_read;
	int count;
	int num_to_model = NUM_CANDIDATES_MODELLED/numprocs;
	int num_models = 0;
	model_ids.clear();
	while(combiin.good() && num_models < num_to_model){
		combiin.getline(buff,BUFSIZE);
		if(count % numprocs == procid && combiin.gcount() > 0){
			MultiTransformation mtr = MultiTransformation(buff);
			num_models++;
			stringstream ss (stringstream::in | stringstream::out);
			stringstream ss2 (stringstream::in | stringstream::out);
			ss << mtr.id;
			for(int i = 0; i < mtr.transformation_ids.size(); i++){
				if(i > 0)
					ss2 << ".";
				long tid;
				ss >> tid;
				ss2 << tid;
			}
			string mid;
			ss2 >> mid;
			model_ids.push_back( *(new string(mid.c_str())) );
		}
		count++;
	}
	combiin.close();
	*out << "#node combinations " << model_ids.size() << endl;
}

/*
 * Generate contact constraints for each transformation and run modeller
 */
void generate_models(){
	// copy restraint files of individual proteins to scratch directory
	stringstream ss (stringstream::in | stringstream::out);
	string ligand_id, receptor_id;
	ss << (ligand->c->pdbcode) << "_" << (ligand->c->chains);
	ss >> ligand_id;
	ss.clear();
	ss << (receptor->c->pdbcode) << "_" << (receptor->c->chains);
	ss >> receptor_id;

	sprintf(command, "cp modeller_data/*  %s/",scratch_dir);	
	int ret = system(command);
	*out << command << " " << ret << endl;
	
	// start working in scratch_dir
	getcwd(buff,BUFSIZE);
	string local_dir = *(new string(buff));
	chdir(scratch_dir);
	//getcwd(buff,BUFSIZE);
	//*out << "dir " << buff << endl;
	
	vector<MultiTransformation*> modelled_combinations = *(new vector<MultiTransformation*>);
	int numrresidues = receptor->c->num_aminoacids;
	for(vector<MultiTransformation*>::iterator mitr = clustered_combinations.begin(); mitr != clustered_combinations.end(); mitr++){
		MultiTransformation *mtr = *mitr;
		stringstream ss (stringstream::in | stringstream::out);
		//ss << scratch_dir << "/";
		Transformation *tr;
		int count=0;
		for(vector<Transformation*>::iterator itr = mtr->transformations.begin();
		 itr != mtr->transformations.end(); itr++){
		 	tr = *itr;
		 	if(count++ > 0)
		 		ss << ".";
			ss << tr->frame_number;
		}
		string id;
		ss >> id;
		id = string(id.c_str());
		//*out << "id " << id << endl;
		
		ss.clear();
		ss << id;
		ss << ".pdb";
		string pdbfilename;
		ss >> pdbfilename;
		pdbfilename = string(pdbfilename).c_str();
		// generate initial conditions
		//*out << pdbfilename << endl;
		write_as_pdb(receptor->c, ligand->c, tr, pdbfilename);
		
		// generate contacts
		ss.clear();
		ss << id;
		ss << ".contacts";
		string contact_constraints_file;
		ss >> contact_constraints_file;
		contact_constraints_file = string(contact_constraints_file.c_str());
		fstream fout(contact_constraints_file.c_str(), ios::out);
		if(!fout.is_open()){
			cout << "Error opening file " << contact_constraints_file << endl;
			exit(1);
		}
		hash_map<long,float,hash<long>,eqlong> residue_energy;
		hash_map<int, short, hash<int>,eqint> lresidue_vdw_energy;
		hash_map<int, short, hash<int>,eqint> rresidue_vdw_energy;
		mtr->compute_details(&residue_energy, &lresidue_vdw_energy , &rresidue_vdw_energy);
		
		for(hash_map<long,float,hash<long>,eqlong>::iterator rditr = residue_energy.begin();
		 rditr != residue_energy.end(); rditr++){
		 	long index = rditr->first;
		 	long alindex, arindex;
		 	alindex = index/MAX_ATOMS;
		 	arindex = index % MAX_ATOMS;
		 	if(rditr->second < 0){
		 		// what about constraints between chains in the same molecule?
		 	 	fout << receptor->c->aminoacid[arindex]->index << " " << ligand->c->aminoacid[alindex]->index << endl;
		 	}
		}
		fout.close();
		
		sprintf(command, "%s/%s %s %s %s %d",piedock_home,(string(RUN_MODELLER)).c_str(),receptor_id.c_str(),ligand_id.c_str(),id.c_str(),numrresidues);
		ret = 0;//system(command);
		*out << command << " " << ret << endl;
		if(ret == 0)
			modelled_combinations.push_back(mtr);
	}
	clustered_combinations = modelled_combinations;
	
	// move back to the original directory and save all models
	chdir(local_dir.c_str());
	sprintf(command, "cp %s/* models/",scratch_dir);
	ret = system(command);
	*out << command << " " << ret << endl;
	/*sprintf(command, "cp %s/*.py models/",scratch_dir);
	ret = system(command);
	*out << command << " " << ret << endl;
	sprintf(command, "cp %s/*.log models/",scratch_dir);
	ret = system(command);
	*out << command << " " << ret << endl;*
	sprintf(command, "cp %s/*.pdb models/",scratch_dir);
	ret = system(command);
	*out << command << " " << ret << endl;*/
}

#define MAXTRANSINBUFFERBASIC 1024

/* saving transformations to file
 * if not the master node, send candidates to master node
 * master node updates the frame number so that it is unique across nodes
 * transformations divided as pieces since all of them cannot be kept in memory
 * transformations deleted as they get collected
 */
void collect_transformations(bool uptomax, int maxtransformations){
	//cout << "collecting " << endl;
	vector<TransformationAndTag*> node_heap;
	long node_count=0;
	fstream transin[pieces.size()+1];
	bool transin_done[pieces.size()+1];
	long num_node_transformations=0;
	unsigned int num_pieces=0;
	for(hash_map<unsigned int,long,hash<unsigned int>,eqint>::iterator pitr=pieces.begin(); pitr!=pieces.end(); pitr++){
		num_node_transformations += pitr->second;
		char tfilename[512];
		sprintf(tfilename, "%s/%s/%d/trans%d",node_tmp_dir,refpdbcode.c_str(),procid,pitr->first);
		*out << tfilename << endl; out->flush();
		transin[num_pieces].open(tfilename,ios::binary|ios::in);
		num_pieces++;
	}
	// fillup node_heap
	for(int i=0;i<num_pieces;i++){
		//*out << "reading from piece " << i << "\t"; out->flush();
		transin[i].read(buff,Transformation::basic_byte_size);
		int bytes_read = transin[i].gcount();
		transin_done[i] = (bytes_read == 0); 
		if(!transin_done[i]){
			Transformation *tr = new Transformation(buff,TN_BASIC);
			TransformationAndTag *tn = new TransformationAndTag(tr,i+numprocs);
			node_heap.push_back(tn);
		}
	}
	make_heap(node_heap.begin(),node_heap.end(),greater<TransformationAndTag*>());
	
	long *num_transformations;
	int MESSAGES_BEFORE_STATUS_UPDATE=5;  // should be greater than 2	
	if(procid == 0){
		num_transformations = new long[numprocs];
		unsigned int num_messages_received[numprocs];
		num_transformations[0] = num_node_transformations;
		long total_transformations = num_node_transformations;
		for(int i=1;i<numprocs;i++){
			//mainout << "getting #candidates from node " << i << endl;
			MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
			stringstream ss (stringstream::in | stringstream::out);
			ss << buff;
			ss >> num_transformations[i];
			if(state == GENERATE_MATCHES || state == FILTER_STERIC_CLASHES){
				for(int j = 0; j < NUM_GENERATION_STATS; j++){
					long l;
					ss >> l;
					generation_stats[j] += l;
				}
			}			
			total_transformations += num_transformations[i];
			num_messages_received[i] = 1;
		}
		if(state == GENERATE_MATCHES || state == FILTER_STERIC_CLASHES)
			for(int j = 0; j < NUM_GENERATION_STATS; j++)
				cout << generation_stats[j] << "\t";
		cout << "#candidates " << total_transformations << endl;
		if(receptor != NULL && ligand != NULL){
			cout << "probe radius " << probe_radius << " receptor #points " << receptor->num_faces << " ligand #points " 
				<< ligand->num_faces << " vote cutoff " << MIN_VOTES(receptor->num_faces,ligand->num_faces) << endl;
		}
		cout.flush();
	
		fstream transout;
		transout.open(local_transformations_file,ios::binary|ios::out);
		
		//merge transformations from different nodes on the basis of less<Transformation*>
		long *transformations_read = new long[numprocs];
		long *transformations_written = new long[numprocs];
		vector<TransformationAndTag*> heap;
			
		for(int i = 0 ; i < numprocs ; i++){
			transformations_read[i] = 0;
			transformations_written[i] = 0;
		}
		long count = 0;
		queue<Transformation*> trbuffer[numprocs];
		int bytesreceived, transformationsreceived;
		unsigned int num_transformations_limit =  minimum(maxtransformations,total_transformations);
		// change of stopping condition requires updating status messages
		while((!uptomax && count < total_transformations) || (uptomax && count < num_transformations_limit)){
			if(count == 0){
				if(node_heap.size() > 0){
					pop_heap(node_heap.begin(),node_heap.end(),greater<TransformationAndTag*>());
					node_heap.pop_back();
					TransformationAndTag *tn = (TransformationAndTag*) *(node_heap.end());
					heap.push_back(tn);
					transformations_read[0]++;
				}
				for(int i=1;i<numprocs;i++){
					if(transformations_read[i] < num_transformations[i]){
						//cout << "reading candidates from node " << i << "\t"; cout.flush();
						MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
						MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
						transformationsreceived = bytesreceived/(Transformation::basic_byte_size);
						//cout << "node i " << transformationsreceived << endl; cout.flush();
						transformations_read[i] += transformationsreceived;
						num_messages_received[i]++;
						for(int tri=0; tri<transformationsreceived; tri++)	
							trbuffer[i].push(new Transformation(buff+tri*(Transformation::basic_byte_size),TN_BASIC));
						Transformation *tr = (Transformation*) (trbuffer[i].front());
						trbuffer[i].pop();
						TransformationAndTag *tn = new TransformationAndTag(tr,i);
						heap.push_back(tn);
					}
				}
				make_heap(heap.begin(),heap.end(),greater<TransformationAndTag*>());
				cout << "initialized heap\n"; cout.flush();
			}
			
			pop_heap(heap.begin(),heap.end(),greater<TransformationAndTag*>());
			heap.pop_back();
			TransformationAndTag *min = (TransformationAndTag*) *(heap.end());
			unsigned int min_tag = min->tag;
			Transformation *tr = min->tr;

			if(state == GENERATE_MATCHES)	tr->frame_number = count;
			
			tr->write_binary(&transout,TN_BASIC);
			if(count <= 10)//20000)	
				tr->print_details(&cout,TN_BASIC);
			
			unsigned int list_picked;
			if(min_tag < numprocs)
				list_picked = min_tag;
			else
				list_picked = 0;
				
			transformations_written[list_picked]++;
			count++;
			if(count % 100000 == 0){	cout << "at " << count << " " << list_picked << endl; cout.flush(); }
				
			if(list_picked == 0){
				list_picked = min_tag - numprocs;
				if(!transin_done[list_picked]){
					transin[list_picked].read(buff,Transformation::basic_byte_size);
					int bytes_read = transin[list_picked].gcount();
					transin_done[list_picked] = (bytes_read == 0); 
					if(!transin_done[list_picked]){
						Transformation *tr = new Transformation(buff,TN_BASIC);
						TransformationAndTag *tn = new TransformationAndTag(tr,list_picked+numprocs);
						node_heap.push_back(tn);
						push_heap(node_heap.begin(),node_heap.end(),greater<TransformationAndTag*>());
					}
				}
				if(node_heap.size() > 0){
					pop_heap(node_heap.begin(),node_heap.end(),greater<TransformationAndTag*>());
					node_heap.pop_back();
					TransformationAndTag *tn = (TransformationAndTag*) *(node_heap.end());;
					heap.push_back(tn);
					transformations_read[0]++;
					push_heap(heap.begin(),heap.end(),greater<TransformationAndTag*>());
				}
			} else{
				//if(numprocs == 1) cout << "alarm " << list_picked << endl; cout.flush();
				if(trbuffer[list_picked].empty() && transformations_read[list_picked] < num_transformations[list_picked]){
					//cout << "reading candidates from node " << list_picked << "\t"; cout.flush();
					MPI_Recv(buff, BUFSIZE, MPI_CHAR, list_picked, TAG, MPI_COMM_WORLD, &mpistat);
					MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
					transformationsreceived = bytesreceived/(Transformation::basic_byte_size);
					//cout << transformationsreceived << endl;
					transformations_read[list_picked] += transformationsreceived;
					num_messages_received[list_picked]++;
					if(num_messages_received[list_picked] % MESSAGES_BEFORE_STATUS_UPDATE == 0){
						bool collection_done = (uptomax && count >= num_transformations_limit);
						stringstream ss (stringstream::in | stringstream::out);
						ss << collection_done << " ";
						char buf[128];
						ss.getline(buf,128);
						MPI_Ssend(buf, 128, MPI_CHAR, list_picked, TAG, MPI_COMM_WORLD);
						if(collection_done)	transformations_read[list_picked] = num_transformations[list_picked];
					}
					for(int tri=0; tri<transformationsreceived; tri++)	
						trbuffer[list_picked].push(new Transformation(buff+tri*(Transformation::basic_byte_size),TN_BASIC));					
				}
				if(!trbuffer[list_picked].empty()){
					Transformation *tr = (Transformation*) (trbuffer[list_picked].front());
					trbuffer[list_picked].pop();
					TransformationAndTag *tn = new TransformationAndTag(tr,list_picked);
					heap.push_back(tn);
					push_heap(heap.begin(),heap.end(),greater<TransformationAndTag*>());
				}
			}
			
			delete min;
		}
		
		transout.close();
		cout << "saved transformations " << count << " total " << total_transformations << endl; cout.flush();
		
		char command[512];
		sprintf(command, "cp %s %s",local_transformations_file,transformations_file);
		int ret = system(command);
		cout << state << " " << command << " " << ret << endl;
		if(ret != 0)	success=0;
		
		// if picked only few transformations, receive Ssend messages from other nodes and relieve them
		if(uptomax && numprocs > 1 && count < total_transformations){
			cout << "max reached, relieving other processes" << endl; cout.flush();
			for(int i = 1; i < numprocs; i++)
				while(transformations_read[i] < num_transformations[i]){
					MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
					MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
					transformationsreceived = bytesreceived/(Transformation::basic_byte_size);
					transformations_read[i] += transformationsreceived;
					num_messages_received[i]++;
					if(num_messages_received[i] % MESSAGES_BEFORE_STATUS_UPDATE == 0){
						stringstream ss (stringstream::in | stringstream::out);
						ss << true << " ";
						ss.getline(buff,128);
						MPI_Ssend(buff, 128, MPI_CHAR, i, TAG, MPI_COMM_WORLD);
						transformations_read[i] = num_transformations[i];
					}
				}
		}
		/*for(int i = 0 ; i < numprocs ; i++)
			cout << i << " " << num_transformations[i] << " " << transformations_read[i] << " " << transformations_written[i] << endl;
		cout << "heap size " << heap.size() << endl;*/
	} else {
		stringstream ss (stringstream::in | stringstream::out);
		ss << num_node_transformations << " ";
		if(state == GENERATE_MATCHES || state == FILTER_STERIC_CLASHES){
			for(int i = 0; i < NUM_GENERATION_STATS; i++)	ss << generation_stats[i] << " ";
		}
		ss.getline(buff,BUFSIZE);
		MPI_Ssend(buff,NUM_GENERATION_STATS*64 , MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
		*out << "done sending #transformations " << num_node_transformations << endl;
		unsigned int num_messages_sent=1;
		
		int transformationsinbuffer=0;
		ss.clear();
		bool collection_done = false;
		while(node_heap.size() > 0 && !collection_done){
			pop_heap(node_heap.begin(),node_heap.end(),greater<TransformationAndTag*>());
			node_heap.pop_back();
			TransformationAndTag *tn = (TransformationAndTag*) *(node_heap.end());;
			Transformation* tr = tn->tr;
			unsigned int list_picked = tn->tag - numprocs;
			tr->write_binary(&ss,TN_BASIC);
			delete tr;
			transformationsinbuffer++;
			
			if(transformationsinbuffer == MAXTRANSINBUFFERBASIC){
				ss.read(buff,transformationsinbuffer*(Transformation::basic_byte_size));
				MPI_Ssend(buff,transformationsinbuffer*(Transformation::basic_byte_size), MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
				ss.clear(); ss.str(""); transformationsinbuffer=0;
				num_messages_sent++;
				if(num_messages_sent % MESSAGES_BEFORE_STATUS_UPDATE == 0){
					MPI_Recv(buff, 128, MPI_CHAR, 0, TAG, MPI_COMM_WORLD, &mpistat);
					stringstream ss (stringstream::in | stringstream::out);
					ss << buff;
					ss >> collection_done;
				}
			}
			
			if(!transin_done[list_picked]){
				transin[list_picked].read(buff,Transformation::basic_byte_size);
				int bytes_read = transin[list_picked].gcount();
				transin_done[list_picked] = (bytes_read == 0); 
				if(!transin_done[list_picked]){
					Transformation *tr = new Transformation(buff,TN_BASIC);
					TransformationAndTag *tn = new TransformationAndTag(tr,list_picked+numprocs);
					node_heap.push_back(tn);
					push_heap(node_heap.begin(),node_heap.end(),greater<TransformationAndTag*>());
				}
			}
		}
		if(transformationsinbuffer > 0 && !collection_done){
			ss.read(buff,transformationsinbuffer*(Transformation::basic_byte_size));
			MPI_Ssend(buff,transformationsinbuffer*(Transformation::basic_byte_size), MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
			num_messages_sent++;
			if(num_messages_sent % MESSAGES_BEFORE_STATUS_UPDATE == 0)
				MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, TAG, MPI_COMM_WORLD, &mpistat);
		}
		//node_transformations.clear();
		*out << "sent candidates to node 0" << endl;
	}
}

#define MAXTRANSINBUFFERVERIFY 256 //16

void collect_transformations_verify_trans(bool compute_details,bool compute_seqaverages){
	int *num_transformations;
	int num_node_transformations = node_transformations.size();
	short num_homologue_pairs=0;
	
	if(procid == 0)	cout << "Array sizes " << num_species << " " << 
		Transformation::protprot_detailed_scores_verify_byte_size << " " << BUFSIZE << endl; cout.flush();
	int lBUFFSIZE=1024*512;
	switch(state){
		case VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA:
			lBUFFSIZE += Transformation::protrna_detailed_scores_verify_byte_size*(num_homologue_pairs + MAXTRANSINBUFFERVERIFY);
			break;
		default:
			lBUFFSIZE += Transformation::protprot_detailed_scores_verify_byte_size*(num_homologue_pairs + MAXTRANSINBUFFERVERIFY);
			break;
	}
	char buff[lBUFFSIZE];
	
	sort(node_transformations.begin(),node_transformations.end(),less<Transformation*>());
	
	ProtProtDetailedScoringMetrics **hom_details;
	int total_transformations;
	if(procid == 0){
		num_transformations = new int[numprocs];
		num_transformations[0] = num_node_transformations;
		total_transformations = num_node_transformations;
		for(int i=1;i<numprocs;i++){
			//cout << "getting #candidates from node " << i << endl; cout.flush();
			MPI_Recv(buff, lBUFFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
			//cout << buff << endl; cout.flush();
			stringstream ss (stringstream::in | stringstream::out);
			ss << buff;
			ss >> num_transformations[i];
			total_transformations += num_transformations[i];
		}
		cout << "#candidates " << total_transformations << endl; cout.flush();
		
		{
			stringstream ss (stringstream::in | stringstream::out);
			ss << total_transformations << " ";
			ss.getline(buff,lBUFFSIZE);
		}
		for(int i=1;i<numprocs;i++)
			MPI_Ssend(buff, 256, MPI_CHAR, i, TAG, MPI_COMM_WORLD);
		
		fstream transout;
		transout.open(local_transformations_file,ios::out);
		
		int rmsd_cutoff = 10;
		float rmsd_good = 4.0;
		int maxnegatives = 200000;
		int numnegatives = 0;
		vector<Transformation*> good_transformations;
		int rmsd_d[rmsd_cutoff], irmsd_d[rmsd_cutoff];
		vector<Transformation*> filtered_transformations;
		int num_clusters = 0, num_hits_filtered = 0, first_hit = -1;
		float min_eVdw, max_eResiduepair, min_curvature_score;
		
		//transout << "rmsd\t"<<"lrmsd\t"<<"irmsd\t"<<"#cnts\t"<<"E\t"<<"details"<<endl;
		transout << setiosflags(ios::fixed) << setprecision(3);
			
		for(int i=0;i<rmsd_cutoff;i++){
			rmsd_d[i] = 0;
			irmsd_d[i] = 0;
		}
		
		//merge transformations from different nodes on the basis of less<Transformation*>
		int *transformations_read = new int[numprocs];
		int *transformations_written = new int[numprocs];
		vector<TransformationAndTag*> heap;
			
		vector<Transformation*>::iterator itr = node_transformations.begin(), end = node_transformations.end();
		
		for(int i = 0 ; i < numprocs ; i++){
			transformations_read[i] = 0;
			transformations_written[i] = 0;
		}
		long count = 0;
		queue<Transformation*> trbuffer[numprocs];
		int bytesreceived, transformationsreceived;
		while((!compute_seqaverages && count < total_transformations)
		 || (compute_seqaverages && count < total_transformations*(num_homologue_pairs+1))){
			if(count == 0){
				if(itr != end){
					TransformationAndTag *tn = new TransformationAndTag(*itr,0);
					heap.push_back(tn);
					itr++;
					transformations_read[0]++;
				}
				for(int i=1;i<numprocs;i++){
					if(transformations_read[i] < num_transformations[i]){
						//cout << "reading candidates from node " << i << "\t"; cout.flush();
						MPI_Recv(buff, lBUFFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
						MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
						if(compute_details)
							switch(state){
								case VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA:
									transformationsreceived = bytesreceived/(Transformation::protrna_detailed_scores_verify_byte_size);
								break;
								default:
									transformationsreceived = bytesreceived/(Transformation::protprot_detailed_scores_verify_byte_size);
								break;
							}
						else
							transformationsreceived = bytesreceived/(Transformation::verify_byte_size);
						//cout << transformationsreceived << endl; cout.flush();
						transformations_read[i] += transformationsreceived;
						for(int tri=0; tri<transformationsreceived; tri++)
							if(compute_details)
								switch(state){
									case VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA:
										trbuffer[i].push(new Transformation(buff+tri*(Transformation::protrna_detailed_scores_verify_byte_size),TN_PROTRNA_DETAILED_SCORE_VERIFY));
									break;
									default:	
										trbuffer[i].push(new Transformation(buff+tri*(Transformation::protprot_detailed_scores_verify_byte_size),TN_PROTPROT_DETAILED_SCORE_VERIFY));
									break;
								}
							else
								trbuffer[i].push(new Transformation(buff+tri*(Transformation::verify_byte_size),TN_VERIFY));
						Transformation *tr = (Transformation*) (trbuffer[i].front());
						trbuffer[i].pop();
						TransformationAndTag *tn = new TransformationAndTag(tr,i);
						heap.push_back(tn);
					}
				}
				make_heap(heap.begin(),heap.end(),greater<TransformationAndTag*>());
			}
			
			pop_heap(heap.begin(),heap.end(),greater<TransformationAndTag*>());
			heap.pop_back();
			TransformationAndTag *min = (TransformationAndTag*) *(heap.end());
			unsigned short list_picked = min->tag;
			Transformation *tr = min->tr;

			//if(tr->vmetrics->rmsd < rmsd_good || numnegatives++ < maxnegatives)
			if(compute_details){
				if(list_picked == 0){
					if(compute_seqaverages){
						receptor->compute_detailed_seqavg_energy(receptor,ligand,tr,&receptor_vs_reference,&ligand_vs_reference,species, num_species, &hom_details);
						//cout << hom_details << endl; cout.flush();
						long tr_frame_number = tr->frame_number;
						delete tr->detailed_scores;
						for(int hi=0; hi < num_homologue_pairs; hi++){
						 	tr->detailed_scores = hom_details[hi];
						 	tr->frame_number = tr_frame_number + total_transformations * (hi+1);
						 	tr->print_details(&transout,TN_PROTPROT_DETAILED_SCORE_VERIFY);
						 	transformations_written[0]++;	count++;
						}
						for(int hi=0; hi < num_homologue_pairs; hi++)	delete hom_details[hi];
						tr->frame_number = tr_frame_number;	
					}
					switch(state){
						case VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA:
							((ProtRnaObject*) receptor)->compute_detailed_scores_protrna(((ProtRnaObject*)ligand),tr);
						break;
						default: 
							receptor->compute_detailed_scores(ligand,tr);
						break;
					}
				}
				switch(state){
					case VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA:
						tr->print_details(&transout,TN_PROTRNA_DETAILED_SCORE_VERIFY);
					break;
					default :
						tr->print_details(&transout,TN_PROTPROT_DETAILED_SCORE_VERIFY);
					break;
				}
				if(list_picked == 0)	delete tr->detailed_scores;
			} else
				tr->print_details(&transout,TN_VERIFY);
			
			if(tr->vmetrics->rmsd <= rmsd_cutoff && tr->vmetrics->rmsd >= 0.0)
				rmsd_d[((int) tr->vmetrics->rmsd)]++;
			/*if(tr->irmsd <= rmsd_cutoff)
				irmsd_d[((int) tr->irmsd)]++;
			if(tr->rmsd < rmsd_good)
				num_rmsd_hits_generated++;*/
			
			bool select = false;
			if(num_clusters < NUM_TRANS_FILTERED){
				select = true;
				for(vector<Transformation*>::iterator ftitr = filtered_transformations.begin(); ftitr != filtered_transformations.end(); ftitr++){
					Transformation *ftr = *ftitr;
					float d, ud;
					ftr->distance(&d, &ud, tr);
					if(d <= TR_MAX_R_DISTANCE && ud <= TR_MAX_ROTATION_DISTANCE){
						select = false;
					}
				}
				if(select){
					filtered_transformations.push_back(tr);
					num_clusters++;
				}
			}
				
			if(tr->vmetrics->rmsd < rmsd_good && good_transformations.size() < 50000){
				good_transformations.push_back(tr);
				if(first_hit < 0){
					first_hit = num_clusters;
					if(first_hit == NUM_TRANS_FILTERED)
						first_hit = count;
					min_eVdw = tr->eVdw;
					max_eResiduepair = tr->eResiduepair;
					min_curvature_score = tr->curvature_score;
				} else {
					min_eVdw = minimum(min_eVdw,tr->eVdw);
					max_eResiduepair = max(max_eResiduepair,tr->eResiduepair);
					min_curvature_score = minimum(min_curvature_score,tr->curvature_score);
				}
				if(select)
					num_hits_filtered++;
			} else if(list_picked != 0 && !select){
				delete min;
			}
			
			transformations_written[list_picked]++;
			count++;
			if(count % 100000 == 0){
				cout << count << " " << num_hits_filtered << " " << good_transformations.size() << " " 
				 << num_clusters << " " << filtered_transformations.size() << endl;
			}
				
			if(list_picked == 0){
				if(itr != end){
					TransformationAndTag *tn = new TransformationAndTag(*itr,0);
					itr++;
					transformations_read[0]++;
					heap.push_back(tn);
					push_heap(heap.begin(),heap.end(),greater<TransformationAndTag*>());
				}
			} else{
				if(trbuffer[list_picked].empty() && ((!compute_seqaverages && (transformations_read[list_picked] < num_transformations[list_picked]))
				 || (compute_seqaverages && (transformations_read[list_picked] < num_transformations[list_picked]*(num_homologue_pairs+1)) ))){
					//cout << "reading candidates from node " << list_picked << "\t"; cout.flush();
					MPI_Recv(buff, lBUFFSIZE, MPI_CHAR, list_picked, TAG, MPI_COMM_WORLD, &mpistat);
					MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
					if(compute_details)
						switch(state){
							case VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA:
								transformationsreceived = bytesreceived/(Transformation::protrna_detailed_scores_verify_byte_size);
							break;
							default:
								transformationsreceived = bytesreceived/(Transformation::protprot_detailed_scores_verify_byte_size);
							break;
						}
					else
						transformationsreceived = bytesreceived/(Transformation::verify_byte_size);
					//cout << transformationsreceived << endl; cout.flush();
					transformations_read[list_picked] += transformationsreceived;
					for(int tri=0; tri<transformationsreceived; tri++)
						if(compute_details)
							switch(state){
								case VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA:
									trbuffer[list_picked].push(new Transformation(buff+tri*(Transformation::protrna_detailed_scores_verify_byte_size),TN_PROTRNA_DETAILED_SCORE_VERIFY));
								break;	
								default:
									trbuffer[list_picked].push(new Transformation(buff+tri*(Transformation::protprot_detailed_scores_verify_byte_size),TN_PROTPROT_DETAILED_SCORE_VERIFY));
								break;
							}
						else
							trbuffer[list_picked].push(new Transformation(buff+tri*(Transformation::verify_byte_size),TN_VERIFY));
				}
				if(!trbuffer[list_picked].empty()){
					Transformation *tr = (Transformation*) (trbuffer[list_picked].front());
					trbuffer[list_picked].pop();
					TransformationAndTag *tn = new TransformationAndTag(tr,list_picked);
					heap.push_back(tn);
					push_heap(heap.begin(),heap.end(),greater<TransformationAndTag*>());
				}
			}
		}		
		transout.close();
		cout << "saved transformations " << total_transformations << endl;
		
		char command[512];
		sprintf(command, "gzip %s",local_transformations_file);
		int ret = system(command);
		cout << state << " " << command << " " << ret << endl;
		if(ret != 0)	success=0;
		if(compute_details)
			sprintf(command, "cp %s.gz %s.vtrans.gz",local_transformations_file,tag);
		else
			sprintf(command, "cp %s.gz %s.vmetrics.gz",local_transformations_file,tag);
		
		ret = system(command);
		cout << state << " " << command << " " << ret << endl;
		if(ret != 0)	success=0;
		
		cout << "rmsd distribution 1 to " << rmsd_cutoff << "\t";
		for(int i=0;i<rmsd_cutoff;i++)
			cout << rmsd_d[i] << " ";
		cout << endl;
		/*cout << "irmsd distribution 1 to " << rmsd_cutoff << endl;
		for(int i=0;i<rmsd_cutoff;i++)
			cout << irmsd_d[i] << " ";
		cout << endl;*/
		cout << "hit if transformation rmsd < " << rmsd_good << " #hits generated " /*<< num_rmsd_hits_generated << " "*/ << good_transformations.size() << " ";
		cout << "#clusters " << num_clusters << " ";
		cout << "hits filtered " << num_hits_filtered << " best rank hit " << first_hit << endl;
		//cout << "Min eVdw " << min_eVdw << " Max eResiduepair " << max_eResiduepair << " Min curvature score " << min_curvature_score << endl;
		//cout << "rmsd\t"<<"lrmsd\t"<<"irmsd\t"<<"#cnts\t"<<"E\t"<<"details"<<endl;
		cout << "top 10: ";
		count = 0;
		for(vector<Transformation*>::iterator titr = filtered_transformations.begin();titr != filtered_transformations.end() && count++ < 10; titr++){
			Transformation *tr = *titr;
			cout << tr->vmetrics->rmsd << " ";
		}	
		cout << endl;
		for(vector<Transformation*>::iterator titr = good_transformations.begin();titr != good_transformations.end(); titr++){
			Transformation *tr = *titr;
			tr->print_details(&cout,TN_VERIFY);
			stringstream ss (stringstream::in | stringstream::out);
			ss << "hit_details/" << tr->frame_number << ".pdb";
			string filename; ss >> filename;
			//cout << filename << endl;
			//tr->write_as_pdb(ligand->c,filename,false);
		}
	} else {
		stringstream ss (stringstream::in | stringstream::out);
		ss << num_node_transformations << " ";
		ss.getline(buff,lBUFFSIZE);
		MPI_Ssend(buff, 256, MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
		*out << "done sending #transformations " << num_node_transformations << endl;
		
		MPI_Recv(buff, lBUFFSIZE, MPI_CHAR, 0, TAG, MPI_COMM_WORLD, &mpistat);
		{
			stringstream ss (stringstream::in | stringstream::out);
			ss << buff;
			ss >> total_transformations;
		}
		
		int transformationsinbuffer=0;
		ss.clear();
		char ssbuf[Transformation::protprot_detailed_scores_verify_byte_size*(MAXTRANSINBUFFERVERIFY+num_homologue_pairs+2)];
		// TRANS NOT IN SORTED ENERGY ORDER
		for(vector<Transformation*>::iterator frameitr = node_transformations.begin(); frameitr != node_transformations.end(); frameitr++){
			Transformation* tr = *frameitr;
			if(compute_details){
				if(compute_seqaverages){
					receptor->compute_detailed_seqavg_energy(receptor,ligand,tr,&receptor_vs_reference,&ligand_vs_reference,species, num_species,&hom_details);
					long tr_frame_number = tr->frame_number;
					delete tr->detailed_scores;
					for(int hi=0; hi < num_homologue_pairs; hi++){
					 	tr->detailed_scores = hom_details[hi];
					 	tr->frame_number = tr_frame_number + total_transformations * (hi+1);
					 	tr->write_binary(&ss,TN_PROTPROT_DETAILED_SCORE_VERIFY);
					 	transformationsinbuffer++;
					}
					for(int hi=0; hi < num_homologue_pairs; hi++)	delete hom_details[hi];
					tr->frame_number = tr_frame_number;	
				}  
				switch(state){
					case VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA:
						((ProtRnaObject*)receptor)->compute_detailed_scores_protrna(((ProtRnaObject*)ligand),tr);
						tr->write_binary(&ss,TN_PROTRNA_DETAILED_SCORE_VERIFY);
					break;
					default:
						receptor->compute_detailed_scores(ligand,tr);
						tr->write_binary(&ss,TN_PROTPROT_DETAILED_SCORE_VERIFY);
					break;
				}	
			} else 
				tr->write_binary(&ss,TN_VERIFY);
			transformationsinbuffer++;
			if(transformationsinbuffer >= MAXTRANSINBUFFERVERIFY){
				int buffsize;
				if(compute_details)
					switch(state){
						case VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA:
							buffsize = transformationsinbuffer*(Transformation::protrna_detailed_scores_verify_byte_size);
						break;
						default:
							buffsize = transformationsinbuffer*(Transformation::protprot_detailed_scores_verify_byte_size);
						break;
					}
				else 
					buffsize = transformationsinbuffer*(Transformation::verify_byte_size);
				ss.read(buff,buffsize);
				MPI_Ssend(buff,buffsize, MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
				//*out << procid << " sent " << transformationsinbuffer << endl; out->flush();
				ss.clear(); ssbuf[0] = '\0'; ss.str(ssbuf); transformationsinbuffer=0;
			}
			if(compute_details)	delete tr->detailed_scores;
			delete tr->vmetrics;
			//delete tr;
		}
		if(transformationsinbuffer > 0){
			int buffsize;
			if(compute_details)
				switch(state){
					case VERIFY_TRANS_COMPUTE_DETAILS_PROTRNA:
						buffsize = transformationsinbuffer*(Transformation::protrna_detailed_scores_verify_byte_size);
					break;
					default:
						buffsize = transformationsinbuffer*(Transformation::protprot_detailed_scores_verify_byte_size);
					break;
				}
			else 
				buffsize = transformationsinbuffer*(Transformation::verify_byte_size);
			ss.read(buff,buffsize);
			MPI_Ssend(buff,buffsize, MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
		}
		//node_transformations.clear();
		time(&current_time);
		*out << "node " << procid << " sent candidates to node 0\t time:" << difftime(current_time,start_time) << "s" << endl;;
	}
}

void filter_trans_basedon_info(ModelInfo *modelinfo){
	// build aacontact grid on both molecules
	ligand->grid_compute_aacid_contacts();
	
	vector<Transformation *> oldnode_transformations = node_transformations;
	node_transformations = *(new vector<Transformation *>);
	for(vector<Transformation *>::iterator itr = oldnode_transformations.begin(); itr != oldnode_transformations.end(); itr++){
		Transformation *tr = (Transformation*) *itr;
		bool consistent = receptor->consistent_with_info_T50(receptor, ligand, modelinfo, tr);
		if(consistent)	node_transformations.push_back(tr);
	}
	*out << "node transformations " << oldnode_transformations.size() << " filtered " << node_transformations.size() << endl;
	out->flush();
}

/*
 * split the box into two boxes such that 
 *  - the points are approximately distributed equally
 *  - Sum ( #points in cell ^2 ) is distributed equally 
 *  - Sum ( 2 ^(#points in cell) ) is distributed equally
 */
vector<int*> split(int box[6], hash_map<long,int,hash<long>,eqlong> *frequencies, int stage, int total_stages){
	vector<int*> result;
	// splitting only along theta and phi
	int axis = (stage % 3); //(stage %2) + 1;
	int forward = box[axis], backward = box[3+axis];
	
	if(stage == total_stages){
		int* boxarray = (int*) malloc(6*sizeof(int));
		memcpy(boxarray,box,6*sizeof(int));
		result.push_back(boxarray);
		return result;
	}
	
	float forward_weight = 0, backward_weight = 0;
	long index;
	while(forward != backward){
		//*out << forward << " " << forward_weight << " " << backward << " " << backward_weight << endl;
		if(forward_weight < backward_weight){
			switch(axis){
				case 0:
					for(int j = box[1]; j <= box[4]; j++){
						for(int k = box[2] ; k <= box[5]; k++){
							index = forward;
							index = index * num_cmr_x_divisions + j;
							index = index * num_cmr_y_divisions + k;
							if(frequencies->count(index) != 0){
								switch(stage){
									/*case GENERATE_COMBINATIONS:
										forward_weight += pow(2.0,(*frequencies)[index]);
									break;*/
									default:
										forward_weight += (*frequencies)[index];
										//forward_weight += (*frequencies)[index] * (*frequencies)[index];
									break;
								}
							}
						}
					}
				break;
				case 1:
					for(int l = box[0]; l <= box[3]; l++){
						for(int k = box[2] ; k <= box[5]; k++){
							index = l;
							index = index * num_cmr_x_divisions + forward;
							index = index * num_cmr_y_divisions + k;
							if(frequencies->count(index) != 0){
								switch(stage){
									/*case GENERATE_COMBINATIONS:
										forward_weight += pow(2.0,(*frequencies)[index]);
									break;*/
									default:
										forward_weight += (*frequencies)[index];
										//forward_weight += (*frequencies)[index] * (*frequencies)[index];
									break;
								}
							}
						}
					}
				break;
				case 2:
					for(int l = box[0]; l <= box[3]; l++){
						for(int j = box[1]; j <= box[4]; j++){
							index = l;
							index = index * num_cmr_x_divisions + j;
							index = index * num_cmr_y_divisions + forward;
							if(frequencies->count(index) != 0){
								switch(stage){
									/*case GENERATE_COMBINATIONS:
										forward_weight += pow(2.0,(*frequencies)[index]);
									break;*/
									default:
										forward_weight += (*frequencies)[index];
										//forward_weight += (*frequencies)[index] * (*frequencies)[index];
									break;
								}
							}	
						}
					}
				break;
			}
			forward++;
		} else {
			switch(axis){
				case 0:
					for(int j = box[1]; j <= box[4]; j++){
						for(int k = box[2] ; k <= box[5]; k++){
							index = backward;
							index = index * num_cmr_x_divisions + j;
							index = index * num_cmr_y_divisions + k;
							if(frequencies->count(index) != 0){
								switch(stage){
									/*case GENERATE_COMBINATIONS:
										backward_weight += pow(2.0,(*frequencies)[index]);
									break;*/
									default:
										backward_weight += (*frequencies)[index];
										//backward_weight += (*frequencies)[index] * (*frequencies)[index];
									break;
								}
							}
						}
					}
				break;
				case 1:
					for(int l = box[0]; l <= box[3]; l++){
						for(int k = box[2] ; k <= box[5]; k++){
							index = l;
							index = index * num_cmr_x_divisions + backward;
							index = index * num_cmr_y_divisions + k;
							if(frequencies->count(index) != 0){
								switch(stage){
									/*case GENERATE_COMBINATIONS:
										backward_weight += pow(2.0,(*frequencies)[index]);
									break;*/
									default:
										backward_weight += (*frequencies)[index];
										//backward_weight += (*frequencies)[index] * (*frequencies)[index];
									break;
								}
							}
						}
					}
				break;
				case 2:
					for(int l = box[0]; l <= box[3]; l++){
						for(int j = box[1]; j <= box[4]; j++){
							index = l;
							index = index * num_cmr_x_divisions + j;
							index = index * num_cmr_y_divisions + backward;
							if(frequencies->count(index) != 0){
								switch(stage){
									/*case GENERATE_COMBINATIONS:
										backward_weight += pow(2.0,(*frequencies)[index]);
									break;*/
									default:
										backward_weight += (*frequencies)[index];
										//backward_weight += (*frequencies)[index] * (*frequencies)[index];
									break;
								}
							}
						}
					}
				break;
			}
			backward--;
		}
	}
	
	int* box1 = (int*) malloc(6*sizeof(int));
	int* box2 = (int*) malloc(6*sizeof(int));
	for(int i = 0 ; i < 3; i++){
		box1[i] = box[i];
		box2[3+i] = box[3+i];
	}
	int split_index = backward-1;
	if(split_index < forward)
		split_index = forward;
	
	for(int i = 0 ; i < 3; i++){
		if(i == axis){
			box1[3+i] = split_index;
			box2[i] = split_index+1;
		} else {
			box2[i] = box[i];
			box1[3+i] = box[3+i];
		}
	}
	//*out << stage << " " << forward << " " << forward_weight << " " << backward << " " << backward_weight << endl; 
	vector<int*> result1 = split(box1, frequencies, stage+1, total_stages);
	vector<int*>::iterator ritr = result1.begin(), rend = result1.end();
	while(ritr != rend){
		result.push_back(*ritr);
		ritr++;
	}
	vector<int*> result2 = split(box2, frequencies, stage+1, total_stages);
	ritr = result2.begin(), rend = result2.end();
	while(ritr != rend){
		result.push_back(*ritr);
		ritr++;
	}
	return result;
}

/* 
 * already generated transformations can read from file
 * copy to scratch directory before reading
 * 
 * save NFS! reading in a round robin fashion 
 *   - copying using pbat
 */
void examine_transformations(){
	*out << "examining transformations" << endl;
	
	sprintf(command, "cp %s %s",transformations_file,local_transformations_file);
	if(procid > 0){
		MPI_Recv(buff, BUFSIZE, MPI_CHAR, procid-1, TAG, MPI_COMM_WORLD, &mpistat);
		*out << buff << endl;
	}
	
	int ret = system(command);
	*out << command << " " << ret << endl;
	
	sprintf(buff, "node-%d: finished reading file",procid);
	if(procid < numprocs-1) {
		MPI_Ssend(buff, BUFSIZE, MPI_CHAR, procid+1, TAG, MPI_COMM_WORLD);
	}
	
	cmr_rmax = ligand->c->diameter + receptor->c->diameter;
	*out << "rmax " << cmr_rmax << endl;
	num_cmr_x_divisions = num_cmr_y_divisions = num_cmr_z_divisions = (2*cmr_rmax)/TRCLUSTERING_GRID_SPACING+2;
	*out << " #divisions " << num_cmr_x_divisions << endl;
	
	fstream transin(local_transformations_file,ios::binary|ios::in); 
	//transin.seekg(ios_base::beg);
	*out << "reading transformations from file" << endl;
	*out << local_transformations_file << " " << transin.good() << endl;
	
	int num_matches = 0;
	long index;
	while(transin.good()){
		transin.read(buff,Transformation::basic_byte_size);
		int bytes_read = transin.gcount();
		//cout << num_matches << " " << bytes_read << endl; cout.flush();
		if(bytes_read > 0){
			Transformation *tr = new Transformation(buff,TN_BASIC);
			//tr->print_details(out, TN_BASIC); out->flush();
			
			tr->compute_coordinates((void *)receptor, (void *)ligand);
			Vector v = Vector(tr->cmr) + Vector(cmr_rmax,cmr_rmax,cmr_rmax);
			
			index = (int) (v.x/TRCLUSTERING_GRID_SPACING);
			index = index * num_cmr_x_divisions + (int) (v.y/TRCLUSTERING_GRID_SPACING);
			index = index * num_cmr_y_divisions + (int) (v.z/TRCLUSTERING_GRID_SPACING);
			
			if(cmr_frequencies.count(index) == 0)	cmr_frequencies[index] = 0;
			cmr_frequencies[index]++;
			
			if(tr->eVdw >= MIN_VDW_FILTER2)	num_matches++;
				
			delete tr;
		}
	}
	transin.close();
	*out << "matches read " << num_matches << endl;
	
	hash_map<long,int,hash<long>,eqlong>::iterator fitr = cmr_frequencies.begin(), fend = cmr_frequencies.end();
	while(fitr != fend){
		int f = fitr->second;
		if(f > cell_max_frequency)	cell_max_frequency = f;
		fitr++;
	}
	*out << "cell max frequency " << cell_max_frequency << endl;
	
	// get the frequency distribution of how clustered the transformations are
	if(procid == 0){
		hash_map<int,int,hash<int>,eqint> cluster_frequency;
		fitr = cmr_frequencies.begin(); fend = cmr_frequencies.end();
		while(fitr != fend){
			int f = fitr->second;
			if(cluster_frequency.count(f) == 0)	cluster_frequency[f] = 0;
			cluster_frequency[f]++;
			if(f > cell_max_frequency)	cell_max_frequency = f;
			fitr++;
		}
		int cluster_frequency_array[cell_max_frequency+1];
		for(int i = 0 ; i <= cell_max_frequency; i++)
			cluster_frequency_array[i] = 0;
		hash_map<int,int,hash<int>,eqint>::iterator citr = cluster_frequency.begin(), cend = cluster_frequency.end();
		while(citr != cend){
			cluster_frequency_array[citr->first] = citr->second;
			citr++;
		}
		cout << "#tr per cell distribution" << endl;
		for(int i = 0 ; i <= cell_max_frequency; i++)
			cout << cluster_frequency_array[i] << " ";
		cout << endl;
	}
}

void write_trans_txt(){
	fstream transin(local_transformations_file,ios::binary|ios::in);
	fstream transout("trans.txt",ios::out); 
	//transin.seekg(ios_base::beg);
	*out << "reading transformations from file" << endl;
	*out << local_transformations_file << " " << transin.good() << endl;
	
	while(transin.good()){
		transin.read(buff,Transformation::basic_byte_size);
		int bytes_read = transin.gcount();
		if(bytes_read > 0){
			Transformation *tr = new Transformation(buff,TN_BASIC);
			tr->compute_coordinates((void *)receptor, (void *)ligand);
			tr->print_details(&transout, TN_BASIC); //transout.flush();
				
			delete tr;
		}
	}
	transin.close();
	transout.close();
}

/* 
 * doing file i/o - write to file and take relevant portions from file?
 */
void read_transformations(){
	int node_box[numprocs][6];
	int proc_index = 0;
	for(int i = 0 ; i < 3; i++)		box[i] = 0;
	
	box[3] = num_cmr_x_divisions - 1;
	box[4] = num_cmr_y_divisions - 1;
	box[5] = num_cmr_z_divisions - 1;
	
	int num_stages = (int) log2(numprocs);
	vector<int*> divisions = split(box, &cmr_frequencies,0,num_stages);
	
	*out << "#divisions " << divisions.size() << endl;
	vector<int*>::iterator ditr = divisions.begin(), dend = divisions.end();
	while(ditr != dend){
		int* box = (int*) *ditr;
		*out << "(" << box[0] << " " << box[1] << " " << box[2] << ") -> ("
			<< box[3] << " " << box[4] << " " << box[5] << ")" << endl;
		for(int i = 0 ; i < 6 ; i++){
			node_box[proc_index][i] = box[i];
		}
		proc_index++;
		ditr++;
	}
	
	for(int i = 0 ; i < 6; i++){
		box[i] = node_box[procid][i];
	}
	*out << "box = (" << box[0] << " " << box[1] << " " << box[2] << ") -> ("
			<< box[3] << " " << box[4] << " " << box[5] << ")" << endl;
			
	node_transformations.clear();
	transformations_by_cell.clear();
	fstream transin(local_transformations_file,ios::binary|ios::in);
	*out << local_transformations_file << " " << transin.good() << endl;
	
	int num_transformations_read = 0;
	while(transin.good()){
		transin.read(buff,Transformation::basic_byte_size);
		if(transin.gcount() > 0){
			Transformation *tr = new Transformation(buff,TN_BASIC);
			
			tr->compute_coordinates((void *)receptor, (void *)ligand);
			Vector v = Vector(tr->cmr) + Vector(cmr_rmax,cmr_rmax,cmr_rmax);
			
			int cmr_x_index = (int) (v.x/TRCLUSTERING_GRID_SPACING);
			int cmr_y_index = (int) (v.y/TRCLUSTERING_GRID_SPACING);
			int cmr_z_index = (int) (v.z/TRCLUSTERING_GRID_SPACING);
			
			bool my_transformation = false, neighbor_transformation = false;
			my_transformation = (contained_in(box[0],box[3],cmr_x_index) 
						&& contained_in(box[1],box[4],cmr_y_index)
						&& contained_in(box[2],box[5],cmr_z_index));
			
			//*out << tr->frame_number << " " << my_transformation << endl;
				
			// add boundary neighbors to the hashmap
			neighbor_transformation = contained_in(box[0]-R_SPREAD,box[3]+R_SPREAD,cmr_x_index)
										&& contained_in(box[1]-R_SPREAD,box[4]+R_SPREAD,cmr_y_index)
										&& contained_in(box[2]-R_SPREAD,box[5]+R_SPREAD,cmr_z_index);
			
			if(state == GENERATE_PDB
				|| state == COMPUTE_DETAILS
				|| state == SCD_GIVEN_INTERFACE)
				my_transformation = (tr->frame_number % numprocs == procid);
				
			if(state==VERIFY_TRANS)
				my_transformation = (numprocs == 1) || (tr->frame_number % (numprocs-1) == (procid-1)); 
				
			if( (state == FILTER_STERIC_CLASHES && my_transformation)
			 || (state == GENERATE_COMBINATIONS && neighbor_transformation)
			 || (state == COMPUTE_DETAILS && my_transformation)
			 || (state == SCD_GIVEN_INTERFACE && my_transformation)
			 || (state == VERIFY_TRANS && my_transformation)
			 || (state == GENERATE_PDB && my_transformation)
			 || (state == CHECK_GRIDSCORE && my_transformation)
			 || (state == REFINE_TRANSFORMATION && my_transformation)
			 || (state == REFINE_SIDECHAINS && my_transformation)
			 ){
				num_transformations_read++;
				long index = (cmr_x_index*num_cmr_x_divisions + cmr_y_index)*num_cmr_y_divisions + cmr_z_index;
				if(transformations_by_cell.count(index) == 0)
					transformations_by_cell[index] = *(new vector<Transformation*>);
				transformations_by_cell[index].push_back(tr);
				
				if(my_transformation 
				 //&& tr->eVdw >= MIN_VDW_FILTER2
				 //&& tr->eResiduepair <= MAX_CONTACT_ENERGY(1)
				 ) {
					node_transformations.push_back(tr);
					if(state == GENERATE_PDB) {
						stringstream ss (stringstream::in | stringstream::out);
						string s;
						ss << "generatepdb/tl" << tr->frame_number << ".pdb";
						ss >> s;
						tr->write_as_pdb(ligand->c, "-", false, s, false);
					}
				 }
			} else
				delete tr;
		}
	}
	transin.close();
	*out << "#candidates " << node_transformations.size() << " #cells " << transformations_by_cell.size() 
		<< " #trans held " << num_transformations_read << endl;
}

/* 
 * Select transformations whose ids are in a given file
 */
void select_transformations(){
	hash_set<long,hash<long>,eqlong> selected_ids;
	fstream selectin("select.ids", ios::in);
	while(selectin.good()){
		long frame_number;
		selectin >> frame_number;
		selected_ids.insert(frame_number);
	}
	selectin.close();
	
	fstream selectout("select.trans", ios::binary|ios::out);
	fstream transin(local_transformations_file,ios::binary|ios::in);
	*out << local_transformations_file << " " << transin.good() << endl;
	
	int num_trans_selected = 0;
	while(transin.good()){
		transin.read(buff,Transformation::basic_byte_size);
		if(transin.gcount() > 0){
			Transformation *tr = new Transformation(buff,TN_BASIC);
			if(selected_ids.count(tr->frame_number) > 0){
				tr->write_binary(&selectout,TN_BASIC);
				//tr->print_details(&cout,TN_BASIC);
				num_trans_selected++;
			} else 
				delete tr;
		}
	}
	transin.close();
	selectout.close();
	cout << "#selected " << num_trans_selected << " " << selected_ids.size() << endl;
}

extern Transformation **localneighbors;

void initialize_transformation_localneighbors(){
	// generate the list of local transformations to be considered
	localneighbors = (Transformation **) malloc((TR_NUM_LOCAL_NEIGHBORS+1)*sizeof(Transformation*));
	
	/* Sampling translations on a sphere */
	Vector sphere_uniform[27];
	int index=1;
	sphere_uniform[0] = Vector(0,0,0);
	string filename = piedock_home + "/" + string(DOCK_DIR) + "7.sphere";
	char buf[8192];
	fstream frotations(filename.c_str());
    while(frotations.good()){
    	frotations.getline(buf,8192);
    	if(frotations.gcount() > 0){
    		stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
    		float x,y,z;
    		ss >> x; ss >> y; ss >> z;
    		sphere_uniform[index++] = Vector(x,y,z)*2.4;
    	}
    }
    frotations.close();
    frotations.clear();
    filename = piedock_home + "/" + string(DOCK_DIR) + "19.sphere";
    frotations.open(filename.c_str(),fstream::in);
    while(frotations.good()){
    	frotations.getline(buf,8192);
    	if(frotations.gcount() > 0){
    		stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
    		float x,y,z;
    		ss >> x; ss >> y; ss >> z;
    		sphere_uniform[index++] = Vector(x,y,z)*4.0;
    	}
    }
    frotations.close();
	
	float phi=0.06;
	index=0;
	for(int ai = 0; ai < 3; ai++){
		float alpha = ai*0.03;
		for(int bi = 0; bi < 3; bi++){
			float beta = bi*0.03;
			for(int gi = 0; gi < 3; gi++){
				float gamma = gi*0.03;
				//if(ai + gi != 3){
					for(int j = 0; j < 27; j++){
						Transformation *tr = new Transformation(alpha,beta,gamma,0);
						Vector v = tr->inverse_rotate(*(ligand->c->center));
						*(tr->translation) = sphere_uniform[j];
						
						// make the rotations about the center of the ligand
						if(procid==0)	*out << index << " translation norm2 " << tr->translation->norm_squared() << "\tabout center\t"; 
						*(tr->translation) = *(tr->translation) + *(ligand->c->center) - v; 
						if(procid==0)	*out << tr->translation->norm_squared() << endl;
						
						localneighbors[index++] = tr;
						//tr->print_details(&cout,TN_BASIC);
					}
				//}
			}
		}
	}
	
	// distance distribution
	for(int i = 0 ; i < TR_NUM_LOCAL_NEIGHBORS; i++){
		Transformation *tr1 = localneighbors[i];
		for(int j = i ; j < TR_NUM_LOCAL_NEIGHBORS; j++){
			float d,Ud;
			tr1->distance(&d,&Ud,localneighbors[j],*(ligand->c->center));
			//if(procid==0)	*out << i << " " << j << " " << d << " " << Ud << endl;
		}
	}
	
	if(procid == 0)	cout << "number of local neighbors is " << index << endl; 
}

void optimize_transformations(){
	initialize_transformation_localneighbors();
	
	// optimize each transformation locally, and write to file
	char tfilename[512];
	sprintf(tfilename, "%s/%s/%d/trans%d",node_tmp_dir,refpdbcode.c_str(),procid,procid);
	fstream transout(tfilename,ios::binary|ios::out);
				
	vector<Transformation*> node_oldtransformations = node_transformations; 
	node_transformations = *(new vector<Transformation*>);
	for(vector<Transformation*>::iterator titr = node_oldtransformations.begin(); titr != node_oldtransformations.end(); titr++){
		Transformation *tr = (Transformation *) *titr;
		Transformation *tr_optimized = optmize_transformation_bruteforce(receptor,ligand,tr);
		node_transformations.push_back(tr_optimized);
		tr_optimized->write_binary(&transout,TN_BASIC);
		
		node_transformations.push_back(tr);
		tr->write_binary(&transout,TN_BASIC);
		for(int i = 0 ; i < TR_NUM_LOCAL_NEIGHBORS; i++){
			Reference_Frame *rf = Reference_Frame::compose(localneighbors[i],tr);
			Transformation *ntr = new Transformation(rf->translation, rf->ex, rf->ey, 1.0, 0, i);
			//ntr->write_binary(&transout,TN_BASIC);
		}
		//tr_optimized->print_details(out,TN_BASIC);
		
		delete tr;
	}
	transout.close();
	pieces[procid] = node_transformations.size();
}

/* compute approximations of entropy
 * 	currently computing the number of neighbors
*/
void compute_entropy(){
	for(vector<Transformation*>::iterator tritr = node_transformations.begin(); tritr != node_transformations.end(); tritr++){
		Transformation* tr = *tritr;
		tr->num_neighbors=0;
	}
	
	for(hash_map<long,vector<Transformation*>,hash<long>,eqlong>::iterator citr = transformations_by_cell.begin(); citr != transformations_by_cell.end(); citr++){
		long index = citr->first;
		int r_x,r_y,r_z;
		r_z = index % num_cmr_y_divisions;
		r_y = (index/num_cmr_y_divisions) % num_cmr_x_divisions;
		r_x = ((index/num_cmr_y_divisions) / num_cmr_x_divisions);
		
		bool my_cell = (contained_in(box[0],box[3],r_x) && contained_in(box[1],box[4],r_y) && contained_in(box[2],box[5],r_z));
		if(my_cell){
			int min_r_x,max_r_x,min_r_y,max_r_y,min_r_z,max_r_z;
			min_r_x = r_x - R_SPREAD;
			if(min_r_x <= 0) min_r_x = 0;
			max_r_x = r_x + R_SPREAD;
			if(max_r_x >= num_cmr_x_divisions - 1) max_r_x = num_cmr_x_divisions - 1;
			min_r_y = r_y - R_SPREAD;
			if(min_r_y <= 0) min_r_y = 0;
			max_r_y = r_y + R_SPREAD;
			if(max_r_y >= num_cmr_x_divisions - 1) max_r_y = num_cmr_y_divisions - 1;
			min_r_z = r_z - R_SPREAD;
			if(min_r_z <= 0) min_r_z = 0;
			max_r_z = r_z + R_SPREAD;
			if(max_r_z >= num_cmr_x_divisions - 1) max_r_z = num_cmr_z_divisions - 1;
			 
			vector<Transformation*> cell_transformations = citr->second;
			vector<Transformation*>::iterator titr = cell_transformations.begin(), tend = cell_transformations.end();
			while(titr != tend){
				Transformation *tr = (Transformation*) *titr;
				//*out << tr->frame_number << " - ";
				
				for(int irx = min_r_x; irx <= max_r_x; irx++){
					for(int iry = min_r_y; iry <= max_r_y; iry++){
						for(int irz = min_r_z; irz <= max_r_z; irz++){
							long nindex = (irx*num_cmr_x_divisions + iry)*num_cmr_y_divisions + irz;
							//*out << nindex << " ";
							if(transformations_by_cell.count(nindex) > 0){
								vector<Transformation*> adjacent_cell_transformations = transformations_by_cell[nindex];
								for(vector<Transformation*>::iterator adj_tritr = adjacent_cell_transformations.begin(); adj_tritr != adjacent_cell_transformations.end(); adj_tritr++){
									Transformation* adj_tr = *adj_tritr;
									// compute distance between transformations and add
									if(tr->frame_number < adj_tr->frame_number){
										float d,ud;
										tr->distance(&d,&ud,adj_tr);
										if(d <= R_SPREAD && ud <= UR_SPREAD){
											//*out << adj_tr->frame_number << " (" << d << ":" << ud << ") ";
											tr->num_neighbors++;
											adj_tr->num_neighbors++;
										}
									}
								}
							}
						}
					}
				}
				//*out << endl;
				titr++;
			}
		}	
	}
}

/*
 * Use relaxed global requirements for feasability of a transformation
 * and filter
 */
void filter_steric_clashes(){
	//int vote_cutoff = (int) MIN_VOTES(receptor->num_points, ligand->num_points);
	//if(tr->votes >= vote_cutoff)

	hash_map<long,vector<Transformation*>,hash<long>,eqlong> filtered_transformations_by_cell;
	hash_map<long,vector<Transformation*>,hash<long>,eqlong>::iterator citr, cend;
	vector<Transformation*> node_filtered_transformations;
	
	long num_filtered = 0;
	for(int f = cell_max_frequency; f >= 0; f--){
		citr = transformations_by_cell.begin();
		cend = transformations_by_cell.end();
		
		while(citr != cend){
			vector<Transformation*> cell_transformations = citr->second;
			vector<Transformation*> cell_filtered_transformations;
			if(cell_transformations.size() == f){
				//compute how bad a cell is in terms of vander waals clashes
				float cell_score=0;
				vector<Transformation*>::iterator titr = cell_transformations.begin(), tend = cell_transformations.end();
				while(titr != tend){
					Transformation *tr = (Transformation*) *titr;
					//*out << tr->frame_number << endl;
					//out->flush();
					if(receptor->filter1(ligand,tr)){
						if(receptor->filter2(ligand,tr)){
							receptor->filter3(ligand,tr);
							//tr->compute_references();
							cell_filtered_transformations.push_back(tr);
							node_filtered_transformations.push_back(tr);
						}
					}
					titr++;
				}
								
				if(cell_filtered_transformations.size() > 0){
					//*out << citr->first << " #filtered " << cell_filtered_transformations.size() << endl;
					
					num_filtered += cell_filtered_transformations.size();
					filtered_transformations_by_cell[citr->first] = cell_filtered_transformations;
					cell_transformations = cell_filtered_transformations;
				}
			}
			citr++;	
		}
	}
	transformations_by_cell = filtered_transformations_by_cell;
	node_transformations = node_filtered_transformations;
	
	*out << "after clearing steric clashes:" << endl << "#candidates "  << num_filtered << " #cells " << transformations_by_cell.size() << endl;
	sort(node_transformations.begin(), node_transformations.end(),less<Transformation*>());
}


/*
 * sort combinations according to their partial order and pick different looking maximal elements
 * using total order on num contacts for now
 */
void cluster_combinations_by_sorting(){
	vector<MultiTransformation*> sorted_combinations;
	for(hash_map<const char*,MultiTransformation*,hash<const char*>,eqstr>::iterator mitr = combinations.begin(); mitr != combinations.end(); mitr++){
		MultiTransformation *mtr = mitr->second;
		mtr->score();
		sorted_combinations.push_back(mtr); 
	}
	sort(sorted_combinations.begin(), sorted_combinations.end(), less<MultiTransformation*>());
	*out << "sorted combinations " << sorted_combinations.size() << endl;
	
	int num_lresidues = ligand->c->num_aminoacids;
	int num_rresidues = receptor->c->num_aminoacids;
	long num_hd_computations = 0;
	for(vector<MultiTransformation*>::iterator mitr = sorted_combinations.begin(); mitr != sorted_combinations.end(); mitr++){
		MultiTransformation *mtr = *mitr;
		bool select = true;
		//*out << mtr->id << " " << selected_combinations.size() << " ";
		//out->flush();
		for(vector<MultiTransformation*>::iterator mitr2 = clustered_combinations.begin(); mitr2 != clustered_combinations.end(); mitr2++){
			MultiTransformation *selected_mtr = *mitr2;
			float d, ud;
			selected_mtr->distance(&d, &ud, mtr);
			if(d <= MTR_MAX_R_DISTANCE && ud <= MTR_MAX_ROTATION_DISTANCE){
				int hd, mtr_num_contacts;
				selected_mtr->hamming_distance(&hd, &mtr_num_contacts, mtr, num_lresidues, num_rresidues);
				//*out << hd << "-" << mtr_num_contacts << "-" << selected_mtr->num_contacts << " ";
				num_hd_computations++;
				if(hd < MIN_DIVERSITY*(mtr_num_contacts+selected_mtr->num_contacts)){
					select = false;
					break;
				}
			}
		}
		//*out << select << endl;
		//out->flush();
		if(select){
			// compute contacts
			mtr->residue_distances = new hash_map<long,float,hash<long>,eqlong>; 
			mtr->lresidue_vdw_energy = new hash_map<int, short, hash<int>,eqint>;
			mtr->rresidue_vdw_energy = new hash_map<int, short, hash<int>,eqint>;
			mtr->compute_details(mtr->residue_distances, mtr->lresidue_vdw_energy , mtr->rresidue_vdw_energy);
			mtr->score();
			clustered_combinations.push_back(mtr);
		}
	}
	
	sort(clustered_combinations.begin(), clustered_combinations.end(), less<MultiTransformation*>());
	/*for(vector<MultiTransformation*>::iterator mitr = clustered_combinations.begin(); mitr != clustered_combinations.end(); mitr++){
		MultiTransformation *mtr = *mitr;
		mtr->print_details(out);
	}*/
	*out << "#selected combinations " << clustered_combinations.size() << " #hd computations " << num_hd_computations << endl;
}

hash_map<long,vector<Transformation*>,hash<long>,eqlong> clustered_transformations;

/*
 * obey the original order
 */
void cluster_sorted_transformations(Object* robj, Object* lobj, unsigned short cluster_level){
	Complex *receptor = robj->c, *ligand = lobj->c;
	vector<long> sorted_trids;
	hash_set<long,hash<long>,eqlong> selected_ids;
	fstream sortin("sorted.ids", ios::in);
	while(sortin.good()){
		long frame_number;
		sortin >> frame_number;
		if(selected_ids.count(frame_number) == 0){
			selected_ids.insert(frame_number);
			sorted_trids.push_back(frame_number);
		}
	}
	sortin.close();
	//cout << "sorted_trids.size() " << sorted_trids.size() << endl;
	
	hash_map<long,Transformation *,hash<long>,eqlong> selected_tr;
	int num_trans_selected = 0;
	fstream transin(local_transformations_file,ios::binary|ios::in);
	while(transin.good()){
		transin.read(buff,Transformation::basic_byte_size);
		if(transin.gcount() > 0){
			Transformation *tr = new Transformation(buff,TN_BASIC);
			if(selected_ids.count(tr->frame_number) > 0){
				selected_tr[tr->frame_number] = tr;
				tr->num_neighbors = 0;
				num_trans_selected++;
			} else 
				delete tr;
		}
	}
	transin.close();
	cout << "#selected " << num_trans_selected << " " << selected_ids.size() << endl;
	
	vector<Transformation *> sorted_tr;
	Transformation *identity = new Transformation(new Vector(0,0,0),new Vector(1,0,0), new Vector(0,1,0), 1.0,1,-1);
	for(vector<long>::iterator itr = sorted_trids.begin(); itr != sorted_trids.end(); itr++){
		bool discard = false;
		Transformation *tr = selected_tr[(long) *itr];
		/*/ select only symmetric dimers
		Reference_Frame *tr2rf = Reference_Frame::compose(tr,tr);
		float d, ud;
		tr2rf->distance(&d,&ud,identity);
		discard = (d >=6.0 || ud >=0.20);
		*out << tr->frame_number << " " << d << " " << ud << endl;
		if(!discard)*/
			sorted_tr.push_back(selected_tr[(long) *itr]);
	}
	//cout << "sorted_tr.size() " << sorted_tr.size() << endl;
	
	unsigned int num_clusters = 0;
	for(hash_map<long,vector<Transformation*>,hash<long>,eqlong>::iterator hitr = clustered_transformations.begin(); hitr != clustered_transformations.end(); hitr++){
		vector<Transformation*> trlist = (vector<Transformation*>) hitr->second;
		num_clusters += trlist.size();
	}
	clustered_transformations.clear();
	
	// selected_transformations are the set of newly selected cluster centers
	vector<Transformation*> selected_transformations;
	unsigned int num_trans=0,num_selected=0;
	fstream claout("cluster.assignments", ios::out);
	for(vector<Transformation*>::iterator itr = sorted_tr.begin(); itr != sorted_tr.end(); itr++){
		Transformation *tr = *itr;
		
		bool select = true;
		Transformation *trneighbor=NULL;
		int trx = (((int) tr->translation->x) + 200)/5;
		int tr_y = (((int) tr->translation->y) + 200)/5;
		int trz = (((int) tr->translation->z) + 200)/5;
		long index = (trx*100 + tr_y)*100 + trz;
			
		short extent = 1;
		if(cluster_level > 1) extent = 3;
		
		for(short level = 0; level <= extent && select; level++)
			for(int xi = -level; xi <= level && select; xi++)
				for(int yi = -level; yi <= level && select; yi++)
					for(int zi = -level; zi <= level && select; zi++)
						if(xi == -level || yi == -level || zi == -level || xi == level || yi == level || zi == level){
							long index = ((trx + xi)*100 + tr_y + yi)*100 + trz + zi;
							if(clustered_transformations.count(index)>0){
								vector<Transformation*> trlist = clustered_transformations[index];
								for(vector<Transformation*>::iterator itr = trlist.begin(); itr != trlist.end() && select; itr++){
									Transformation *selected_tr = *itr;
									float d, ud;
									selected_tr->distance(&d, &ud, tr);
									switch(cluster_level){
										case 0:
											//select = !((d <= 4.0 && ud <= 0.2) || (d <= 3.0 && ud <= 0.3));
											select = !((d <= 4.0 && ud <= 0.1) || (d <= 3.0 && ud <= 0.2));
											break;
										case 1:
											select = !((d <= 6.0 && ud <= 0.2) || (d <= 4.5 && ud <= 0.3));
											break;
										case 2:
											select = !(d*d + 400*ud*ud <= 100);
											break;
										case 3:
											//d = tr_irmsd_distance(receptor , ligand , selected_tr , tr);
											d = tr_irmsd_distance(receptor , lobj , selected_tr , tr);
											select = !(d <=2.0);
											//select = !(d <=1.2);
											//select = !(d <=4.5);
											break;
										case 4:
											d = tr_frac_shared_contacts(receptor , ligand , selected_tr , tr);
											//select = !(d >= 0.5);
											select = !(d >= 0.75);
											break;
									}
									//*out << cluster_level << " " << select << endl; 
									
									if(!select)	{
										trneighbor=selected_tr;
										break;
									}
								}
							}
						}

		if(select){
			selected_transformations.push_back(tr);
			if(clustered_transformations.count(index) == 0){
				clustered_transformations[index] = *(new vector<Transformation*>);
			}
			clustered_transformations[index].push_back(tr);
			tr->num_neighbors = 0;
			tr->votes = num_clusters;
			num_clusters++;
			num_selected++;
			claout << tr->frame_number << " " << tr->votes << endl;
		} else {
			trneighbor->num_neighbors++;
			claout << tr->frame_number << " " << trneighbor->votes << endl;
			delete tr;
		}
			
		num_trans++;
		if(false && num_trans % 10000 == 0){
			cout << "#trans " << num_trans << " #selected " << num_selected << endl;
			char filename[512];
			sprintf(filename,"clusters.%d",num_trans);
			fstream clout(filename, ios::out);
			for(vector<Transformation*>::iterator itr = selected_transformations.begin(); itr != selected_transformations.end(); itr++){
				Transformation *tr = *itr;
				clout << tr->frame_number << " " << tr->num_neighbors << endl;
			}
			clout.close();
		}
	}
	claout.close();
	
	fstream clout("clustered.ids", ios::out);
	for(vector<Transformation*>::iterator itr = selected_transformations.begin(); itr != selected_transformations.end(); itr++){
		Transformation *tr = *itr;
		clout << tr->frame_number << " " << tr->num_neighbors << endl;
	}
	clout.close();
	
	cout << "#selected transformations " << selected_transformations.size() << endl;
}

void compute_entropy_approx1(Object* receptor, Object* ligand, string options_file){
	ligand->grid_compute_aacid_contacts();
	
	fstream optin(options_file.c_str(), ios::in);
	int lineno=0;
	if(!optin.good()){
		if(procid==0){
			cout << "ERROR missing options file\n";
			cout.flush();
		}
		exit(-1);
	}
	string scorefile;
	optin >> scorefile;
	optin.close();
	
	// each process reads all transformations and scores, assume score file is sorted
	unsigned int num_transformations=0, sum_transformations=0;
	hash_map<long,double,hash<long>,eqlong> trid_vs_score;
	hash_map<long,float,hash<long>,eqlong> trid_vs_irmsd, trid_vs_rmsd;
	hash_set<long,hash<long>,eqlong> local_trids;
	fstream sortin(scorefile.c_str(), ios::in);
	while(sortin.good()){// && sum_transformations < 10000){
		sortin.getline(buff,8192);
//		*out << string(buff) << " " << sortin.gcount() << endl; out->flush();
		if(sortin.gcount() > 0){
			stringstream line(buff,stringstream::in);
			double score;
			line >> score;
			long frame_number;
			line >> frame_number;
			trid_vs_score[frame_number] = score;
			if(sum_transformations % numprocs == procid){
				local_trids.insert(frame_number);
				num_transformations++;
			}
			float irmsd, rmsd;
			line >> irmsd;
			trid_vs_irmsd[frame_number] = irmsd;
			line >> rmsd;
			trid_vs_rmsd[frame_number] = rmsd;
			sum_transformations++;
//			*out << score << " " << frame_number << " sum " << sum_transformations << " " << trid_vs_score.size() << endl; out->flush();
		}
	}
	sortin.close();
	*out << "trid_vs_score.size() " << trid_vs_score.size() << endl;
	
	hash_map<long,Transformation *,hash<long>,eqlong> local_tr, selected_tr;
	fstream transin(local_transformations_file,ios::binary|ios::in);
	while(transin.good()){
		transin.read(buff,Transformation::basic_byte_size);
		if(transin.gcount() > 0){
			Transformation *tr = new Transformation(buff,TN_BASIC);
			if(trid_vs_score.count(tr->frame_number) > 0){
				selected_tr[tr->frame_number] = tr;
				if(local_trids.count(tr->frame_number) > 0){
					local_tr[tr->frame_number] = tr;
					tr->num_neighbors = 0;
				}
			} else 
				delete tr;
		}
	}
	transin.close();
	*out << "#selected " << selected_tr.size() << " mine " << local_tr.size() << "|" << num_transformations << endl;
	
	// compute entropy for local transformations
	hash_map<long,float*,hash<long>,eqlong> local_trid_vs_freeE;
	int num_beta_intervals = 37;
	float beta[num_beta_intervals];
	for(int i = 0; i < num_beta_intervals; i++){
		beta[i] = pow(2.0 , ((double) i)/4.0)/8.0 ;
	}
	Vector receptor_interface_points[receptor->c->num_aminoacids+1];
	Vector ligand_interface_points[ligand->c->num_aminoacids+1];
	Vector ref_interface_points[receptor->c->num_aminoacids+ligand->c->num_aminoacids+1];
	for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator itr = local_tr.begin(); itr != local_tr.end(); itr++){
		Transformation *tr = itr->second;
		
		hash_set<long,hash<long>,eqlong> ref_interface_contacts;
		for(int ai = 0 ; ai < receptor->c->num_aminoacids; ai++){
			Aminoacid *ar = receptor->c->aminoacid[ai];
			
			if(ar->centroid != NULL){
				Vector vr = tr->transform(*(ar->centroid));
				Vector vv = (vr - *(ligand->grid_origin)) - Vector(SS_CUTOFF/AA_GRID_SPACING,SS_CUTOFF/AA_GRID_SPACING,SS_CUTOFF/AA_GRID_SPACING);
				int x,y,z;
				x = (int) (vv.x/AA_GRID_SPACING);
				y = (int) (vv.y/AA_GRID_SPACING);
				z = (int) (vv.z/AA_GRID_SPACING);
				if(x >= 0 && x < ligand->aagrid_num_xdivisions && y >= 0 && y < ligand->aagrid_num_ydivisions && z >= 0 && z < ligand->aagrid_num_zdivisions){
					unsigned int index = (x*ligand->aagrid_num_ydivisions + y)*ligand->aagrid_num_zdivisions + z;
					//*out << laindex << " rgrid " << index << " " << ligand->aagrid[index] << endl;
					if(ligand->aagrid[index] != NULL){
						unsigned short *aagcontact = ligand->aagrid[index];
						for(int agi = 0; agi < ligand->aagrid_size[index]; agi++){
							int laindex = aagcontact[agi];
							Aminoacid *la = ligand->c->aminoacid[laindex];
							if(la->centroid != NULL && Vector::distance_squared(vr,*(la->centroid)) < SS_CUTOFF*SS_CUTOFF){
								 ref_interface_contacts.insert(ai*MAX_ATOMS + laindex);
							}
						}
					}
				}
		 	}
		}
		
		int num_receptor_interface_points=0, num_ligand_interface_points=0;
		int num_ref_interface_points=0;
		hash_set<int,hash<int>,eqint> added_ligand_residue, added_receptor_residue;
		for(hash_set<long,hash<long>,eqlong>::iterator itr = ref_interface_contacts.begin(); itr != ref_interface_contacts.end(); itr++){
			long index = *itr;
			int refrindex = index/MAX_ATOMS;
			int reflindex = index % MAX_ATOMS;
				
			if(added_receptor_residue.count(refrindex) == 0){
				added_receptor_residue.insert(refrindex);
				Aminoacid *aa = receptor->c->aminoacid[refrindex];
				/*if(aa->atom.count("N") > 0 && use_all_bbatom_for_rmsd){
					receptor_interface_points[num_receptor_interface_points++] = Vector(aa->atom["N"]->position);
				} */
				if(aa->atom.count("CA") > 0){
					receptor_interface_points[num_receptor_interface_points++] = Vector(aa->atom["CA"]->position);
					ref_interface_points[num_ref_interface_points++] = Vector(aa->atom["CA"]->position);
				} 
				/*if(aa->atom.count("C") > 0){
					receptor_interface_points[num_receptor_interface_points++] = Vector(aa->atom["C"]->position);
				} 
				if(aa->atom.count("O") > 0){
					receptor_interface_points[num_receptor_interface_points++] = Vector(aa->atom["O"]->position);
				}*/
			}
			if(added_ligand_residue.count(reflindex) == 0){
				added_ligand_residue.insert(reflindex);
				Aminoacid *aa = ligand->c->aminoacid[reflindex];
				
				if(aa->atom.count("CA") > 0){
					ligand_interface_points[num_ligand_interface_points++] = Vector(aa->atom["CA"]->position);
					
				}
			}
		}
		for(int i = 0; i < num_ligand_interface_points; i++){
			ref_interface_points[num_ref_interface_points++] = tr->inverse_transform(ligand_interface_points[i]);
		}
		//tr->print_details(out,TN_BASIC);
		
		bool fast_rmsd = false;
		double R_receptor_interface[3][3], R_ligand_interface[3][3];
		Vector sum_receptor_interface,sum_ligand_interface,sum_ligaligned_interface; 
		Vector avg_aligned_interface;
		float avg_aligned_interface_array[3], sum_ligaligned_interface_array[3];
		float reference_tr_U[3][3], reference_tr_t[3];
		double sum_square_interface_pre;
	
		if(fast_rmsd){
			// compute the R matrix for receptor points
			for(int i = 0; i <3; i++)
				for(int j = 0; i <3; i++)
					R_receptor_interface[i][j] = 0;
			sum_receptor_interface = Vector(0,0,0);
					
			for(int i = 0 ; i < num_receptor_interface_points; i++){
				Vector v = receptor_interface_points[i];
				R_receptor_interface[0][0] += v.x*v.x;
				R_receptor_interface[0][1] += v.x*v.y;
				R_receptor_interface[0][2] += v.x*v.z;
				R_receptor_interface[1][1] += v.y*v.y;
				R_receptor_interface[1][2] += v.y*v.z;
				R_receptor_interface[2][2] += v.z*v.z;
				sum_receptor_interface = sum_receptor_interface + v; 
			}
			R_receptor_interface[1][0] = R_receptor_interface[0][1];
			R_receptor_interface[2][0] = R_receptor_interface[0][2];
			R_receptor_interface[2][1] = R_receptor_interface[1][2];
			
			// compute the ligand points for the "correct" solution
			for(int i = 0; i <3; i++)
				for(int j = 0; i <3; i++)
					R_ligand_interface[i][j] = 0;
			
			sum_ligaligned_interface = Vector(0,0,0);
			sum_ligand_interface = Vector(0,0,0);
			
			for(int i = 0 ; i < num_ligand_interface_points; i++){
				Vector v = ligand_interface_points[i];
				R_ligand_interface[0][0] += v.x*v.x;
				R_ligand_interface[0][1] += v.x*v.y;
				R_ligand_interface[0][2] += v.x*v.z;
				R_ligand_interface[1][1] += v.y*v.y;
				R_ligand_interface[1][2] += v.y*v.z;
				R_ligand_interface[2][2] += v.z*v.z;
				sum_ligand_interface = sum_ligand_interface + v;
				
				v = tr->inverse_transform(v);
				sum_ligaligned_interface = sum_ligaligned_interface + v;
			}
			R_ligand_interface[1][0] = R_ligand_interface[0][1];
			R_ligand_interface[2][0] = R_ligand_interface[0][2];
			R_ligand_interface[2][1] = R_ligand_interface[1][2];
			
			avg_aligned_interface = (sum_receptor_interface+sum_ligaligned_interface) * (1.0/(num_receptor_interface_points+num_ligand_interface_points));
			
			// convert the Vector representation to matrices for more readable code
			Reference_Frame *trinv = Reference_Frame::invert(tr);
			trinv->translation->toarray(reference_tr_t);
			trinv->ex->toarray(reference_tr_U[0]);
			trinv->ey->toarray(reference_tr_U[1]);
			trinv->ez->toarray(reference_tr_U[2]); 
			
			sum_ligaligned_interface.toarray(sum_ligaligned_interface_array); 
			avg_aligned_interface.toarray(avg_aligned_interface_array); 
			
			sum_square_interface_pre = 2*(R_receptor_interface[0][0]+R_receptor_interface[1][1]+R_receptor_interface[2][2]);
			double quadratic_term = 0;
			for(int i = 0; i < 3; i++)
				for(int j = 0; j < 3; j++)
					for(int i1 = 0; i1 < 3; i1++)
						for(int j1 = 0; j1 < 3; j1++)
							quadratic_term += reference_tr_U[i1][i] * reference_tr_U[j1][j] * R_ligand_interface[i1][j1];
						
			double linear_term = Vector(reference_tr_U[0][0], reference_tr_U[1][0], reference_tr_U[2][0]).dot(sum_ligand_interface) * trinv->translation->x 
								+ Vector(reference_tr_U[0][1], reference_tr_U[1][1], reference_tr_U[2][1]).dot(sum_ligand_interface) * trinv->translation->y
								+ Vector(reference_tr_U[0][2], reference_tr_U[1][2], reference_tr_U[2][2]).dot(sum_ligand_interface) * trinv->translation->z;
			
			sum_square_interface_pre += quadratic_term + linear_term + tr->translation->norm_squared()*(num_ligand_interface_points);
		}
	
		// process transformations
		float *freeE_by_beta = new float[num_beta_intervals];
		local_trid_vs_freeE[tr->frame_number] = freeE_by_beta;
		for(int bi = 0; bi < num_beta_intervals; bi++){
			freeE_by_beta[bi] = 0;
		}
		double trd[sum_transformations];
		int trindex=0;
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator nitr = selected_tr.begin(); nitr != selected_tr.end(); nitr++){
			Transformation *ntr = nitr->second;
			if(ntr->frame_number != tr->frame_number){
				float d, ud;
				tr->distance(&d, &ud, ntr);
				
				//if(d*d + 400*ud*ud <= 400) {
				/*if(d <=40.0 && ud <=0.8)*/ {
					float irmsd;
				
					// convert vector representation to matrix representation
					float U[3][3], translation[3];
					ntr->ex->toarray(U[0]);
					ntr->ey->toarray(U[1]);
					ntr->ez->toarray(U[2]);
					ntr->translation->toarray(translation);
					
					if(fast_rmsd){
						// compute R using precomputed values
						Vector v = sum_ligand_interface;
						v = ntr->inverse_transform(v);
						Vector sum_model = sum_receptor_interface + v;
						
						float v_array[3];
						v.toarray(v_array);
						float sum_model_array[3];
						sum_model.toarray(sum_model_array);
						
						double R[3][3];
						for(int i = 0; i < 3; i++)
							for(int j = 0; j < 3; j++){
								double quadratic_term = 0;
								for(int i1 = 0; i1 < 3; i1++)
									for(int j1 = 0; j1 < 3; j1++)
										quadratic_term += reference_tr_U[i1][i] * U[j1][j] * R_ligand_interface[i1][j1];
										
								R[i][j] = R_receptor_interface[i][j] + quadratic_term + sum_ligaligned_interface_array[i]*translation[j] 
											+ v_array[j]*reference_tr_t[i] - avg_aligned_interface_array[i]*sum_model_array[j];
							}
							
						double sum_square_interface=0;
						{
							double quadratic_term = 0;
							for(int i = 0; i < 3; i++)
								for(int j = 0; j < 3; j++)
									for(int i1 = 0; i1 < 3; i1++)
										for(int j1 = 0; j1 < 3; j1++)
											quadratic_term += U[i1][i] * U[j1][j] * R_ligand_interface[i1][j1];
									
							double linear_term = Vector(U[0][0], U[1][0], U[2][0]).dot(sum_ligand_interface) * ntr->translation->x 
											+ Vector(U[0][1], U[1][1], U[2][1]).dot(sum_ligand_interface) * ntr->translation->y
											+ Vector(U[0][2], U[1][2], U[2][2]).dot(sum_ligand_interface) * ntr->translation->z;
											
							double translation_term = ntr->translation->norm_squared();
							sum_square_interface += quadratic_term + linear_term + translation_term*(num_ligand_interface_points);
						}
							
						cubicsolve_rmsd_fromRE(R, sum_square_interface_pre+sum_square_interface, num_receptor_interface_points+num_ligand_interface_points, &irmsd);
						*out << "fast " << irmsd;
					}
						
					/*if(false)*/{
						//tr->print_details(out,TN_BASIC);
						Vector model_interface_points[num_ref_interface_points+1];
						for(int i = 0 ; i < num_receptor_interface_points; i++)
							model_interface_points[i] = receptor_interface_points[i];
						for(int i = 0 ; i < num_ligand_interface_points; i++){
							model_interface_points[i+num_receptor_interface_points] = ntr->inverse_transform(ligand_interface_points[i]);
							/*Vector v = ref_interface_points[i+num_receptor_interface_points];
							*out << i << " (" << v.x << "," << v.y << " " << v.z << ") ";
							v = ligand_interface_points[i];
							*out << " (" << v.x << "," << v.y << " " << v.z << ") ";
							v = model_interface_points[i+num_receptor_interface_points];
							*out << " (" << v.x << "," << v.y << " " << v.z << ")" << endl;*/
						}
							
						irmsd = compute_rmsd(num_ref_interface_points, ref_interface_points, &model_interface_points[0]);
						//*out << "\tregular " << num_ref_interface_points << " " << irmsd << " " << tr->frame_number << " " << ntr->frame_number << " d " << d << " ud " << ud << endl;
					}
					//irmsd = tr_irmsd_distance(receptor->c , ligand->c , ntr , tr);
					trd[trindex] = irmsd;
					//*out << tr->frame_number << " " << ntr->frame_number << " d " << d << " ud " << ud << " dis " << irmsd << endl;
				}
			} else
				trd[trindex] = 0;
				
			if(trd[trindex] < 5.0)	{
				for(int bi = 0; bi < num_beta_intervals; bi++){
					freeE_by_beta[bi] = freeE_by_beta[bi] + exp( beta[bi] * trid_vs_score[ntr->frame_number]);
				}
			}	
			trindex++;
		}
		
		// compute entropy approximation
		double sum_score=0,sum_score_sq=0;
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator nitr = selected_tr.begin(); nitr != selected_tr.end(); nitr++){
			Transformation *ntr = nitr->second;
			if(ntr->frame_number != tr->frame_number){
				sum_score += trid_vs_score[ntr->frame_number];
				sum_score_sq += trid_vs_score[ntr->frame_number] * trid_vs_score[ntr->frame_number];
			}
			trindex++;
		}
		int num_neighbors = 0;
		for(int i=0; i < trindex; i++){
			if(trd[i] !=0 && trd[i] < 3.0)	num_neighbors++;
		}
		if(num_neighbors > 0)
			tr->freeE_rigidmotion = log(num_neighbors);
		else
			tr->freeE_rigidmotion = 0;
		*out <<tr->frame_number << " score " << tr->freeE_rigidmotion << " " << num_neighbors << endl; 
		
		for(int bi = 0; bi < num_beta_intervals; bi++){
			freeE_by_beta[bi] = log(freeE_by_beta[bi]) / beta[bi];
		}
	}

	if(procid == 0){
		fstream sout("entropy_score", ios::out);
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator itr = local_tr.begin(); itr != local_tr.end(); itr++){
			Transformation *tr = itr->second;
			long fno = tr->frame_number;
			sout << trid_vs_score[tr->frame_number] << " " << tr->freeE_rigidmotion << " ";
			float *freeE_by_beta = local_trid_vs_freeE[tr->frame_number];
			for(int bi = 0; bi < num_beta_intervals; bi++){
				sout << freeE_by_beta[bi] << " ";
			} 
			sout << fno << " " << trid_vs_irmsd[fno] << " " << trid_vs_rmsd[fno] << endl;
		}
	
		// collect scores
		for(int i=1;i<numprocs;i++){
			//cout << "reading candidates from node " << i << "\t"; cout.flush();
			int node_num_transformations;
			MPI_Recv(&node_num_transformations, 1, MPI_INT, i, TAG, MPI_COMM_WORLD, &mpistat);
			cout << i << " node_num_transformations " << node_num_transformations << endl;
			
			long fbuf[node_num_transformations+1];
			MPI_Recv(fbuf,node_num_transformations , MPI_LONG, i, TAG, MPI_COMM_WORLD, &mpistat);
			
			float sbuf[node_num_transformations+1];
			MPI_Recv(sbuf,node_num_transformations , MPI_FLOAT, i, TAG, MPI_COMM_WORLD, &mpistat);
			
			float freeE_rigidmotion[(node_num_transformations+1)*num_beta_intervals];
			MPI_Recv(freeE_rigidmotion, (node_num_transformations+1)*num_beta_intervals, MPI_FLOAT, i, TAG, MPI_COMM_WORLD, &mpistat);
			
			for(int j = 0; j < node_num_transformations; j++){
				long fno = fbuf[j];
				sout <<  trid_vs_score[fno] << " " << sbuf[j] << " ";
				for(int bi = 0; bi < num_beta_intervals; bi++){
					sout << freeE_rigidmotion[j*num_beta_intervals + bi] << " ";
				}
				sout << fno << " " << trid_vs_irmsd[fno] << " " << trid_vs_rmsd[fno] << endl;
			}
		}
		sout.close();
		cout << "#computed entropy approx" << endl;
	} else {
		// send scores
		MPI_Ssend(&num_transformations, 1 , MPI_INT, 0, TAG, MPI_COMM_WORLD);
		long frame_number[num_transformations+1];
		float S_rigidmotion[num_transformations+1];
		int trindex=0;
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator itr = local_tr.begin(); itr != local_tr.end(); itr++){
			Transformation *tr = itr->second;
			frame_number[trindex] = tr->frame_number;
			S_rigidmotion[trindex] = tr->freeE_rigidmotion;
			trindex++;
		}
		MPI_Ssend(frame_number, num_transformations , MPI_LONG, 0, TAG, MPI_COMM_WORLD);
		MPI_Ssend(S_rigidmotion, num_transformations , MPI_FLOAT, 0, TAG, MPI_COMM_WORLD);
		
		float freeE_rigidmotion[(num_transformations+1)*num_beta_intervals];
		trindex=0;
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator itr = local_tr.begin(); itr != local_tr.end(); itr++){
			Transformation *tr = itr->second;
			float *freeE_by_beta = local_trid_vs_freeE[tr->frame_number];
			for(int bi = 0; bi < num_beta_intervals; bi++){
				freeE_rigidmotion[trindex*num_beta_intervals + bi] = freeE_by_beta[bi];
			}
			trindex++;
		}
		MPI_Ssend(freeE_rigidmotion, (num_transformations+1)*num_beta_intervals , MPI_FLOAT, 0, TAG, MPI_COMM_WORLD);
	}
}

void compute_entropy_approx2(Object* receptor, Object* ligand, string options_file){
	ligand->grid_compute_aacid_contacts();
	
	fstream optin(options_file.c_str(), ios::in);
	int lineno=0;
	if(!optin.good()){
		if(procid==0){
			cout << "ERROR missing options file\n";
			cout.flush();
		}
		exit(-1);
	}
	string scorefile;
	optin >> scorefile;
	string clusterfile;
	optin >> clusterfile;
	optin.close();
	
	// each process reads all transformations and scores, assume score file is sorted
	unsigned int sum_all_transformations=0;
	hash_map<long,double,hash<long>,eqlong> trid_vs_score;
	hash_map<long,float,hash<long>,eqlong> trid_vs_irmsd, trid_vs_rmsd;
	fstream sortin(scorefile.c_str(), ios::in);
	while(sortin.good()){
		sortin.getline(buff,8192);
		if(sortin.gcount() > 0){
			stringstream line(buff,stringstream::in);
			double score;
			line >> score;
			long frame_number;
			line >> frame_number;
			trid_vs_score[frame_number] = score;
			float irmsd, rmsd;
			line >> irmsd;
			trid_vs_irmsd[frame_number] = irmsd;
			line >> rmsd;
			trid_vs_rmsd[frame_number] = rmsd;
			sum_all_transformations++;
		}
	}
	sortin.close();
	*out << "trid_vs_score.size() " << trid_vs_score.size() << endl;
	
	unsigned int num_transformations=0, sum_transformations=0;
	hash_set<long,hash<long>,eqlong> local_trids;
	fstream clusin(clusterfile.c_str(), ios::in);
	while(clusin.good()){
		clusin.getline(buff,8192);
		if(clusin.gcount() > 0){
			stringstream line(buff,stringstream::in);
			long frame_number;
			line >> frame_number;
			if(sum_transformations % numprocs == procid){
				local_trids.insert(frame_number);
				num_transformations++;
			}
			sum_transformations++;
		}
	}
	clusin.close();
	
	hash_map<long,Transformation *,hash<long>,eqlong> local_tr, selected_tr;
	fstream transin(local_transformations_file,ios::binary|ios::in);
	while(transin.good()){
		transin.read(buff,Transformation::basic_byte_size);
		if(transin.gcount() > 0){
			Transformation *tr = new Transformation(buff,TN_BASIC);
			if(trid_vs_score.count(tr->frame_number) > 0){
				selected_tr[tr->frame_number] = tr;
				if(local_trids.count(tr->frame_number) > 0){
					local_tr[tr->frame_number] = tr;
					tr->num_neighbors = 0;
				}
			} else 
				delete tr;
		}
	}
	transin.close();
	*out << "#selected " << selected_tr.size() << " mine " << local_tr.size() << "|" << num_transformations << endl;
	
	// compute entropy for local transformations
	hash_map<long,float*,hash<long>,eqlong> local_trid_vs_freeE;
	int num_beta_intervals = 37;
	float beta[num_beta_intervals];
	for(int i = 0; i < num_beta_intervals; i++){
		beta[i] = pow(2.0 , ((double) i)/6.0)/4.0 ;
	}
	Vector receptor_interface_points[receptor->c->num_aminoacids+1];
	Vector ligand_interface_points[ligand->c->num_aminoacids+1];
	Vector ref_interface_points[receptor->c->num_aminoacids+ligand->c->num_aminoacids+1];
	for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator itr = local_tr.begin(); itr != local_tr.end(); itr++){
		Transformation *tr = itr->second;
		
		hash_set<long,hash<long>,eqlong> ref_interface_contacts;
		for(int ai = 0 ; ai < receptor->c->num_aminoacids; ai++){
			Aminoacid *ar = receptor->c->aminoacid[ai];
			
			if(ar->centroid != NULL){
				Vector vr = tr->transform(*(ar->centroid));
				Vector vv = (vr - *(ligand->grid_origin)) - Vector(SS_CUTOFF/AA_GRID_SPACING,SS_CUTOFF/AA_GRID_SPACING,SS_CUTOFF/AA_GRID_SPACING);
				int x,y,z;
				x = (int) (vv.x/AA_GRID_SPACING);
				y = (int) (vv.y/AA_GRID_SPACING);
				z = (int) (vv.z/AA_GRID_SPACING);
				if(x >= 0 && x < ligand->aagrid_num_xdivisions && y >= 0 && y < ligand->aagrid_num_ydivisions && z >= 0 && z < ligand->aagrid_num_zdivisions){
					unsigned int index = (x*ligand->aagrid_num_ydivisions + y)*ligand->aagrid_num_zdivisions + z;
					//*out << laindex << " rgrid " << index << " " << ligand->aagrid[index] << endl;
					if(ligand->aagrid[index] != NULL){
						unsigned short *aagcontact = ligand->aagrid[index];
						for(int agi = 0; agi < ligand->aagrid_size[index]; agi++){
							int laindex = aagcontact[agi];
							Aminoacid *la = ligand->c->aminoacid[laindex];
							if(la->centroid != NULL && Vector::distance_squared(vr,*(la->centroid)) < SS_CUTOFF*SS_CUTOFF){
								 ref_interface_contacts.insert(ai*MAX_ATOMS + laindex);
							}
						}
					}
				}
		 	}
		}
		
		int num_receptor_interface_points=0, num_ligand_interface_points=0;
		int num_ref_interface_points=0;
		hash_set<int,hash<int>,eqint> added_ligand_residue, added_receptor_residue;
		for(hash_set<long,hash<long>,eqlong>::iterator itr = ref_interface_contacts.begin(); itr != ref_interface_contacts.end(); itr++){
			long index = *itr;
			int refrindex = index/MAX_ATOMS;
			int reflindex = index % MAX_ATOMS;
				
			if(added_receptor_residue.count(refrindex) == 0){
				added_receptor_residue.insert(refrindex);
				Aminoacid *aa = receptor->c->aminoacid[refrindex];
				if(aa->atom.count("CA") > 0){
					receptor_interface_points[num_receptor_interface_points++] = Vector(aa->atom["CA"]->position);
					ref_interface_points[num_ref_interface_points++] = Vector(aa->atom["CA"]->position);
				} 
			}
			if(added_ligand_residue.count(reflindex) == 0){
				added_ligand_residue.insert(reflindex);
				Aminoacid *aa = ligand->c->aminoacid[reflindex];
				
				if(aa->atom.count("CA") > 0){
					ligand_interface_points[num_ligand_interface_points++] = Vector(aa->atom["CA"]->position);
					
				}
			}
		}
		for(int i = 0; i < num_ligand_interface_points; i++){
			ref_interface_points[num_ref_interface_points++] = tr->inverse_transform(ligand_interface_points[i]);
		}
		
		bool fast_rmsd = false;
		double R_receptor_interface[3][3], R_ligand_interface[3][3];
		Vector sum_receptor_interface,sum_ligand_interface,sum_ligaligned_interface; 
		Vector avg_aligned_interface;
		float avg_aligned_interface_array[3], sum_ligaligned_interface_array[3];
		float reference_tr_U[3][3], reference_tr_t[3];
		double sum_square_interface_pre;
	
		// process transformations
		float *freeE_by_beta = new float[num_beta_intervals];
		local_trid_vs_freeE[tr->frame_number] = freeE_by_beta;
		for(int bi = 0; bi < num_beta_intervals; bi++){
			freeE_by_beta[bi] = 0;
		}
		double trd[sum_all_transformations];
		int trindex=0;
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator nitr = selected_tr.begin(); nitr != selected_tr.end(); nitr++){
			Transformation *ntr = nitr->second;
			if(ntr->frame_number != tr->frame_number){
				float d, ud;
				tr->distance(&d, &ud, ntr);
				
				{
					float irmsd;
				
					// convert vector representation to matrix representation
					float U[3][3], translation[3];
					ntr->ex->toarray(U[0]);
					ntr->ey->toarray(U[1]);
					ntr->ez->toarray(U[2]);
					ntr->translation->toarray(translation);
					
					{
						Vector model_interface_points[num_ref_interface_points+1];
						for(int i = 0 ; i < num_receptor_interface_points; i++)
							model_interface_points[i] = receptor_interface_points[i];
						for(int i = 0 ; i < num_ligand_interface_points; i++){
							model_interface_points[i+num_receptor_interface_points] = ntr->inverse_transform(ligand_interface_points[i]);
						}
						
						irmsd = compute_rmsd(num_ref_interface_points, ref_interface_points, &model_interface_points[0]);
						//*out << "\tregular " << num_ref_interface_points << " " << irmsd << " " << tr->frame_number << " " << ntr->frame_number << " d " << d << " ud " << ud << endl;
					}
					//irmsd = tr_irmsd_distance(receptor->c , ligand->c , ntr , tr);
					trd[trindex] = irmsd;
				}
			} else
				trd[trindex] = 0;
				
			if(trd[trindex] < 5.0)	{
				float score = trid_vs_score[ntr->frame_number];
				if(score > trid_vs_score[tr->frame_number])
					score = trid_vs_score[tr->frame_number];
				for(int bi = 0; bi < num_beta_intervals; bi++){
					freeE_by_beta[bi] = freeE_by_beta[bi] + exp( beta[bi] * score);
				}
			}	
			trindex++;
		}
		
		// compute entropy approximation
		int num_neighbors = 0;
		for(int i=0; i < trindex; i++){
			if(trd[i] !=0 && trd[i] < 3.0)	num_neighbors++;
		}
		if(num_neighbors > 0)
			tr->freeE_rigidmotion = log(num_neighbors);
		else
			tr->freeE_rigidmotion = 0;
		*out <<tr->frame_number << " score " << tr->freeE_rigidmotion << " " << num_neighbors << endl; 
		
		for(int bi = 0; bi < num_beta_intervals; bi++){
			freeE_by_beta[bi] = log(freeE_by_beta[bi]) / beta[bi];
		}
	}

	if(procid == 0){
		fstream sout("entropy_score", ios::out);
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator itr = local_tr.begin(); itr != local_tr.end(); itr++){
			Transformation *tr = itr->second;
			long fno = tr->frame_number;
			sout << trid_vs_score[tr->frame_number] << " " << tr->freeE_rigidmotion << " ";
			float *freeE_by_beta = local_trid_vs_freeE[tr->frame_number];
			for(int bi = 0; bi < num_beta_intervals; bi++){
				sout << freeE_by_beta[bi] << " ";
			} 
			sout << fno << " " << trid_vs_irmsd[fno] << " " << trid_vs_rmsd[fno] << endl;
		}
	
		// collect scores
		for(int i=1;i<numprocs;i++){
			//cout << "reading candidates from node " << i << "\t"; cout.flush();
			int node_num_transformations;
			MPI_Recv(&node_num_transformations, 1, MPI_INT, i, TAG, MPI_COMM_WORLD, &mpistat);
			cout << i << " node_num_transformations " << node_num_transformations << endl;
			
			long fbuf[node_num_transformations+1];
			MPI_Recv(fbuf,node_num_transformations , MPI_LONG, i, TAG, MPI_COMM_WORLD, &mpistat);
			
			float sbuf[node_num_transformations+1];
			MPI_Recv(sbuf,node_num_transformations , MPI_FLOAT, i, TAG, MPI_COMM_WORLD, &mpistat);
			
			float freeE_rigidmotion[(node_num_transformations+1)*num_beta_intervals];
			MPI_Recv(freeE_rigidmotion, (node_num_transformations+1)*num_beta_intervals, MPI_FLOAT, i, TAG, MPI_COMM_WORLD, &mpistat);
			
			for(int j = 0; j < node_num_transformations; j++){
				long fno = fbuf[j];
				sout <<  trid_vs_score[fno] << " " << sbuf[j] << " ";
				for(int bi = 0; bi < num_beta_intervals; bi++){
					sout << freeE_rigidmotion[j*num_beta_intervals + bi] << " ";
				}
				sout << fno << " " << trid_vs_irmsd[fno] << " " << trid_vs_rmsd[fno] << endl;
			}
		}
		sout.close();
		cout << "#computed entropy approx" << endl;
	} else {
		// send scores
		MPI_Ssend(&num_transformations, 1 , MPI_INT, 0, TAG, MPI_COMM_WORLD);
		long frame_number[num_transformations+1];
		float S_rigidmotion[num_transformations+1];
		int trindex=0;
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator itr = local_tr.begin(); itr != local_tr.end(); itr++){
			Transformation *tr = itr->second;
			frame_number[trindex] = tr->frame_number;
			S_rigidmotion[trindex] = tr->freeE_rigidmotion;
			trindex++;
		}
		MPI_Ssend(frame_number, num_transformations , MPI_LONG, 0, TAG, MPI_COMM_WORLD);
		MPI_Ssend(S_rigidmotion, num_transformations , MPI_FLOAT, 0, TAG, MPI_COMM_WORLD);
		
		float freeE_rigidmotion[(num_transformations+1)*num_beta_intervals];
		trindex=0;
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator itr = local_tr.begin(); itr != local_tr.end(); itr++){
			Transformation *tr = itr->second;
			float *freeE_by_beta = local_trid_vs_freeE[tr->frame_number];
			for(int bi = 0; bi < num_beta_intervals; bi++){
				freeE_rigidmotion[trindex*num_beta_intervals + bi] = freeE_by_beta[bi];
			}
			trindex++;
		}
		MPI_Ssend(freeE_rigidmotion, (num_transformations+1)*num_beta_intervals , MPI_FLOAT, 0, TAG, MPI_COMM_WORLD);
	}
}

void compute_feig_score(Complex* receptor, Complex* ligand, string options_file){
	fstream optin(options_file.c_str(), ios::in);
	int lineno=0;
	if(!optin.good()){
		if(procid==0){
			cout << "ERROR missing options file\n";
			cout.flush();
		}
		exit(-1);
	}
	string scorefile;
	optin >> scorefile;
	optin.close();
	
	// each process reads all transformations and scores, assume score file is sorted
	unsigned int num_transformations=0, sum_transformations=0;
	hash_map<long,double,hash<long>,eqlong> trid_vs_score;
	hash_map<long,float,hash<long>,eqlong> trid_vs_irmsd, trid_vs_rmsd;
	hash_set<long,hash<long>,eqlong> local_trids;
	fstream sortin(scorefile.c_str(), ios::in);
	while(sortin.good() && sum_transformations < 2000){
		sortin.getline(buff,8192);
//		*out << string(buff) << " " << sortin.gcount() << endl; out->flush();
		if(sortin.gcount() > 0){
			stringstream line(buff,stringstream::in);
			double score;
			line >> score;
			long frame_number;
			line >> frame_number;
			trid_vs_score[frame_number] = score;
			if(sum_transformations % numprocs == procid){
				local_trids.insert(frame_number);
				num_transformations++;
			}
			float irmsd, rmsd;
			line >> irmsd;
			trid_vs_irmsd[frame_number] = irmsd;
			line >> rmsd;
			trid_vs_rmsd[frame_number] = rmsd;
			sum_transformations++;
//			*out << score << " " << frame_number << " sum " << sum_transformations << " " << trid_vs_score.size() << endl; out->flush();
		}
	}
	sortin.close();
	*out << "trid_vs_score.size() " << trid_vs_score.size() << endl;
	
	hash_map<long,Transformation *,hash<long>,eqlong> local_tr, selected_tr;
	fstream transin(local_transformations_file,ios::binary|ios::in);
	while(transin.good()){
		transin.read(buff,Transformation::basic_byte_size);
		if(transin.gcount() > 0){
			Transformation *tr = new Transformation(buff,TN_BASIC);
			if(trid_vs_score.count(tr->frame_number) > 0){
				selected_tr[tr->frame_number] = tr;
				if(local_trids.count(tr->frame_number) > 0){
					local_tr[tr->frame_number] = tr;
					tr->num_neighbors = 0;
				}
			} else 
				delete tr;
		}
	}
	transin.close();
	*out << "#selected " << selected_tr.size() << " mine " << local_tr.size() << "|" << num_transformations << endl;
	
	// compute rank scores for local transformations
	for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator itr = local_tr.begin(); itr != local_tr.end(); itr++){
		Transformation *tr = itr->second;
		
		double trd[sum_transformations];
		int trindex=0;
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator nitr = selected_tr.begin(); nitr != selected_tr.end(); nitr++){
			Transformation *ntr = nitr->second;
			if(ntr->frame_number != tr->frame_number){
				float d, ud;
				//tr->distance(&d, &ud, ntr);
				d = tr_irmsd_distance(receptor , ligand , ntr , tr);
				//d = tr_frac_shared_contacts(receptor , ligand , selected_tr , tr);
				trd[trindex] = d;
				//*out << tr->frame_number << " " << ntr->frame_number << " dis " << d << endl;
			} else
				trd[trindex] = 0;
			trindex++;
		}
		
		double sum_prod_score_dis=0,sum_score=0,sum_dis=0,sum_score_sq=0,sum_dis_sq=0;
		trindex=0;
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator nitr = selected_tr.begin(); nitr != selected_tr.end(); nitr++){
			Transformation *ntr = nitr->second;
			if(ntr->frame_number != tr->frame_number){
				sum_score += trid_vs_score[ntr->frame_number];
				sum_dis += trd[trindex];
				sum_prod_score_dis += trid_vs_score[ntr->frame_number]*trd[trindex];
				sum_score_sq += trid_vs_score[ntr->frame_number] * trid_vs_score[ntr->frame_number];
				sum_dis_sq += trd[trindex] * trd[trindex];
			}
			trindex++;
		}
		
		double var_scores = (sum_transformations-1)*sum_score_sq - sum_score*sum_score;
		double var_dis = (sum_transformations-1)*sum_dis_sq - sum_dis*sum_dis;
		tr->curvature_score = ((sum_transformations-1)*sum_prod_score_dis - sum_score*sum_dis )/sqrt(var_scores*var_dis);
		*out << "score " << tr->curvature_score << " " << tr->frame_number << endl; 
	}

	if(procid == 0){
		fstream sout("feig_score", ios::out);
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator itr = local_tr.begin(); itr != local_tr.end(); itr++){
			Transformation *tr = itr->second;
			long fno = tr->frame_number;
			sout << tr->curvature_score << " " << fno << " " << trid_vs_irmsd[fno] << " " << trid_vs_rmsd[fno] << endl;
		}
	
		// collect scores
		for(int i=1;i<numprocs;i++){
			//cout << "reading candidates from node " << i << "\t"; cout.flush();
			int node_num_transformations;
			MPI_Recv(&node_num_transformations, 1, MPI_INT, i, TAG, MPI_COMM_WORLD, &mpistat);
			cout << i << " node_num_transformations " << node_num_transformations << endl;
			
			long fbuf[node_num_transformations+1];
			MPI_Recv(fbuf,node_num_transformations , MPI_LONG, i, TAG, MPI_COMM_WORLD, &mpistat);
			
			float sbuf[node_num_transformations+1];
			MPI_Recv(sbuf,node_num_transformations , MPI_FLOAT, i, TAG, MPI_COMM_WORLD, &mpistat);
			
			for(int j = 0; j < node_num_transformations; j++){
				long fno = fbuf[j];
				sout << sbuf[j] << " " << fno << " " << trid_vs_irmsd[fno] << " " << trid_vs_rmsd[fno] << endl;
			}
		}
		sout.close();
		cout << "#computed Feig scores" << endl;
	} else {
		// send scores
		MPI_Ssend(&num_transformations, 1 , MPI_INT, 0, TAG, MPI_COMM_WORLD);
		long frame_number[num_transformations+1];
		float feig_score[num_transformations+1];
		int trindex=0;
		for(hash_map<long,Transformation *,hash<long>,eqlong>::iterator itr = local_tr.begin(); itr != local_tr.end(); itr++){
			Transformation *tr = itr->second;
			frame_number[trindex] = tr->frame_number;
			feig_score[trindex] = tr->curvature_score;
			trindex++;
		}
		MPI_Ssend(frame_number, num_transformations , MPI_LONG, 0, TAG, MPI_COMM_WORLD);
		MPI_Ssend(feig_score, num_transformations , MPI_FLOAT, 0, TAG, MPI_COMM_WORLD);
	}
}

void read_transformation_clusters(){
	unsigned int num_clusters = 0;
	fstream fclustin("cluster_centers", ios::in);
	while(fclustin.good()){
		string transfilename;
		fclustin >> transfilename;
		
		string idfilename;
		fclustin >> idfilename;
		vector<long> sorted_trids;
		hash_set<long,hash<long>,eqlong> selected_ids;
		fstream sortin(idfilename.c_str(), ios::in);
		while(sortin.good()){
			long frame_number;
			sortin >> frame_number;
			if(selected_ids.count(frame_number)	== 0){
				//cout << "frameno " << frame_number << endl;
				selected_ids.insert(frame_number);
				int size; sortin >> size;
			}
		}
		sortin.close();
		
		fstream transin(transfilename.c_str(),ios::binary|ios::in);
		while(transin.good()){
			transin.read(buff,Transformation::basic_byte_size);
			if(transin.gcount() > 0){
				Transformation *tr = new Transformation(buff,TN_BASIC);
				if(selected_ids.count(tr->frame_number) > 0){
					int trx = (((int) tr->translation->x) + 200)/5;
					int tr_y = (((int) tr->translation->y) + 200)/5;
					int trz = (((int) tr->translation->z) + 200)/5;
					long index = (trx*100 + tr_y)*100 + trz;
					
					if(clustered_transformations.count(index) == 0){
						clustered_transformations[index] = *(new vector<Transformation*>);
					}
					clustered_transformations[index].push_back(tr);
					tr->num_neighbors = 0;
					tr->votes = num_clusters;
					num_clusters++;
				} else 
					delete tr;
			}
		}
		transin.close();
	}
	fclustin.close();
	
	cout << "#existing_clusters " << num_clusters << " " << clustered_transformations.size() << endl;
}

/*
 * do an approximate k-median clustering
 */
void cluster_combinations_KMedian(){
	int K = minimum(NUM_CONTACT_CLUSTERS, combinations.size());
	*out << "K " << K << endl;
	vector<MultiTransformation*> cluster[K+1];
	MultiTransformation *cluster_median[K+1];
	float cluster_median_num_contacts[K+1];

	for(hash_map<const char*,MultiTransformation*,hash<const char*>,eqstr>::iterator mitr = combinations.begin(); mitr != combinations.end(); mitr++){
		(mitr->second)->score();
		(mitr->second)->cluster_id = -1; 
	}
	
	*out << "scored transformations" << endl;
	
	int index = 0;
	for(hash_map<const char*,MultiTransformation*,hash<const char*>,eqstr>::iterator mitr = combinations.begin(); mitr != combinations.end() && index < K; mitr++){ 
		MultiTransformation* mtr = mitr->second;
		cluster_median[index] = mtr;
		mtr->residue_distances = new hash_map<long,float,hash<long>,eqlong>; 
		mtr->lresidue_vdw_energy = new hash_map<int, short, hash<int>,eqint>;
		mtr->rresidue_vdw_energy = new hash_map<int, short, hash<int>,eqint>;
		mtr->compute_details(mtr->residue_distances, mtr->lresidue_vdw_energy , mtr->rresidue_vdw_energy);
		cluster_median_num_contacts[index] = (mtr->residue_distances)->size();
		mtr->cluster_id = index;
		index++;
	}
	
	int num_lresidues = ligand->c->num_aminoacids;
	int num_rresidues = receptor->c->num_aminoacids;
	
	int num_iterations = 0;
	float distance_squared, new_distance_squared = 0;
	bool done = false;
	while(!done){
		done = false;
		distance_squared = new_distance_squared;
		new_distance_squared = 0;
		
		//do not associate any points with the cluster
		for(int i = 0 ; i < K; i++){
			cluster[i].clear();
		}

		long num_hd_computations = 0;
		// compute the closest centroid for each point and add it to the corresponding cluster
		for(hash_map<const char*,MultiTransformation*,hash<const char*>,eqstr>::iterator mitr = combinations.begin(); mitr != combinations.end(); mitr++){
			MultiTransformation* mtr = mitr->second;
			//*out << mtr->id << " - ";
			float closest_distance = 0;
			int closest_cluster;
			
			if(mtr->cluster_id < 0){
				//*out << "non cluster median " << endl;	
				for(int j = 0 ; j < K; j++){
					float d, ud;
					//*out << j << " ";
					cluster_median[j]->distance(&d, &ud, mtr);
					//*out << "d " << d << " ud " << ud << endl;
					if(d <= MTR_MAX_R_DISTANCE && ud <= MTR_MAX_ROTATION_DISTANCE){
						int hd, mtr_num_contacts;	
						cluster_median[j]->hamming_distance(&hd, &mtr_num_contacts, mtr, num_lresidues, num_rresidues);
						d = hd;
						num_hd_computations++;
					} else {
						d = 50*d + 100*ud;
					}
						 
					if(mtr->num_contacts > cluster_median_num_contacts[j])
						d = d + (mtr->num_contacts - cluster_median_num_contacts[j]);
						
					if(j == 0 || d < closest_distance){
						closest_distance = d;
						closest_cluster = j;
					}
				}
			} else {
				closest_cluster = mtr->cluster_id;
			}
			new_distance_squared += closest_distance;
			cluster[closest_cluster].push_back(mtr);
			//*out << closest_cluster << " " << closest_distance << endl;
		}
		
		*out << "cluster sizes" << endl;
		// update the cluster medians
		for(int i = 0 ; i < K; i++){
			// recompute the median - median is the best combination in the cluster
			MultiTransformation *new_median;
			float new_median_num_contacts;
			int count = 0;
			for(vector<MultiTransformation*>::iterator mitr = cluster[i].begin(); mitr != cluster[i].end(); mitr++){
				MultiTransformation* mtr = *mitr;
				
				if(num_iterations == 0)
					mtr->score();
				
				if(count++ == 0 || new_median_num_contacts < mtr->num_contacts){
					new_median = mtr;
					new_median_num_contacts = mtr->num_contacts;
				}
			}
			
			// garbage collect old median
			MultiTransformation* old_median = cluster_median[i];
			
			if(old_median->id != new_median->id){
				cluster_median[i] = new_median;
				delete old_median->residue_distances; 
				delete old_median->lresidue_vdw_energy;
				delete old_median->rresidue_vdw_energy;
				delete old_median->contacts;
				old_median->contacts = NULL;
				old_median->cluster_id = -1;
				
				new_median->residue_distances = new hash_map<long,float,hash<long>,eqlong>; 
				new_median->lresidue_vdw_energy = new hash_map<int, short, hash<int>,eqint>;
				new_median->rresidue_vdw_energy = new hash_map<int, short, hash<int>,eqint>;
				new_median->compute_details(new_median->residue_distances, new_median->lresidue_vdw_energy , new_median->rresidue_vdw_energy);
				cluster_median_num_contacts[i] = (new_median->residue_distances)->size();
				new_median->cluster_id = i;
			}
			*out << new_median->id << " - " << cluster_median_num_contacts[i] << " " << cluster[i].size() << endl;
		}
		
		num_iterations++;
		done = (num_iterations > 1 && (new_distance_squared == 0 || ((distance_squared - new_distance_squared)/distance_squared <= .01)));
		
		*out << "#iterations " << num_iterations << " #hd_computations " << num_hd_computations << " distance squared " << new_distance_squared << endl;	
	}

	combinations.clear();
	for(int i = 0 ; i < K; i++)
		combinations[cluster_median[i]->id.c_str()] = cluster_median[i];
		//clustered_combinations.push_back(cluster_median[i]);
		
	*out << "K " << K << " #clustered combinations " << combinations.size() << endl;
}

void score_models(){
	*out << "score models " << clustered_combinations.size() << endl;
	for(vector<MultiTransformation*>::iterator mitr = clustered_combinations.begin(); mitr != clustered_combinations.end(); mitr++){
		MultiTransformation *mtr = *mitr;
		receptor->score(ligand,mtr);
	}
	sort(clustered_combinations.begin(), clustered_combinations.end(), less<MultiTransformation*>());
}

/*
 * The head node does the computation
 */
Transformation* examine_reference(){
	cout << "examine reference " << endl;
	cout << "probe radius " << probe_radius << " vote cutoff " << MIN_VOTES(receptor->num_faces,ligand->num_faces) << endl;	
	
	cout << receptor_vs_reference.size() << " " << reference_vs_receptor.size() << " " << ligand_vs_reference.size() << " " << reference_vs_ligand.size() << endl;
	//for(hash_map<long, long, hash<long>, eqlong>::iterator itr = reference_vs_receptor.begin(); itr != reference_vs_receptor.end(); itr++)
	//	cout << (long) itr->first << "|" << (long) itr->second << endl;
	reference->compute_motions();
	
	//receptor->c->write_as_pdb("rec.pdb");
	
	Transformation **trs = receptor->score_reference(ligand,reference,referenceH,&refrchains,&reflchains,&receptor_vs_reference,&reference_vs_receptor, &ligand_vs_reference, 
		&reference_vs_ligand ,procid);
	
	Transformation *reference_tr = trs[2]; 
	
	//receptor->test_sasa(ligand,reference_tr);
	receptor->compute_detailed_scores(ligand,reference_tr); 
	int num_aacontacts_core=0, num_aacontacts_rim=0;
	for(int i=0; i <NUM_RESIDUE_TYPES; i++)
		for(int j=i; j <NUM_RESIDUE_TYPES; j++){
			num_aacontacts_core += (((ProtProtDetailedScoringMetrics*)reference_tr->detailed_scores)->residue_contacts_core[i][j]);
			num_aacontacts_rim += (((ProtProtDetailedScoringMetrics*)reference_tr->detailed_scores)->residue_contacts_rim[i][j]);
		} 
	cout << "scores " << reference_tr->num_contacts << " " << reference_tr->eVdw << " " << reference_tr->eResiduepair
		<< " " << reference_tr->eSolvation << " " << reference_tr->delta_sasa << " contacts " << reference_tr->num_contacts
		<< " " << num_aacontacts_core << " " << num_aacontacts_rim << endl;
	
	reference_tr->vmetrics->frac_native_contacts_predicted = 1.0;
	fstream rout;
	rout.open((string("reference.ascore")).c_str(), fstream::out);
	reference_tr->print_details(&rout,TN_PROTPROT_DETAILED_SCORE_VERIFY);
	rout.close();
	
	// list transformations generated from points in the interface
	//receptor->match_surfaces_at_interface(ligand, &node_transformations);
	
	trs[0]->write_as_pdb(receptor->c, "-", false, string("rec_vs_ref.pdb"), true);
	trs[1]->write_as_pdb(ligand->c, "-", false, string("lig_vs_ref.pdb"), true);
	reference_tr->write_as_pdb(ligand->c, "-", false, string("lig_vs_rec.pdb"), false);
	trs[0]->write_as_pdb(reference, refrchains, false, string("ref_vs_rec.pdb"), false);
	trs[1]->write_as_pdb(reference, reflchains, false, string("ref_vs_lig.pdb"), false);

	return reference_tr;
}

// variables required for align utilities
const char* pdbcode;
string* chains;
string* sequence;
hash_map<const char*, Sequence*, hash<const char*>, eqstr> matching_sequences, matching_sequences_in_pdb, sequences_with_struct_alignment;
hash_map<const char*, Molecule*, hash<const char*>, eqstr> homologues;
char **malignment;
const char ***malignment_indices;

/*
 * Read the homologues and their alignments
 * loopp alignment are against the unbound proteins
 * blast alignments are against the native sequences
 */
void read_homologues(int aligntype){
	string refallchains = refrchains + reflchains;
	pdbcode = refpdbcode.c_str();
	chains = new string(refallchains);
	
	char rchain = refrchains.c_str()[0];
	char lchain = reflchains.c_str()[0];	
	
	raacidcindexstart = reference->mmonostart[refrchains.c_str()[0]];
	laacidcindexstart = reference->mmonostart[reflchains.c_str()[0]];
	
	hash_map<char, hash_map<const char*, const char*, hash<const char*>, eqstr>, hash<char>, eqint> hsequence_vs_speciesid;
	hash_map<char, hash_map<const char*, short, hash<const char*>, eqstr>, hash<char>, eqint> hsequence_vs_looppid;
	hash_map<short, const char*, hash<short>, eqint> hspecies;
	// works only for 2 chain proteins as of now
	//if(aligntype == LOOPP_ALIGN)
	{
		stringstream ss (stringstream::in | stringstream::out);
		//ss << "../" << refpdbcode << "_" << refallchains << ".shomologues";
		ss << "../loopp/" << refpdbcode << "_" << refallchains << ".shomologues";
		string filename;
		ss >> filename;
		fstream fin;
		fin.open(filename.c_str(),ios::in);
		if(procid == 0)	cout << filename << " " << fin.is_open() << endl;
		
		hsequence_vs_speciesid[rchain] = *(new hash_map<const char*, const char*, hash<const char*>, eqstr>);
		hsequence_vs_speciesid[lchain] = *(new hash_map<const char*, const char*, hash<const char*>, eqstr>);
		hsequence_vs_looppid[rchain] = *(new hash_map<const char*, short, hash<const char*>, eqstr>);
		hsequence_vs_looppid[lchain] = *(new hash_map<const char*, short, hash<const char*>, eqstr>);
		num_species=0;
		while (!fin.eof()){
			fin.getline(buff,BUFSIZE);
			if(fin.gcount() > 0){
				stringstream line(buff,stringstream::in);
				string s;
				line >> s;
				if(s == "SPECIES"){
					string species_name="";
					do{
						line >> s;
						if(s!="#")	species_name=species_name+s;
					}while( s != "#");
					species_name = *(new string(species_name.c_str()));
					
					int numrhomologues, numlhomologues;
					line >> numrhomologues;
					line >> numlhomologues;
					
					homologue_sequences[species_name.c_str()] = *(new hash_map<char, vector<Sequence*>, hash<char>, eqint>);
					homologue_sequences[species_name.c_str()][rchain] = *(new vector<Sequence*>);
					homologue_sequences[species_name.c_str()][lchain] = *(new vector<Sequence*>);
					
					for(int j = 0; j < 2; j++){
						int n=numrhomologues;
						char chain=rchain;
						if(j==1){
							n=numlhomologues;
							chain=lchain;
						}
						for(int i = 0; i < n; i++){
							fin.getline(buff,BUFSIZE);
							stringstream line(buff,stringstream::in);
							string id;	line >> id;
							id = *(new string(id));
							hsequence_vs_speciesid[chain][id.c_str()] = species_name.c_str();
							hsequence_vs_looppid[chain][id.c_str()] = i;
						}
					}
					
					if(procid == 0){
						cout << species_name << " " << numrhomologues << " " << numlhomologues << " " << 
							hsequence_vs_speciesid[rchain].size() << " " << hsequence_vs_speciesid[lchain].size() << endl;
					}
					hspecies[num_species] = species_name.c_str();
					num_species++;	
				}
			}
		}
		
		if(procid == 0)	cout << "#homspecies " << num_species << endl; 
	}
	
	hash_map<const char*, short, hash<const char*>, eqstr> neghom_vs_looppid[2];
	hash_map<const char*, Sequence*, hash<const char*>, eqstr> neghom_sequences[2];
	for(int j = 0; j < 2; j++){
		char chain=rchain;
		if(j==1)	chain=lchain;
		stringstream ss (stringstream::in | stringstream::out);
		//ss << "../" << refpdbcode << "_" << chain << ".neghomologues";
		ss << "../loopp/" << refpdbcode << "_" << chain << ".neghomologues";
		string filename;
		ss >> filename;
		fstream fin;
		fin.open(filename.c_str(),ios::in);
		
		int seqno=0;
		while (!fin.eof()){
			fin.getline(buff,BUFSIZE);
			if(fin.gcount() > 0){
				stringstream line(buff,stringstream::in);
				string id;
				line >> id;
				neghom_vs_looppid[j][(new string(id))->c_str()] = seqno++;
			}  
		}
		fin.close();
		
		// read alignments
		read_blast_hits(chain,DB_PDBAA,"..");
		read_blast_hits(chain,DB_NR,"..");
		int current=0;
		for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr = matching_sequences.begin(); sitr != matching_sequences.end(); sitr++){
			Sequence *s = (Sequence *) sitr->second;
			if(hsequence_vs_speciesid[chain].count(s->id_lowercase.c_str()) > 0)
				homologue_sequences[hsequence_vs_speciesid[chain][s->id_lowercase.c_str()]][chain].push_back(s);
			else if(neghom_vs_looppid[j].count(s->id_lowercase.c_str()) > 0)
				neghom_sequences[j][s->id_lowercase.c_str()] = s;
		}
		matching_sequences.clear();
	}
	*out << "#neghomologues " << neghom_sequences[0].size() << " " << neghom_sequences[1].size() << endl;
	
	int spindex=0;
	species = (Species **) malloc(sizeof(Species*)*(num_species+2));
	for(int si=0; si < num_species; si++){
		const char* species_name = hspecies[si];
		hash_map<char, vector<Sequence*>, hash<char>, eqint> hsequences = homologue_sequences[species_name];
		hash_map<int,Alignment*,hash<int>, eqint> receptor_alignments, ligand_alignments;
		
		Species *sp = new Species();
		if(procid == 0)	cout << string(species_name) << " " <<  hsequences[rchain].size() << " " <<  hsequences[lchain].size() << endl;
		if(aligntype == LOOPP_ALIGN){
			read_loopp_alignments(receptor->c->num_aminoacids, si, rchain, 0, hsequences[rchain].size(), &receptor_alignments);
			read_loopp_alignments(ligand->c->num_aminoacids, si, lchain, 1, hsequences[lchain].size(), &ligand_alignments);
		}
		
		sp->num_sequences = (short *) malloc(sizeof(short *)*2);
		sp->sequences = (Sequence ***) malloc(sizeof(Sequence **)*2);
		for(int j = 0; j < 2; j++){
			char chain = rchain;
			int num_residues = receptor->c->num_aminoacids;
			hash_map<int,Alignment*,hash<int>, eqint> *loopp_alignments = &receptor_alignments;
			if(j==1){
				chain = lchain;
				loopp_alignments = &ligand_alignments;
				num_residues = ligand->c->num_aminoacids;
			}
			vector<Sequence*> seqs = hsequences[chain];
			sp->num_sequences[j] = seqs.size();
			sp->sequences[j] = (Sequence **) malloc(sizeof(Sequence *)*(sp->num_sequences[j]+1)); 
			
			int fseqindex=0;
			for(vector<Sequence*>::iterator itr = seqs.begin(); itr != seqs.end(); itr++){
				Sequence *s = *itr;
				int looppid = hsequence_vs_looppid[chain][s->id_lowercase.c_str()];
				if((aligntype == LOOPP_ALIGN && loopp_alignments->count(looppid) > 0)
				  || (aligntype == BLAST_ALIGN && s->seq_alignment->aseq1.size()/num_residues >=0.60)){
					if(aligntype == LOOPP_ALIGN){
						//cout << s->id << " " << looppid << " " << loopp_alignments->count(looppid) << endl;
						s->loopp_alignment = (*loopp_alignments)[looppid];
					}
					sp->sequences[j][fseqindex++] = s;
				}
			}
			sp->num_sequences[j] = fseqindex;
		}
		
		if(procid == 0){
			cout << string(species_name) << " #alignments " << receptor_alignments.size() << " " << ligand_alignments.size() << endl;
		}
		if(sp->num_sequences[0] > 0 && sp->num_sequences[1] > 0){
			species[spindex++] = sp;
		}
	}
	num_species = spindex;
	if(procid == 0){	cout << "#species filtered " << num_species << endl; cout.flush(); }
	
	// negative homologues
	Species *negatives = species[spindex] = new Species();
	negatives->num_sequences = (short *) malloc(sizeof(short *)*2);
	negatives->sequences = (Sequence ***) malloc(sizeof(Sequence **)*2);
	for(int cj = 0; cj < 2; cj++){
		char chain = rchain;
		int num_residues = receptor->c->num_aminoacids;
		if(cj==1){
			chain = lchain;
			num_residues = ligand->c->num_aminoacids;
		}
		
		negatives->num_sequences[cj] = neghom_sequences[cj].size();
		hash_map<int,Alignment*,hash<int>, eqint> loopp_alignments;
		read_loopp_alignments(num_residues, -1 , chain, cj,  negatives->num_sequences[cj], &loopp_alignments);
		if(procid == 0)	cout << "neghomologues chain " << cj << " " << negatives->num_sequences[cj] << " " << loopp_alignments.size() << " " << neghom_sequences[cj].size() << " " << neghom_vs_looppid[cj].size() << endl;
		
		negatives->sequences[cj] = (Sequence **) malloc(sizeof(Sequence *)*(negatives->num_sequences[cj]+1)); 
		int seqindex=0;	
		for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator itr = neghom_sequences[cj].begin(); itr != neghom_sequences[cj].end(); itr++){
			Sequence *s = itr->second;
			int looppid = neghom_vs_looppid[cj][s->id_lowercase.c_str()];
			if(procid == 0)	cout << cj << " " << s->id_lowercase << " " << looppid << " " << loopp_alignments.count(looppid) << endl;
			if((aligntype == LOOPP_ALIGN && loopp_alignments.count(looppid) > 0)
			  || (aligntype == BLAST_ALIGN && s->seq_alignment->aseq1.size()/num_residues >=0.60)){
				if(aligntype == LOOPP_ALIGN){
					s->loopp_alignment = loopp_alignments[looppid];
				}
				negatives->sequences[cj][seqindex++] = s;
				//cout << "negatives " << cj << " " << seqindex-1 << " " << s << " " << s->id << " " << s->loopp_alignment << endl;
			}
		}
		negatives->num_sequences[cj] = seqindex;
	}
	if(procid == 0)	cout << "filtered neghomologues " << negatives->num_sequences[0] << " " << negatives->num_sequences[1] << endl;
	
	// check if loopp and moilr see the same sequence in a pdb
	bool checksequences=false;
	if(checksequences){
		bool problem=false;
		string rseq = ((Protein*) receptor->c->molecules.begin()->second)->compute_aasequence();
		string lseq = ((Protein*) ligand->c->molecules.begin()->second)->compute_aasequence();
		/*for(int i = 0; i < num_species; i++)
			for(int ci=0; ci<2; ci++){
				Alignment *a = homologues_by_organism[i][ci]->loopp_alignment;
				string aseq = a->aseq1;
				//remove gaps
				char aseqc_nogaps[aseq.length()+1];
				const char *aseqc = aseq.c_str();
				int index=0;
				for(int j=0; j < aseq.size(); j++)
					if(aseqc[j] != '-')	aseqc_nogaps[index++] = aseqc[j];
				aseqc_nogaps[index] = '\0';
				string aseq_nogaps = string(aseqc_nogaps);
				
				string seqread;
				if(ci==0)	seqread = rseq;
				else	seqread = lseq;
				bool flag = (seqread.find(aseq_nogaps) == string::npos);
				if(flag)	*out << "Seq ERROR\n" << seqread << "\n" << aseq_nogaps << endl;	
			}*/
	}
}

/* assume receptor is the first portion and ligand is the second portion of the chain
 */
bool chain_continuous(Complex *receptor,Complex *ligand,Reference_Frame *rf, bool rf_is_lig_vs_rec, unsigned short looplength){
	Vector *vo = receptor->aminoacid[receptor->num_aminoacids-1]->atom["O"]->position;
	Vector vn;
	if(rf_is_lig_vs_rec)
		vn = rf->transform(*(ligand->aminoacid[0]->atom["N"]->position));
	else
		vn = rf->inverse_transform(*(ligand->aminoacid[0]->atom["N"]->position));
	double d2 = Vector::distance_squared(*vo,vn);
	float cutoff = 3.8*3.8*looplength*looplength;  
	return (d2 < cutoff);
}

/* difference map between complex forming homologues and non-complex_forming homologues
*/
void get_evolutionary_pressure(){
	// initialize blosum62 rates
    for(int i = 0; i < 20; i++)
    	for(int j = 0; j < 20; j++){
    		blosum62_rates[i][j] = exp(blosum62_lambda*blosum62[i][j]);
    		//cout << i << " " << j << " " << blosum62_rates << " " << blosum62[i][j] << " " << blosum62_rates[i][j] << endl;
    	}
    		
	for(int ci=0; ci<2; ci++){
		int numresidues = receptor->c->num_aminoacids;
		Complex *c = receptor->c;
		if(ci == 1){
			numresidues = ligand->c->num_aminoacids;
			c = ligand->c;
		}
		
		for(int j = 0; j < numresidues; j++)
			for(int k=0; k<=20; k++)	
				if(ci == 0)	c->aminoacid[j]->profile_typecountsp[k] = c->aminoacid[j]->profile_typecountsn[k] = 0;
			
		for(int i = 0; i <= num_species; i++){
			Species *sp = species[i];	
			for(int si=0; si < sp->num_sequences[ci]; si++){
				for(int j = 0; j < numresidues; j++)	{
					short type = sp->homologues_aatypes[ci][si][j];
					if(type == GAP)	type = 20;
					if(i == num_species)	c->aminoacid[j]->profile_typecountsn[type]++;
					else c->aminoacid[j]->profile_typecountsp[type]++;
				}
			}
		}
		for(int j = 0; j < numresidues; j++)
			c->aminoacid[j]->compute_evolutionary_pressure(0.10);
		
		if(procid == 0){
			cout << "pstn\ttype\t";
			for(int j = 0; j < 20; j++)	cout << Aminoacid::get_symbol(j) << "\t";
			cout << "gap" << endl;
			for(int j = 0; j < numresidues; j++)
				for(int ai=0; ai<2; ai++){
					cout << j+1 << "\t" << c->aminoacid[j]->get_symbol() << "\t";
					for(int type = 0; type <= 20; type++)	
						if(ai==0)	cout << c->aminoacid[j]->profile_typecountsp[type] << "\t";
						else cout << c->aminoacid[j]->profile_typecountsn[type] << "\t";
					cout << endl;
				}
				
			for(int j = 0; j < numresidues; j++){
				cout << j+1 << "\t" << c->aminoacid[j]->get_symbol() << " evolpressure ";
				for(int k=1; k <=10; k++){
					c->aminoacid[j]->compute_evolutionary_pressure(0.05*k);
					cout << c->aminoacid[j]->interaction_evolutionary_pressure << "\t";
				}
				cout << endl;
			}
		}
	}
}

// prepare lookup tables for fast processing of a transformation
void preprocess_homologues(int aligntype){
	if(procid==0){
		for(int ci=0; ci<2; ci++){
			int numresidues;
			if(ci == 0){
				numresidues = receptor->c->num_aminoacids;
				cout << "Receptor:\n";
				for(int j = 0; j < numresidues; j++)	cout << receptor->c->aminoacid[j]->get_symbol();
				cout << endl;
			} else {
				numresidues = ligand->c->num_aminoacids;
				cout << "\nLigand:\n";
				for(int j = 0; j < numresidues; j++)	cout << ligand->c->aminoacid[j]->get_symbol();
				cout << endl;
			}
		}
	}
	
	for(int i = 0; i <= num_species; i++){
		Species *sp = species[i];
		sp->homologues_aatypes = (short ***) malloc(sizeof(short **)*2);
		for(int ci=0; ci<2; ci++){
			int numresidues;
			if(ci == 0)	numresidues = maximum(receptor->c->num_aminoacids,((Protein*)reference->molecules[refrchains.c_str()[0]])->num_aminoacids);
			else numresidues = maximum(ligand->c->num_aminoacids,((Protein*)reference->molecules[reflchains.c_str()[0]])->num_aminoacids);
			
			sp->homologues_aatypes[ci] = (short **) malloc(sizeof(short *)*(sp->num_sequences[ci]+1));
			
			for(int si=0; si < sp->num_sequences[ci]; si++){
				sp->homologues_aatypes[ci][si] = (short *) malloc(sizeof(short)*(numresidues+1));
				for(int j = 0; j <= numresidues; j++)	sp->homologues_aatypes[ci][si][j] = GAP; 
				
				Sequence *s = sp->sequences[ci][si];	
				Alignment *a;
				if(aligntype == LOOPP_ALIGN)	a = s->loopp_alignment;
				else if(aligntype == BLAST_ALIGN)	a = s->seq_alignment;
				
				//if(i==num_species)	cout << "negatives " << ci << " " << si << " " << s << " " << s->id << " " << a << endl;
				
				int n = a->aseq1.size();
				const char* aseq1c = a->aseq1.c_str();
				const char* aseq2c = a->aseq2.c_str();
				
				int num_aminoacids = receptor->c->num_aminoacids;
				hash_map<long, long, hash<long>, eqlong> *m_vs_reference = &receptor_vs_reference;
				if(ci == 1){
					num_aminoacids = ligand->c->num_aminoacids;
					m_vs_reference = &ligand_vs_reference;
				}
				
				for(int j = 0; j < num_aminoacids; j++){
					short type;
					if(m_vs_reference->count(j) > 0){
						int index = j;
						if(aligntype == BLAST_ALIGN){
							if(ci==0)	index = (*m_vs_reference)[j] - raacidcindexstart;
							else index = (*m_vs_reference)[j] - laacidcindexstart;
						}
						if(index >= a->qstart && index < a->qend){
							char qc='-',sc='-';
							int qindex = a->qstart-1, i;
							for(i = 0 ; i < n ; i++){
								if(aseq1c[i] != '-'){
									qindex++;
									if(qindex == index+1) {
										qc=aseq1c[i];
										sc=aseq2c[i];
										break;
									}
								}
							}
							if(sc != '-'){
								type = get_aatype(sc);
							} else type = GAP;
						} else type = GAP;
					} else type = GAP;
					sp->homologues_aatypes[ci][si][j] = type;
				}
			}
		}
	
		// output alignments
		if(procid==0){
			for(int ci=0; ci<2; ci++){
				int numresidues;
				if(ci == 0)	{
					numresidues = receptor->c->num_aminoacids;
				} else 	{
					numresidues = ligand->c->num_aminoacids;
				}
				for(int si=0; si < sp->num_sequences[ci]; si++){
					if(ci == 0)	{
						if(i < num_species)	cout << "Rhom:\t";
						else cout << "Rnhom:\t";
					} else 	{
						if(i < num_species)	cout << "Lhom:\t";
						else cout << "Lnhom:\t";
					}	
					char sequence[numresidues+1];
					sequence[numresidues]='\0';
					for(int j = 0; j < numresidues; j++)	sequence[j] = Aminoacid::get_symbol(sp->homologues_aatypes[ci][si][j]);
					cout << string(sequence) << endl;
				}
			} 
		}
	}
	get_evolutionary_pressure();
}

void check_alignment_quality(){
	hash_set<long,hash<long>,eqlong> aminoacids_in_contact;
	for(int i = reference->mmonostart[refrchains.c_str()[0]]; i < reference->mmonoend[refrchains.c_str()[0]]; i++){
	  Monomer *mr = reference->monomer[i];
	  if(IS_AMINOACID(mr->type)){
	 	Aminoacid *ra = (Aminoacid*) mr;
	 	for(int j = reference->mmonostart[reflchains.c_str()[0]]; j < reference->mmonoend[reflchains.c_str()[0]]; j++){
	 	  Monomer *ml = reference->monomer[j];
	  	  if(IS_AMINOACID(ml->type)){
			 Aminoacid *la = (Aminoacid*) ml;
			 if(ra->alpha_carbon != NULL && la->alpha_carbon != NULL && Vector::distance(ra->alpha_carbon->position, la->alpha_carbon->position) < SS_CUTOFF){
				aminoacids_in_contact.insert(la->cindex*MAX_ATOMS + ra->cindex);
			}
	  	  }
		}
	  }
	}
	
	return;
	hash_map<char, hash_map<const char*, Sequence*, hash<const char*>, eqstr>, hash<char>, eqint> homologue_sequences;
	short ratype, latype;
	int contacts_numgaps=0;
	for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator rhitr = (homologue_sequences[refrchains.c_str()[0]]).begin(); rhitr != (homologue_sequences[refrchains.c_str()[0]]).end(); rhitr++){
		if(string((const char*) rhitr->first) != receptor->c->pdbcode){
			Sequence *rs = (Sequence *) rhitr->second;
			Alignment *ra = rs->seq_alignment;
			int rn = ra->aseq1.size();
			const char* raseq1c = ra->aseq1.c_str();
			const char* raseq2c = ra->aseq2.c_str();
		
			for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator lhitr = (homologue_sequences[reflchains.c_str()[0]]).begin(); lhitr != (homologue_sequences[reflchains.c_str()[0]]).end(); lhitr++){
				if(string((const char*) lhitr->first) != ligand->c->pdbcode){
					Sequence *ls = (Sequence *) lhitr->second;
					Alignment *la = ls->seq_alignment;
					int ln = la->aseq1.size();
					const char* laseq1c = la->aseq1.c_str();
					const char* laseq2c = la->aseq2.c_str();

					for(hash_set<long,hash<long>,eqlong>::iterator itr = aminoacids_in_contact.begin(); itr != aminoacids_in_contact.end(); itr++){
						long index = *itr;
						int laindex = index / MAX_ATOMS;
						int raindex = index % MAX_ATOMS;
					
						if(reference_vs_receptor.count(raindex) > 0){
							int index = raindex - raacidcindexstart;
							if(index >= ra->qstart && index < ra->qend){
								char qc='-',sc='-';
								int qindex = ra->qstart-1, i;
								for(i = 0 ; i < rn ; i++){
									if(raseq1c[i] != '-'){
										qindex++;
										if(qindex == index+1) {
											qc=raseq1c[i];
											sc=raseq2c[i];
											break;
										}
									}
								}
								//*out << index << "-" << i << " " << qc << sc << " ";
								*out << sc;
								if(sc != '-'){
									ratype = get_aatype(sc);
								} else	ratype = GAP;
							} else {
								ratype = GAP;
								*out << "-";
							}
						} else {
							ratype = GAP;
							*out << "-";
						}
				
						if(reference_vs_ligand.count(laindex) > 0){
							int index = laindex - laacidcindexstart;
							//*out << index << "|" << la->qstart << "|" << la->qend << " ";
							if(index >= la->qstart && index < la->qend){
								char qc='-',sc='-';
								int qindex = la->qstart-1, i;
								for(i = 0 ; i < ln ; i++){
									if(laseq1c[i] != '-'){
										qindex++;
										if(qindex == index+1) {
											qc=laseq1c[i];
											sc=laseq2c[i];
											break;
										}
									}
								}
								//*out << index << "--" << i << " " << qc << sc << " ";
								*out << sc;
								if(sc != '-'){
									latype = get_aatype(sc);
								} else	latype = GAP;
							} else {
								latype = GAP;
								*out << "-";
							}
						} else {
							latype = GAP;
							*out << "-";
						}
						
						if(ratype == GAP || latype == GAP)
							contacts_numgaps++;
					}
					*out << endl;
				}
			}
		}
	}
	cout << "homologues contacts #gaps " << contacts_numgaps << endl;
}

void verify_transformations(){
	if(procid == 0){
		cout << "probe radius " << probe_radius << " vote cutoff " << MIN_VOTES(receptor->num_faces,ligand->num_faces) << endl;	
	}
	
	*out << "verify transformations " << node_transformations.size() << endl;
	*out << receptor_vs_reference.size() << " " << reference_vs_receptor.size() << " " << ligand_vs_reference.size() << " " << reference_vs_ligand.size() << endl;
	
	Transformation **trs = receptor->score_reference(ligand,reference,referenceH,&refrchains,&reflchains,&receptor_vs_reference,&reference_vs_receptor, &ligand_vs_reference, &reference_vs_ligand	
		,procid);
	
	receptor->verify_transformations(ligand, reference, &refrchains, &reflchains, &receptor_vs_reference,&reference_vs_receptor,
		&ligand_vs_reference, &reference_vs_ligand,	&ligand_vs_receptor_symmetry, &receptor_symmetry, &ligand_symmetry, CALPHA, &node_transformations, trs);
		
	//sort(node_transformations.begin(), node_transformations.end(),Transformation_Compare_Rms());
}

/*
 * 
 */
void verify_models(){
	*out << "verify models " << endl; //clustered_combinations.size() << endl;
	
}

void verify_combinations(){
	*out << "verify combinations " << clustered_combinations.size() << endl;
	*out << receptor_vs_reference.size() << " " << reference_vs_receptor.size() << " " << ligand_vs_reference.size() << " " << reference_vs_ligand.size() << endl;
	
	Transformation **trs = receptor->score_reference(ligand,reference,referenceH,&refrchains,&reflchains,&receptor_vs_reference,&reference_vs_receptor,
		&ligand_vs_reference, &reference_vs_ligand,	procid);
			
	if(procid == 0){
		cout << "probe radius " << probe_radius << " vote cutoff " << MIN_VOTES(receptor->num_faces,ligand->num_faces) << endl; 
	}
	
	receptor->verify_combinations(ligand, reference,&receptor_vs_reference,&reference_vs_receptor,
		&ligand_vs_reference, &reference_vs_ligand,	&clustered_combinations);
}

/*
 * Assuming that sequences in blast are the same as the sequences in pdb
 * 
 * Assuming reference monomers are proteins
 * when docking multiple chains, refrchains correspond to receptorchains in order (same for reflchains)
 * for older version go to 1.1.2.18 or lower
 */
void read_alignments(){
	const char* refchain, *pchain;
	string filename;
	string aseq1,aseq2,s;
	int qstart, sstart;
	bool alignment_done;
	stringstream *line;
	refchain = refrchains.c_str();
	pchain = receptor->c->chains.c_str();
	receptor_vs_reference.clear();
	reference_vs_receptor.clear();
	ligand_vs_reference.clear();
	reference_vs_ligand.clear();
	
	short tmalign = 1, nwa = 2, alignment = nwa;
	for(int i = 0; i < refrchains.size(); i++){
		int offset2 = reference->mmonostart[refchain[i]];

		Molecule *m = receptor->c->molecules[pchain[i]];
		int offset1 = receptor->c->mmonostart[m->chain];
		
		stringstream ss (stringstream::in | stringstream::out);
		ss << "../" << rpdbcode << "_" << (m->chain) << "_vs_" << refpdbcode << "_" << refchain[i];
		if(alignment == nwa)	ss << ".ali";
		else	ss << ".tmali";
		ss >> filename;
		fstream fin;
		fin.open(filename.c_str(), ios::in);

		if(fin.is_open()){
			aseq1 = ""; aseq2 = "";
			qstart = sstart = 1;
			
			if(alignment == nwa){
				// reading input from the output of nwa
				fin.getline(buff,BUFSIZE);
				fin.getline(buff,BUFSIZE);
				do{
					line = new stringstream(buff,stringstream::in);
					*line >> s;
					aseq1 += s;
					fin.getline(buff,BUFSIZE);
				}while((string(buff)).find(">>") == string::npos);
				while(fin.good()){
					fin.getline(buff,BUFSIZE);
					if(fin.gcount() > 0){
						line = new stringstream(buff,stringstream::in);
						*line >> s;
						aseq2 += s;
						//*out << ">" << aseq2 << endl;
					}
				}
			} else {
				do{
					fin.getline(buff,BUFSIZE);
				}while(fin.good() && (string(buff)).find("Angstrom)") == string::npos);
					
				fin.getline(buff,BUFSIZE);
				aseq1=string(buff);
					
				fin.getline(buff,BUFSIZE);
				fin.getline(buff,BUFSIZE);
				aseq2=string(buff);
			}
			
			*out << aseq1 << endl << aseq2 << endl;
			
			int qindex = qstart-1, sindex = sstart-1;
			int n = aseq1.size();
			const char* aseq1c = aseq1.c_str();
			const char* aseq2c = aseq2.c_str();
			
			for(int i = 0 ; i < n ; i++){
				int qindexc = qindex + offset1;
				int sindexc = sindex + offset2;
				if(aseq1c[i] != '-' && aseq2c[i] != '-' && reference->aminoacid[sindexc]->alpha_carbon != NULL){
					receptor_vs_reference[qindexc] = sindexc;
					reference_vs_receptor[sindexc] = qindexc;
					*out << qindex << "-" << qindexc << "-" << sindex << "-" << sindexc << " "; out->flush();
				}
				if(aseq1c[i] != '-')	qindex++;
				if(aseq2c[i] != '-')	sindex++;	
			}
			*out << endl;
			fin.close();
		} else {
			if(procid == 0){
				cout << "ERROR: Alignment does not exist " << filename << endl;
				exit(-1);
			}
		}
	}
	out->flush();
	
	refchain = reflchains.c_str();
	pchain = ligand->c->chains.c_str();
	for(int i = 0; i < reflchains.size(); i++){
		int offset2 = reference->mmonostart[refchain[i]];

		Molecule *m = ligand->c->molecules[pchain[i]];
		int offset1 = ligand->c->mmonostart[m->chain];
		
		stringstream ss (stringstream::in | stringstream::out);
		ss << "../" << lpdbcode << "_" << (m->chain) << "_vs_" << refpdbcode << "_" << refchain[i];
		if(alignment == nwa)	ss << ".ali";
		else	ss << ".tmali";
		ss >> filename;
		fstream fin;
		fin.open(filename.c_str(), ios::in);
		
		if(fin.is_open()){
			//*out << filename << endl; out->flush();
			aseq1 = ""; aseq2 = "";
			qstart = sstart = 1;
				
			if(alignment == nwa){
				// reading input from the output of nwa
				fin.getline(buff,BUFSIZE);
				fin.getline(buff,BUFSIZE);
				do{
					line = new stringstream(buff,stringstream::in);
					*line >> s;
					aseq1 += s;
					fin.getline(buff,BUFSIZE);
				}while((string(buff)).find(">>") == string::npos);
				while(fin.good()){
					fin.getline(buff,BUFSIZE);
					if(fin.gcount() > 0){
						line = new stringstream(buff,stringstream::in);
						*line >> s;
						aseq2 += s;
						//*out << ">" << aseq2 << endl; out->flush();
					}
				}
			} else {
				do{
					fin.getline(buff,BUFSIZE);
				}while(fin.good() && (string(buff)).find("Angstrom)") == string::npos);
					
				fin.getline(buff,BUFSIZE);
				aseq1=string(buff);
					
				fin.getline(buff,BUFSIZE);
				fin.getline(buff,BUFSIZE);
				aseq2=string(buff);
			}
			
			*out << endl << aseq1 << endl << aseq2 << endl;
			
			int qindex = qstart-1, sindex = sstart-1;
			int n = aseq1.size();
			const char* aseq1c = aseq1.c_str();
			const char* aseq2c = aseq2.c_str();
			
			for(int i = 0 ; i < n ; i++){
				int sindexc = sindex + offset2;
				int qindexc = qindex + offset1;
				if(aseq1c[i] != '-' && aseq2c[i] != '-' && reference->aminoacid[sindexc]->alpha_carbon != NULL){
					ligand_vs_reference[qindexc] = sindexc;
					reference_vs_ligand[sindexc] = qindexc;
					*out << qindex << "-" << qindexc << "-" << sindex << "-" << sindexc << " "; out->flush();
				}
				if(aseq1c[i] != '-')	qindex++;
				if(aseq2c[i] != '-')	sindex++;	
			}
			*out << endl;
			fin.close();
		} else {
			if(procid == 0){
				cout << "ERROR: Alignment does not exist " << filename << endl;
				exit(-1);
			}
		}
	}
	*out << receptor_vs_reference.size() << "|" <<  reference_vs_receptor.size() << " " << ligand_vs_reference.size() << "|" << reference_vs_ligand.size() << endl;
	out->flush();
}

void read_symmetries(){
	const char* p1chain, *p2chain;
	string filename;
	string aseq1,aseq2,s;
	int qstart, sstart;
	bool alignment_done;
	stringstream *line;
	hash_map<long, long, hash<long>, eqlong> refp1_vs_refp2, refp2_vs_refp1;
	Vector receptor_points[reference->num_aminoacids], ligand_points[reference->num_aminoacids];
	
	// homodimers
	// assuming single chain proteins
	p1chain = refrchains.c_str();
	p2chain = reflchains.c_str();
	for(int i = 0; i < 1; i++){
		Molecule *m = reference->molecules[p2chain[i]];
		int offset1 = reference->mmonostart[p1chain[i]];
		int offset2 = reference->mmonostart[m->chain];
		stringstream ss (stringstream::in | stringstream::out);
		ss << "../" << refpdbcode << "_" << p1chain[i] << "_vs_" << refpdbcode << "_" << (m->chain) << ".ali";
		ss >> filename;
		fstream fin;
		fin.open(filename.c_str(), ios::in);
		
		if(fin.is_open()){
			//*out << filename << endl; out->flush();
			aseq1 = ""; aseq2 = "";
			qstart = sstart = 1;
				
			// reading input from the output of nwa
			fin.getline(buff,BUFSIZE);
			fin.getline(buff,BUFSIZE);
			do{
				line = new stringstream(buff,stringstream::in);
				*line >> s;
				aseq1 += s;
				fin.getline(buff,BUFSIZE);
			}while((string(buff)).find(">>") == string::npos);
			while(fin.good()){
				fin.getline(buff,BUFSIZE);
				if(fin.gcount() > 0){
					line = new stringstream(buff,stringstream::in);
					*line >> s;
					aseq2 += s;
					//*out << ">" << aseq2 << endl; out->flush();
				}
			}
			
			*out << endl << aseq1 << endl << aseq2 << endl;
			
			int qindex = qstart-1, sindex = sstart-1;
			int n = aseq1.size();
			const char* aseq1c = aseq1.c_str();
			const char* aseq2c = aseq2.c_str();
			
			for(int i = 0 ; i < n ; i++){
				int qindexc = qindex + offset1;
				int sindexc = sindex + offset2;
				if(aseq1c[i] != '-' && reference->aminoacid[qindexc]->alpha_carbon != NULL
				 && aseq2c[i] != '-' && reference->aminoacid[sindexc]->alpha_carbon != NULL){
					refp1_vs_refp2[qindexc] = sindexc;
					refp2_vs_refp1[sindexc] = qindexc;
					*out << qindex << "-" << qindexc << "-" << sindex << "-" << sindexc << " ";
				}
				if(aseq1c[i] != '-')	qindex++;
				if(aseq2c[i] != '-')	sindex++;	
			}
			*out << endl;
			fin.close();
		} else {
			if(procid == 0){
				cout << "WARNING: Alignment does not exist " << filename << endl;
			}
		}
		if(refp2_vs_refp1.size() >= 0.5*(((Protein*)reference->molecules[p1chain[i]])->num_aminoacids + ((Protein*)m)->num_aminoacids)){
			Transformation *reflig_to_refrec = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
	    	int point_index=0;
	    	for(hash_map<long, long, hash<long>, eqlong>::iterator itr = refp2_vs_refp1.begin(); itr != refp2_vs_refp1.end(); itr++){
	        	Aminoacid *aa_reflig = reference->aminoacid[(long) itr->first];
				Aminoacid *aa_refrec = reference->aminoacid[(long) itr->second];
				receptor_points[point_index] = Vector(aa_refrec->alpha_carbon->position);
				ligand_points[point_index] = Vector(aa_reflig->alpha_carbon->position);
				point_index++;
	        }
	        float rmsd = compute_rmsd(point_index, &receptor_points[0], &ligand_points[0], reflig_to_refrec);
	        *out << "receptor vs ligand - #points " << point_index << " rmsd " << rmsd << endl;out->flush();
	        reflig_to_refrec->write_as_pdb(reference, reflchains, false, string("reflig_to_refrec.pdb"), true);
	        reflig_to_refrec->write_as_pdb(reference, refrchains, false, string("refrec_transformed.pdb"), true);
	        //Reference_Frame *composed = Reference_Frame::compose(reflig_to_refrec,reflig_to_refrec);
	        //composed->write_as_pdb(reference, reflchains, false, string("reflig_homodimer.pdb"), true);
	        ligand_vs_receptor_symmetry.push_back(reflig_to_refrec);
	    }
	}
	out->flush();
	
	// receptor or ligand have symmetries
	for(int z=0; z<2; z++){
		unsigned short nchains;
		if(z==0){
			p1chain = p2chain = refrchains.c_str();
			nchains = refrchains.size();
		} else {
			p1chain = p2chain = reflchains.c_str();
			nchains = reflchains.size();
		}
		
		if( nchains > 1 ) {
			for(int i = 0; i < nchains; i++){
				int offset1 = reference->mmonostart[p1chain[i]];
				for(int j = 0; j < nchains; j++){
					if(i != j){
						Molecule *m = reference->molecules[p2chain[j]];
						int offset2 = reference->mmonostart[m->chain];
				
						refp1_vs_refp2.clear();
	        			refp2_vs_refp1.clear();
	        
						stringstream ss (stringstream::in | stringstream::out);
						ss << "../" << refpdbcode << "_" << p1chain[i] << "_vs_" << refpdbcode << "_" << (m->chain) << ".ali";
						ss >> filename;
						fstream fin;
						fin.open(filename.c_str(), ios::in);
						
						if(fin.is_open()){
							//*out << filename << endl; out->flush();
							aseq1 = ""; aseq2 = "";
							qstart = sstart = 1;
								
							// reading input from the output of nwa
							fin.getline(buff,BUFSIZE);
							fin.getline(buff,BUFSIZE);
							do{
								line = new stringstream(buff,stringstream::in);
								*line >> s;
								aseq1 += s;
								fin.getline(buff,BUFSIZE);
							}while((string(buff)).find(">>") == string::npos);
							while(fin.good()){
								fin.getline(buff,BUFSIZE);
								if(fin.gcount() > 0){
									line = new stringstream(buff,stringstream::in);
									*line >> s;
									aseq2 += s;
									//*out << ">" << aseq2 << endl; out->flush();
								}
							}
							
							*out << endl << aseq1 << endl << aseq2 << endl;
							
							int qindex = qstart-1, sindex = sstart-1;
							int n = aseq1.size();
							const char* aseq1c = aseq1.c_str();
							const char* aseq2c = aseq2.c_str();
							
							for(int i = 0 ; i < n ; i++){
								int qindexc = qindex + offset1;
								int sindexc = sindex + offset2;
								if(aseq1c[i] != '-' && reference->aminoacid[qindexc]->alpha_carbon != NULL
								 && aseq2c[i] != '-' && reference->aminoacid[sindexc]->alpha_carbon != NULL){
									refp1_vs_refp2[qindexc] = sindexc;
									refp2_vs_refp1[sindexc] = qindexc;
									*out << qindex << "-" << qindexc << "-" << sindex << "-" << sindexc << " ";
								}
								if(aseq1c[i] != '-')	qindex++;
								if(aseq2c[i] != '-')	sindex++;	
							}
							*out << endl;
							fin.close();
						} else {
							if(procid == 0){
								cout << "WARNING: Alignment does not exist " << filename << endl;
							}
						}
						if(refp2_vs_refp1.size() >= 0.5*(((Protein*)reference->molecules[p1chain[i]])->num_aminoacids + ((Protein*)m)->num_aminoacids)){
							Transformation *refc1_to_refc2 = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
				        	int point_index=0;
				        	for(hash_map<long, long, hash<long>, eqlong>::iterator itr = refp2_vs_refp1.begin(); itr != refp2_vs_refp1.end(); itr++){
				            	Aminoacid *aa_reflig = reference->aminoacid[(long) itr->first];
								Aminoacid *aa_refrec = reference->aminoacid[(long) itr->second];
								receptor_points[point_index] = Vector(aa_refrec->alpha_carbon->position);
								ligand_points[point_index] = Vector(aa_reflig->alpha_carbon->position);
								point_index++;
				            }
				            float rmsd = compute_rmsd(point_index, &receptor_points[0], &ligand_points[0], refc1_to_refc2);
				            *out << "ref chain " << p1chain[i] << " vs " << p2chain[j] << " - #points " << point_index << " rmsd " << rmsd << endl;out->flush();
				            if(z == 0)	receptor_symmetry.push_back(refc1_to_refc2);
				            else	ligand_symmetry.push_back(refc1_to_refc2);
				        }
					}
				}
			}
		}
	}
	out->flush();
	
	if(procid == 0){
		cout << "receptor #symmetries " << receptor_symmetry.size() << " ligand #symmetries " << ligand_symmetry.size() <<
			" homodimer #symmetries " << ligand_vs_receptor_symmetry.size() << endl;
	}
	
	//receptor->c->read_sppider_predictions("../sppider");
	//ligand->c->read_sppider_predictions("../sppider");
}

void elect_leader_on_node(){
	hosts = new string*[numprocs];
	gethostname(buff,BUFSIZE);
	hosts[procid] = host = new string(buff);
	
	for(int i=0;i<procid;i++){
		MPI_Ssend((void*) host->c_str(), host->size()+1, MPI_CHAR, i, TAG, MPI_COMM_WORLD);
	}	
	for(int i=procid+1;i<numprocs;i++){
		MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
		hosts[i] = new string(buff);
	}
	for(int i=numprocs-1; i > procid;i--){
		MPI_Ssend((void*) host->c_str(), host->size()+1, MPI_CHAR, i, TAG, MPI_COMM_WORLD);
	}
	for(int i = procid-1; i >= 0; i--){
		MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
		hosts[i] = new string(buff);
	}
	
	num_processes_on_node=1;
	masterprocessonnode=true;
	for(int i=0;i<numprocs;i++)
		if(i != procid && *hosts[i] == *host){
			num_processes_on_node++;
			if(i < procid)
				masterprocessonnode = false;
		}
}
