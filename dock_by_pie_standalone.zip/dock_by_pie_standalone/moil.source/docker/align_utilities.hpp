/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#ifndef INCLUDED_MOLECULE
	#define INCLUDED_MOLECULE
	#include "molecule.hpp"
	#include "evolution.hpp"
#endif

#define SEQ_ALIGN 1
#define STRUCT_ALIGN 2
#define SELECT_CHAIN "scripts/select_chain.sh"

#ifndef DSSP_EXECUTABLE
#define DSSP_EXECUTABLE "external/dsspcmbi"
#endif

#define RUN_CE "external/ce/run_ce.sh"
#define RUN_TMALIGN "external/run_tmalign.sh"

extern const char* pdbcode;
extern string* chains;
extern hash_map<const char*, Sequence*, hash<const char*>, eqstr> matching_sequences; 
extern hash_map<const char*, Sequence*, hash<const char*>, eqstr> matching_sequences_in_pdb, sequences_with_struct_alignment;
extern string* sequence;
extern hash_map<const char*, Molecule*, hash<const char*>, eqstr> homologues;

extern char **malignment;
extern const char ***malignment_indices;

#define DB_PDBAA 1
#define DB_NR 2
#define DB_SWISSPROT 3
#define DB_STRING 4
void read_blast_hits(char,unsigned short,string);

#define BLAST_ALIGN 1
#define LOOPP_ALIGN 2

void read_optm_local_hits(char *);
void read_loopp_alignments(int , int, char, int, int , hash_map<int,Alignment*,hash<int>, eqint> *);

Alignment *read_lalign_alignment(string* query, char *filename,unsigned int);

void pairwise_struct_align(int,char);
void read_molecules(int);
void multiple_align(int,char);
void read_profile(Protein*, char*);
void read_part_profile(Protein*,int, int, char*);
void read_profile(Protein*);
