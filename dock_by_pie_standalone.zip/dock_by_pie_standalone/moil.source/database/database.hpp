/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include <sqlite3.h>

#define DOCK_DB_FILE "complexes/dock.db"
//mysql user ravid password program name
sqlite3* dockdb;

#define QUERY_SIZE 8192
char q[QUERY_SIZE];
char *err = NULL;

/*
void init_database();
*/
