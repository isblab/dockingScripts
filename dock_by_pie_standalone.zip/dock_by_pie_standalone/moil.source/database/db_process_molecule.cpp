/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "molecule.hpp"
//#include "database.hpp"

#define MAX_CONTACT_DISTANCE 8
#define CHAIN_SEPARATION 4

char q[8192];
ostream *out;
string datadir;
char buf[8192];

void read_profile(Protein *m){
	Aminoacid* aacid[m->aminoacid.size()+1];
	int maaindex=0;
	for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = m->aminoacid.begin(); aaitr != m->aminoacid.end(); aaitr++)
		aacid[maaindex++] = ((Aminoacid*) aaitr->second);
	
	sort(aacid, aacid+m->aminoacid.size(),less<Aminoacid*>());
	
	stringstream ss (stringstream::in | stringstream::out);
	string filename;
	ss << datadir << m->pdbcode << "_" << m->chain << ".profile";
	ss >> filename;
	fstream fin(filename.c_str(), fstream::in);
	if(!fin.is_open()){
		*out << "ERROR: profile not present" << endl;
		out->flush(); exit(1);
	}
	
	do {
		fin.getline(buf,8192);
	} while ((string(buf)).find("position") == string::npos);
	fin.getline(buf,8192);
	
	int aaindex = 0;
	while(!fin.eof() && ((string(buf)).find("Lambda") == string::npos)){
		fin.getline(buf,8192);
		if(fin.gcount() > 150){
			Aminoacid* aa = aacid[aaindex];
	
			float entropy;
			{
				stringstream line(buf+150,stringstream::in);
				line >> entropy;
			}
		
			aa->entropy_sequence = entropy;
			aaindex++;
			//*out << aa->get_symbol() << " " << aa->entropySequence << endl;
		}
	}
	fin.close();
}

/*
 * input pdbcode chains
 * Read the molecule and the dssp files (for each chain and each pair of chains)
 */
int main(int argc, char *argv[]){
	out = &cout;
	read_molecule_config();
	stringstream ss (stringstream::in | stringstream::out);
	ss << argv[1] << ".sql";
	string filename; ss >> filename;
	fstream sqlout(filename.c_str(),fstream::out);
	ss.clear();
	ss << "/proj/ravid/statpotential/data/" << argv[1] << "/";
	ss >> datadir;
	
	//Complex *c = new Complex(argv[1],argv[2],PDB);
	int nchains = string(argv[2]).size();
	hash_map<char, Protein*, hash<char>, eqint> molecules;
	
	for(int i = 0 ; i < nchains; i++){
		char chain = argv[2][i];
		stringstream ss (stringstream::in | stringstream::out);
		ss << datadir << argv[1] << "_" << chain << ".pdb";
		string filename; ss >> filename;
		fstream fin(filename.c_str(), fstream::in);
		Protein *m = new Protein(&fin,argv[1],chain,PDB);
		molecules[chain] = m;
		read_profile(m);
		
		hash_map<const char*, short, hash<const char*>,eqstr> nn;
		for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr1 = m->aminoacid.begin(); aaitr1 != m->aminoacid.end(); aaitr1++){
			Aminoacid *aa1 = aaitr1->second;
			for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr2 = aaitr1; aaitr2 != m->aminoacid.end(); aaitr2++){
				Aminoacid *aa2 = aaitr2->second;
				if(abs(atoi(aa1->index.c_str()) - atoi(aa2->index.c_str())) >= CHAIN_SEPARATION){
					double d = Vector::distance(*(aa1->centroid),*(aa2->centroid));
					if(d <= MAX_CONTACT_DISTANCE){
						sprintf(q,"insert into distances values (\"%s\",\'%c\',\"%s\",\'%c\',\"%s\",%f);",
							m->pdbcode.c_str(),m->chain,aa1->index.c_str(),m->chain,aa2->index.c_str(),d);
						sqlout << q << endl;
						
						if(nn.count(aa1->index.c_str()) == 0)
							nn[aa1->index.c_str()] = 0;
						if(nn.count(aa2->index.c_str()) == 0)
							nn[aa2->index.c_str()] = 0;
						nn[aa1->index.c_str()]++;
						nn[aa2->index.c_str()]++;
					}
				}
			}
		}
		
		/* read the dssp files for individual chains */
		ss.clear();
		ss << datadir << m->pdbcode.c_str() << "_" << m->chain << "." << "dssp";
		ss >> filename;
		fstream dsspin(filename.c_str(), fstream::in);
		*out << filename << " " << dsspin.is_open() << endl;
		
		do {
			dsspin.getline(buf,8192);
		} while (((string(buf)).find("STRUCTURE") == string::npos) && !dsspin.eof());
		while(!dsspin.eof()){
			dsspin.getline(buf,8192);
			char chain = buf[11];
			if(dsspin.gcount() > 0 && chain != ' ' && buf[13] != '!'){
				string aacid_index;
				{
					stringstream line(buf+5,stringstream::in);
					line >> aacid_index;
				}
				if(buf[10] != ' '){
					//*out << aacid_index << " " << aacid_index.find(buf[10]) << endl;
					aacid_index = aacid_index.substr(0,aacid_index.find(buf[10])+1);
				}
				char sstructure = buf[16];
				m->aminoacid[aacid_index.c_str()]->sstructure = sstructure;
				//*out << aacid_index << " " << sstructure << endl;
				float exposedarea;
				{
					stringstream line(buf+34,stringstream::in);
					line >> exposedarea;
				}
				
				short num_neighbors = nn[aacid_index.c_str()];
				
				sprintf(q,"insert into exposedarea values (\"%s\",\"%c\",\'%c\',\"%s\",%f,%d);",
					m->pdbcode.c_str(),chain,chain,aacid_index.c_str(),exposedarea,num_neighbors);
				sqlout << q << endl;
			}
		}
		dsspin.close();
		
		for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = m->aminoacid.begin(); aaitr != m->aminoacid.end(); aaitr++){
			Aminoacid *aa = aaitr->second;
			sprintf(q,"insert into chain values (\"%s\",\'%c\',\"%s\",%d,%f,\'%c\');",
				m->pdbcode.c_str(),m->chain,aa->index.c_str(),aa->type,aa->entropy_sequence,aa->sstructure);
			sqlout << q << endl;
		}
	}
	
	/*
	 * compute contacts
	 * read the dssp file for pairs of chains and populate exposed surface areas
	 */
	for(hash_map<char, Protein*, hash<char>, eqint>::iterator mitr = molecules.begin(); mitr != molecules.end(); mitr++){
		Protein *m1 = mitr->second;
		for(hash_map<char, Protein*, hash<char>, eqint>::iterator mitr2 = mitr; mitr2 != molecules.end(); mitr2++){
			Protein *m2 = mitr2->second;
			if(m1 != m2){
				hash_map<const char*, short, hash<const char*>,eqstr> nn1,nn2;
				for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr1 = m1->aminoacid.begin(); aaitr1 != m1->aminoacid.end(); aaitr1++){
					Aminoacid *aa1 = aaitr1->second;
					for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr2 = m2->aminoacid.begin(); aaitr2 != m2->aminoacid.end(); aaitr2++){
						Aminoacid *aa2 = aaitr2->second;
						if(m1 != m2){
							double d = Vector::distance(*(aa1->centroid),*(aa2->centroid));
							if(d <= MAX_CONTACT_DISTANCE){
								sprintf(q,"insert into distances values (\"%s\",\'%c\',\"%s\",\'%c\',\"%s\",%f);",
									m1->pdbcode.c_str(),m1->chain,aa1->index.c_str(),m2->chain,aa2->index.c_str(),d);
								sqlout << q << endl;
								if(nn1.count(aa1->index.c_str()) == 0)
									nn1[aa1->index.c_str()] = 0;
								if(nn2.count(aa2->index.c_str()) == 0)
									nn2[aa2->index.c_str()] = 0;
								nn1[aa1->index.c_str()]++;
								nn2[aa2->index.c_str()]++;
							}
						}
					}
				}
				stringstream ss (stringstream::in | stringstream::out);
				string chains;
				ss << m1->chain << m2->chain;
				ss >> chains;
				string filename;
				ss.clear();
				ss << datadir << m1->pdbcode.c_str() << "_" << chains.c_str() << "." << "dssp";
				ss >> filename;
				fstream dsspin(filename.c_str(), fstream::in);
				if(!dsspin.is_open()){
					ss.clear();
					ss << datadir << m1->pdbcode.c_str() << "_" << m2->chain << m1->chain << "." << "dssp";
					ss >> filename;
					dsspin.clear();
					dsspin.open(filename.c_str(), fstream::in);
				}
				*out << filename << " " << dsspin.is_open() << endl;
				if(dsspin.is_open()){
					do {
						dsspin.getline(buf,8192);
						//*out << buf << endl; out->flush();
					} while (((string(buf)).find("STRUCTURE") == string::npos) && !dsspin.eof());
					while(!dsspin.eof()){
						dsspin.getline(buf,8192);
						
						char chain = buf[11];
						if(dsspin.gcount() > 0 && chain != ' ' && buf[13] != '!'){
							string aacid_index;
							{
								stringstream line(buf+5,stringstream::in);
								line >> aacid_index;
							}
							if(buf[10] != ' '){
								aacid_index = aacid_index.substr(0,aacid_index.find(buf[10])+1);
							}
							float exposedarea;
							{
								stringstream line(buf+34,stringstream::in);
								line >> exposedarea;
							}
							
							short num_neighbors;
							if(chain == m1->chain){
								num_neighbors = nn1[aacid_index.c_str()];
							} else {
								num_neighbors = nn2[aacid_index.c_str()];
							}
							sprintf(q,"insert into exposedarea values (\"%s\",\"%s\",\'%c\',\"%s\",%f,%d);",
								m1->pdbcode.c_str(),chains.c_str(),chain,aacid_index.c_str(),exposedarea,num_neighbors);
							sqlout << q << endl;
						}
					}
					dsspin.close();
				}
			}
		}
	}
	
	sqlout.close();
}
