/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include <iostream>
//#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <algorithm>
#include <cctype>
#include <iomanip>

using namespace std; 

#include "ap.h"
#include "legendre.h"

#define PI 3.14159265358

char command[8192], buf[8192];

/*double K(const int n, const double x){
}

double Kderiv(const int n, const double x){
}*/

/*
 * Computing shape dependent dielectrics in the absence of salt
 * Arguments: 
 */
int main(int argc, char *argv[]){
	stringstream ss (stringstream::in | stringstream::out);
	//ss << argv[1] << ".pdb";
	string filename;
	ss >> filename;
	//fstream fin(filename.c_str(), fstream::in);
	
	double D_in = 2.0, D_out = 80.0;
	unsigned short num_rdivisions=20, num_thetadivisions=32;
	cout << D_in << " " << D_out << " " << num_rdivisions << " " << num_thetadivisions << endl;
	for(unsigned short r1i = 0; r1i < num_rdivisions; r1i++)
		for(unsigned short r2i = r1i; r2i < num_rdivisions; r2i++)
			for(unsigned short thetai = 0; thetai <= num_thetadivisions; thetai++){
				double theta = (PI*thetai)/num_thetadivisions;
				double r1=((float) r1i)/num_rdivisions, r2=((float) r2i)/num_rdivisions;
				double cos_theta = cos(theta); 
				double r = sqrt(r1*r1 + r2*r2 - 2*r1*r2*cos_theta);
				double y = r1*r2;
				double inv_D = 1.0;
				double ratio=0;
				unsigned int n = 0;
				while((inv_D < 0 || ratio > 0.0001) || n < 2){
					double term = r*pow(y,n)*legendrecalculate(n,cos_theta)*(((n+1)*(D_in-D_out))/(n*(D_in+D_out)+D_out));
					inv_D += term;
					ratio = term/inv_D;
					ratio = (ratio < 0) ? 0-ratio : ratio;
					n++;
					//if(inv_D < 0)
					//	cout << "iteration " << n << " " << r1i << " " << r2i << " " << thetai << " " << inv_D << " " << term << " " << ratio << endl;
				}
				double D = D_in/inv_D;
				cout << r1i << " " << r2i << " " << thetai << " " << D << endl;	
			}
}
