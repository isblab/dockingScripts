/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "miniball/BoundingSphere.h"
#include "miniball/Point.h"
#include "elecutil.hpp"

unsigned short eps_num_rdivisions, eps_num_thetadivisions;
float ***effective_eps;
bool initialized=false, wrote_receptor=false;
extern char scratch_dir[];

void init(){
	string filename = string(getenv(string("HOME").c_str())) + "/" + string(DOCK_DIR) + "dielectric";
	fstream fdielec(filename.c_str());
	int line=0;
	char buf[8192];	
    while(fdielec.good()){
    	fdielec.getline(buf,8192);
    	if(fdielec.gcount() > 0){
	    	stringstream ss (stringstream::in | stringstream::out);
	    	ss << buf;
	    	float eps;
	    	if(line == 0){
	    		ss >> eps; ss >> eps;
	    		ss >> eps_num_rdivisions; ss >> eps_num_thetadivisions;
	    		effective_eps = (float ***) malloc(sizeof(float **) * eps_num_rdivisions);
	    		for(int i = 0; i < eps_num_rdivisions; i++){
	    			effective_eps[i] = (float **) malloc(sizeof(float *) * eps_num_rdivisions);
	    			for(int j = 0; j < eps_num_rdivisions; j++)
	    				effective_eps[i][j] = (float *) malloc(sizeof(float) * eps_num_thetadivisions);
	    		}
	    	} else {
	    		unsigned int r1i, r2i, thetai;
	    		ss >> r1i; ss >> r2i; ss >> thetai;
		    	ss >> effective_eps[r1i][r2i][thetai];
		    	effective_eps[r2i][r1i][thetai] = effective_eps[r1i][r2i][thetai];;
	    	}
	    	line = line + 1;
    	}
    }
    fdielec.close();
}

/*
 * Assuming all electronegative atoms are protonated, adding charge of the corresponding hydrogen to the atom in the PROP file
 * Compute the enclosing sphere
 */
void Complex::compute_electrostatics(){
	if(!initialized){
		init();
		initialized = true;
	}
	
	charged_atom = (Atom **) malloc(sizeof(Atom*)*num_atoms); 
	
	using namespace MiniBall;
	Point *P = new Point[num_atoms];

	num_charged_atoms=0;
	for(int i = 0 ; i < num_atoms; i++){
		Atom *a = atom[i];
		if(a->charge != 0 
		//&& (a->name).c_str()[0] != 'H'
		){
			P[num_charged_atoms].x = a->position->x;
			P[num_charged_atoms].y = a->position->y;
			P[num_charged_atoms].z = a->position->z;
			charged_atom[num_charged_atoms] = a;
			num_charged_atoms++;
		}
	}	

	BoundingSphere BS = Sphere::miniBall(P,num_charged_atoms);
	min_sphere_center = new Vector(BS.center.x, BS.center.y, BS.center.z);
	min_sphere_radius = BS.radius;

	*out << "center of mass : (" << center_of_mass->x << "," << center_of_mass->y << "," << center_of_mass->z << ") min sphere center : (" 
		<< min_sphere_center->x << "," << min_sphere_center->y << "," << min_sphere_center->z << ") radius : " << min_sphere_radius << endl;
}

/*
 * Compute the minimum ball enclosing the complex, assume the complex is a sphere
 */
void Object::compute_electrostatic_energy_sphere(Object *receptor, Object *ligand, Transformation *tr, DetailedScoringMetrics *details){
	if(!initialized){
		init();
		initialized = true;
	}
	
	Complex *cl = ligand->cH, *cr = receptor->cH; 
	Vector vR = *(cr->min_sphere_center), vL = tr->inverse_transform(cl->min_sphere_center);
	float d = Vector::distance(vR, vL), rR = cr->min_sphere_radius, rL = cl->min_sphere_radius;
	float radius;
	Vector center;
	if(d*d > (rR-rL)*(rR-rL)){
		if(rR > rL){
			radius = rR; center = vR;
		} else {
			radius = rL; center = vL;
		}
	} else {
		radius = 0.5*(d+rR+rL); 
		center = vR * ((radius - rL)/d) + vL * ((radius - rR)/d);
	}
	//*out << "center : (" << center.x << ","  << center.y << ","  << center.z << ") radius : " << radius << endl;
	
	float coloumb_energy = 0, canonical_energy = 0;
	float inter_energy = 0;
	Vector r2[cl->num_atoms];
	float r2norm[cl->num_atoms];
	unsigned short r2i[cl->num_atoms];
	float eps;
	
	for(int j = 0 ; j < cl->num_charged_atoms; j++){
		Atom *al = cl->charged_atom[j];
		unsigned short alcindex = al->cindex;
		r2[alcindex] = ((Reference_Frame*) tr)->inverse_transform(*(al->position)) - center;
		r2norm[alcindex] = r2[alcindex].norm();
		r2i[alcindex] = (unsigned short) ((r2norm[alcindex]*eps_num_rdivisions)/radius);
	}
	
	Vector r1[cr->num_atoms];
	float r1norm[cr->num_atoms];
	unsigned short r1i[cr->num_atoms],thetai;
	
	for(int i = 0 ; i < cr->num_charged_atoms; i++){
		Atom *ar = cr->charged_atom[i];
		unsigned short arcindex = ar->cindex;
		r1[arcindex] = *(ar->position) - center;
		r1norm[arcindex] = r1[arcindex].norm();
		r1i[arcindex] = (unsigned short) ((r1norm[arcindex]*eps_num_rdivisions)/radius);
		//*out << arcindex << " r1norm " << r1norm[arcindex] << " r1i " << r1i[arcindex] << endl; out->flush();
		for(int j = 0 ; j < cl->num_charged_atoms; j++){
			Atom *al = cl->charged_atom[j];
			unsigned short alcindex = al->cindex;
			thetai = (acos(r1[arcindex].dot(r2[alcindex])/(r1norm[arcindex]*r2norm[alcindex]))*eps_num_thetadivisions)/PI;
			if(r1i[arcindex] < eps_num_rdivisions && r2i[alcindex] < eps_num_rdivisions)
				eps = effective_eps[r1i[arcindex]][r2i[alcindex]][thetai];
			else
				eps = EPS_WATER;
			
			d = Vector::distance(*(ar->position),((Reference_Frame*) tr)->inverse_transform(*(al->position)));
			if(d < 0.8*(ar->radius + al->radius))
				d = 0.8*(ar->radius + al->radius);
			
			inter_energy += (ar->charge * al->charge)/(eps*d);
			coloumb_energy += (ar->charge * al->charge)/d;
			
			eps = (d < 6) ? 4 : ( (d > 8) ? 80 : (38*d-224) );
			canonical_energy += (ar->charge * al->charge)/(eps*d);
		}
	}
	
	float receptor_intra_energy=0, ligand_intra_energy=0;
	for(int i = 0 ; i < cr->num_charged_atoms; i++){
		Atom *a1 = cr->charged_atom[i];
		unsigned short a1cindex = a1->cindex;
		for(int j = i+1 ; j < cr->num_charged_atoms; j++){
			Atom *a2 = cr->atom[j];
			unsigned short a2cindex = a2->cindex;
			thetai = (acos(r1[a1cindex].dot(r1[a2cindex])/(r1norm[a1cindex]*r1norm[a2cindex]))*eps_num_thetadivisions)/PI;
			if(r1i[a1cindex] < eps_num_rdivisions && r1i[a2cindex] < eps_num_rdivisions)
				eps = effective_eps[r1i[a1cindex]][r1i[a2cindex]][thetai];
			else
				eps = EPS_WATER;
				
			d = Vector::distance(*(a1->position),*(a2->position));
			if(d < 0.8*(a1->radius + a2->radius))
				d = 0.8*(a1->radius + a2->radius);
					
			receptor_intra_energy += (a1->charge * a2->charge)/(eps*d);
		}
	}
	for(int i = 0 ; i < cl->num_charged_atoms; i++){
		Atom *a1 = cl->charged_atom[i];
		unsigned short a1cindex = a1->cindex;
		for(int j = i+1 ; j < cl->num_charged_atoms; j++){
			Atom *a2 = cl->atom[j];
			unsigned short a2cindex = a2->cindex;
			thetai = (acos(r2[a1cindex].dot(r2[a2cindex])/(r2norm[a1cindex]*r2norm[a2cindex]))*eps_num_thetadivisions)/PI;
			if(r2i[a1cindex] < eps_num_rdivisions && r2i[a2cindex] < eps_num_rdivisions)
				eps = effective_eps[r2i[a1cindex]][r2i[a2cindex]][thetai];
			else
				eps = EPS_WATER;
			
		
			float d = Vector::distance(*(a1->position),*(a2->position));
			if(d < 0.8*(a1->radius + a2->radius))
				d = 0.8*(a1->radius + a2->radius);
					
			ligand_intra_energy += (a1->charge * a2->charge)/(eps*d);
		}
	}
	
	details->elec[0] = inter_energy;
	details->elec[1] = receptor_intra_energy + ligand_intra_energy;
	details->elec[2] = coloumb_energy;
	details->elec[3] = canonical_energy;
}

/*
 * Using Delphi
 */
void Object::compute_electrostatic_energy_pb(Object *receptor, Object *ligand, Transformation *tr, DetailedScoringMetrics *details){
	char buf[8192];
	if(!wrote_receptor){
		sprintf(buf,"%s/receptor.pdb",scratch_dir);
		Transformation *id = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
		//id->write_as_pdb(receptor->c,receptor->c->chains, true, string(buf),true);
		id->write_as_pdb(receptor->cH,receptor->cH->chains, false, string(buf),true);
		wrote_receptor=true;
	}
	
	sprintf(buf,"%s/l%ld.pdb",scratch_dir,tr->frame_number);
	//tr->write_as_pdb(ligand->c, ligand->c->chains,true, string(buf), false);
	tr->write_as_pdb(ligand->cH, ligand->cH->chains,false, string(buf), false);
	sprintf(buf, "/proj/ravid/software/delphi/run_delphi.sh %ld %s %d",tr->frame_number,scratch_dir,((int) ((receptor->cH->diameter + ligand->cH->diameter)*1.2)));
	int	ret = system(buf);
	*out << buf << " " << ret << endl; out->flush();
	
	if(tr->frame_number == 1){
		sprintf(buf,"cp %s/c%ld.*out .",scratch_dir,tr->frame_number);
		system(buf);
	}
	
	float e[6][4]; unsigned short line=0;
	sprintf(buf,"%s/%ld.delphi.res",scratch_dir,tr->frame_number);
	fstream delphiin(buf,fstream::in);
	while(delphiin.good()){
		delphiin.getline(buf,8192);
		stringstream ss(stringstream::in | stringstream::out);
		ss << buf;
		if(line < 6)
			for(unsigned short i=0; i < 4; i++)
				ss >> e[line][i];
		line++; 
	}
	
	float delta_coulombic, delta_reactionfield, delta_ions;
	delta_coulombic = e[0][1] - (e[1][1]+e[2][1]);
	delta_reactionfield = e[0][2] - (e[1][2]+e[2][2]);
	delta_ions = (e[3][0]-e[0][0]) - ((e[4][0]-e[1][0])+(e[5][0]-e[2][0]));
	details->elec[0] = delta_coulombic + delta_reactionfield + delta_ions;
	details->elec[1] = delta_coulombic;
	details->elec[2] = delta_reactionfield;
	details->elec[3] = delta_ions;
	for(unsigned short i = 0; i < 12; i++){
		details->elec[i+4] = e[i/4][i%4];
	}
	for(unsigned short i = 0; i < 3; i++)
		details->elec[i+16] = e[i+3][0];
}

/*
 * Take care of the change in the self energy when the dielectric changes
 */
void Object::compute_electrostatic_energy_coloumb(Object *receptor, Object *ligand, Transformation *tr){
	tr->eElectrostatic = 0;
	for(int i = 0 ; i < receptor->cH->num_charged_atoms; i++){
		Atom *ar = receptor->cH->atom[i];
		if(ar->charge != 0 && (ar->name).c_str()[0] != 'H'){
			for(int j = 0 ; j < ligand->cH->num_charged_atoms; j++){
				Atom *al = ligand->cH->atom[j];
				if(al->charge != 0 && (al->name).c_str()[0] != 'H'){	
					float d = Vector::distance(*(ar->position), ((Reference_Frame*) tr)->inverse_transform(*(al->position)));
					if(d < 1.0*(ar->radius + al->radius))
						d = 1.0*(ar->radius + al->radius);
				
					tr->eElectrostatic += (ar->charge * al->charge)/d;
				}
			}
		}
	}
}

/*
 * There is a difference of 0.14 per chain in the charges from ALL.MONO and ewald (ewald sees a higher positive charge)
 * because of modification of charge at the residues adjacent to NTER and CTER
 * 
 * Ions are added separately
 */
void write_as_crd(Complex* receptor, int nrchains, Complex* ligand, int nlchains, Transformation* tr){
	char buf[32];
	sprintf(buf,"es/cmplx.crd");
	fstream crdout(buf, fstream::out);
	crdout << setiosflags(ios::fixed) << setprecision(5);
	
	float charge = 0;
	int num_atoms = 1;
	for(int aai = 0; aai < receptor->num_aminoacids; aai++){
		Aminoacid *aa = receptor->aminoacid[aai];
		int natoms = (aa->atom).size();
		Atom *aa_atoms[natoms + 1];
		int count = 0;
		for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = (aa->atom).begin(); aitr != (aa->atom).end(); aitr++){
			aa_atoms[count++] = aitr->second;
		}
		// sort atoms by index
		for(int i=0;i<natoms;i++)
			for(int j=i+1;j<natoms;j++)
				if(aa_atoms[i]->cindex > aa_atoms[j]->cindex){
					Atom *a = aa_atoms[i];
					aa_atoms[i] = aa_atoms[j];
					aa_atoms[j] = a;
				}
		for(int i=0;i<natoms;i++){
			Atom *a = aa_atoms[i];		
			float coord[3];
			coord[0] = a->position->x;
			coord[1] = a->position->y;
			coord[2] = a->position->z;
			int ci[3];
			char cf[3][9];
			for(int i=0;i<3;i++){
				ci[i] = (int) coord[i];
				float d = coord[i] - ci[i];
				sprintf(cf[i],"%8.5f",d);
			}
			char buf[256];
			sprintf(buf,"%5d%5d %-4s %-4s%4d.%s%4d.%s%4d.%s ", num_atoms++,aa->cindex,(aa->name).c_str(),(a->name).c_str(),ci[0],&cf[0][3],ci[1],&cf[1][3],ci[2],&cf[2][3]);
			crdout << buf << endl;
			//cout << buf << " " << a->charge << endl;
			charge += a->charge;
		}
	}
	
	for(int aai = 0; aai < ligand->num_aminoacids; aai++){
		Aminoacid *aa = ligand->aminoacid[aai];
		int natoms = (aa->atom).size();
		Atom *aa_atoms[natoms + 1];
		int count = 0;
		for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = (aa->atom).begin(); aitr != (aa->atom).end(); aitr++){
			aa_atoms[count++] = aitr->second;
		}
		// sort atoms by index
		for(int i=0;i<natoms;i++)
			for(int j=i+1;j<natoms;j++)
				if(aa_atoms[i]->cindex > aa_atoms[j]->cindex){
					Atom *a = aa_atoms[i];
					aa_atoms[i] = aa_atoms[j];
					aa_atoms[j] = a;
				}
		for(int i=0;i<natoms;i++){
			Atom *a = aa_atoms[i];		
			Vector v = ((Reference_Frame*) tr)->inverse_transform(*(a->position));
			float coord[3];
			coord[0] = v.x;
			coord[1] = v.y;
			coord[2] = v.z;
			int ci[3];
			char cf[3][9];
			for(int i=0;i<3;i++){
				ci[i] = (int) coord[i];
				float d = coord[i] - ci[i];
				sprintf(cf[i],"%8.5f",d);
			}		
			char buf[256];
			sprintf(buf,"%5d%5d %-4s %-4s%4d.%s%4d.%s%4d.%s ", num_atoms++, receptor->num_aminoacids + aa->cindex,(aa->name).c_str(),(a->name).c_str(),ci[0],&cf[0][3],ci[1],&cf[1][3],ci[2],&cf[2][3]); 
			crdout << buf << endl;
			//cout << buf << " " << a->charge << endl;			
			charge += a->charge;
		}
	}
	crdout.close();
	/*float ewald_charge = charge + (0.14)*(nrchains+nlchains);
	if(ewald_charge != 0){
		*out << "ERROR: compute electrostatics - charge " << charge << " ewaldcharge " << ewald_charge << endl; out->flush();
	}*/
}

/*
 * Need to subtract base energy to get the change in electrostatic energy on complex formation
 */
void Object::compute_electrostatic_energy_ewald(Object *receptor, Object *ligand, Transformation *tr){
	/*write_as_crd(receptor->cH,receptor->c->chains.size(),ligand->cH,ligand->c->chains.size(),tr);
	char command[512];
	sprintf(command, "%s/%s %ld %s",getenv(string("HOME").c_str()),(string(RUN_EWALD)).c_str(),tr->frame_number,scratch_dir);
	int	ret = system(command);
	*out << command << " " << ret << endl;
	
	char buf[8192];
	sprintf(buf,"%s/%ld.ene",scratch_dir,tr->frame_number);
	fstream enein(buf,fstream::in);
	do {
		enein.getline(buf,8192);
	} while (((string(buf)).find("E elec TOTAL") == string::npos) && !enein.eof());
	
	// assuming ewald does not crash
	stringstream line(buf+(string(buf)).find("=")+1,stringstream::in);
	line >> tr->eElectrostatic;
	*out << tr->eElectrostatic << endl;
	
	enein.close();*/
}

