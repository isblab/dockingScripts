#include "mVector.h"

#include <math.h>

namespace MiniBall
{
	mVector mVector::operator+() const
	{
		return *this;
	}

	mVector mVector::operator-() const
	{
		return mVector(-x, -y, -z);
	}

	mVector &mVector::operator+=(const mVector &v)
	{
		x += v.x;
		y += v.y;
		z += v.z;

		return *this;
	}

	mVector &mVector::operator-=(const mVector &v)
	{
		x -= v.x;
		y -= v.y;
		z -= v.z;

		return *this;
	}

	mVector &mVector::operator*=(float s)
	{
		x *= s;
		y *= s;
		z *= s;

		return *this;
	}

	mVector &mVector::operator/=(float s)
	{
		float r = 1.0f / s;

		return *this *= r;
	}

	bool operator==(const mVector &U, const mVector &v)
	{
		if(U.x == v.x && U.y == v.y && U.z == v.z)
			return true;
		else
			return false;
	}

	bool operator!=(const mVector &U, const mVector &v)
	{
		if(U.x != v.x || U.y != v.y || U.z != v.z)
			return true;
		else
			return false;
	}

	mVector operator+(const mVector &u, const mVector &v)
	{
		return mVector(u.x + v.x, u.y + v.y, u.z + v.z);
	}

	mVector operator-(const mVector &u, const mVector &v)
	{
		return mVector(u.x - v.x, u.y - v.y, u.z - v.z);
	}

	float operator*(const mVector &u, const mVector &v)
	{
		return u.x * v.x + u.y * v.y + u.z * v.z;
	}

	mVector operator*(float s, const mVector &v)
	{
		return mVector(s * v.x, s * v.y, s * v.z);
	}

	mVector operator*(const mVector &v, float s)
	{
		return mVector(v.x * s, v.y * s, v.z * s);
	}

	mVector operator/(const mVector &v, float s)
	{
		float r = 1.0f / s;

		return mVector(v.x * r, v.y * r, v.z * r);
	}

	float operator^(const mVector &u, const mVector &v)
	{
		return acosf(u / mVector::N(u) * v / mVector::N(v));
	}

	mVector operator%(const mVector &u, const mVector &v)
	{
		return mVector(u.y * v.z - u.z * v.y, u.z * v.x - u.x * v.z, u.x * v.y - u.y * v.x);
	}

	float mVector::N(const mVector &v)
	{
		return sqrtf(v^2);
	}

	float mVector::N2(const mVector &v)
	{
		return v^2;
	}
}