#include "Timer.h"

namespace MiniBall
{
	Timer::Timer()
	{
	}

	double Timer::seconds()
	{
		return 0;
	}

	double Timer::ticks()
	{
		return 4800.0 * seconds();
	}

	void Timer::pause(double p)
	{
		double stopTime = Timer::seconds() + p;

		while(Timer::seconds() < stopTime);
	}
}
