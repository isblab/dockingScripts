#ifndef VECTOR_H
#define VECTOR_H

#include "Tuple.h"

namespace MiniBall
{
	class Point;

	class mVector : public Tuple<3>
	{
	public:
		mVector();
		mVector(const int i);
		mVector(const mVector &v);
		mVector(const Point &p);
		mVector(float v_x, float v_y, float v_z);

		mVector &operator=(const mVector &v);

		float getX() const;
		void setX(float x);
		/*__declspec(property(get = getX, put = setX))*/ float x;

		float getY() const;
		void setY(float y);
		/*__declspec(property(get = getY, put = setY))*/ float y;

		float getZ() const;
		void setZ(float z);
		/*__declspec(property(get = getZ, put = setZ))*/ float z;

		mVector operator+() const;
		mVector operator-() const;

		mVector &operator+=(const mVector &v);
		mVector &operator-=(const mVector &v);
		mVector &operator*=(float s);
		mVector &operator/=(float s);

		friend bool operator==(const mVector &u, const mVector &v);
		friend bool operator!=(const mVector &u, const mVector &v);

		friend mVector operator+(const mVector &u, const mVector &v);
		friend mVector operator-(const mVector &u, const mVector &v);
		friend float operator*(const mVector &u, const mVector &v);   // Dot product
		friend mVector operator*(float s, const mVector &v);
		friend mVector operator*(const mVector &v, float s);
		friend mVector operator/(const mVector &v, float s);
		friend float operator^(const mVector &v, const int n);   // mVector power
		friend float operator^(const mVector &u, const mVector &v);   // Angle between mVectors
		friend mVector operator%(const mVector &u, const mVector &v);   // Cross product

		static float N(const mVector &v);   // Norm
		static float N2(const mVector &v);   // Squared norm
	};
}

#include "Point.h"

#include <assert.h>

namespace MiniBall
{
	inline mVector::mVector()
	{
	}

	inline mVector::mVector(const int i)
	{
		const float s = (float)i;

		x = s;
		y = s;
		z = s;
	}

	inline mVector::mVector(const mVector &v)
	{
		x = v.x;
		y = v.y;
		z = v.z;
	}

	inline mVector::mVector(const Point &P)
	{
		x = P.x;
		y = P.y;
		z = P.z;
	}

	inline mVector::mVector(float v_x, float v_y, float v_z)
	{
		x = v_x;
		y = v_y;
		z = v_z;
	}

	inline mVector &mVector::operator=(const mVector &v)
	{
		x = v.x;
		y = v.y;
		z = v.z;

		return *this;
	}

	inline float mVector::getX() const
	{
		return element[0];
	}

	inline void mVector::setX(float x_)
	{
		element[0] = x_;
	}

	inline float mVector::getY() const
	{
		return element[1];
	}

	inline void mVector::setY(float y_)
	{
		element[1] = y_;
	}

	inline float mVector::getZ() const
	{
		return element[2];
	}

	inline void mVector::setZ(float z_)
	{
		element[2] = z_;
	}

	inline float operator^(const mVector &v, const int n)
	{
		switch(n)
		{
		case 2:
			return v*v;
		default:
			assert(n == 2);   // FIXME: Compile time assert?
			return 1;
		}
	}
}

#endif   // VECTOR_H
