#include "Tuple.h"

namespace MiniBall
{
}