/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];

/*
 * Arguments: transformationfile 
 * */
int main(int argc, char *argv[]){
	out = &cout;
	read_molecule_config();
	read_dock_config();
	
	float sigma = 1.5;//2.0;
	float	debye_length = 5.0;
	float scale_factor = 556.0 /80.0; // calculated with temperature 300
	//scale_factor = 1000.0;
	
	fstream transin(argv[1],ios::binary|ios::in);
	*out << argv[1] << " " << transin.good() << endl;
	
	float max_r = 400.0;
	float spacing = 0.1;
	int num_divisions = max_r/spacing;
	float probability[num_divisions];
	for(int i = 0; i < num_divisions; i++)
		probability[i] = 0.0;

	// transformation id starts with 0 and they are in increasing order of id
	int count=0;
	while(transin.good()){
		//transin.seekg(tid*Transformation::basic_byte_size,ios::beg);
		transin.read(buf,Transformation::basic_byte_size);
		if(transin.gcount() > 0){
			Transformation *tr = new Transformation(buf,TN_BASIC);
			//tr->print_details(out,TN_BASIC);

			float r = tr->translation->norm();
			int division = r/spacing;
			float point_weight = expf(tr->eSolvation * scale_factor);
			probability[division] += point_weight;

			if(count%100000 == 1)	cout << "processing at " << count << " U " << tr->eSolvation * scale_factor << endl;
			count++;
			delete tr;
		}
	}
	transin.close();

	float sum=0;
	for(int i = 0; i < num_divisions; i++)	sum += probability[i];
	for(int i = 0; i < num_divisions; i++){
		cout << i << " " << probability[i]/sum << endl;
	}
}
