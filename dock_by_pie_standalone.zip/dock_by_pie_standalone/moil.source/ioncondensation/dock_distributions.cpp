/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "dock_util.hpp"

string dist1_filename, dist2_filename;

MKL_Complex8 *rec_shape, *lig_shape, *rec_elec, *lig_elec;
DFTI_DESCRIPTOR_HANDLE fft_desc_handle;
MKL_LONG mkl_status, gridsize[3], strides[4];
unsigned int size;
float sqrt_size;

bool debug=false;

#define SPACED_ROTATIONS "68760.euler"
float grid_spacing=1.50;//2.0;

#define R_SPACING 0.1
#define R_MAX 600.0

const int num_r_divisions = R_MAX / R_SPACING + 2;
double r_probability[num_r_divisions], r_count[num_r_divisions];

unsigned int max_transformations=1024*1024;

float **rot_angles;
int num_rotations;

Vector rec_center, lig_center, rec_grid_origin, lig_grid_origin;
float ***rec_charge, ***rec_mass;
float ***lig_charge, ***lig_mass;

float sigma, debye_length;
float scale_factor = 556.0 /80.0;

unsigned int rgridsize[3], lgridsize[3];

typedef struct {
	float evdw, evdw_real, evdw_imag , score;
	unsigned int index, rotindex;
} transformationscore;

transformationscore *rotation_scores,*node_result,*work0, *work1;
unsigned int merge_output_index=0;
unsigned int num_node_transforms=0;

bool transscore_bettersum(transformationscore t1,transformationscore t2){
	return(t1.score > t2.score);
}

bool (*transscore_better)(transformationscore t1,transformationscore t2) = &transscore_bettersum;

float rcutoff;

void build_fft_exclusion_grid(float grid_spacing, MKL_Complex8 *fftgrid, MKL_LONG *fftgridsize, unsigned int gridsize[3], Reference_Frame *tr, bool isreceptor){
	// rotations keep the center invariant
	Vector center, grid_origin;
	float ***mass;
	if(isreceptor){
		center = Vector(rec_center);
		mass = rec_mass;
		grid_origin = Vector(rec_grid_origin);
	} else {
		center = Vector(lig_center);
		mass = lig_mass;
		grid_origin = Vector(lig_grid_origin);
	}
	
	for(int i = 0; i < size; i++)
		((fftgrid)[i]).real = ((fftgrid)[i]).imag = 0.0;
		
	for(int i = 0; i < gridsize[0]; i++)
		for(int j = 0; j < gridsize[1]; j++)
			for(int k = 0; k < gridsize[2]; k++)
				if(mass[i][j][k] > 0){
					Vector v = Vector(i,j,k)*grid_spacing;
					Vector tv = tr->transform(v - center) - grid_origin;
					int vx = (int) (tv.x/grid_spacing);
					int vy = (int) (tv.y/grid_spacing);
					int vz = (int) (tv.z/grid_spacing);
		
					unsigned int index = (vx*fftgridsize[1] + vy)*fftgridsize[2] + vz;
				
					fftgrid[index].real = mass[i][j][k];
				}

	*out << "build fft exclusion grid" << endl; 
}

void build_elec_grid(float grid_spacing, MKL_Complex8 *fftgrid, MKL_LONG *fftgridsize, unsigned int gridsize[3], Reference_Frame *tr, bool isreceptor){
	// rotations keep the center invariant
	Vector center, grid_origin;
	float ***charge;
	if(isreceptor){
		center = Vector(rec_center);
		charge = rec_charge;
		grid_origin = Vector(rec_grid_origin);
	} else {
		center = Vector(lig_center);
		charge = lig_charge;
		grid_origin = Vector(lig_grid_origin);
	}
	
	for(int i = 0; i < size; i++)
		((fftgrid)[i]).real = ((fftgrid)[i]).imag = 0.0;
	
	unsigned long nummarkings = 0;	
	for(int i = 0; i < gridsize[0]; i++)
		for(int j = 0; j < gridsize[1]; j++)
			for(int k = 0; k < gridsize[2]; k++)
				if(charge[i][j][k] > 0){
					if(isreceptor){
						*out << "(" << i << "," << j << "," << k << ") " << nummarkings << endl;
						out->flush();
					}
					
					Vector v = Vector(i,j,k)*grid_spacing;
					Vector tv = tr->transform(v - center) - grid_origin;
					int vx = (int) (tv.x/grid_spacing);
					int vy = (int) (tv.y/grid_spacing);
					int vz = (int) (tv.z/grid_spacing);
		
					int minx,maxx,miny,maxy,minz,maxz;
					minx = maxx = vx;
					miny = maxy = vy;
					minz = maxz = vz;
					int level = 0;
					float radius_squared = rcutoff*rcutoff;
					if(!isreceptor)	radius_squared = 0;
					bool intersects_surface = true;
					while(intersects_surface){
						if(debug && isreceptor){
							*out << "(" << i << "," << j << "," << k << ") " << nummarkings << " level " << level << endl;
							out->flush();
						}
						intersects_surface = false;
						bool intersectsxmin,intersectsxmax,intersectsymin,intersectsymax,intersectszmin,intersectszmax;
						for(int x = minx; x <= maxx; x++){
							for(int y = miny; y <= maxy; y++){
								for(int z = minz; z <= maxz; z++){
									Vector corner_000 = Vector( (((float) x) )*grid_spacing, (((float) y) )*grid_spacing, (((float) z) )*grid_spacing);
									Vector grid_center = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) + 0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing);
									bool intersects_cell = false;
									if( x == minx || x == maxx || y == miny || y == maxy || z == minz || z == maxz ){
										float d,d2,d_2;
										intersects_cell = ((d2 = Vector::distance_squared(tv,corner_000)) <= radius_squared) || (level == 0);
										intersects_surface = intersects_surface || intersects_cell;
			
										if(intersects_cell){
											unsigned int index = (x*fftgridsize[1] + y)*fftgridsize[2] + z;
											float factor = 0;								
			
											// trilinear interpolate
											if(!isreceptor){
												factor = charge[i][j][k];
												Vector v = tv * (1.0/grid_spacing);
												float wx[2],wy[2],wz[2];
												wx[0] = x+1.0 - v.x;
												wx[1] = v.x - x;
												wy[0] = y+1.0 - v.y;
												wy[1] = v.y - y;
												wz[0] = z+1.0 - v.z;
												wz[1] = v.z - z;
												
												for(int cci =0; cci <=1; cci++)
													for(int ccj =0; ccj <=1; ccj++)
														for(int cck =0; cck <=1; cck++){
															int nx = (x+cci)% fftgridsize[0];
															int ny = (y+ccj)% fftgridsize[1];
															int nz = (z+cck)% fftgridsize[2];
															unsigned int nindex = (nx*fftgridsize[1] + ny)*fftgridsize[2] + nz;
															float nfactor = factor *wx[cci]*wy[ccj]*wz[cck];
															((fftgrid)[nindex]).real += nfactor;
														}
											} else if(d2>0.01) {
												float d = sqrt(d2);
			 									factor = charge[i][j][k] * expf(0-(d-sigma)/debye_length)/d;
			 									((fftgrid)[index]).real += factor;
											}
			
											nummarkings++;
			
											if( x == minx)
												intersectsxmin = true;
											if( x == maxx)
												intersectsxmax = true;
											if( y == miny)
												intersectsymin = true;
											if( y == maxy)
												intersectsymax = true;
											if( z == minz)
												intersectszmin = true;
											if( z == maxz)
												intersectszmax = true;
										}
									}
								}
							}
						}
						if(intersectsxmin && minx > 0)
							minx--;
						if(intersectsxmax && maxx < fftgridsize[0] - 1)
							maxx++;
						if(intersectsymin && miny > 0)
							miny--;
						if(intersectsymax && maxy < fftgridsize[1] - 1)
							maxy++;
						if(intersectszmin && minz > 0)
							minz--;
						if(intersectszmax && maxz < fftgridsize[2] - 1)
							maxz++;
		
						if(debug)
							*out << minx << "," << maxx << " " << miny << "," << maxy << " " << minz << "," << maxz << " " << fftgridsize[0] << " " << fftgridsize[1] << " " << fftgridsize[2] << endl;	
						level++;
					}							
				}

	*out << "build fft elec grid #markings " << nummarkings << endl; 
}


void process_receptor(){
	char buf[8192];
	fstream freceptor(dist1_filename.c_str());
	if(!freceptor.good()){
		if(procid==0){
			cout << "file missing " << dist1_filename << endl;
			cout.flush();
		}
		exit(-1);
	}
	int lineno=0;
	float rgridspacing[3];
	rgridspacing[0] = rgridspacing[1] = rgridspacing[2] = grid_spacing;
	float rmin[3], rmax[3];
	for(int i = 0; i < 3; i++)	rmin[i] = rmax[i] = 0;
	float sum_charge = 0;
	while(freceptor.good()){
    	freceptor.getline(buf,8192);
    	if(freceptor.gcount() > 0){
    		lineno++;
    		stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
			if(lineno <= 3){
				string tag;
				ss >> tag; ss >> tag;
				ss >> rmin[lineno-1];
				//rmin[lineno-1] /= 2;
				ss >> tag; ss >> tag;
				ss >> rmax[lineno-1];
				//rmax[lineno-1] /= 2;
				rgridsize[lineno-1] = (rmax[lineno-1])/rgridspacing[lineno-1] + 1;
				
				*out << string(buf) << endl;
				*out << lineno << " " << rgridsize[lineno-1] << " " << rgridspacing[lineno-1] << endl; out->flush();
				
				if(lineno == 3){
					rec_charge = (float ***) malloc(sizeof(float**)*rgridsize[0]);
					rec_mass = (float ***) malloc(sizeof(float**)*rgridsize[0]);
					for(int i=0; i<rgridsize[0]; i++){
						rec_charge[i] = (float **) malloc(sizeof(float*)*rgridsize[1]);
						rec_mass[i] = (float **) malloc(sizeof(float*)*rgridsize[1]);
						for(int j=0; j<rgridsize[1]; j++){
							rec_charge[i][j] = (float *) malloc(sizeof(float)*rgridsize[2]);
							rec_mass[i][j] = (float *) malloc(sizeof(float)*rgridsize[2]);
							for(int k=0; k<rgridsize[2]; k++){
								rec_charge[i][j][k] = 0.0;
								rec_mass[i][j][k] = 0.0;
							}
						}
					} 
				}
			} else {
				int x,y,z;
				float charge, mass;
				ss >> x;
				ss >> y;
				ss >> z;
				ss >> charge;
				ss >> mass;
				rec_charge[x][y][z] = charge;
				rec_mass[x][y][z] = mass;
				sum_charge += charge;
			}
    	}
    }
    freceptor.close();
    if(procid==0)
    	cout << "net charge " << sum_charge << endl;
    
   	fstream fligand(dist2_filename.c_str());
   	if(!fligand.good()){
		if(procid==0){
			cout << "file missing " << dist2_filename << endl;
			cout.flush();
		}
		exit(-1);
	}
	lineno=0;
	float lgridspacing[3];
	lgridspacing[0] = lgridspacing[1] = lgridspacing[2] = grid_spacing;
	float lmin[3], lmax[3];
	for(int i = 0; i < 3; i++)	lmin[i] = lmax[i] = 0;
	while(fligand.good()){
    	fligand.getline(buf,8192);
    	if(fligand.gcount() > 0){
    		lineno++;
    		stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
			if(lineno <= 3){
				string tag;
				ss >> tag; ss >> tag;
				ss >> lmin[lineno-1];
				//lmin[lineno-1] /= 2;
				ss >> tag; ss >> tag;
				ss >> lmax[lineno-1];
				//lmax[lineno-1] /= 2;
				lgridsize[lineno-1] = lmax[lineno-1]/lgridspacing[lineno-1] + 1;
				
				*out << string(buf) << endl;
				*out << lineno << " " << lgridsize[lineno-1] << " " << lgridspacing[lineno-1] << endl; out->flush();
				
				if(lineno == 3){
					lig_charge = (float ***) malloc(sizeof(float**)*lgridsize[0]);
					lig_mass = (float ***) malloc(sizeof(float**)*lgridsize[0]);
					for(int i=0; i<lgridsize[0]; i++){
						lig_charge[i] = (float **) malloc(sizeof(float*)*lgridsize[1]);
						lig_mass[i] = (float **) malloc(sizeof(float*)*lgridsize[1]);
						for(int j=0; j<lgridsize[1]; j++){
							lig_charge[i][j] = (float *) malloc(sizeof(float)*lgridsize[2]);
							lig_mass[i][j] = (float *) malloc(sizeof(float)*lgridsize[2]);
							for(int k=0; k<lgridsize[2]; k++){
								lig_charge[i][j][k] = 0.0;
								lig_mass[i][j][k] = 0.0;
							}
						}
					} 
				}
			} else {
				int x,y,z;
				float charge, mass;
				ss >> x;
				ss >> y;
				ss >> z;
				ss >> charge;
				ss >> mass;
				lig_charge[x][y][z] = charge;
				lig_mass[x][y][z] = mass;
			}
    	}
    }
    fligand.close();
    
    // allocate fft arrays
    float max_rextent=0, max_lextent=0;
    for(int i = 0; i < 3; i++){
    	float d = (rmax[i] - rmin[i] + 1);//*rgridspacing[i];
    	if(max_rextent<d)
    		max_rextent = d; 
    	d = (lmax[i] - lmin[i] + 1);//*lgridspacing[i];
    	max_lextent += d*d;
    }
    max_rextent = max_rextent;
    max_lextent = ceil(sqrt(max_lextent));
    
    //int spread = (max_lextent + 200.0)/grid_spacing;
    int spread = (2*max_lextent + 40.0)/grid_spacing;
    int maxsize = ((float)max_rextent)/grid_spacing + spread;
    *out << "rextent " << max_rextent << " " << " lextent " << max_lextent << " spread " << spread << endl;
    if(maxsize%2 == 1)	maxsize++;
	gridsize[0] = gridsize[1] = gridsize[2] = maxsize; 
		
	size = gridsize[0] * gridsize[1] * gridsize[2];
	
	*out << "size " << size << " " << sizeof(MKL_Complex8) << " " << rec_shape << endl;
	if(procid==0)
		cout << "gridsize " << gridsize[0] << " " << gridsize[1] << " " << gridsize[2] << " " << size << endl;
	
	rec_shape = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
	lig_shape = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
	rec_elec = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
	lig_elec = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
	
	rec_center = Vector((rmax[0] + rmin[0])/((int)2) , (rmax[1] + rmin[1])/((int)2), (rmax[2] + rmin[2])/((int)2))*grid_spacing;
	rec_grid_origin = Vector(-1,-1,-1) * (((float)maxsize)*grid_spacing/2);
	lig_center = Vector((lmax[0] + lmin[0])/((int)2) , (lmax[1] + lmin[1])/((int)2), (lmax[2] + lmin[2])/((int)2))*grid_spacing;
	lig_grid_origin = Vector(-1,-1,-1) * (((float)maxsize)*grid_spacing/2);
	
	Transformation *identity = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
	build_fft_exclusion_grid(grid_spacing, rec_shape, gridsize, rgridsize, identity, true);
	build_elec_grid(grid_spacing, rec_elec, gridsize, rgridsize, identity, true);
	
	mkl_status = DftiCreateDescriptor( &fft_desc_handle, DFTI_SINGLE, DFTI_COMPLEX, 3, gridsize );
	*out << DftiErrorMessage(mkl_status) << endl;
	mkl_status = DftiSetValue( fft_desc_handle, DFTI_PLACEMENT, DFTI_INPLACE );
	*out << DftiErrorMessage(mkl_status) << endl;
	
	strides[0]=0;
	strides[1]=gridsize[1]*gridsize[2];
	strides[2]=gridsize[2];
	strides[3]=1;
	
	mkl_status = DftiCommitDescriptor(fft_desc_handle);
	*out << DftiErrorMessage(mkl_status) << endl;
	
	mkl_status = DftiComputeBackward(fft_desc_handle, rec_shape);
	*out << "receptor exclusion ift " << DftiErrorMessage(mkl_status) << endl;
	
	mkl_status = DftiComputeBackward(fft_desc_handle, rec_elec);
	*out << "receptor elec ift " << DftiErrorMessage(mkl_status) << endl;
	
	rotation_scores = (transformationscore *) malloc(sizeof(transformationscore) * size);
	work0 = (transformationscore *) malloc(sizeof(transformationscore) * (size+max_transformations));
	work1 = (transformationscore *) malloc(sizeof(transformationscore) * (size+max_transformations));
}

void read_rotations(){
	string filename = string(getenv(string("HOME").c_str())) + "/" + string(DOCK_DIR) + string(SPACED_ROTATIONS);
	char buf[8192];
	num_rotations = 0;
	fstream frotations(filename.c_str());
    while(frotations.good()){
    	frotations.getline(buf,8192);
    	if(frotations.gcount() > 0)
    		num_rotations++;
    }
	rot_angles = (float**) malloc(sizeof(float*)*num_rotations);
	for(int i = 0 ; i < num_rotations; i++)	rot_angles[i] = (float*) malloc(sizeof(float)*3);
    
    num_rotations = 0;
    frotations.clear();
    frotations.seekg(ios_base::beg);
    while(frotations.good()){
    	frotations.getline(buf,8192);
    	if(frotations.gcount() > 0){
    		stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
			ss >> rot_angles[num_rotations][0];
			ss >> rot_angles[num_rotations][1];
			ss >> rot_angles[num_rotations][2];
			num_rotations++;
    	}
    }
    frotations.close();
}

Vector get_translation(transformationscore *trscore, Transformation *tr){						
	float x = (int) (trscore->index/(gridsize[1]*gridsize[2]));
	float y = ((trscore->index/gridsize[2]) % gridsize[1]);
	float z = (trscore->index % gridsize[2]);

	if(x >= gridsize[0]/2)	x = x - gridsize[0];
	if(y >= gridsize[1]/2)	y = y - gridsize[1];
	if(z >= gridsize[2]/2)	z = z - gridsize[2];	
	
	Vector v = (lig_center) +tr->inverse_rotate((lig_grid_origin) - (Vector(-x,-y,-z)*grid_spacing + (rec_grid_origin) + (rec_center)));

	return v;
}

Transformation *convert_transformation(unsigned int translation, unsigned int rotindex){
	Transformation *tr = new Transformation(rot_angles[rotindex][0],rot_angles[rotindex][1], rot_angles[rotindex][2],0);
	
	float x = translation/(gridsize[1]*gridsize[2]);
	float y = ((translation/gridsize[2]) % gridsize[1]);
	float z = (translation % gridsize[2]);
		
	if(x >= gridsize[0]/2)	x = x - gridsize[0];
	if(y >= gridsize[1]/2)	y = y - gridsize[1];
	if(z >= gridsize[2]/2)	z = z - gridsize[2];	
	
	*(tr->translation) = lig_center +tr->inverse_transform(lig_grid_origin) - (Vector(-x,-y,-z)*grid_spacing + (rec_grid_origin) + (rec_center));
	Reference_Frame* rf_invtr = Reference_Frame::invert(tr);
	
	Transformation *invtr = new Transformation(new Vector(rf_invtr->translation), new Vector(rf_invtr->ex), new Vector(rf_invtr->ey), 1.0, 0, 0);	

	delete tr;
	delete rf_invtr;
	return invtr;
}

void write_nodetransforms_tofile(Transformation *reftr){
	// delete arrays to create space
	if(reftr==NULL){
		delete(rec_shape);	delete(lig_shape);
		delete(rec_elec);	delete(lig_elec);
		delete(rotation_scores);
	} 
	
	*out << node_result << endl; out->flush();
	fstream transout;
	char tfilename[512];
	sprintf(tfilename, "%s/%s/%d/trans%d",node_tmp_dir,refpdbcode.c_str(),procid,0);
	transout.open(tfilename,ios::binary|ios::out);
	
	Transformation *tr, *invtr;
	Reference_Frame *rf_invtr;
	vector<Transformation *> tr_trace, invtr_trace;
	vector<Reference_Frame *> rf_invtr_trace;
	for(int i = 0; i < num_node_transforms; i++){
		transformationscore trscore = node_result[i];
		if(i<10)	*out << trscore.evdw << " " << trscore.evdw_real << " " << trscore.evdw_imag << endl;
		
		/* meaning of a transformation as generated
		 * 	translate the ligand such that its center is the origin
		 * 	rotate using euler angles
		 * 	translate such that coordinates are positive
		 * 	translate as specified by the result of fft
		 * 
		 * the receptor was translated such that its center was the origin and again translated such that the coordinates were positive
		 */
		
		if(reftr == NULL)
			tr = new Transformation(rot_angles[trscore.rotindex][0],rot_angles[trscore.rotindex][1], rot_angles[trscore.rotindex][2],i);
		else
			tr = new Transformation(new Vector(0,0,0), new Vector(*(reftr->ex)), new Vector(*(reftr->ey)), 1.0, 0, 0);
		
		*(tr->translation) = get_translation(&trscore,tr);
				
		//*out << "before invert" << endl; out->flush();
		rf_invtr = Reference_Frame::invert(tr);
		invtr = new Transformation(rf_invtr->translation, rf_invtr->ex, rf_invtr->ey, 1.0, 0, i);
		invtr->eVdw = trscore.evdw;
		invtr->sEvolution_interface = trscore.evdw_real;
		invtr->votes = trscore.rotindex;
		invtr->eResiduepair = trscore.index;
		
		invtr->eSolvation = trscore.score;
		
		invtr->frame_number = trscore.index;
		invtr->num_contacts = 0;
		
		invtr->write_binary(&transout,TN_BASIC);
		if(i<10) invtr->print_details(out,TN_BASIC); out->flush();
		
		delete tr;
		delete rf_invtr;
		//delete invtr;
		//invtr_trace.push_back(invtr);
	}
	transout.close();
	
	// delete - deletion in the loop is causing crashes
	for(vector<Transformation*>::iterator itr = tr_trace.begin(); itr != tr_trace.end(); itr++)
		delete ((Transformation*) *itr);
	for(vector<Transformation*>::iterator itr = invtr_trace.begin(); itr != invtr_trace.end(); itr++)
		delete ((Transformation*) *itr);
	for(vector<Reference_Frame*>::iterator itr = rf_invtr_trace.begin(); itr != rf_invtr_trace.end(); itr++)
		delete ((Reference_Frame*) *itr);
	
	// delete restrans 
	char command[512];
	sprintf(command , "rm %s/%s/%d/restrans*",node_tmp_dir,refpdbcode.c_str(),procid);
	int ret = system(command);
	*out << command << " " << ret << endl;
}

void match_rotation(unsigned int rotation_index, Transformation *tr){
	*out << "rotationtr " << lig_shape << " "; tr->print_details(out,TN_BASIC);
	
	// build grid on the ligand
	build_fft_exclusion_grid(grid_spacing, lig_shape, gridsize, lgridsize, tr, false);
	build_elec_grid(grid_spacing, lig_elec, gridsize, lgridsize, tr, false);
	
	// fft
	mkl_status = DftiComputeForward(fft_desc_handle, lig_shape);
	if(mkl_status != DFTI_NO_ERROR){
		*out << rotation_index << " fft " << DftiErrorMessage(mkl_status) << endl; out->flush();
	}
	mkl_status = DftiComputeForward(fft_desc_handle, lig_elec);
	if(mkl_status != DFTI_NO_ERROR){
		*out << rotation_index << " fft " << DftiErrorMessage(mkl_status) << endl; out->flush();
	}
	
	float real_fourier, imag_fourier;
	
	// product
	//*out << "computing product " << endl; out->flush();
	for(int i = 0; i < size; i++){
		// combined attractive and repulsive parts of vdw interaction
		{
			real_fourier = rec_shape[i].real*lig_shape[i].real - rec_shape[i].imag*lig_shape[i].imag;
			imag_fourier = rec_shape[i].real*lig_shape[i].imag + rec_shape[i].imag*lig_shape[i].real;
			lig_shape[i].real = real_fourier;
			lig_shape[i].imag = imag_fourier;
		}
			
		{
			real_fourier = rec_elec[i].real*lig_elec[i].real - rec_elec[i].imag*lig_elec[i].imag;
			imag_fourier = rec_elec[i].real*lig_elec[i].imag + rec_elec[i].imag*lig_elec[i].real;
			lig_elec[i].real = real_fourier;
			lig_elec[i].imag = imag_fourier;
		}
	}
				
	// ift
	mkl_status = DftiComputeBackward(fft_desc_handle, lig_shape);
	if(mkl_status != DFTI_NO_ERROR)
		*out << rotation_index << " ift " << DftiErrorMessage(mkl_status) << endl;
	mkl_status = DftiComputeBackward(fft_desc_handle, lig_elec);
	if(mkl_status != DFTI_NO_ERROR)
		*out << rotation_index << " ift " << DftiErrorMessage(mkl_status) << endl;

	// collect scores
	float grid_spacing_cubed = grid_spacing*grid_spacing*grid_spacing;
	float size_inv = 1.0/size;
	for(unsigned int index = 0; index < size; index++){
		rotation_scores[index].index = index;

		rotation_scores[index].evdw_real = lig_shape[index].real*size_inv;	
		rotation_scores[index].evdw = lig_shape[index].real*size_inv + lig_shape[index].imag*size_inv;
		rotation_scores[index].evdw_imag = lig_shape[index].imag*size_inv;
		
		rotation_scores[index].rotindex = rotation_index;
		
		rotation_scores[index].score = 0 - lig_elec[index].real * size_inv;
		//*out << "score " << rotation_index << " " << index << " " << rotation_scores[index].evdw_real << " " << rotation_scores[index].score << endl; 
	}
	
	float min_vdw_repulsion = 0.04;
	
	/* remove structures that have volume overlaps */
	unsigned int num_removed=0, num_filtered=0;
	vector<transformationscore> filtered_transformations;
	
	for(unsigned int i = 0; i < size; i++){
		bool remove=false;
		if(rotation_scores[i].evdw_real > min_vdw_repulsion || ABS(rotation_scores[i].score) < 1.0e-9)	{
			rotation_scores[i].score = rotation_scores[i].evdw = rotation_scores[i].score = -1000000.0;
			remove=true;
		}
		
		*(tr->translation) = get_translation(&(rotation_scores[i]),tr);
		Vector v = tr->transform(Vector(0,0,0));
		float r = tr->translation->norm();
		int r_division = r/R_SPACING;
		if(r_division >= num_r_divisions){
			*out << "r out of box " << r << " " << r_division << " " << rotation_scores[i].score << endl;
		} else
			r_count[r_division] += 1.0;
		
		if(remove)	num_removed++;
		else {
			filtered_transformations.push_back(rotation_scores[i]);
			num_filtered++;
			
			float point_weight = expf(rotation_scores[i].score * scale_factor);
			if(r_division < num_r_divisions)
				r_probability[r_division] += point_weight;
			
			if(num_filtered%1000 == 0)	*out << "|E|" << rotation_scores[i].score << endl;
		}
	}
	
	sort(filtered_transformations.begin(),filtered_transformations.end(),transscore_better);
	
	transformationscore *current_inputarray,*current_outputarray;
	if(merge_output_index %2 == 0){
		current_outputarray = work0;
		current_inputarray = work1;
	} else {
		current_outputarray = work1;
		current_inputarray = work0;
	}
	merge_output_index++;
	//*out << work0 << " " << work1 << " " << current_inputarray << " " << current_outputarray << endl;
	
	merge( &(current_inputarray)[0], &(current_inputarray)[0] + min(max_transformations,num_node_transforms), 
		filtered_transformations.begin(),filtered_transformations.end(), &(current_outputarray)[0], transscore_better);
	
	num_node_transforms = min(num_node_transforms+num_filtered,max_transformations);
	node_result = current_outputarray;
	
	generation_stats[0] += size;
	generation_stats[1] += num_filtered;
	*out << "done rotation " << rotation_index << " " << num_removed << " " << num_filtered << " " << num_node_transforms << endl;
}

void match_rotation(unsigned int rotation_index){
	*out << "match rotation " << rotation_index << endl; out->flush();
	Transformation *tr = new Transformation(rot_angles[rotation_index][0],rot_angles[rotation_index][1],rot_angles[rotation_index][2],rotation_index);

	match_rotation(rotation_index, tr);
}

void generate_transformations(int rotstart, int rotend){
    node_transformations.clear();
	
	for(int i = 0; i < NUM_GENERATION_STATS; i++)	generation_stats[i] = 0;
	
	rotstart = max(rotstart,0);
	rotend = min(rotend,num_rotations);
	
	for(int i = 0; i < num_r_divisions; i++)
		r_probability[i] = r_count[i] = 0;
	
	if(procid == 0){
		if(numprocs == 1){
			for(int i=rotstart; i< rotend; i++){
				match_rotation( i );
			}
			
			write_nodetransforms_tofile(NULL);
			pieces[0] = num_node_transforms;
		} else {
			cout << "rotstart " << rotstart << " rotend " << rotend << endl;
			int current = rotstart;
			bool node_done[numprocs];
			for(int i = 1; i < numprocs; i++)	node_done[i] = false;
			bool done = false;
						
			while(!done){
				// receive a token and send work
				MPI_Recv(buff, BUFSIZE, MPI_CHAR, MPI_ANY_SOURCE, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
				int node = atoi(buff);
				
				sprintf(buff, "%d", current);
				MPI_Ssend(buff, 256, MPI_CHAR, node, GENERATE_TAG, MPI_COMM_WORLD);
				
				// ended the computation at the node
				if(current >= rotend)	node_done[node] = true;
				
				*out << "node " << node << " working on " << current << " " << node_done[node] << endl; out->flush();
				
				current = current + 1;
				if(current %500 == 0){
					time(&current_time);
					cout << "at rotation " << current << " time " <<  difftime(current_time,start_time) << endl; cout.flush();
				}
				
				done = true;
				for(int i = 1; i < numprocs; i++)	done &= node_done[i];
			}
			
			cout << "finished assigning ids for matching" << endl;
			
			// collect ensemble averages
			for(int i=1;i<numprocs;i++){
				double recv_r_probability[num_r_divisions], recv_r_count[num_r_divisions];
				MPI_Recv(recv_r_probability, num_r_divisions, MPI_DOUBLE, i, TAG, MPI_COMM_WORLD, &mpistat);
				MPI_Recv(recv_r_count, num_r_divisions, MPI_DOUBLE, i, TAG, MPI_COMM_WORLD, &mpistat);
				for(int i = 0; i < num_r_divisions; i++){
					r_probability[i] += recv_r_probability[i];
					r_count[i] += recv_r_count[i];
				}
			}
			cout << "finished receiving ensemble averages" << endl;
		}
	} else {
		bool done = false;
		while(!done){
			sprintf(buff, "%d",procid);
			MPI_Ssend(buff, 256, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD);
			MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
			int start = atoi(buff);
			if(start >= rotend){
				done = true;
				break;
			} else {
				match_rotation( start );
			}
		}
		
		// send ensemble averages
		MPI_Ssend(r_probability,num_r_divisions , MPI_DOUBLE, 0, TAG, MPI_COMM_WORLD);
		MPI_Ssend(r_count,num_r_divisions , MPI_DOUBLE, 0, TAG, MPI_COMM_WORLD);
		*out << "done sending ensemble calculations" << endl;
		
		write_nodetransforms_tofile(NULL);
		pieces[0] = num_node_transforms;
	}
	
	time(&current_time);
	*out << "node " << procid << " generated transformations # " << num_node_transforms << "\t time:"
		<< difftime(current_time,start_time) << "s" << endl; out->flush();
}

int main(int argc, char *argv[]){
	time(&start_time);
	int ret = MPI_Init(&argc,&argv);
	if(ret == MPI_SUCCESS){
		MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
		MPI_Comm_rank(MPI_COMM_WORLD,&procid);
				
		if(procid == 0){
			cout << "Job running on " << numprocs << " processors" << endl;
			cout << "#args " << argc << endl;
			cout.flush();
		}
		
		tmp_dir = (char*) string("/state/partition1").c_str();
		//tmp_dir = (char*) string(".").c_str();
		node_tmp_dir = (char*) (new string(string(tmp_dir)+"/"+string(getenv(string("JOB_ID").c_str()))))->c_str();
		
		elect_leader_on_node();
		
		//initialize
		refpdbcode = "rna";
		sprintf(command, "%s/cluster_scripts/setup.sh %s %d %s %d",getenv(string("HOME").c_str()),getenv(string("JOB_ID").c_str()),procid, refpdbcode.c_str(), masterprocessonnode);
		ret = system(command);
		
		sprintf(scratch_dir, "%s/%s/%d",node_tmp_dir,refpdbcode.c_str(),procid);
		sprintf(filename, "%s/%s/%sout%d",node_tmp_dir,refpdbcode.c_str(),refpdbcode.c_str(),procid);
		//cout << filename << endl; cout.flush();
		fstream outstream;
		outstream.open(filename,ios::out);
		if(!outstream.good()){
			cout << "ERROR: could not open file " << filename << " " << errno << "\n"; cout.flush();
			exit(-1);
		}
		out = &outstream;
		
		tag = (char*) (new string("result"))->c_str();
		stringstream ss (stringstream::in | stringstream::out);
		string ts;
		ss << string(tag) << ".trans";
		ss >> ts;
		transformations_file = (char*) (new string(ts.c_str()))->c_str();
		sprintf(local_transformations_file,"%s/%s",scratch_dir,transformations_file);
		
		*out << procid << " " << *host << " am_master " << masterprocessonnode << endl;
		*out << "setup " << command << " " << ret << endl;
		
		dist1_filename = string(argv[1]);
		dist2_filename = string(argv[2]);
		
		sigma = grid_spacing;
		debye_length = 5.0;
		rcutoff = 60.0;
		
		// read charge distribution
		process_receptor();
		
		// match rotations
		read_rotations();
		int rotstart = atoi(argv[3]);
		int rotend = atoi(argv[4]);
		generate_transformations(rotstart,rotend);
		
		state = GENERATE_MATCHES;
		collect_transformations(true,max_transformations);
		
		if(procid == 0){
			cout << "Ensemble averages:" << endl;
			for(int i = 0; i < num_r_divisions; i++)
				cout << i << " " << r_probability[i] << " " << r_count[i] << endl;		 
		}
		
		MPI_Finalize();
		//outstream.close();
		
		if(procid == 0){
			time(&current_time);
			cout << "done" << " " << success << "\t time:" << difftime(current_time,start_time) << "s" << endl;
		}
		
		return 0;
	} else {
		cout << "init failed" << endl;
		return 1;
	}
}
