/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "dock_util.hpp"
#include "fftdock_util.hpp"

string dist1_filename, dist2_filename;

MKL_Complex8 *rec_elec, *lig_elec;
DFTI_DESCRIPTOR_HANDLE fft_desc_handle;
MKL_LONG mkl_status, gridsize[3], strides[4];
unsigned int size;
float sqrt_size;

bool debug=false;

#define SPACED_ROTATIONS "68760.euler"
float grid_spacing=1.50;//2.0;

#define R_SPACING 0.1
#define R_MAX 600.0

const int num_r_divisions = R_MAX / R_SPACING + 2;
double r_probability[num_r_divisions], r_count[num_r_divisions];

unsigned int max_transformations=1024*1024;

float **rot_angles;
int num_rotations;

Vector rec_center, lig_center, rec_grid_origin, lig_grid_origin;
float ***rec_charge, ***rec_mass;
float ***lig_charge, ***lig_mass;

float sigma, debye_length;
float scale_factor = 556.0 /80.0;

unsigned int rgridsize[3], lgridsize[3];

transformationscore *work0, *work1;
unsigned int merge_output_index=0;

bool transscore_bettersum(transformationscore t1,transformationscore t2){
	return(t1.score > t2.score);
}

bool (*transscore_better)(transformationscore t1,transformationscore t2) = &transscore_bettersum;

float rcutoff;


void build_elec_grid(float grid_spacing, MKL_Complex8 *fftgrid, MKL_LONG *fftgridsize, unsigned int gridsize[3], Reference_Frame *tr, bool isreceptor){
	// rotations keep the center invariant
	Vector center, grid_origin;
	float ***charge;
	if(isreceptor){
		center = Vector(rec_center);
		charge = rec_charge;
		grid_origin = Vector(rec_grid_origin);
	} else {
		center = Vector(lig_center);
		charge = lig_charge;
		grid_origin = Vector(lig_grid_origin);
	}
	
	for(int i = 0; i < size; i++)
		((fftgrid)[i]).real = ((fftgrid)[i]).imag = 0.0;
	
	unsigned long nummarkings = 0;	
	for(int i = 0; i < gridsize[0]; i++)
		for(int j = 0; j < gridsize[1]; j++)
			for(int k = 0; k < gridsize[2]; k++)
				if(charge[i][j][k] > 0){
					if(isreceptor){
						*out << "(" << i << "," << j << "," << k << ") " << nummarkings << endl;
						out->flush();
					}
					
					Vector v = Vector(i,j,k)*grid_spacing;
					Vector tv = tr->transform(v - center) - grid_origin;
					int vx = (int) (tv.x/grid_spacing);
					int vy = (int) (tv.y/grid_spacing);
					int vz = (int) (tv.z/grid_spacing);
		
					int minx,maxx,miny,maxy,minz,maxz;
					minx = maxx = vx;
					miny = maxy = vy;
					minz = maxz = vz;
					int level = 0;
					float radius_squared = rcutoff*rcutoff;
					if(!isreceptor)	radius_squared = 0;
					bool intersects_surface = true;
					while(intersects_surface){
						if(debug && isreceptor){
							*out << "(" << i << "," << j << "," << k << ") " << nummarkings << " level " << level << endl;
							out->flush();
						}
						intersects_surface = false;
						bool intersectsxmin,intersectsxmax,intersectsymin,intersectsymax,intersectszmin,intersectszmax;
						for(int x = minx; x <= maxx; x++){
							for(int y = miny; y <= maxy; y++){
								for(int z = minz; z <= maxz; z++){
									Vector corner_000 = Vector( (((float) x) )*grid_spacing, (((float) y) )*grid_spacing, (((float) z) )*grid_spacing);
									Vector grid_center = Vector( (((float) x) + 0.5)*grid_spacing, (((float) y) + 0.5)*grid_spacing, (((float) z) + 0.5)*grid_spacing);
									bool intersects_cell = false;
									if( x == minx || x == maxx || y == miny || y == maxy || z == minz || z == maxz ){
										float d,d2,d_2;
										intersects_cell = ((d2 = Vector::distance_squared(tv,corner_000)) <= radius_squared) || (level == 0);
										intersects_surface = intersects_surface || intersects_cell;
			
										if(intersects_cell){
											unsigned int index = (x*fftgridsize[1] + y)*fftgridsize[2] + z;
											float factor = 0;								
			
											// trilinear interpolate
											if(!isreceptor){
												factor = charge[i][j][k];
												Vector v = tv * (1.0/grid_spacing);
												float wx[2],wy[2],wz[2];
												wx[0] = x+1.0 - v.x;
												wx[1] = v.x - x;
												wy[0] = y+1.0 - v.y;
												wy[1] = v.y - y;
												wz[0] = z+1.0 - v.z;
												wz[1] = v.z - z;
												
												for(int cci =0; cci <=1; cci++)
													for(int ccj =0; ccj <=1; ccj++)
														for(int cck =0; cck <=1; cck++){
															int nx = (x+cci)% fftgridsize[0];
															int ny = (y+ccj)% fftgridsize[1];
															int nz = (z+cck)% fftgridsize[2];
															unsigned int nindex = (nx*fftgridsize[1] + ny)*fftgridsize[2] + nz;
															float nfactor = factor *wx[cci]*wy[ccj]*wz[cck];
															((fftgrid)[nindex]).real += nfactor;
														}
											} else if(d2>0.01) {
												float d = sqrt(d2);
			 									factor = charge[i][j][k] * expf(0-(d-sigma)/debye_length)/d;
			 									((fftgrid)[index]).real += factor;
											}
			
											nummarkings++;
			
											if( x == minx)
												intersectsxmin = true;
											if( x == maxx)
												intersectsxmax = true;
											if( y == miny)
												intersectsymin = true;
											if( y == maxy)
												intersectsymax = true;
											if( z == minz)
												intersectszmin = true;
											if( z == maxz)
												intersectszmax = true;
										}
									}
								}
							}
						}
						if(intersectsxmin && minx > 0)
							minx--;
						if(intersectsxmax && maxx < fftgridsize[0] - 1)
							maxx++;
						if(intersectsymin && miny > 0)
							miny--;
						if(intersectsymax && maxy < fftgridsize[1] - 1)
							maxy++;
						if(intersectszmin && minz > 0)
							minz--;
						if(intersectszmax && maxz < fftgridsize[2] - 1)
							maxz++;
		
						if(debug)
							*out << minx << "," << maxx << " " << miny << "," << maxy << " " << minz << "," << maxz << " " << fftgridsize[0] << " " << fftgridsize[1] << " " << fftgridsize[2] << endl;	
						level++;
					}							
				}

	*out << "build fft elec grid #markings " << nummarkings << endl; 
}

void process_receptor(){
	rec_shape = NULL;
	gridsize[0] = gridsize[1] = gridsize[2] = 0;
	Transformation *identity = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);

	receptor->build_fft_opls_vdw_grid(grid_spacing,  ligand->c->diameter,&rec_shape,gridsize, identity, true);

	size = gridsize[0] * gridsize[1] * gridsize[2];
	*out << "gridsize " << gridsize[0] << "," << gridsize[1] << "," << gridsize[2] << " " << rec_shape << endl;
	if(procid == 0)	cout << "grid spacing used " << grid_spacing << " size " << size << endl;
		
	mkl_status = DftiCreateDescriptor( &fft_desc_handle, DFTI_SINGLE, DFTI_COMPLEX, 3, gridsize );
	*out << DftiErrorMessage(mkl_status) << endl;
	mkl_status = DftiSetValue( fft_desc_handle, DFTI_PLACEMENT, DFTI_INPLACE );
	*out << DftiErrorMessage(mkl_status) << endl;

	strides[0]=0;
	strides[1]=gridsize[1]*gridsize[2];
	strides[2]=gridsize[2];
	strides[3]=1;
	/*mkl_status = DftiSetValue( fft_desc_handle, DFTI_INPUT_STRIDES, strides);
	*out << DftiErrorMessage(mkl_status) << endl;*/
	
	mkl_status = DftiCommitDescriptor(fft_desc_handle);
	*out << DftiErrorMessage(mkl_status) << endl;
	
	mkl_status = DftiComputeBackward(fft_desc_handle, rec_shape);
	*out << "receptor ift " << DftiErrorMessage(mkl_status) << endl;

	rec_elec = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
	build_elec_grid(grid_spacing, rec_elec, gridsize, rgridsize, identity, true);
	
	mkl_status = DftiComputeBackward(fft_desc_handle, rec_shape);
	*out << "receptor elec ift " << DftiErrorMessage(mkl_status) << endl;
	
	sqrt_size = sqrt(size);

	lig_shape = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
	lig_elec = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);

	rotation_scores = (transformationscore *) malloc(sizeof(transformationscore) * size);
	work0 = (transformationscore *) malloc(sizeof(transformationscore) * (size+max_transformations));
	work1 = (transformationscore *) malloc(sizeof(transformationscore) * (size+max_transformations));
}

void match_rotation(unsigned int rotation_index, Transformation *tr){
	*out << "rotationtr " << lig_shape << " "; tr->print_details(out,TN_BASIC);
	
	// build grid on the ligand
	build_fft_exclusion_grid(grid_spacing, lig_shape, gridsize, lgridsize, tr, false);
	build_elec_grid(grid_spacing, lig_elec, gridsize, lgridsize, tr, false);
	
	// fft
	mkl_status = DftiComputeForward(fft_desc_handle, lig_shape);
	if(mkl_status != DFTI_NO_ERROR){
		*out << rotation_index << " fft " << DftiErrorMessage(mkl_status) << endl; out->flush();
	}
	mkl_status = DftiComputeForward(fft_desc_handle, lig_elec);
	if(mkl_status != DFTI_NO_ERROR){
		*out << rotation_index << " fft " << DftiErrorMessage(mkl_status) << endl; out->flush();
	}
	
	float real_fourier, imag_fourier;
	
	// product
	//*out << "computing product " << endl; out->flush();
	for(int i = 0; i < size; i++){
		// combined attractive and repulsive parts of vdw interaction
		{
			real_fourier = rec_shape[i].real*lig_shape[i].real - rec_shape[i].imag*lig_shape[i].imag;
			imag_fourier = rec_shape[i].real*lig_shape[i].imag + rec_shape[i].imag*lig_shape[i].real;
			lig_shape[i].real = real_fourier;
			lig_shape[i].imag = imag_fourier;
		}
			
		{
			real_fourier = rec_elec[i].real*lig_elec[i].real - rec_elec[i].imag*lig_elec[i].imag;
			imag_fourier = rec_elec[i].real*lig_elec[i].imag + rec_elec[i].imag*lig_elec[i].real;
			lig_elec[i].real = real_fourier;
			lig_elec[i].imag = imag_fourier;
		}
	}
				
	// ift
	mkl_status = DftiComputeBackward(fft_desc_handle, lig_shape);
	if(mkl_status != DFTI_NO_ERROR)
		*out << rotation_index << " ift " << DftiErrorMessage(mkl_status) << endl;
	mkl_status = DftiComputeBackward(fft_desc_handle, lig_elec);
	if(mkl_status != DFTI_NO_ERROR)
		*out << rotation_index << " ift " << DftiErrorMessage(mkl_status) << endl;

	// collect scores
	float grid_spacing_cubed = grid_spacing*grid_spacing*grid_spacing;
	float size_inv = 1.0/size;
	for(unsigned int index = 0; index < size; index++){
		rotation_scores[index].index = index;

		rotation_scores[index].evdw_real = lig_shape[index].real*size_inv;	
		rotation_scores[index].evdw = lig_shape[index].real*size_inv + lig_shape[index].imag*size_inv;
		rotation_scores[index].evdw_imag = lig_shape[index].imag*size_inv;
		
		rotation_scores[index].rotindex = rotation_index;
		
		rotation_scores[index].score = 0 - lig_elec[index].real * size_inv;
		//*out << "score " << rotation_index << " " << index << " " << rotation_scores[index].evdw_real << " " << rotation_scores[index].score << endl; 
	}
	
	float min_vdw_repulsion = 0.04;
	
	/* remove structures that have volume overlaps */
	unsigned int num_removed=0, num_filtered=0;
	vector<transformationscore> filtered_transformations;
	
	for(unsigned int i = 0; i < size; i++){
		bool remove=false;
		if(rotation_scores[i].evdw_real > min_vdw_repulsion || ABS(rotation_scores[i].score) < 1.0e-9)	{
			rotation_scores[i].score = rotation_scores[i].evdw = rotation_scores[i].score = -1000000.0;
			remove=true;
		}
		
		*(tr->translation) = get_translation(&(rotation_scores[i]),tr);
		Vector v = tr->transform(Vector(0,0,0));
		float r = tr->translation->norm();
		int r_division = r/R_SPACING;
		if(r_division >= num_r_divisions){
			*out << "r out of box " << r << " " << r_division << " " << rotation_scores[i].score << endl;
		} else
			r_count[r_division] += 1.0;
		
		if(remove)	num_removed++;
		else {
			filtered_transformations.push_back(rotation_scores[i]);
			num_filtered++;
			
			float point_weight = expf(rotation_scores[i].score * scale_factor);
			if(r_division < num_r_divisions)
				r_probability[r_division] += point_weight;
			
			if(num_filtered%1000 == 0)	*out << "|E|" << rotation_scores[i].score << endl;
		}
	}
	
	sort(filtered_transformations.begin(),filtered_transformations.end(),transscore_better);
	
	transformationscore *current_inputarray,*current_outputarray;
	if(merge_output_index %2 == 0){
		current_outputarray = work0;
		current_inputarray = work1;
	} else {
		current_outputarray = work1;
		current_inputarray = work0;
	}
	merge_output_index++;
	//*out << work0 << " " << work1 << " " << current_inputarray << " " << current_outputarray << endl;
	
	merge( &(current_inputarray)[0], &(current_inputarray)[0] + min(max_transformations,num_node_transforms), 
		filtered_transformations.begin(),filtered_transformations.end(), &(current_outputarray)[0], transscore_better);
	
	num_node_transforms = min(num_node_transforms+num_filtered,max_transformations);
	node_result = current_outputarray;
	
	generation_stats[0] += size;
	generation_stats[1] += num_filtered;
	*out << "done rotation " << rotation_index << " " << num_removed << " " << num_filtered << " " << num_node_transforms << endl;
}


void generate_transformations(int rotstart, int rotend){
    node_transformations.clear();
	
	for(int i = 0; i < NUM_GENERATION_STATS; i++)	generation_stats[i] = 0;
	
	rotstart = max(rotstart,0);
	rotend = min(rotend,num_rotations);
	
	for(int i = 0; i < num_r_divisions; i++)
		r_probability[i] = r_count[i] = 0;
	
	if(procid == 0){
		if(numprocs == 1){
			for(int i=rotstart; i< rotend; i++){
				match_rotation( i );
			}
			
			write_nodetransforms_tofile(NULL);
			pieces[0] = num_node_transforms;
		} else {
			cout << "rotstart " << rotstart << " rotend " << rotend << endl;
			int current = rotstart;
			bool node_done[numprocs];
			for(int i = 1; i < numprocs; i++)	node_done[i] = false;
			bool done = false;
						
			while(!done){
				// receive a token and send work
				MPI_Recv(buff, BUFSIZE, MPI_CHAR, MPI_ANY_SOURCE, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
				int node = atoi(buff);
				
				sprintf(buff, "%d", current);
				MPI_Ssend(buff, 256, MPI_CHAR, node, GENERATE_TAG, MPI_COMM_WORLD);
				
				// ended the computation at the node
				if(current >= rotend)	node_done[node] = true;
				
				*out << "node " << node << " working on " << current << " " << node_done[node] << endl; out->flush();
				
				current = current + 1;
				if(current %500 == 0){
					time(&current_time);
					cout << "at rotation " << current << " time " <<  difftime(current_time,start_time) << endl; cout.flush();
				}
				
				done = true;
				for(int i = 1; i < numprocs; i++)	done &= node_done[i];
			}
			
			cout << "finished assigning ids for matching" << endl;
			
			// collect ensemble averages
			for(int i=1;i<numprocs;i++){
				double recv_r_probability[num_r_divisions], recv_r_count[num_r_divisions];
				MPI_Recv(recv_r_probability, num_r_divisions, MPI_DOUBLE, i, TAG, MPI_COMM_WORLD, &mpistat);
				MPI_Recv(recv_r_count, num_r_divisions, MPI_DOUBLE, i, TAG, MPI_COMM_WORLD, &mpistat);
				for(int i = 0; i < num_r_divisions; i++){
					r_probability[i] += recv_r_probability[i];
					r_count[i] += recv_r_count[i];
				}
			}
			cout << "finished receiving ensemble averages" << endl;
		}
	} else {
		bool done = false;
		while(!done){
			sprintf(buff, "%d",procid);
			MPI_Ssend(buff, 256, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD);
			MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
			int start = atoi(buff);
			if(start >= rotend){
				done = true;
				break;
			} else {
				match_rotation( start );
			}
		}
		
		// send ensemble averages
		MPI_Ssend(r_probability,num_r_divisions , MPI_DOUBLE, 0, TAG, MPI_COMM_WORLD);
		MPI_Ssend(r_count,num_r_divisions , MPI_DOUBLE, 0, TAG, MPI_COMM_WORLD);
		*out << "done sending ensemble calculations" << endl;
		
		write_nodetransforms_tofile(NULL);
		pieces[0] = num_node_transforms;
	}
	
	time(&current_time);
	*out << "node " << procid << " generated transformations # " << num_node_transforms << "\t time:"
		<< difftime(current_time,start_time) << "s" << endl; out->flush();
}

int main(int argc, char *argv[]){
	time(&start_time);
	int ret = MPI_Init(&argc,&argv);
	if(ret == MPI_SUCCESS){
		MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
		MPI_Comm_rank(MPI_COMM_WORLD,&procid);
				
		if(procid == 0){
			cout << "Job running on " << numprocs << " processors" << endl;
			cout << "#args " << argc << endl;
			cout.flush();
		}
		
		read_molecule_config(NA);
		float atomp_vdw_weight;
		if(NUM_FFT_ATOM_TYPES == 18){
			coarsen_atomtypesto18();
			particle_potential = &atom18_potential;
			atomp_vdw_weight = vdw_weight;
		} else if(NUM_FFT_ATOM_TYPES == 20){
			coarsen_atomtypesto20();
			particle_potential = &atom20_potential;
			atomp_vdw_weight = vdw_weight;
		}
		read_dock_config();
		node_tmp_dir = (char*) (new string(string(tmp_dir)+"/"+string(getenv(string("JOB_ID").c_str()))))->c_str();
		
		elect_leader_on_node();
		
		//initialize
		refpdbcode = string(argv[9]);
		sprintf(command, "%s/cluster_scripts/setup.sh %s %d %s %d",getenv(string("HOME").c_str()),getenv(string("JOB_ID").c_str()),procid, refpdbcode.c_str(), masterprocessonnode);
		ret = system(command);
		
		sprintf(scratch_dir, "%s/%s/%d",node_tmp_dir,refpdbcode.c_str(),procid);
		sprintf(filename, "%s/%s/%sout%d",node_tmp_dir,refpdbcode.c_str(),refpdbcode.c_str(),procid);
		//cout << filename << endl; cout.flush();
		fstream outstream;
		outstream.open(filename,ios::out);
		if(!outstream.good()){
			cout << "ERROR: could not open file " << filename << " " << errno << "\n"; cout.flush();
			exit(-1);
		}
		out = &outstream;
		
		*out << procid << " " << *host << " am_master " << masterprocessonnode << endl;
		*out << "setup " << command << " " << ret << endl;

		filetype = atoi(argv[1]);
		docktype = atoi(argv[2]);
		start_state = atoi(argv[3]);
		end_state = atoi(argv[4]);
		*out << "start " << start_state << " end " << end_state << endl;out->flush();

		stringstream ss (stringstream::in | stringstream::out);
		string s;
		ss << argv[5] << "_" << argv[6] << "_vs_" << argv[7] << "_" << argv[8] << "fft";
		ss >> s;
		tag = (char*) (new string(s.c_str()))->c_str();

		ss.clear();
		string ts;
		ss << s << ".trans";
		ss >> ts;
		transformations_file = (char*) (new string(ts.c_str()))->c_str();
		sprintf(local_transformations_file,"%s/%s",scratch_dir,transformations_file);
		
		rpdbcode = string(argv[5]);
		rchains = string(argv[6]);
		lpdbcode = string(argv[7]);
		lchains = string(argv[8]);
		refrchains = string(argv[10]);
		reflchains = string(argv[11]);
		
		Complex* cr = new Complex(("../"+rpdbcode).c_str(),rchains.c_str(), filetype);
		Complex* crH =cr;
		out->flush();
		receptor = new Object(cr,crH);
		
		Complex* cl = new Complex(("../"+lpdbcode).c_str(),lchains.c_str(), filetype);
		Complex* clH = cl;
		ligand = new Object(cl, clH);
		
		if(start_state == FFT_GENERATE_MATCHES_VDW ){
			state=start_state;

			sigma = grid_spacing;
			debye_length = 5.0;
			rcutoff = 60.0;

			process_receptor();
			pieces.clear();

			//*out << "generating " << endl;
			read_rotations();

			generate_transformations(atoi(argv[12]),atoi(argv[13]));

			state = GENERATE_MATCHES;
			collect_transformations(true,max_transformations);
			if(procid == 0)	cout << "grid spacing used " << grid_spacing << " size " << size << " start state " << start_state << " vdw_weight " << vdw_weight << endl;
		}
		
		if(procid == 0){
			cout << "Ensemble averages:" << endl;
			for(int i = 0; i < num_r_divisions; i++)
				cout << i << " " << r_probability[i] << " " << r_count[i] << endl;		 
		}
		
		MPI_Finalize();
		//outstream.close();
		
		if(procid == 0){
			time(&current_time);
			cout << "done" << " " << success << "\t time:" << difftime(current_time,start_time) << "s" << endl;
		}
		
		return 0;
	} else {
		cout << "init failed" << endl;
		return 1;
	}
}
