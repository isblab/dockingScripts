/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"
#include "align_utilities.hpp"
const char* pdbcode;
string* chains;
int filetype;

string* seqres_sequence, *sequence;
hash_map<const char*, Sequence*, hash<const char*>, eqstr> matching_sequences, matching_sequences_in_pdb, sequences_with_struct_alignment;
hash_map<const char*, Molecule*, hash<const char*>, eqstr> homologues;
char **malignment;
const char ***malignment_indices;

ostream *out;
char scratch_dir[512], command[8192];
extern char buf[16384];
extern char *tmp_dir;
extern bool **aacontact_core, **aacontact_rim, *aarcontact, *aalcontact;

extern float aminoacid_probabilities[20];

vector<Sequence*> sequence_homologues, domain_homologues[2];
int scop_dom1start, scop_dom1end, scop_dom2start, scop_dom2end;
int dom1start, dom1end, dom2start,dom2end;

float **hom_res_probabilities;// **dom_hom_res_probabilities[2];

hash_map<long, long, hash<long>, eqlong> seqres_vs_atom, atom_vs_seqres;

void read_seqres_to_atom_alignment(Complex *c){
	string filename;
	string aseq1,aseq2,s;
	int qstart, sstart;
	bool alignment_done;
	stringstream *line;
	seqres_vs_atom.clear();
	atom_vs_seqres.clear();
	
	{
		int offset2 = 0;

		Molecule *m = (c->molecules.begin())->second;
		int offset1 = 0;
		
		stringstream ss (stringstream::in | stringstream::out);
		ss << string(pdbcode) << "_" << *chains << "_vs_" << string(pdbcode) << "_" << *chains << "_atom.ali";
		ss >> filename;
	//	cout << "filename " << filename << endl;
		fstream fin;
		fin.open(filename.c_str(), ios::in);

		if(fin.is_open()){
			aseq1 = ""; aseq2 = "";
			qstart = sstart = 1;
			
			{
				// reading input from the output of nwa
				fin.getline(buf,16384);
				fin.getline(buf,16384);
				do{
					line = new stringstream(buf,stringstream::in);
					*line >> s;
					aseq1 += s;
					fin.getline(buf,16384);
				}while((string(buf)).find(">>") == string::npos);
				while(fin.good()){
					fin.getline(buf,16384);
					if(fin.gcount() > 0){
						line = new stringstream(buf,stringstream::in);
						*line >> s;
						aseq2 += s;
						//*out << ">" << aseq2 << endl;
					}
				}
			}
			*out << aseq1 << endl << aseq2 << endl;
			seqres_sequence = new string(aseq1);
			
			int qindex = qstart-1, sindex = sstart-1;
			int n = aseq1.size();
			const char* aseq1c = aseq1.c_str();
			const char* aseq2c = aseq2.c_str();
			
			for(int i = 0 ; i < n ; i++){
				int qindexc = qindex + offset1;
				int sindexc = sindex + offset2;
				if(aseq1c[i] != '-' && aseq2c[i] != '-' && c->aminoacid[sindexc]->alpha_carbon != NULL){
					seqres_vs_atom[qindexc] = sindexc;
					atom_vs_seqres[sindexc] = qindexc;
					*out << qindex << "-" << qindexc << "-" << sindex << "-" << sindexc << " "; out->flush();
				}
				if(aseq1c[i] != '-')	qindex++;
				if(aseq2c[i] != '-')	sindex++;	
			}
			*out << endl;
			fin.close();
		} else {
			cout << "ERROR: Alignment does not exist " << filename << endl;
			exit(-1);
		}
	}
	out->flush();
	
	*out << seqres_vs_atom.size() << "|" <<  atom_vs_seqres.size() << endl;
	out->flush();
}

void read_seqres_profile(Molecule *m, char *filename, unsigned int seqsize){
	Aminoacid* aacid[m->aminoacid.size()+1];
	int maaindex=0;
	for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = m->aminoacid.begin(); aaitr != m->aminoacid.end(); aaitr++)
		aacid[maaindex++] = ((Aminoacid*) aaitr->second);
	
	sort(aacid, aacid+m->aminoacid.size(),less<Aminoacid*>());	
	
	stringstream ss (stringstream::in | stringstream::out);
	fstream fin(filename, fstream::in);
	if(!fin.is_open()){
		*out << "ERROR: profile not present" << endl;
		out->flush(); exit(1);
	}
	
	char buf[8192];
	do {
		fin.getline(buf,8192);
	} while ((string(buf)).find("position") == string::npos);
	fin.getline(buf,8192);
	
	int seqres_index = 0;
	while(!fin.eof() && ((string(buf)).find("Lambda") == string::npos)){
		fin.getline(buf,8192);
		if(fin.gcount() > 150){
			int aaindex = seqres_vs_atom[seqres_index];
			Aminoacid* aa = aacid[aaindex];
	
			float entropy;
			{
				stringstream line(buf+150,stringstream::in);
				line >> entropy;
				line >> aa->entropy_sequence_percentile;
			}
		
			{
				stringstream line(buf,stringstream::in);
				for(int j = 0; j < 22; j++){
					string tag;
					line >> tag;
				}
				for(int j = 0; j < 20; j++){
					line >> aa->profile_probabilities_n[j];
				}
			}
			
			aa->pInterface = entropy;
			seqres_index++;
		}
	}
	fin.close();
}

#define PAIRING_USE_BLAST_ENTROPY

void read_homologues_and_multiple_align(string pdbid, Complex *c){
	int aligntype = BLAST_ALIGN;
	char chain = c->chains.c_str()[0];
	pdbcode = pdbid.c_str();
			
	// read alignments
	//read_blast_hits(chain,DB_PDBAA,".");
	read_blast_hits(chain,DB_NR,".");
	
	domain_homologues[0].clear();
	domain_homologues[1].clear();
	short dom1_size = scop_dom1end - scop_dom1start;
	short dom2_size = scop_dom2end - scop_dom2start;
	hash_set<int, hash<int> , eqint> alignments_considered;
	for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr = matching_sequences.begin(); sitr != matching_sequences.end(); sitr++){
		Sequence *s = (Sequence *) sitr->second;
		Alignment *a = s->seq_alignment;
	  if(alignments_considered.count((int) a->index) == 0){
		alignments_considered.insert((int) a->index);
		
		float intersect_start = maximum(a->qstart,scop_dom1start);
		float intersect_end = minimum(a->qend,scop_dom1end);
		float domain1_coverage = (intersect_end-intersect_start)/dom1_size;
		intersect_start = maximum(a->qstart,scop_dom2start);
		intersect_end = minimum(a->qend,scop_dom2end);
		float domain2_coverage = (intersect_end-intersect_start)/dom2_size;
		// identities above 30% and alignment covers atleast 60% of each domain
		if(a->identities >= 30 && (((float) (a->qend - a->qstart))/(dom1_size + dom2_size) >= 0.60)){
			if(domain1_coverage >=0.60 && domain2_coverage >= 0.60){
				sequence_homologues.push_back(s);
				//cout << s << " alignment " << a << endl;
				//cout << a->identities << " " << domain1_coverage << " " << domain2_coverage << endl;
			}
		}// else
		//	cout << a->identities << " " << domain1_coverage << " " << domain2_coverage << endl;
		if(domain1_coverage >=0.60 && domain2_coverage <= 0.20){
			domain_homologues[0].push_back(s);
		}
		if(domain2_coverage >=0.60 && domain1_coverage <= 0.20){
			domain_homologues[1].push_back(s);
		}
	  }
	}
	
	cout << "#sequences domain1 (only) " << domain_homologues[0].size() << " domain2 (only) " << domain_homologues[1].size() 
		<< " both " << sequence_homologues.size() << " total " << matching_sequences.size() << endl; cout.flush(); 
	
	int seqsize = seqres_sequence->size();
	int n = sequence_homologues.size();
	string *sequence = seqres_sequence;
			
	malignment = (char**) malloc(n*sizeof(char*));
	malignment_indices = (const char ***) malloc(n*sizeof(const char **));
	for(int i = 0; i < n ; i++){
		malignment[i] = (char*) malloc((seqsize+1)*sizeof(char));
		malignment_indices[i] = (const char **) malloc(seqsize*sizeof(const char *));
		for(int j = 0; j < seqsize ; j++){
			malignment[i][j] = '-';
			malignment_indices[i][j] = NULL;
		}
		malignment[i][seqsize] = '\0';
	}

	string atom_sequence = (c->molecules.begin())->second->compute_aasequence();

#ifdef PAIRING_USE_BLAST_ENTROPY
	// output sequences of each domain
	sprintf(buf,"%s0_%s.seq",c->pdbcode,c->chains);
	fstream d0seqout(buf,fstream::out);
	string d0sequence = atom_sequence.substr(dom1start-1,dom1end - dom1start+1);
	d0seqout << d0sequence;
	d0seqout.close();
	
	sprintf(buf,"%s1_%s.seq",c->pdbcode,c->chains);
	string d1sequence = atom_sequence.substr(dom2start-1,dom2end - dom2start+1);
	fstream d1seqout(buf,fstream::out);
	d1seqout << d1sequence;
	d1seqout.close();
#endif

	for(int pj = 0 ; pj < 3; pj++){
		vector<Sequence*> *homologues = &sequence_homologues;
		if(pj < 2)	homologues = &(domain_homologues[pj]);
		//cout << "check " << pj << " " << homologues->size() << endl;
		
#ifdef PAIRING_USE_BLAST_ENTROPY
		sprintf(buf,"sequences%d",pj);
		fstream seqout(buf,fstream::out);
#endif

		float hom_residue_count[seqsize][20];
		for(int j = 0; j < seqsize ; j++)
			for(int k = 0; k <20; k++)	hom_residue_count[j][k] = 0;
			
		int mindex = 0;
		hash_set<int, hash<int> , eqint> alignments_considered;
		for(vector<Sequence*>::iterator sitr = homologues->begin();	sitr != homologues->end(); sitr++){
			Sequence *s = *sitr;
			//cout << mindex << " " << s << endl;
			Alignment *a =  s->seq_alignment;
		  if(alignments_considered.count((int) a->index) == 0){
		  	alignments_considered.insert((int) a->index);
			s->aasequence = sequence;
					
			string s1,s2;
			//assuming aseq1 is the query
			s1 = a->aseq1;
			s2 = a->aseq2;
			
			char gapless_s2c[s2.size() + 1];
			const char* s2c = s2.c_str();
			int s2_vs_gapless_s2[s2.size() + 1];
			for(int i = 0 ; i < s2.size()+1; i++)
				s2_vs_gapless_s2[i] = -1;
				
			int gapless_index = 0;
			for(int i = 0 ; i < s2.size(); i++){
				if(s2c[i] != '-'){
					s2_vs_gapless_s2[i] = gapless_index;
					gapless_s2c[gapless_index++] = s2c[i];
				}
			} 
			gapless_s2c[gapless_index] = s2c[s2.size()];
			string gapless_s2 = string(gapless_s2c);

#ifdef PAIRING_USE_BLAST_ENTROPY
			seqout << ">pdb|" << mindex << endl << gapless_s2 << endl;
#endif		
			if(pj == 2){
				s->malignment_index = mindex;
			
				// remove gaps from s1 and note the alignment
				char gapless_s1c[s1.size() + 1];
				int gapless_s1_vs_s2[s1.size() + 1];
				const char* s1c = s1.c_str();
				gapless_index = 0;
				for(int i = 0 ; i < s1.size(); i++){
					if(s1c[i] != '-'){
						gapless_s1_vs_s2[gapless_index] = i;
						gapless_s1c[gapless_index++] = s1c[i];
					}
				} 
				gapless_s1c[gapless_index] = s1c[s1.size()];
				string gapless_s1 = string(gapless_s1c);
				
				int s1start = sequence->find(gapless_s1);
				int s1end = s1start + gapless_s1.size();
				if(s1start == string::npos){
					*out << "ERROR: alignment not consistent with string" << endl;
					*out << *sequence << endl;
					*out << gapless_s1 << endl;
					*out << s1start << "\t" << s1end << "\t" << s1 << endl;
					out->flush(); 
				} else {
					*out << s1start << " " << s1end << endl;
				
					const char* s2c = s2.c_str();
					for(int i = s1start ; i < s1end; i++){
						int s2index = gapless_s1_vs_s2[i-s1start];
						char aatype = s2c[s2index];
						malignment[mindex][i] = aatype; 
						short aatypen = get_aatype(aatype);
						if(aatypen >=0 )	hom_residue_count[i][aatypen]++; 
					}
					
					cout << string(malignment[mindex]) << endl;
					mindex++;
				}
			}
		  }
		}
		//cout << "alignments considered " << alignments_considered.size() << " " << mindex << endl;
	
		if(pj == 2){
			for(int i = 0; i < seqsize ; i++){
				float total_non_gaps = 0;
				for(int k = 0; k <20; k++)	total_non_gaps += hom_residue_count[i][k];
				for(int k = 0; k <20; k++){
					float p = 0;
					if(total_non_gaps>0)	p = hom_residue_count[i][k]/total_non_gaps;
					hom_res_probabilities[i][k] = p;
				}	
			}
		}
	
#ifdef PAIRING_USE_BLAST_ENTROPY
		seqout.close();
		
		stringstream ss (stringstream::in | stringstream::out);
		ss << getenv(string("HOME").c_str()) << "/blast/getblastprofile.sh ";
		if(pj<2)	ss << c->pdbcode << pj << "_" << c->chains;  
		else ss << c->pdbcode << "_" << c->chains << "_atom";
		ss << " sequences" << pj << " > paired_blast_profile" << pj << ".out";
		{
			char buf[2048];
			ss.getline(buf,2048);
			cout << string(buf) << endl;
			int ret = system(buf);
			*out << buf << " " << ret << endl;
		}
		
		
		for(hash_map<char, Molecule*, hash<char>, eqint>::iterator mitr = c->molecules.begin(); mitr != c->molecules.end(); mitr++){
			Molecule *m = (Molecule *) (mitr->second);

			if(pj < 2){			
				sprintf(buf,"%s%d_%s_vs_sequences%d.profile",c->pdbcode, pj , c->chains, pj);
				if(pj == 0)
					read_part_profile(m, dom1start-1, dom1end,(char*) string(buf).c_str());
				else 
					read_part_profile(m, dom2start-1, dom2end,(char*) string(buf).c_str());
			} else {
				for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = m->aminoacid.begin(); aaitr != m->aminoacid.end(); aaitr++){
					Aminoacid *aa = (Aminoacid *) (aaitr->second);
					aa->eInterface = aa->entropy_sequence;
				}
				sprintf(buf,"%s_%s_atom_vs_sequences%d.profile",c->pdbcode, c->chains, pj);
				read_profile(m, buf);
				/*for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = m->aminoacid.begin(); aaitr != m->aminoacid.end(); aaitr++){
					Aminoacid *aa = (Aminoacid *) (aaitr->second);
					float v = aa->eInterface;
					aa->eInterface = aa->entropy_sequence;
					aa->entropy_sequence = v;
				}*/
			}
		}
#endif			
	}
}

/*
 * Arguments: pdbid chain domain1_start domain1_end domain2_start domain2_end 
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	read_dock_config();
	
	string s = string(argv[1]);
	string pdbid = s;//.substr(s.length()-4,4);
	cout << "pdbid " << pdbid << endl;
	pdbcode = s.c_str();
	chains = new string(argv[2]);
	
	Complex *c = new Complex(argv[1],argv[2], PDB);
	
	scop_dom1start = atoi(argv[3]);
	scop_dom1end = atoi(argv[4]);
	scop_dom2start = atoi(argv[5]);
	scop_dom2end = atoi(argv[6]);
	
	dom1start = dom1end = dom2start = dom2end = -1;
	for(int i = 0; i < c->num_aminoacids; i++){
		Aminoacid *aa = c->aminoacid[i];
		if(aa->index == string(argv[3]) && dom1start == -1)
			dom1start = aa->cindex+1;
		if(aa->index == string(argv[4]) && dom1end == -1)
			dom1end = aa->cindex+1;
		if(aa->index == string(argv[5]) && dom2start == -1)
			dom2start = aa->cindex+1;
		if(aa->index == string(argv[6]) && dom2end == -1)
			dom2end = aa->cindex+1;
	}
	if(dom1start == -1 || dom1end == -1 || dom2start == -1 || dom2end == -1){
		cout << "cannot identify domain boundaries in pdb file\n";
		exit(-1);
	}
	
	// compute fragment sasa
	compute_fragment_sasa(c, dom1start-1,dom1end);
	compute_fragment_sasa(c, dom2start-1,dom2end);
	
	read_seqres_to_atom_alignment(c);
	
	sprintf(buf,"%s_%s.profile",c->pdbcode, c->chains);
	read_seqres_profile(c->molecules.begin()->second, buf , seqres_sequence->size());
	
	// compute profiles from paired sequences
	hom_res_probabilities = (float**) malloc(sizeof(float*)* seqres_sequence->size());
	for(int i = 0 ; i < seqres_sequence->size(); i++)
		hom_res_probabilities[i] = (float*) malloc(sizeof(float)*20);
	
	read_homologues_and_multiple_align(pdbid, c);
	
	unsigned short num_intra_contacts[c->num_aminoacids], num_inter_contacts[c->num_aminoacids];
	for(int i = 0; i < c->num_aminoacids; i++)
		num_intra_contacts[i] = num_inter_contacts[i] = 0;
	
	float d2;
	for(int i = dom1start-1; i < dom1end; i++){
		Aminoacid *aa1 = c->aminoacid[i];
		if(aa1->centroid != NULL)
			for(int j = i+2; j < dom1end; j++){
				Aminoacid *aa2 = c->aminoacid[j];
				if(aa2->centroid != NULL){
					if((d2 = Vector::distance_squared(aa1->centroid,aa2->centroid)) < 6.5*6.5){
						num_intra_contacts[i]++;
						num_intra_contacts[j]++;
					}
				}
			}
	}
	
	for(int i = dom2start-1; i < dom2end; i++){
		Aminoacid *aa1 = c->aminoacid[i];
		if(aa1->centroid != NULL)
			for(int j = i+2; j < dom2end; j++){
				Aminoacid *aa2 = c->aminoacid[j];
				if(aa2->centroid != NULL){
					if((d2 = Vector::distance_squared(aa1->centroid,aa2->centroid)) < 6.5*6.5){
						num_intra_contacts[i]++;
						num_intra_contacts[j]++;
					}
				}
			}
	}
	
	for(int i = dom1start-1; i < dom1end; i++){
	 	Aminoacid *ar = c->aminoacid[i];
	 	if(ar->centroid != NULL)
	 		for(int j = dom2start-1; j < dom2end; j++){
			 	Aminoacid *al = c->aminoacid[j];
			 	if(al->centroid != NULL){
			 		float d2 = Vector::distance_squared(ar->centroid, al->centroid);
			 		if(d2 <= 6.5*6.5){
			 			num_inter_contacts[i]++;
			 			num_inter_contacts[j]++;
			 		}
			 	}
			}
	}
	
	// list residues along with difference in profile
	cout << "tag\tpstn\tnative\trsa\t#cnts\t#icnts\t";
	cout << "nprof\tsprof\tpairprof" << "\t";
	cout << "spseudo\tpairpseudo\t";
	for(int j = 0; j < 20; j++)	cout << Aminoacid::get_symbol(j) << " ";
	for(int i = dom1start-1; i < dom2end; i++){
		Aminoacid *aa = c->aminoacid[i];
		cout << "prof\t" << aa->index << "\t" << aa->get_symbol() << "\t";
		printf("%1.3f\t",aa->rsa);
		cout << num_intra_contacts[i] << "\t" << num_inter_contacts[i] << "\t";
		cout << aa->eInterface << "\t";
		
		//cout << aa->pInterface << "\t";
		float mixture_entropy = 0;
		float mixture_weight[20];
		float sum = 0;
		for(int j = 0; j < 20; j++){
			mixture_weight[j] = aa->profile_probabilities_n[j] /* aa->entropy_sequence_percentile*/ + 100.0 * aminoacid_probabilities[j];
			sum += mixture_weight[j];
		}
		for(int j = 0; j < 20; j++){
			float w = mixture_weight[j] / sum;
			mixture_entropy += w*log(w);
		}
		cout << mixture_entropy << "\t";
		
		//cout << aa->entropy_sequence << "\t";
		mixture_entropy = 0;
		sum = 0;
		for(int j = 0; j < 20; j++){
			mixture_weight[j] = aa->profile_probabilities_p[j] /* aa->blast_pseudocount*/ + 100.0 * aminoacid_probabilities[j];
			sum += mixture_weight[j];
		}
		for(int j = 0; j < 20; j++){
			float w = mixture_weight[j] / sum;
			mixture_entropy += w*log(w);
		}
		cout << mixture_entropy << "\t";
		
		cout << aa->entropy_sequence_percentile << "\t" << aa->blast_pseudocount << "\t";
		for(int j = 0; j < 20; j++){
			cout << aa->profile_probabilities_p[j] << "/" << aa->profile_probabilities_n[j] << " ";
		}
		cout << endl;
	}
}
