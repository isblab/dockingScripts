/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"
#include "align_utilities.hpp"
const char* pdbcode;
string* chains;
int filetype;

string* sequence;
hash_map<const char*, Sequence*, hash<const char*>, eqstr> matching_sequences, matching_sequences_in_pdb, sequences_with_struct_alignment;
hash_map<const char*, Molecule*, hash<const char*>, eqstr> homologues;
char **malignment;
const char ***malignment_indices;

ostream *out;
char scratch_dir[512], command[8192];
extern char buf[16384];
extern char *tmp_dir;
extern bool **aacontact_core, **aacontact_rim, *aarcontact, *aalcontact;

hash_map<const char* ,hash_map<char, vector<Sequence*>, hash<char>, eqint>,hash<const char*>,eqstr> homologue_sequences;
vector<Sequence*> rec_homologues, lig_homologues;

float **rec_hom_res_probabilities, **lig_hom_res_probabilities;

#define PAIRING_USE_BLAST_ENTROPY

//#define USE_STABILITY_PROFILE
#ifdef USE_STABILITY_PROFILE
//#define USE_COMPLEX_PROFILE
#endif
#define USE_PROCESSED_STABILITY_PROFILE

void read_homologues(string pdbid, Complex *cr, Complex *cl){
	int aligntype = BLAST_ALIGN;
	string refallchains = cr->chains + cl->chains;
	string *chains = new string(refallchains);
	
	pdbcode = pdbid.c_str();
	char rchain = cr->chains.c_str()[0];
	char lchain = cl->chains.c_str()[0];	
	
	hash_map<char, hash_map<const char*, const char*, hash<const char*>, eqstr>, hash<char>, eqint> hsequence_vs_speciesid;
	hash_map<char, hash_map<const char*, short, hash<const char*>, eqstr>, hash<char>, eqint> hsequence_vs_looppid;
	hash_map<short, const char*, hash<short>, eqint> hspecies;
	int num_species=0;
	
	// works only for 2 chain proteins as of now
	{
		stringstream ss (stringstream::in | stringstream::out);
		ss << pdbcode << "_" << refallchains << ".shomologues";
		string filename;
		ss >> filename;
		fstream fin;
		fin.open(filename.c_str(),ios::in);
		cout << filename << " " << fin.is_open() << endl;
		
		hsequence_vs_speciesid[rchain] = *(new hash_map<const char*, const char*, hash<const char*>, eqstr>);
		hsequence_vs_speciesid[lchain] = *(new hash_map<const char*, const char*, hash<const char*>, eqstr>);
		hsequence_vs_looppid[rchain] = *(new hash_map<const char*, short, hash<const char*>, eqstr>);
		hsequence_vs_looppid[lchain] = *(new hash_map<const char*, short, hash<const char*>, eqstr>);
		
		while (!fin.eof()){
			fin.getline(buf,16384);
			if(fin.gcount() > 0){
				stringstream line(buf,stringstream::in);
				string s;
				line >> s;
				if(s == "SPECIES"){
					string species_name="";
					do{
						line >> s;
						if(s!="#")	species_name=species_name+s;
					}while( s != "#");
					species_name = *(new string(species_name.c_str()));
					
					int numrhomologues, numlhomologues;
					line >> numrhomologues;
					line >> numlhomologues;
					
					homologue_sequences[species_name.c_str()] = *(new hash_map<char, vector<Sequence*>, hash<char>, eqint>);
					homologue_sequences[species_name.c_str()][rchain] = *(new vector<Sequence*>);
					homologue_sequences[species_name.c_str()][lchain] = *(new vector<Sequence*>);
					
					for(int j = 0; j < 2; j++){
						int n=numrhomologues;
						char chain=rchain;
						if(j==1){
							n=numlhomologues;
							chain=lchain;
						}
						for(int i = 0; i < n; i++){
							fin.getline(buf,16384);
							stringstream line(buf,stringstream::in);
							string id;	line >> id;
							id = *(new string(id));
							hsequence_vs_speciesid[chain][id.c_str()] = species_name.c_str();
							hsequence_vs_looppid[chain][id.c_str()] = i;
						}
					}
					
					cout << species_name << " " << numrhomologues << " " << numlhomologues << " " << 
						hsequence_vs_speciesid[rchain].size() << " " << hsequence_vs_speciesid[lchain].size() << endl;
					
					hspecies[num_species] = species_name.c_str();
					num_species++;	
				}
			}
		}
		
		cout << "#homspecies " << num_species << endl; 
	}
	
	for(int j = 0; j < 2; j++){
		char chain=rchain;
		if(j==1)	chain=lchain;
		stringstream ss (stringstream::in | stringstream::out);
		
		// read alignments
		read_blast_hits(chain,DB_PDBAA,"");
		read_blast_hits(chain,DB_NR,"");
		int current=0;
		for(hash_map<const char*, Sequence*, hash<const char*>, eqstr>::iterator sitr = matching_sequences.begin(); sitr != matching_sequences.end(); sitr++){
			Sequence *s = (Sequence *) sitr->second;
			if(hsequence_vs_speciesid[chain].count(s->id_lowercase.c_str()) > 0)
				homologue_sequences[hsequence_vs_speciesid[chain][s->id_lowercase.c_str()]][chain].push_back(s);
		}
		matching_sequences.clear();
	}
	
	int spindex=0;
	for(int si=0; si < num_species; si++){
		const char* species_name = hspecies[si];
		hash_map<char, vector<Sequence*>, hash<char>, eqint> hsequences = homologue_sequences[species_name];
		bool selected_rec=false, selected_lig=false;
				
		for(int j = 0; j < 2; j++){
			char chain = rchain;
			float num_residues = cr->num_aminoacids;
			if(j==1){
				chain = lchain;
				num_residues = cl->num_aminoacids;
			}
			vector<Sequence*> seqs = hsequences[chain];
			
			for(vector<Sequence*>::iterator itr = seqs.begin(); itr != seqs.end(); itr++){
				Sequence *s = *itr;
				//cout << s->id << " " << s->seq_alignment << " " << s->seq_alignment->identities << " ratio " << s->seq_alignment->aseq1 << " " << s->seq_alignment->aseq1.size()/num_residues << endl;
				if((aligntype == BLAST_ALIGN && s->seq_alignment->aseq1.size()/num_residues >=0.60)){
					if(j == 0){
						rec_homologues.push_back(s);
						selected_rec=true;
					}
					else{
						lig_homologues.push_back(s);
						selected_lig=true;
					}
				}
			}
		}
		if(selected_rec && selected_lig)	spindex++;
	}
	num_species = spindex;
	cout << "#species filtered " << num_species << endl; cout.flush(); 
}

void multiple_align_homologues(Complex *cr, Complex *cl){
	string *sequence;
	for(int pj = 0 ; pj < 2; pj++){
		vector<Sequence*>::iterator sitr, send; 
		int seqsize,n;
		if(pj == 0){
			sitr = rec_homologues.begin();
			send = rec_homologues.end();
			seqsize = cr->num_aminoacids;
			n = rec_homologues.size();
			sequence = new string(((Molecule*)cr->molecules.begin()->second)->compute_aasequence().c_str());
		} else {
			sitr = lig_homologues.begin();
			send = lig_homologues.end();
			seqsize = cl->num_aminoacids;
			n = lig_homologues.size();
			sequence = new string(((Molecule*)cl->molecules.begin()->second)->compute_aasequence().c_str());
		}
		
#ifdef PAIRING_USE_BLAST_ENTROPY
		sprintf(buf,"sequences%d",pj);
		fstream seqout(buf,fstream::out);
		/*seqout << "<pdb|"; 
		if(pj == 0)
			seqout << cr->pdbcode << "|" << cr->chains << endl;
		else
			seqout << cl->pdbcode << "|" << cl->chains << endl;
		seqout << *sequence << endl;*/
#endif
			
		malignment = (char**) malloc(n*sizeof(char*));
		malignment_indices = (const char ***) malloc(n*sizeof(const char **));
		int m = seqsize; 
		for(int i = 0; i < n ; i++){
			malignment[i] = (char*) malloc((m+1)*sizeof(char));
			malignment_indices[i] = (const char **) malloc(m*sizeof(const char *));
			for(int j = 0; j < m ; j++){
				malignment[i][j] = '-';
				malignment_indices[i][j] = NULL;
			}
			malignment[i][m] = '\0';
		}

		float hom_residue_count[m][20];
		for(int j = 0; j < m ; j++)
			for(int k = 0; k <20; k++)	hom_residue_count[j][k] = 0;
		
		int mindex = 0;
		while(sitr != send){
			Sequence *s = *sitr;
			Alignment *a =  s->seq_alignment;
			s->aasequence = sequence;
				
			string s1,s2;
			//assuming aseq1 is the query
			s1 = a->aseq1;
			s2 = a->aseq2;
			
			char gapless_s2c[s2.size() + 1];
			const char* s2c = s2.c_str();
			int s2_vs_gapless_s2[s2.size() + 1];
			for(int i = 0 ; i < s2.size()+1; i++)
				s2_vs_gapless_s2[i] = -1;
				
			int gapless_index = 0;
			for(int i = 0 ; i < s2.size(); i++){
				if(s2c[i] != '-'){
					s2_vs_gapless_s2[i] = gapless_index;
					gapless_s2c[gapless_index++] = s2c[i];
				}
			} 
			gapless_s2c[gapless_index] = s2c[s2.size()];
			string gapless_s2 = string(gapless_s2c);
#ifdef PAIRING_USE_BLAST_ENTROPY
			seqout << ">pdb|" << mindex << endl << gapless_s2 << endl;
#endif
			
			{
				s->malignment_index = mindex;
			
				// remove gaps from s1 and note the alignment
				char gapless_s1c[s1.size() + 1];
				int gapless_s1_vs_s2[s1.size() + 1];
				const char* s1c = s1.c_str();
				gapless_index = 0;
				for(int i = 0 ; i < s1.size(); i++){
					if(s1c[i] != '-'){
						gapless_s1_vs_s2[gapless_index] = i;
						gapless_s1c[gapless_index++] = s1c[i];
					}
				} 
				gapless_s1c[gapless_index] = s1c[s1.size()];
				string gapless_s1 = string(gapless_s1c);
				
				int s1start = sequence->find(gapless_s1);
				int s1end = s1start + gapless_s1.size();
				if(s1start == string::npos){
					*out << "ERROR: alignment not consistent with string" << endl;
					*out << *sequence << endl;
					*out << gapless_s1 << endl;
					*out << s1start << "\t" << s1end << "\t" << s1 << endl;
					out->flush(); 
				} else {
					*out << s1start << " " << s1end << endl;
				
					const char* s2c = s2.c_str();
					for(int i = s1start ; i < s1end; i++){
						int s2index = gapless_s1_vs_s2[i-s1start];
						char aatype = s2c[s2index];
						malignment[mindex][i] = aatype; 
						short aatypen = get_aatype(aatype);
						if(aatypen >=0 )	hom_residue_count[i][aatypen]++; 
					}
					
					cout << string(malignment[mindex]) << endl;
					mindex++;
				}
			}
			
			sitr++;
		}
		
		for(int i = 0; i < m ; i++){
			float total_non_gaps = 0;
			for(int k = 0; k <20; k++)	total_non_gaps += hom_residue_count[i][k];
			for(int k = 0; k <20; k++){
				float p = 0;
				if(total_non_gaps>0)	p = hom_residue_count[i][k]/total_non_gaps;
				if(pj==0)	rec_hom_res_probabilities[i][k] = p;
				else lig_hom_res_probabilities[i][k] = p;
			}	
		}
		
#ifdef PAIRING_USE_BLAST_ENTROPY
		seqout.close();
		
		stringstream ss (stringstream::in | stringstream::out);
		ss << getenv(string("HOME").c_str()) << "/blast/getblastprofile.sh ";
		if(pj==0)	ss << cr->pdbcode << "_" << cr->chains;  
		else ss << cl->pdbcode << "_" << cl->chains;
		ss << " sequences" << pj << " > paired_blast_profile" << pj << ".out";
		{
			char buf[2048];
			ss.getline(buf,2048);
			cout << string(buf) << endl;
			int ret = system(buf);
			*out << buf << " " << ret << endl;
		}
		Complex *c;
		if(pj==0)	c = cr;
		else	c = cl;
		for(hash_map<char, Molecule*, hash<char>, eqint>::iterator mitr = c->molecules.begin(); mitr != c->molecules.end(); mitr++){
			Molecule *m = (Molecule *) (mitr->second);
			for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = m->aminoacid.begin(); aaitr != m->aminoacid.end(); aaitr++){
				Aminoacid *aa = (Aminoacid *) (aaitr->second);
				aa->eInterface = aa->entropy_sequence;
			}
			sprintf(buf,"%s_%s_vs_sequences%d.profile",c->pdbcode, c->chains, pj);
			read_profile(m, buf);
			for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = m->aminoacid.begin(); aaitr != m->aminoacid.end(); aaitr++){
				Aminoacid *aa = (Aminoacid *) (aaitr->second);
				float v = aa->eInterface;
				aa->eInterface = aa->entropy_sequence;
				aa->entropy_sequence = v;
			}
		}
#endif		
	}
}

//#define USE_COMPLEX_PROFILE

/*
 * Arguments: pdbid receptor-chains ligand-chains 
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	read_dock_config();
	
	Complex *cr, *cl;
	cr = new Complex(argv[1],argv[2], PROCESSED);//PDB);
	cl = new Complex(argv[1],argv[3], PROCESSED);//PDB);
	cr->compute_volume_sasa(false,false);
	cl->compute_volume_sasa(false,false);
	string s = string(argv[1]);
	string pdbid = s;//.substr(s.length()-4,4);
	cout << "pdbid " << pdbid << endl;
	for(hash_map<char, Molecule*, hash<char>, eqint>::iterator mitr = cr->molecules.begin(); mitr != cr->molecules.end(); mitr++){
		Molecule *m = (Molecule *) (mitr->second);
		m->pdbcode = pdbid;
		read_profile(m);
	}
	for(hash_map<char, Molecule*, hash<char>, eqint>::iterator mitr = cl->molecules.begin(); mitr != cl->molecules.end(); mitr++){
		Molecule *m = (Molecule *) (mitr->second);
		m->pdbcode = pdbid;
		read_profile(m);
	}
	
	// compute profiles from paired sequences
	rec_hom_res_probabilities = (float**) malloc(sizeof(float*)*cr->num_aminoacids);
	for(int i = 0 ; i < cr->num_aminoacids; i++)
		rec_hom_res_probabilities[i] = (float*) malloc(sizeof(float)*20);
	lig_hom_res_probabilities  = (float**) malloc(sizeof(float*)*cl->num_aminoacids);
	for(int i = 0 ; i < cl->num_aminoacids; i++)
		lig_hom_res_probabilities[i] = (float*) malloc(sizeof(float)*20);
		
	read_homologues(pdbid, cr, cl);
	multiple_align_homologues(cr, cl);
	
	bool contact[cr->num_aminoacids][cl->num_aminoacids];
	for(int i = 0; i < cr->num_aminoacids; i++)
		for(int j = 0; j < cl->num_aminoacids; j++)
			contact[i][j] = false;
	
	unsigned short rec_num_intra_contacts[cr->num_aminoacids], rec_num_inter_contacts[cr->num_aminoacids],
	 lig_num_intra_contacts[cl->num_aminoacids], lig_num_inter_contacts[cl->num_aminoacids];
	for(int i = 0; i < cr->num_aminoacids; i++)
		rec_num_intra_contacts[i] = rec_num_inter_contacts[i] = 0;
	for(int i = 0; i < cl->num_aminoacids; i++)
		lig_num_intra_contacts[i] = lig_num_inter_contacts[i] = 0;
	
	float d2;
	for(int i = 0; i < cr->num_aminoacids; i++){
		Aminoacid *aa1 = cr->aminoacid[i];
		if(aa1->centroid != NULL)
			for(int j = i+2; j < cr->num_aminoacids; j++){
				Aminoacid *aa2 = cr->aminoacid[j];
				if(aa2->centroid != NULL){
					if((d2 = Vector::distance_squared(aa1->centroid,aa2->centroid)) < 6.5*6.5){
						rec_num_intra_contacts[i]++;
						rec_num_intra_contacts[j]++;
					}
				}
			}
	}
	
	for(int i = 0; i < cl->num_aminoacids; i++){
		Aminoacid *aa1 = cl->aminoacid[i];
		if(aa1->centroid != NULL)
			for(int j = i+2; j < cl->num_aminoacids; j++){
				Aminoacid *aa2 = cl->aminoacid[j];
				if(aa2->centroid != NULL){
					if((d2 = Vector::distance_squared(aa1->centroid,aa2->centroid)) < 6.5*6.5){
						lig_num_intra_contacts[i]++;
						lig_num_intra_contacts[j]++;
					}
				}
			}
	}
	
	// read profile of receptor chain alone
	unsigned int rec_sequences_residue_count[cr->num_aminoacids][20], num_rec_sequences=0;
	for(int i = 0; i < cr->num_aminoacids; i++)
		for(int j = 0; j < 20; j++)	rec_sequences_residue_count[i][j] = 0;

#ifdef USE_STABILITY_PROFILE		
	fstream freceptorp(argv[4],fstream::in);
	cout << "filename " << string(argv[4]) << " " << freceptorp.good() << endl;
	int markov_chain_position=0;
    while(freceptorp.good()){
    	freceptorp.getline(buf,8192*128);
    	if(freceptorp.gcount() > 0){
	    	stringstream ss (stringstream::in | stringstream::out);
	    	ss << buf;
	    	string tag; ss >> tag;
	    	if(tag == "Seq="){
	    		//cout << string(buf) << " " << tag << endl; cout.flush();
	    		markov_chain_position++;
	    		if(markov_chain_position>50){
			    	for(int i = 0; i < cr->num_aminoacids; i++){
			    		unsigned int residue;
			    		ss >> residue;
			    		rec_sequences_residue_count[i][residue-1]++;
			    	}
			    	num_rec_sequences++;
			    	//cout << string(buf) << " " << tag << " #" << num_rec_sequences << endl;
	    		}
	    	} else {
	    		markov_chain_position=0;
	    	}
    	}
    }
    freceptorp.close();
    cout << "num receptor sequences " << num_rec_sequences << endl;
    
	// read profile of ligand chain alone
	unsigned int lig_sequences_residue_count[cl->num_aminoacids][20], num_lig_sequences=0;
	for(int i = 0; i < cl->num_aminoacids; i++)
		for(int j = 0; j < 20; j++)	lig_sequences_residue_count[i][j] = 0;
		
	fstream fligandp(argv[5],fstream::in);
	markov_chain_position=0;
    while(fligandp.good()){
    	fligandp.getline(buf,8192*128);
    	if(fligandp.gcount() > 0){
	    	stringstream ss (stringstream::in | stringstream::out);
	    	ss << buf;
	    	string tag; ss >> tag;
	    	if(tag == "Seq="){
	    		markov_chain_position++;
	    		if(markov_chain_position > 50){
			    	for(int i = 0; i < cl->num_aminoacids; i++){
			    		unsigned int residue;
			    		ss >> residue;
			    		lig_sequences_residue_count[i][residue-1]++;
			    	}
			    	num_lig_sequences++;
		    	}
	    	} else {
	    		markov_chain_position=0;
	    	}
    	}
    }
    fligandp.close();
    cout << "num ligand sequences " << num_lig_sequences << endl;
#endif
    
	for(int i = 0; i < cr->num_aminoacids; i++){
	 	Aminoacid *ar = cr->aminoacid[i];
	 	if(ar->centroid != NULL)
			for(int j = 0; j < cl->num_aminoacids; j++){
			 	Aminoacid *al = cl->aminoacid[j];
			 	if(al->centroid != NULL){
			 		float d2 = Vector::distance_squared(ar->centroid, al->centroid);
			 		if(d2 <= 6.5*6.5){
			 			contact[i][j] = true;
			 			rec_num_inter_contacts[i]++;
			 			lig_num_inter_contacts[j]++;
			 		}
			 	}
			}
	}

#ifdef USE_COMPLEX_PROFILE	
	// read profile of receptor and ligand chains in complex
	unsigned int clig_sequences_residue_count[cl->num_aminoacids][20], num_cmplx_sequences=0, 
	 crec_sequences_residue_count[cr->num_aminoacids][20];
	 
	for(int i = 0; i < cr->num_aminoacids; i++)
		for(int j = 0; j < 20; j++)	crec_sequences_residue_count[i][j] = 0;	
	for(int i = 0; i < cl->num_aminoacids; i++)
		for(int j = 0; j < 20; j++)	clig_sequences_residue_count[i][j] = 0;
		
	fstream fcomplexp(argv[6],fstream::in);
    while(fcomplexp.good()){
    	fcomplexp.getline(buf,8192*128);
    	if(fcomplexp.gcount() > 0){
	    	stringstream ss (stringstream::in | stringstream::out);
	    	ss << buf;
	    	string tag; ss >> tag;
	    	if(tag == "Seq="){
	    		for(int i = 0; i < cr->num_aminoacids; i++){
	    			unsigned int residue;
		    		ss >> residue;
		    		crec_sequences_residue_count[i][residue-1]++;
		    	}
		    	for(int i = 0; i < cl->num_aminoacids; i++){
		    		unsigned int residue;
		    		ss >> residue;
		    		clig_sequences_residue_count[i][residue-1]++;
		    	}
		    	num_cmplx_sequences++;
	    	}
    	}
    }
    fcomplexp.close();
    cout << "num complex sequences " << num_cmplx_sequences << endl;
	
	// get difference of profiles
	float diff_profile_rec[cr->num_aminoacids][20] , diff_profile_lig[cl->num_aminoacids][20];
	float prcmplx[cr->num_aminoacids][20] , plcmplx[cl->num_aminoacids][20];
#endif

#ifdef USE_STABILITY_PROFILE
	float prec[cr->num_aminoacids][20], plig[cl->num_aminoacids][20];
	
	for(int i = 0; i < cr->num_aminoacids; i++){
		for(int j = 0; j < 20; j++){
			prec[i][j] = rec_sequences_residue_count[i][j]/((float) num_rec_sequences);
#ifdef USE_COMPLEX_PROFILE
			prcmplx[i][j] = crec_sequences_residue_count[i][j]/((float) num_cmplx_sequences);
			diff_profile_rec[i][j] = prcmplx[i][j] - prec[i][j];
#endif
		}
	}
	
	for(int i = 0; i < cl->num_aminoacids; i++){
		for(int j = 0; j < 20; j++){
			plig[i][j] = lig_sequences_residue_count[i][j]/((float) num_lig_sequences);
#ifdef USE_COMPLEX_PROFILE
			plcmplx[i][j] = clig_sequences_residue_count[i][j]/((float) num_cmplx_sequences);
			diff_profile_lig[i][j] = plcmplx[i][j] - plig[i][j];
#endif			
		}
	}
#define USE_PROFILE_DIFFERENCE	
#endif
	
#ifndef USE_STABILITY_PROFILE 
#ifdef USE_PROCESSED_STABILITY_PROFILE
	float prec[cr->num_aminoacids][20], plig[cl->num_aminoacids][20];
	fstream profilein("processed_profile", fstream::in);
	do{
		profilein.getline(buf,16384);
	}while(((string(buf)).find("pstn") == string::npos) || ((string(buf)).find("native") == string::npos) || ((string(buf)).find("rsa") == string::npos));
	
	for(int i = 0; i < cr->num_aminoacids; i++){
		profilein.getline(buf,16384);
		stringstream *line = new stringstream(buf,stringstream::in);
		string tag; 
		for(int k = 0 ; k < 5; k++)	*line >> tag; 
		
		for(int j = 0; j < 20; j++)	*line >> prec[i][j];
	}
	
	for(int i = 0; i < cl->num_aminoacids; i++){
		profilein.getline(buf,16384);
		stringstream *line = new stringstream(buf,stringstream::in);
		string tag; 
		for(int k = 0 ; k < 5; k++)	*line >> tag; 
		
		for(int j = 0; j < 20; j++)	*line >> plig[i][j];
	}					
	profilein.close();	
#define USE_PROFILE_DIFFERENCE
#endif
#endif
	
	// list residues along with difference in profile
	cout << "pstn\tnative\trsa\t#cnts\t#icnts\t";
#ifdef USE_STABILITY_PROFILE		
	for(int j = 0; j < 20; j++)	cout << Aminoacid::get_symbol(j) << "\t";
#endif	
	cout << "diffprof sprof pairprof seqprof" << endl;
	for(int i = 0; i < cr->num_aminoacids; i++){
		Aminoacid *ar = cr->aminoacid[i];
		cout <<"R" << ar->index << "\t" << ar->get_symbol() << "\t";
		printf("%1.3f\t",ar->rsa);
		cout << rec_num_intra_contacts[i] << "\t" << rec_num_inter_contacts[i] << "\t";
		float entropy = 0;
//#ifdef USE_STABILITY_PROFILE
#ifdef USE_PROFILE_DIFFERENCE		
		for(int j = 0; j < 20; j++)	printf("%2.3f\t",prec[i][j]);
		for(int j = 0; j < 20; j++)	if(prec[i][j] > 0)	entropy += (0-prec[i][j] * log(prec[i][j]));
		cout << " " << entropy << " ";// << ar->entropy_sequence << endl;
#endif

#ifdef USE_PROFILE_DIFFERENCE
		float dotp=0;
		for(int j = 0; j < 20; j++)	{
			dotp = prec[i][j] * rec_hom_res_probabilities[i][j];
		}
		cout << dotp << " ";
#endif

		entropy = 0;
		for(int j = 0; j < 20; j++)	if(rec_hom_res_probabilities[i][j] > 0)	entropy += (0-rec_hom_res_probabilities[i][j] * log(rec_hom_res_probabilities[i][j]));
		cout << entropy << " ";		
#ifdef PAIRING_USE_BLAST_ENTROPY
		cout << ar->eInterface << " ";
#endif
		cout << ar->entropy_sequence << endl;

#ifdef USE_COMPLEX_PROFILE		
		cout <<"Rc" << ar->index << "\t" << ar->get_symbol() << "\t";
		printf("%1.3f\t",ar->rsa);
		cout << rec_num_inter_contacts[i] << "\t";
		for(int j = 0; j < 20; j++)	printf("%2.3f\t",prcmplx[i][j]);
		entropy = 0;
		for(int j = 0; j < 20; j++)	if(prcmplx[i][j] > 0)	entropy += (0-prcmplx[i][j] * log(prcmplx[i][j]));
		cout << " " << entropy << endl;
		
		cout <<"Rd" << ar->index << "\t" << ar->get_symbol() << "\t0\t" << rec_num_inter_contacts[i] << "\t";
		for(int j = 0; j < 20; j++)	printf("%2.3f\t",diff_profile_rec[i][j]);
		cout << endl;
#endif		
	}
	for(int i = 0; i < cl->num_aminoacids; i++){
		Aminoacid *al = cl->aminoacid[i];
		cout << "L" << al->index << "\t" << al->get_symbol() << "\t";
		printf("%1.3f\t",al->rsa); 
		cout << lig_num_intra_contacts[i] << "\t" << lig_num_inter_contacts[i] << "\t";;
		float entropy = 0;
//#ifdef USE_STABILITY_PROFILE
#ifdef USE_PROFILE_DIFFERENCE		
		for(int j = 0; j < 20; j++)	printf("%2.3f\t",plig[i][j]);
		for(int j = 0; j < 20; j++)	if(plig[i][j] > 0)	entropy += (0-plig[i][j] * log(plig[i][j]));
		cout << " " << entropy << " " ;//<< al->entropy_sequence << endl;
#endif	

#ifdef USE_PROFILE_DIFFERENCE
		float dotp=0;
		for(int j = 0; j < 20; j++)	{
			dotp = plig[i][j] * lig_hom_res_probabilities[i][j];
		}
		cout << dotp << " ";
#endif	
		entropy = 0;
		for(int j = 0; j < 20; j++)	if(lig_hom_res_probabilities[i][j] > 0)	entropy += (0-lig_hom_res_probabilities[i][j] * log(lig_hom_res_probabilities[i][j]));
		cout << entropy << " ";
#ifdef PAIRING_USE_BLAST_ENTROPY
		cout << al->eInterface << " ";
#endif
		cout << al->entropy_sequence << endl;

#ifdef USE_COMPLEX_PROFILE		
		cout << "Lc" << al->index << "\t" << al->get_symbol() << "\t";
		printf("%1.3f\t",al->rsa);
		cout << lig_num_inter_contacts[i] << "\t";
		for(int j = 0; j < 20; j++)	printf("%2.3f\t",plcmplx[i][j]);
		entropy = 0;
		for(int j = 0; j < 20; j++)	if(plcmplx[i][j] > 0)	entropy += (0-plcmplx[i][j] * log(plcmplx[i][j]));
		cout << " " << entropy << endl;
		
		cout << "Ld" << al->index << "\t" << al->get_symbol() << "\t0\t" << lig_num_inter_contacts[i] << "\t";
		for(int j = 0; j < 20; j++)	printf("%2.3f\t",diff_profile_lig[i][j]);
		cout << endl;
#endif		
	}
		
}
