module load intel
module load openmpi
