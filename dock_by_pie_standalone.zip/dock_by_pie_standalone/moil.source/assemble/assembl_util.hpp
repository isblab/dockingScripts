/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "assemble.hpp"
#include "dock_util.hpp"

string prot_pdbcode[MAX_UNITS], prot_chains[MAX_UNITS], ref_chains[MAX_UNITS];
short num_units;
unsigned short looplength[MAX_UNITS];
Object *prot_object[MAX_UNITS];
MKL_Complex8 *prot_shape[MAX_UNITS], **prot_particlepgrid[MAX_UNITS];

void compute_trimer_scores_generalized(transformationscore *, Transformation* tr1, Reference_Frame *trinv1, transformationscore *ts2, Transformation* tr2, short *, short *,
 Reference_Frame **, float *, float, float *atomp, unsigned int);

void compute_trimer_scores(transformationscore *, Transformation* tr1, Reference_Frame *trinv1, transformationscore *ts2, Transformation* tr2,int *clashes, 
 unsigned int, float *atomp, unsigned int);
