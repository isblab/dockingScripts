/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#ifndef INCL_DOCKHPP
#include "dock.hpp"
#define INCL_DOCKHPP
#endif

#define LOOP_CONSTRAINT
#define ASSMBL_DEBUG
#define MAX_UNITS 5

typedef struct {
	unsigned int tid;
	float particlep;
	unsigned short p1, p2, num_clashes;
} transformationscore;
