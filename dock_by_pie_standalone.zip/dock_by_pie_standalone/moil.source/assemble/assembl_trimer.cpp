/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "assembl_util.hpp"

#define NUM_FFT_ATOM_TYPES 20

float grid_spacing=FFT_GRID_SPACING;
short num_particlep_arrays=0;

DFTI_DESCRIPTOR_HANDLE fft_desc_handle;
MKL_LONG mkl_status, gridsize[3], strides[4];
unsigned int size;
float sqrt_size;

//unsigned int max_transformations=1024*1024*4;

typedef struct {
	short p11,p12,p21,p22;
	unsigned int t1,t2;
	float particlep;
	short procid;
} multitransformationscore;

bool multitransscore_betterparticlep(multitransformationscore *t1,multitransformationscore *t2){
	return(t1->particlep > t2->particlep);
}

bool multitransscore_worseparticlep(multitransformationscore *t1,multitransformationscore *t2){
	return(t1->particlep < t2->particlep);
}

extern float **atom18_potential, **atom20_potential;
float ***atom_potential;

fstream trans_in[4][4], allsorteddimerscores_in;

#define TRIMER_CLASH_CUTOFF 80
#define TRIMER_MIN_VDW_REPUL -200*INTERMEDIATE_IMAG*INTERMEDIATE_IMAG
//#define TRIMER_MIN_VDW_REPUL -320*INTERMEDIATE_IMAG*INTERMEDIATE_IMAG

//int scoring_function = FFT_GENERATE_MATCHES_VDW;
int scoring_function = FFT_GENERATE_MATCHES_RESIDUE_BKBNP;

void assemble_trimer(float cutoffE, unsigned int max_multitransformations){
	char buf[1024*1024],tfilename[512], command[512];
	int ret;
	
	if(masterprocessonnode){
		// copy files for faster processing
		/*sprintf(command,"cp ? %s/%s/",node_tmp_dir,refpdbcode.c_str());
		ret = system(command);
		*out << command << " " << ret << endl;*/
		
		if(procid == 0){
			
		}
	}
	int a=0,b;
	MPI_Allreduce(&a,&b, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);	
	
	unsigned int num_transforms = 0;
	allsorteddimerscores_in.seekg (0, ios::beg);
	
	while(!allsorteddimerscores_in.eof()){
		allsorteddimerscores_in.getline(buf,8192);
		if(allsorteddimerscores_in.gcount() > 0)
			num_transforms++;
	}
	allsorteddimerscores_in.clear();
  	*out << "num transforms " << num_transforms << endl; out->flush();
  	transformationscore allsorteddimerscores[num_transforms];
  	allsorteddimerscores_in.seekg(0, ios::beg);
  	int ti=0;
  	while(!allsorteddimerscores_in.eof()){
		allsorteddimerscores_in.getline(buf,8192);
		if(allsorteddimerscores_in.gcount() > 0){
			stringstream line(buf,stringstream::in);
			line >> allsorteddimerscores[ti].particlep;
			line >> allsorteddimerscores[ti].tid;
			line >> allsorteddimerscores[ti].p1;
			line >> allsorteddimerscores[ti].p2;
			line >> allsorteddimerscores[ti].num_clashes;
			//*out << string(buf) << endl; out->flush();
			ti++;
		}
	}
  	
	// work in stages, each stage consists of searching a region maintaining top scoring results, collecting and storing results
  	Transformation *identity = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
	
  	float maxE = 0;		
	int phase=0;
	bool done = false;
	unsigned short blocksize1=256*8, blocksize2=64;
	//unsigned short blocksize1=256*8, blocksize2=32;
	vector<multitransformationscore*> node_heap;
	unsigned int node_heap_size=0;
	unsigned int token1outer=0,token2outer=0;
	unsigned int phase_limit=blocksize2*1250;
	bool t1block_done=false;
	while(!done){
		bool phase_done = false;
		unsigned int token1,token2;
		token1=token1outer;
		token2=token2outer;
		unsigned int token1limit = (token1outer+1)*blocksize1;
		if(token1limit > num_transforms)	token1limit = num_transforms;
		unsigned int num_phase_iterations=0;
		
		if(procid == 0){
			float cutoffE_at_begin_phase = cutoffE;
			bool phase_node_done[numprocs];
			for(int i = 1; i < numprocs; i++)	phase_node_done[i] = false;
			while(!phase_done){
				// receive a request and send work
				MPI_Recv(buff, BUFSIZE, MPI_CHAR, MPI_ANY_SOURCE, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
				stringstream ss (stringstream::in | stringstream::out);
				ss << buff;
				int node;
				ss >> node;
				float f;
				ss >> f;
				if(f > maxE)	maxE = f;
				ss >> f;
				if(f >cutoffE)	cutoffE = f;
				ss >> phase_node_done[node];
				if(!t1block_done)	ss >> t1block_done;
				
				if(!phase_node_done[node]){
					sprintf(buff, "%d %d %f", token1, token2, cutoffE_at_begin_phase);
					MPI_Ssend(buff, BUFSIZE, MPI_CHAR, node, GENERATE_TAG, MPI_COMM_WORLD);
					*out << "node " << node << " working on " << token1 << " " << token2 << " " << phase_node_done[node] << endl; out->flush();
					token2 = token2 + 1;
				} else {
					*out << "done phase node " << node << endl; 
				}
				
				// ended the computation at the node
				//phase_node_done[node] = phase_node_done[node] || ((token2-token2outer)*blocksize2 > phase_limit) || (token2*blocksize2 > num_transforms);
				
				if(token2 %1000 == 0){
					time(&current_time);
					cout << "at position " << token1 << " " << token2 << " time " <<  difftime(current_time,start_time) << endl; cout.flush();
				}
				
				phase_done = true;
				for(int i = 1; i < numprocs; i++)	phase_done &= phase_node_done[i];
				num_phase_iterations++;
			}
			cout << "phase " << phase << " maxE " << maxE << " cutoffE " << cutoffE << endl;
		} else {
			float cutoffE_at_begin_phase, cutoffE_at_end_phase;
			while(!phase_done){
				sprintf(buff, "%d %f %f %d %d",procid, maxE, cutoffE, phase_done, t1block_done);
				MPI_Ssend(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD);
				MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
				stringstream ss (stringstream::in | stringstream::out);
				ss << buff;
				ss >> token1;
				ss >> token2;
				
				/* Updating cutoffE on the fly speeds up the algorithm, but debugging is difficult */
				if(num_phase_iterations == 0){
					ss >> cutoffE;
					cutoffE_at_begin_phase = cutoffE;
					cutoffE_at_end_phase = cutoffE;
				}
				
				phase_done = ((token2-token2outer)*blocksize2 > phase_limit) || (token2*blocksize2 > num_transforms);
#ifdef 	ASSMBL_DEBUG
				*out << token1 << " " << token2 << " " << num_transforms << " " << token2outer << " phase done? " << phase_done << endl;
#endif			
				if(phase_done){
					break;
				} else {
			  		// process the given region of transformation couples
			  		unsigned int limit1 = minimum(num_transforms, (token1+1)*blocksize1);
			  		unsigned int limitup2 = minimum(num_transforms, (token2+1)*blocksize2);
			  	 	//*out << "token1 " << token1 << " " << limit1 << endl; out->flush();
			  	 	
			  		for(int t1 = token1*blocksize1 ; t1 < limit1; t1++){
			  			transformationscore ts1 = allsorteddimerscores[t1];
			  			fstream *transin = &(trans_in[ts1.p1][ts1.p2]);
			  			transin->seekg(0, ios::beg);
			  			transin->seekg(Transformation::basic_byte_size*ts1.tid);
			  			transin->read(buf,Transformation::basic_byte_size);
						Transformation *tr1 = new Transformation(buf,TN_BASIC);
						tr1->eSolvation = ts1.particlep;
						//*out << "t1 " << t1 << " " << ts1.p1 << " " << ts1.p2 << " " << ts1.tid << " " << tr1->frame_number << " " << tr1->eSolvation << endl; out->flush();
						if(tr1->eSolvation < cutoffE/3.0 - 2.0){
							delete tr1;
							if(t1 == token1limit-1){
								phase_done=true;
								t1block_done=true;
							}
							break;
						} else {
							Reference_Frame *trinv1 = Reference_Frame::invert(tr1);
							unsigned int limitlo2 = maximum(t1+1,token2*blocksize2);
							//*out << "limitlo2 " << limitlo2 << " " << limitup2 << endl; out->flush();
							
							for(int t2 = limitlo2 ; t2 < limitup2; t2++){
								transformationscore ts2 = allsorteddimerscores[t2];
								if(!(ts1.p1 == ts2.p1 && ts1.p2 == ts2.p2)){
				  					fstream *transin = &(trans_in[ts2.p1][ts2.p2]);
									transin->seekg (0, ios::beg);
									transin->seekg(Transformation::basic_byte_size*ts2.tid);
			  						transin->read(buf,Transformation::basic_byte_size);
									Transformation *tr2 = new Transformation(buf,TN_BASIC);
									tr2->eSolvation = ts2.particlep;
					  				
									//*out << "t1 " << t1 << " t2 " << t2 << endl; 
									//*out << tr2->eSolvation << " " << (cutoffE - tr1->eSolvation)/2.0 - 2.0 << endl;
									if(tr2->eSolvation < (cutoffE - tr1->eSolvation)/2.0 - 2.0){
				  						delete tr2;
				  						if(t1 == token1limit-1){
				  							*out << "reached cutoff " << t1 << " " << t2 << " " << tr2->eSolvation << " " << cutoffE << endl; out->flush();
											t1block_done=true;
											phase_done=true;
				  						}
				  						break;
				  					} else {
				  						float vdw_repul;
				  						float particlep3=0,etotal;
				  						//compute_trimer_scores(&ts1, tr1,trinv1, &ts2, tr2,&clashes,TRIMER_CLASH_CUTOFF,&particlep3,NUM_FFT_ATOM_TYPES);
				  						{ 
				  							short p1=0, p2=0;
				  							Reference_Frame *tr=NULL;
				  							compute_trimer_scores_generalized(&ts1, tr1, trinv1, &ts2, tr2, &p1, &p2, &tr, &vdw_repul, TRIMER_MIN_VDW_REPUL, &particlep3, NUM_FFT_ATOM_TYPES);
				  							//*out << tr->translation->x << "," << tr->translation->y << "," << tr->translation->z << " " <<
											 // tr->ex->x << "," << tr->ex->y << "," <<tr->ex->z << " " <<tr->ey->x << "," <<tr->ey->y << "," <<tr->ey->z << endl;
				  							delete tr;
				  						}
				  						if(vdw_repul > TRIMER_MIN_VDW_REPUL){
					  						etotal = tr1->eSolvation + tr2->eSolvation + particlep3;
					  						bool insert = true;
					  						/*if(node_heap_size < max_multitransformations)	insert = true;
					  						else*/ insert = (etotal > cutoffE);
					  						if(insert){
					  							*out << vdw_repul << " " << t1 << " " << t2 << " etotal " << etotal << endl; out->flush();
					  							multitransformationscore *mtr = (multitransformationscore*) malloc(sizeof(multitransformationscore));
					  							mtr->p11 = ts1.p1;
					  							mtr->p12 = ts1.p2;
					  							mtr->t1 = ts1.tid;
					  							mtr->p21 = ts2.p1;
					  							mtr->p22 = ts2.p2;
					  							mtr->t2 = ts2.tid;
					  							mtr->particlep = etotal;
					  							if(node_heap_size < max_multitransformations){
					  								node_heap.push_back(mtr);
					  								node_heap_size++;
					  								if(node_heap_size == max_multitransformations){
					  									make_heap(node_heap.begin(),node_heap.end(),multitransscore_betterparticlep);
					  									multitransformationscore *mtr2 = (multitransformationscore*) *(node_heap.begin());
														cutoffE_at_end_phase = minimum(mtr2->particlep, cutoffE_at_end_phase);
														/*Immediate update of cutoffE makes program difficult to debug 
														cutoffE = minimum(mtr2->particlep, cutoffE);*/
					  								}
					  							} else if(mtr->particlep > cutoffE){
					  								node_heap.push_back(mtr);
													push_heap(node_heap.begin(),node_heap.end(),multitransscore_betterparticlep);
													pop_heap(node_heap.begin(),node_heap.end(),multitransscore_betterparticlep);
													node_heap.pop_back();
													multitransformationscore *mtr2 = (multitransformationscore*) *(node_heap.end());
													cutoffE_at_end_phase = minimum(mtr2->particlep, cutoffE_at_end_phase);
													/*Immediate update of cutoffE makes program difficult to debug
													cutoffE = minimum(mtr2->particlep,cutoffE);*/
													*out << "heapmod " << mtr->particlep << " " << mtr2->particlep << endl;
													delete mtr2;
					  							}
					  							if(etotal > maxE)	maxE = etotal;
					  						}
					  					}
					  					delete tr2;
					  				}
								}
								//if(t2 > limitlo2 && (t2-limitlo2)%16 == 0){
								//	*out << "at " << t2 << endl; out->flush();
								//}
				  				if((t1 == token1limit-1) && (t2 == num_transforms-1)){
				  					*out << "reached end of phase " << token1 << " " << token2 << endl;
									phase_done=true;
									t1block_done=true;
								}
							}
							delete trinv1;
			  			}
			  			delete tr1;
					} 
			  	}
			  	num_phase_iterations++;
			}
			cutoffE = cutoffE_at_end_phase;
			sprintf(buff, "%d %f %f %d %d",procid, maxE, cutoffE, phase_done,t1block_done);
			MPI_Ssend(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD);
			if(node_heap_size < max_multitransformations)
				make_heap(node_heap.begin(),node_heap.end(),multitransscore_betterparticlep);
			*out << "maxE " << maxE << " " << cutoffE << " " << num_phase_iterations << endl;
		}
		
		// tell all nodes if t1block is done
		if(procid==0){
			//if(phase == 8)	done = true;
			//if(token1outer == 5)	done = true;
			int t1 = (token1outer+1)*blocksize1;
			if(t1 >= num_transforms)	done=true;
			else {
				transformationscore ts = allsorteddimerscores[t1];
				fstream *transin = &(trans_in[ts.p1][ts.p2]);
				transin->seekg (0, ios::beg);
				transin->seekg(Transformation::basic_byte_size*ts.tid);
				transin->read(buf,Transformation::basic_byte_size);
				Transformation *tr1 = new Transformation(buf,TN_BASIC);
				tr1->eSolvation = ts.particlep;
				if(tr1->eSolvation < cutoffE/3.0 - 2.0){
					done = true;
				}
				delete tr1;
			}
			sprintf(buff, "%d %d",t1block_done, done);
			for(int i = 1; i < numprocs; i++) 
				MPI_Ssend(buff, BUFSIZE, MPI_CHAR, i, GENERATE_TAG, MPI_COMM_WORLD);
		} else {
			MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
			stringstream ss (stringstream::in | stringstream::out);
			ss << buff;
			ss >> t1block_done;
			ss >> done;
		}
		
		float a,b;
		MPI_Allreduce(&a, &b, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
		
		// collect multitransforms
		if((phase<4) || (phase<= 32 && phase%8==0) || phase%32==0 || done){
			int MESSAGES_BEFORE_STATUS_UPDATE=5;  // should be greater than 2	
			if(procid == 0){
				unsigned int num_multitrans[numprocs];
				unsigned int num_messages_received[numprocs];
				num_multitrans[0] = 0;
				unsigned int total_multitrans = 0;
				for(int i=1;i<numprocs;i++){
					MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
					num_messages_received[i] = 1;
					stringstream ss (stringstream::in | stringstream::out);
					ss << buff;
					ss >> num_multitrans[i];
					total_multitrans += num_multitrans[i];
				}
				
				cout << phase << " #candidates " << total_multitrans << " " << t1block_done << endl; cout.flush();
				*out << "collecting candidates phase " << phase << endl;
			
				sprintf(tfilename, "%s/%s/phase%dres",node_tmp_dir,refpdbcode.c_str(),phase);
				fstream mtransout;
				//mtransout.open(tfilename,ios::binary|ios::out);
				mtransout.open(tfilename,ios::out);
				
				//merge transformations from different nodes on the basis of less<Transformation*>
				unsigned int multitrans_read[numprocs];
				unsigned int multitrans_written[numprocs];
				vector<multitransformationscore*> heap;
					
				for(int i = 0 ; i < numprocs ; i++){
					multitrans_read[i] = 0;
					multitrans_written[i] = 0;
				}
				unsigned int count = 0;
				queue<multitransformationscore*> mtrbuffer[numprocs];
				int bytesreceived, multitransreceived;
				// change of stopping condition requires updating status messages
				while(count < minimum(max_multitransformations,total_multitrans)){
					if(count == 0){
						for(int i=1;i<numprocs;i++){
							if(multitrans_read[i] < num_multitrans[i]){
								MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
								num_messages_received[i]++;
								MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
								multitransreceived = bytesreceived/sizeof(multitransformationscore);
								multitrans_read[i] += multitransreceived;
								for(int tri=0; tri<multitransreceived; tri++){
									multitransformationscore *mtr = new multitransformationscore;
									memcpy(mtr,buff+tri*sizeof(multitransformationscore),sizeof(multitransformationscore));
									mtrbuffer[i].push(mtr);
								}
								if(multitransreceived > 0){
									multitransformationscore *mtr = (multitransformationscore*) (mtrbuffer[i].front());
									mtrbuffer[i].pop();
									mtr->procid = i;
									heap.push_back(mtr);
								}
							}
						}
						make_heap(heap.begin(),heap.end(),multitransscore_worseparticlep);
						*out << "initialized heap\n"; out->flush();
					}
					
					pop_heap(heap.begin(),heap.end(),multitransscore_worseparticlep);
					heap.pop_back();
					
					multitransformationscore *min = (multitransformationscore *) *(heap.end());
					mtransout << min->particlep << " " << min->p11 << " " << min->p12 << " " << min->t1 << " " << min->p21 << " " << min->p22 << " " << min->t2 << endl;
					
					if(count <= 10){
						cout << min->particlep << " " <<min->p11 << " " << min->p12 << " " << min->t1 << " " << min->p21 << " " << min->p22 << " " << min->t2 << endl;
					}
					
					unsigned int list_picked = min->procid;
					multitrans_written[list_picked]++;
					
					count++;
					if(count % 100000 == 0){	*out << "at " << count << " " << list_picked << endl; out->flush(); }
					if(count == max_multitransformations){
						*out << "collection cutoff " << cutoffE << " " << min->particlep;
						cutoffE = min->particlep;
					}
					
					if(mtrbuffer[list_picked].empty() && multitrans_read[list_picked] < num_multitrans[list_picked]){
						MPI_Recv(buff, BUFSIZE, MPI_CHAR, list_picked, TAG, MPI_COMM_WORLD, &mpistat);
						MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
						multitransreceived = bytesreceived/sizeof(multitransformationscore);
						multitrans_read[list_picked] += multitransreceived;
						num_messages_received[list_picked]++;
						if(num_messages_received[list_picked] % MESSAGES_BEFORE_STATUS_UPDATE == 0){
							bool collection_done = (count >= minimum(max_multitransformations,total_multitrans));
							stringstream ss (stringstream::in | stringstream::out);
							ss << collection_done << " ";
							char buf[128];
							ss.getline(buf,128);
							MPI_Ssend(buf, 128, MPI_CHAR, list_picked, TAG, MPI_COMM_WORLD);
							if(collection_done)	multitrans_read[list_picked] = num_multitrans[list_picked];
						}
						for(int tri=0; tri<multitransreceived; tri++){
							multitransformationscore *mtr = new multitransformationscore;
							memcpy(mtr,buff+tri*sizeof(multitransformationscore),sizeof(multitransformationscore));
							mtrbuffer[list_picked].push(mtr);
						}	
					}
					if(!mtrbuffer[list_picked].empty()){
						multitransformationscore *mtr = (multitransformationscore*) (mtrbuffer[list_picked].front());
						mtrbuffer[list_picked].pop();
						mtr->procid = list_picked;
						heap.push_back(mtr);
						push_heap(heap.begin(),heap.end(),multitransscore_worseparticlep);
					}
					
					delete min;
				}
				
				mtransout.close();
				cout << "saved transformations " << count << " total " << total_multitrans << " cutoffE " << cutoffE << endl; cout.flush();
				
				// if picked only few transformations, receive Ssend messages from other nodes and relieve them
				if(numprocs > 1 && count < total_multitrans){
					*out << "max reached, relieving other processes and clearing buffers" << endl; out->flush();
					for(int i = 1; i < numprocs; i++){
						while(!mtrbuffer[i].empty()){
							multitransformationscore *mtr = (multitransformationscore*) (mtrbuffer[i].front());
							delete mtr;
							mtrbuffer[i].pop();
						}
						
						while(multitrans_read[i] < num_multitrans[i]){
							MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
							MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
							multitransreceived = bytesreceived/sizeof(multitransformationscore);
							multitrans_read[i] += multitransreceived;
							num_messages_received[i]++;
							if(num_messages_received[i] % MESSAGES_BEFORE_STATUS_UPDATE == 0){
								stringstream ss (stringstream::in | stringstream::out);
								ss << true << " ";
								ss.getline(buff,128);
								MPI_Ssend(buff, 128, MPI_CHAR, i, TAG, MPI_COMM_WORLD);
								multitrans_read[i] = num_multitrans[i];
							}
						}
					}
				}
				
				sprintf(command, "gzip %s/%s/phase%dres",node_tmp_dir,refpdbcode.c_str(),phase);
				ret = system(command);
				cout << command << " " << ret << endl;			
				sprintf(command, "cp %s/%s/phase%dres.gz .",node_tmp_dir,refpdbcode.c_str(),phase);
				ret = system(command);
				cout << command << " " << ret << endl;
			} else {
				stringstream ss (stringstream::in | stringstream::out);
				ss << node_heap_size;
				ss.getline(buff,BUFSIZE);
				MPI_Ssend(buff, BUFSIZE, MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
				unsigned int num_messages_sent=1;
				*out << "done sending #multi_trans " << node_heap_size << endl;
				
				if(node_heap_size>0){
					*out << "heap check " << ((multitransformationscore *) *(node_heap.begin()))->particlep << " " << ((multitransformationscore *) node_heap[node_heap.size()-1])->particlep << endl;
					/*for(vector<multitransformationscore*>::iterator hitr = node_heap.begin(); hitr != node_heap.end(); hitr++){
						*out << ((multitransformationscore *) *(hitr))->particlep << " ";
					}
					*out << node_heap_size << endl;*/
					out->flush();
				} 
				sort(node_heap.begin(),node_heap.end(),multitransscore_betterparticlep);
				int nmtr=0;
				char *current = buff;
				bool collection_done = false;
				while(nmtr < node_heap_size  && !collection_done){
					multitransformationscore *mtr = node_heap[nmtr];
					memcpy(current,mtr,sizeof(multitransformationscore));
					current += sizeof(multitransformationscore);
					//delete mtr;
					if(nmtr==0)	*out << "sort " << phase << " " << mtr->particlep << endl;
					
					nmtr++;
					if((nmtr % 32) == 0){
						MPI_Ssend(buff,32*(sizeof(multitransformationscore)), MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
						current = buff;
						num_messages_sent++;
						if(num_messages_sent % MESSAGES_BEFORE_STATUS_UPDATE == 0){
							MPI_Recv(buff, 128, MPI_CHAR, 0, TAG, MPI_COMM_WORLD, &mpistat);
							stringstream ss (stringstream::in | stringstream::out);
							ss << buff;
							ss >> collection_done;
						}
					}
				}
				if((nmtr % 32) != 0 && !collection_done){
					MPI_Ssend(buff,(nmtr%32)*(sizeof(multitransformationscore)), MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
					num_messages_sent++;
					if(num_messages_sent % MESSAGES_BEFORE_STATUS_UPDATE == 0)
						MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, TAG, MPI_COMM_WORLD, &mpistat);
				}
				//node_heap.clear();
				//*out << "check " << node_heap.size() << endl; out->flush();
				make_heap(node_heap.begin(),node_heap.end(),multitransscore_betterparticlep);
				//*out << "check " << node_heap.size() << endl; out->flush();
				if(node_heap.size()>0){
					*out << "heap check " << ((multitransformationscore *) *(node_heap.begin()))->particlep << " " << ((multitransformationscore *) node_heap[node_heap.size()-1])->particlep << endl;
					out->flush();
				}
				*out << "sent candidates to node 0" << endl;
			}
		}
		phase++;
		
		if(!done){
			if(!t1block_done){
				token2outer += phase_limit/blocksize2;
			} else {
				token1outer++;
				token2outer = (token1outer+1)/blocksize2;
				t1block_done = false;
			}
			if(procid == 0)	*out << "outer limits " << token1outer << " " << token2outer << " " << t1block_done << endl;
		}
	}
	
	time(&current_time);
	*out << "node " << procid << " assembled transformations\t time:" << difftime(current_time,start_time) << "s" << endl; out->flush();
}

void build_grids(){
	Transformation *identity = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
	
	prot_shape[0] = NULL;
	gridsize[0] = gridsize[1] = gridsize[2] = 0;
	
	for(short pi = 0 ; pi < 2; pi++){
		float max_partner_diameter = maximum(prot_object[(pi+1)%3]->c->diameter,prot_object[(pi+2)%3]->c->diameter);
		float max_extent = minimum(max_partner_diameter,40.0);
		prot_object[pi]->build_fft_opls_vdw_grid(grid_spacing,max_extent ,&(prot_shape[pi]),gridsize, identity, true);
	
		if(pi == 0){
			size = gridsize[0] * gridsize[1] * gridsize[2];
			*out << "gridsize " << gridsize[0] << "," << gridsize[1] << "," << gridsize[2] << " " << prot_shape[0] << endl;
			sqrt_size = sqrt(size);
			prot_shape[1] = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
		}
		
		if(scoring_function == FFT_GENERATE_MATCHES_ATOMP){
			num_particlep_arrays = (NUM_FFT_ATOM_TYPES+1)/2;
			*out << "num_particlep_arrays " << num_particlep_arrays << endl;

			prot_particlepgrid[pi] = (MKL_Complex8 **) malloc(sizeof(MKL_Complex8 *) * num_particlep_arrays);
			for(int ti = 0; ti < num_particlep_arrays; ti++)
				prot_particlepgrid[pi][ti] = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
			
			prot_object[pi]->build_fft_atomcontact_grid(grid_spacing,prot_particlepgrid[pi],NUM_FFT_ATOM_TYPES,gridsize, identity, true);
		} else if(scoring_function == FFT_GENERATE_MATCHES_RESIDUE_BKBNP){
			num_particlep_arrays = 11;
			*out << "num_particlep_arrays " << num_particlep_arrays << endl;

			prot_particlepgrid[pi] = (MKL_Complex8 **) malloc(sizeof(MKL_Complex8 *) * num_particlep_arrays);
			for(int ti = 0; ti < num_particlep_arrays; ti++)
				prot_particlepgrid[pi][ti] = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
			
			prot_object[pi]->build_fft_residue_bkbn_centroid_bkbn_centroid_contact_potential_grid(grid_spacing, 
				prot_particlepgrid[pi],22, residue_bkbn_potential,gridsize,identity, true);
		}
	}
}

int main(int argc, char *argv[]){
	time(&start_time);
	int ret = MPI_Init(&argc,&argv);
	if(ret == MPI_SUCCESS){
		MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
		MPI_Comm_rank(MPI_COMM_WORLD,&procid);
				
		if(procid == 0){
			cout << "Job running on " << numprocs << " processors" << endl;
			cout << "#args " << argc << endl;
			cout.flush();
		}
		
		read_molecule_config();
		if(NUM_FFT_ATOM_TYPES == 18){
			//coarsen_atomtypesto18();
			atom_potential = &atom18_potential;
		} else if(NUM_FFT_ATOM_TYPES == 20){
			//coarsen_atomtypesto20();
			atom_potential = &atom20_potential;
		}
		read_dock_config();
		node_tmp_dir = (char*) (new string(string(tmp_dir)+"/"+string(getenv(string("JOB_ID").c_str()))))->c_str();
		
		elect_leader_on_node();
		
		//initialize
		refpdbcode = "log";
		sprintf(command, "%s/cluster_scripts/setup.sh %s %d %s %d",getenv(string("HOME").c_str()),getenv(string("JOB_ID").c_str()),procid, refpdbcode.c_str(), masterprocessonnode);
		ret = system(command);
		
		sprintf(scratch_dir, "%s/%s/%d",node_tmp_dir,refpdbcode.c_str(),procid);
		sprintf(filename, "%s/%s/%sout%d",node_tmp_dir,refpdbcode.c_str(),refpdbcode.c_str(),procid);
		//cout << filename << endl; cout.flush();
		fstream outstream;
		outstream.open(filename,ios::out);
		if(!outstream.good()){
			cout << "ERROR: could not open file " << filename << " " << errno << "\n"; cout.flush();
			exit(-1);
		}
		out = &outstream;
		
		*out << procid << " " << *host << " am_master " << masterprocessonnode << endl;
		*out << "setup " << command << " " << ret << endl;
		
		filetype = atoi(argv[1]);
		docktype = atoi(argv[2]);
		start_state = atoi(argv[3]);
		end_state = atoi(argv[4]);
		*out << "start " << start_state << " end " << end_state << endl;out->flush();
		
		num_units = atoi(argv[5]);;
		Complex *c[num_units];
		string optionsfile = *(new string(argv[6]));
		fstream optin(optionsfile.c_str(), ios::in);
		*out << optionsfile << " " << optin.good() << endl; out->flush();
		
		// read information about individual units			
		for(int i = 0; i < num_units; i++){
			optin.getline(buff,8192);
			if(optin.gcount() > 0){
				stringstream line(buff,stringstream::in);
				string tag,pdbcode,chains;
				line >> tag;
				line >> tag;
				line >> pdbcode;
				line >> chains;
			
				prot_pdbcode[i] = *(new string(pdbcode.c_str()));  
				prot_chains[i] = *(new string(chains.c_str()));
			
				c[i] = new Complex(("../"+prot_pdbcode[i]).c_str(),prot_chains[i].c_str(), filetype);
				Complex* cH =c[i];
				prot_object[i] = new Object(c[i],cH);
			} else {
				cout << "ERROR: Do not have all units" << endl; cout.flush(); 
				exit(-1);
			}
		}
		
		// read results of pairwise docking
		string trans_filename[num_units][num_units];
		for(int i = 0; i < num_units; i++){
			optin.getline(buff,8192);
			if(optin.gcount() > 0){
				stringstream line(buff,stringstream::in);
				string tag;
				line >> tag;
				short i,j;
				line >> i; line >> j;
				line >> trans_filename[i][j];
				trans_in[i][j].open(trans_filename[i][j].c_str(),ios::in);
				if(!trans_in[i][j].good()){
					cout << "ERROR: Do not have all dimer transformations" << endl; cout.flush(); 
					exit(-1);
				}
			} else {
				cout << "ERROR: Do not have all dimer transformations" << endl; cout.flush(); 
				exit(-1);
			}
		}
		
		// read sorted and clustered lists of transformationids
		string sortedscore_filename[num_units][num_units];
		for(int i = 0; i < num_units; i++){
			optin.getline(buff,8192);
			if(optin.gcount() > 0){
				stringstream line(buff,stringstream::in);
				string tag;
				line >> tag;
				short i,j;
				line >> i; line >> j;
				line >> sortedscore_filename[i][j];
			}
		}
		string allsorteddimerscores_filename;
		optin.getline(buff,8192);
		if(optin.gcount() > 0){
			stringstream line(buff,stringstream::in);
			string tag;
			line >> tag;
			line >> allsorteddimerscores_filename;
			allsorteddimerscores_in.open(allsorteddimerscores_filename.c_str(), ios::in);
		}
		
		for(int i=0; i < 2; i++)	looplength[i] = 0;
#ifdef LOOP_CONSTRAINT
		do{
			optin.getline(buff,8192);
			if(optin.gcount() > 0){
				stringstream line(buff,stringstream::in);
				string tag;
				line >> tag;
				int loopindex;
				line >> loopindex;
				line >> looplength[loopindex];
				if(procid == 0)
					cout << "loop constraint " << loopindex << "-" << loopindex+1 << " " << looplength[loopindex] << endl;
			}
		} while(optin.good());
#endif
		optin.close();
		
		float lowerbound=atof(argv[7]);

		if(start_state == FFT_GENERATE_TRIMER){
			build_grids();
			assemble_trimer(lowerbound,1024*512);
		}
		
		if(start_state == SCORE_TRIMER && procid==0){
		}
		
		MPI_Finalize();
		//outstream.close();
		
		if(procid == 0){
			time(&current_time);
			cout << "done" << " " << success << "\t time:" << difftime(current_time,start_time) << "s" << endl;
		}
		
		return 0;
	} else {
		cout << "init failed" << endl;
		return 1;
	}
}
