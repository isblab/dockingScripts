/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "assembl_util.hpp"

MKL_Complex8 *rec_shape, *lig_shape, **rec_atompfft, **lig_atompgrid, *atomp_sum;
// rec_atompgrid has the fourier transforms for atom neighbor grids (one each)
// lig_atompgrid contains fft computed for pairs of atom types 
short num_atomp_arrays=0;

DFTI_DESCRIPTOR_HANDLE fft_desc_handle;
MKL_LONG mkl_status, gridsize[3], strides[4];
unsigned int size;
float sqrt_size;

unsigned int max_transformations=1024*1024*4;
typedef struct {
	float evdw, atomp, evdw_real, evdw_imag;
	unsigned int index, rotindex;
} transformationscore;

typedef struct {
	unsigned int t1,t2;
	float atomp;
	short procid;
} multitransformationscore;

transformationscore *rotation_scores,*node_result,*work0, *work1;
bool current_output_is0=true;
unsigned int num_node_transforms=0;
bool computeatompscore=false;
bool symmetrictrimer=false;

bool transscore_bettervdw(transformationscore t1,transformationscore t2){
	//return(t1.index < t2.index);
	return(t1.evdw > t2.evdw);
}

bool transscore_betteratomp(transformationscore t1,transformationscore t2){
	return(t1.atomp > t2.atomp);
}

bool (*transscore_better)(transformationscore t1,transformationscore t2) = &transscore_bettervdw;

bool multitransscore_betteratomp(multitransformationscore *t1,multitransformationscore *t2){
	return(t1->atomp > t2->atomp);
}

bool multitransscore_worseatomp(multitransformationscore *t1,multitransformationscore *t2){
	return(t1->atomp < t2->atomp);
}

extern float **atom18_potential;


Transformation *read_transformation(char* buf){
	char *current = buf;
	float atomp, evdw;
	unsigned int translation, rotation;
	memcpy(&atomp,current,sizeof(float));
	current += sizeof(float);
	memcpy(&evdw,current,sizeof(float));
	current += sizeof(float);
	memcpy(&translation,current,sizeof(unsigned int));
	current += sizeof(unsigned int);
	memcpy(&rotation,current,sizeof(unsigned int));
	current += sizeof(unsigned int);
	
	Transformation *tr = convert_transformation(translation, rotation);
	tr->eSolvation = atomp;
	tr->eVdw = evdw;
	//tr->votes = rotation;
	//tr->frame_number = translation;
	//*out << atomp << " " << evdw << " " << translation << " " << rotation << endl;
	//tr->print_details(out,TN_BASIC);
	return tr;
}


void assemble_trimer_onenode(int rotstart, int rotend){
	char buf[1024*1024*32],tfilename[512], command[512];
	int numintervals=2048*512;
	int sum_atomp_distribution[numintervals];
	for(int i=0; i<numintervals; i++){
		sum_atomp_distribution[i] = 0;
	} 
	
	sprintf(command, "cp atompdistribution.gz %s/%s/%d/",node_tmp_dir,refpdbcode.c_str(),procid);
	int ret = system(command);
	cout << command << " " << ret << endl;
	sprintf(command, "gunzip %s/%s/%d/atompdistribution.gz",node_tmp_dir,refpdbcode.c_str(),procid);
	ret = system(command);
	cout << command << " " << ret << endl;
	
	sprintf(tfilename, "%s/%s/%d/atompdistribution",node_tmp_dir,refpdbcode.c_str(),procid);
	fstream fin(tfilename, ios::in);
	while(fin.good()){
		fin.getline(buf,1024*1024*32);
		if(fin.gcount() > 0){
			stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
			for(int i = 0; i < numintervals; i++){
				int v;	ss >> v;
				sum_atomp_distribution[i] += v;
			}
		}
	}
	fin.close();
	
	*out << "atomp distribution ";
	for(int i=0; i<numintervals; i++)	*out << sum_atomp_distribution[i] << " "; 
	*out << endl;
	
	out=&cout;
	
	long total_transforms=0;
	for(int j = 0; j < numintervals; j++)	total_transforms += sum_atomp_distribution[j];
	int breakpoint[256+1];
	breakpoint[0]=0;
	breakpoint[256]=numintervals;
	long current_count=0;
	int currentproc=0;
	for(int j = 0; j < numintervals; j++){
		if(current_count < total_transforms*(currentproc+1)/256 && current_count + sum_atomp_distribution[j] >= total_transforms*(currentproc+1)/256){
			currentproc++;
			breakpoint[currentproc] = j;
		}
		current_count += sum_atomp_distribution[j];
	}
	*out << "bucket interval " << breakpoint[procid] << "<->" << breakpoint[procid+1] << endl;  
		
	if(rotstart == 0){
		cout << "total transforms " << total_transforms << " breakpoints ";
		for(int i = 0; i <= 256; i++)	cout << breakpoint[i] << ":" << (breakpoint[i]-numintervals/2.0)*128.0/numintervals <<" ";
		cout << endl;
	}
	
	// split node sorted transforms into 256 intervals
	sprintf(command, "cp catrestrans%d.gz %s/%s/%d/catrestrans.gz",rotstart,node_tmp_dir,refpdbcode.c_str(),procid);
	ret = system(command);
	cout << command << " " << ret << endl;
	sprintf(command, "gunzip %s/%s/%d/catrestrans.gz",node_tmp_dir,refpdbcode.c_str(),procid);
	ret = system(command);
	cout << command << " " << ret << endl;
	sprintf(tfilename, "%s/%s/%d/catrestrans",node_tmp_dir,refpdbcode.c_str(),procid);
	fstream transin(tfilename, ios::in);
	fstream fselected[256];
	for(int i = 0; i < 256; i++){
		fselected[i].open(tfilename, ios::out);
		sprintf(tfilename, "%s/%s/%d/interval%d_node%d",node_tmp_dir,refpdbcode.c_str(),procid,i,rotstart);
		fselected[i].open(tfilename, ios::out);
		fselected[i].setf(ios::fixed, ios::floatfield);
	}
	currentproc=256-1;
	unsigned int count=0,num_written=0;
	while(transin.good()){
		transin.getline(buf,8192);
		if(transin.gcount() > 0){
			stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
			float atomp;
			ss >> atomp;
			
			if(atomp < (breakpoint[currentproc]-numintervals/2.0)*128.0/numintervals){
				currentproc--;
			}
			if(currentproc>=0){
				fselected[currentproc] << buf << endl;
				num_written++;
			}
			count++;
		}
	}
	transin.close();
	for(int i = 0; i< 256; i++){
		fselected[i].close();
	}
	*out << "formed local buckets " << num_written << " " << count << endl;
	
	/*sprintf(command, "gzip %s/%s/%d/catrestrans",node_tmp_dir,refpdbcode.c_str(),procid);
	ret = system(command);
	*out << command << " " << ret << endl;
	sprintf(command, "cp %s/%s/%d/catrestrans.gz trimer/catrestrans%d.gz",node_tmp_dir,refpdbcode.c_str(),procid,procid);
	ret = system(command);
	*out << command << " " << ret << endl;*/
	
	for(int i = 0; i < 256; i++){
		sprintf(command, "gzip %s/%s/%d/interval%d_node%d",node_tmp_dir,refpdbcode.c_str(),procid,i,rotstart);
		ret = system(command);
		if(ret != 0){	
			*out << command << " " << ret << endl;
			ret = system(command);
			*out << command << " " << ret << endl;
		}
	
		sprintf(command, "cp %s/%s/%d/interval%d_node%d.gz trimer/",node_tmp_dir,refpdbcode.c_str(),procid,i,rotstart);
		ret = system(command);
		if(ret != 0){
			*out << command << " " << ret << endl;
			ret = system(command);
			*out << command << " " << ret << endl;
		}
	}
	
	time(&current_time);
	*out << "node " << procid << " done spliting transforms time:" << difftime(current_time,start_time) << "s" << endl; out->flush();
	
	sprintf(command, "rm %s/%s/%d/*",node_tmp_dir,refpdbcode.c_str(),procid);
	ret = system(command);
	*out << command << " " << ret << endl;
}

/*
 * Assume trans/restrans*gz, each node cats and sorts part of the transformations
 */
void assemble_trimer_preparefiles(int rotstart, int rotend){
	float cutoff = 12.0;
	char buf[1024*1024],tfilename[512], command[512];
	for(int i = 0; i < NUM_GENERATION_STATS; i++)	generation_stats[i] = 0;
	/* partition rotations among nodes, each node sorts transforms in restrans and aseembles 200MB chunks
	 * these chunks will be copied on demand during assembly */
	int numintervals=2048*512;
	int atomp_distribution[numintervals], sum_atomp_distribution[numintervals];
	for(int i=0; i<numintervals; i++){
		atomp_distribution[i] = 0;
		sum_atomp_distribution[i] = 0;
	} 
	
	// concatenation	
	if(false){
		read_rotations();
		rotstart = max(rotstart,0);
		rotend = min(rotend,num_rotations);	
		
		sprintf(tfilename, "%s/%s/%d/catrestrans",node_tmp_dir,refpdbcode.c_str(),procid);
		fstream transout(tfilename, ios::out);
		transout.setf(ios::fixed, ios::floatfield);
		for(int i = rotstart; i < rotend; i++){
			if(i%numprocs == procid){
				sprintf(command, "cp trans/restrans%d.gz %s/%s/%d/",i,node_tmp_dir,refpdbcode.c_str(),procid);
				int ret = system(command);
				if(ret != 0)	*out << command << " " << ret << endl;
				
				sprintf(command, "gunzip %s/%s/%d/restrans%d.gz",node_tmp_dir,refpdbcode.c_str(),procid,i);
				ret = system(command);
				if(ret != 0)	*out << command << " " << ret << endl;
				
				fstream transin;		
				sprintf(tfilename, "%s/%s/%d/restrans%d",node_tmp_dir,refpdbcode.c_str(),procid,i);
				transin.open(tfilename,ios::in);
				while(transin.good()){
					transin.getline(buf,8192);
	    			if(transin.gcount() > 0){
	    				stringstream ss (stringstream::in | stringstream::out);
						ss << buf;
						float atomp, evdw;
						ss >> atomp;
						ss >> evdw;
						unsigned int translation;
						ss >> translation;
						transout << atomp << " " << evdw << " " << translation << " " << i << endl;
						if(atomp >= -64 && atomp <64)	atomp_distribution[(int) (atomp*numintervals/128+numintervals/2)]++;
	    			}
				}
				transin.close();
			}
		}
		transout.close();
		
		sprintf(command, "rm %s/%s/%d/restrans*",node_tmp_dir,refpdbcode.c_str(),procid);
		int ret = system(command);
		if(ret != 0)	*out << command << " " << ret << endl;
		
		sprintf(command, "sort -nr %s/%s/%d/catrestrans > %s/%s/%d/t",node_tmp_dir,refpdbcode.c_str(),procid,node_tmp_dir,refpdbcode.c_str(),procid);
		ret = system(command);
		*out << command << " " << ret << endl;
		
		sprintf(command, "mv %s/%s/%d/t %s/%s/%d/catrestrans",node_tmp_dir,refpdbcode.c_str(),procid,node_tmp_dir,refpdbcode.c_str(),procid);
		ret = system(command);
		*out << command << " " << ret << endl;
		
		sprintf(command, "gzip %s/%s/%d/catrestrans",node_tmp_dir,refpdbcode.c_str(),procid);
		ret = system(command);
		*out << command << " " << ret << endl;
		sprintf(command, "cp %s/%s/%d/catrestrans.gz trimer/catrestrans%d.gz",node_tmp_dir,refpdbcode.c_str(),procid,procid);
		ret = system(command);
		*out << command << " " << ret << endl;
	}
	
	if(false){
		sprintf(command, "cp trimer/catrestrans%d.gz %s/%s/%d/catrestrans.gz",procid,node_tmp_dir,refpdbcode.c_str(),procid);
		int ret = system(command);
		*out << command << " " << ret << endl;
		sprintf(command, "gunzip %s/%s/%d/catrestrans.gz",node_tmp_dir,refpdbcode.c_str(),procid);
		ret = system(command);
		*out << command << " " << ret << endl;
		
		sprintf(tfilename, "%s/%s/%d/catrestrans",node_tmp_dir,refpdbcode.c_str(),procid);
		fstream catresin(tfilename,ios::in);
		while(catresin.good()){
			catresin.getline(buf,8192);
			if(catresin.gcount() > 0){
				stringstream ss (stringstream::in | stringstream::out);
				ss << buf;
				float atomp;
				ss >> atomp;
				if(atomp >= -64 && atomp <64)	atomp_distribution[(int) (atomp*numintervals/128+numintervals/2)]++;
			}
		}
		catresin.close();
			
		*out << "atomp distribution ";
		for(int i=0; i<numintervals; i++)	*out << atomp_distribution[i] << " "; 
		*out << endl;
	
		/* form a list of transforms scoring above cutoff; how many are there? 
		sprintf(tfilename, "%s/%s/%d/catrestrans",node_tmp_dir,refpdbcode.c_str(),procid);
		fstream transin(tfilename, ios::in);
		sprintf(tfilename, "%s/%s/%d/atabovecutoff%d",node_tmp_dir,refpdbcode.c_str(),procid,procid);
		fstream fselected(tfilename, ios::out);
		int numselected=0;
		while(transin.good()){
			transin.getline(buf,8192);
			if(transin.gcount() > 0){
				stringstream ss (stringstream::in | stringstream::out);
				ss << buf;
				float atomp;
				ss >> atomp;
				if(atomp >= cutoff){
					fselected << buf << endl;
					numselected++;
				}
			}
		}
		transin.close();
		fselected.close();
		*out << "#above cutoff " << numselected << endl;
		
		sprintf(command, "gzip %s/%s/%d/atabovecutoff%d",node_tmp_dir,refpdbcode.c_str(),procid,procid);
		ret = system(command);
		*out << command << " " << ret << endl;
		
		sprintf(command, "cp %s/%s/%d/atabovecutoff%d.gz trimer/atabovecutoff%d.gz",node_tmp_dir,refpdbcode.c_str(),procid,procid,procid);
		ret = system(command);
		*out << command << " " << ret << endl;
		*/
		
		time(&current_time);
		*out << "node " << procid << " done sorting transforms time:" << difftime(current_time,start_time) << "s" << endl; out->flush();
		
		// reduce atomp distribution
		MPI_Allreduce(atomp_distribution, sum_atomp_distribution, numintervals, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
	
		// decide the bucket for this node to sort
		long total_transforms=0;
		for(int j = 0; j < numintervals; j++)	total_transforms += sum_atomp_distribution[j];
		int breakpoint[numprocs+1];
		breakpoint[0]=0;
		breakpoint[numprocs]=numintervals;
		long current_count=0;
		int currentproc=0;
		for(int j = 0; j < numintervals; j++){
			if(current_count < total_transforms*(currentproc+1)/numprocs && current_count + sum_atomp_distribution[j] >= total_transforms*(currentproc+1)/numprocs){
				currentproc++;
				breakpoint[currentproc] = j;
			}
			current_count += sum_atomp_distribution[j];
		}
		*out << "bucket interval " << breakpoint[procid] << "<->" << breakpoint[procid+1] << endl;  
			
		if(procid == 0){
			cout << "total transforms " << total_transforms << " breakpoints ";
			for(int i = 0; i <= numprocs; i++)	cout << breakpoint[i] << ":" << (breakpoint[i]-numintervals/2.0)*128.0/numintervals <<" ";
			cout << endl;
		}
		
		// split node sorted transforms into numprocs intervals
		sprintf(tfilename, "%s/%s/%d/catrestrans",node_tmp_dir,refpdbcode.c_str(),procid);
		fstream transin(tfilename, ios::in);
		fstream fselected[numprocs];
		for(int i = 0; i < numprocs; i++){
			sprintf(tfilename, "%s/%s/%d/interval%d_node%d",node_tmp_dir,refpdbcode.c_str(),procid,i,procid);
			fselected[i].open(tfilename, ios::out);
			fselected[i].setf(ios::fixed, ios::floatfield);
		}
		currentproc=numprocs-1;
		unsigned int count=0,num_written=0;
		while(transin.good()){
			transin.getline(buf,8192);
			if(transin.gcount() > 0){
				stringstream ss (stringstream::in | stringstream::out);
				ss << buf;
				float atomp;
				ss >> atomp;
				
				if(atomp < (breakpoint[currentproc]-numintervals/2.0)*128.0/numintervals){
					currentproc--;
				}
				if(currentproc>=0){
					fselected[currentproc] << buf << endl;
					num_written++;
				}
				count++;
			}
		}
		transin.close();
		for(int i = 0; i< numprocs; i++){
			fselected[i].close();
		}
		*out << "formed local buckets " << num_written << " " << count << endl;
		
		/*sprintf(command, "gzip %s/%s/%d/catrestrans",node_tmp_dir,refpdbcode.c_str(),procid);
		ret = system(command);
		*out << command << " " << ret << endl;
		sprintf(command, "cp %s/%s/%d/catrestrans.gz trimer/catrestrans%d.gz",node_tmp_dir,refpdbcode.c_str(),procid,procid);
		ret = system(command);
		*out << command << " " << ret << endl;*/
		
		for(int i = 0; i < numprocs; i++){
			sprintf(command, "gzip %s/%s/%d/interval%d_node%d",node_tmp_dir,refpdbcode.c_str(),procid,i,procid);
			ret = system(command);
			if(ret != 0){	
				*out << command << " " << ret << endl;
				ret = system(command);
				*out << command << " " << ret << endl;
			}
		
			sprintf(command, "cp %s/%s/%d/interval%d_node%d.gz trimer/",node_tmp_dir,refpdbcode.c_str(),procid,i,procid);
			ret = system(command);
			if(ret != 0){
				*out << command << " " << ret << endl;
				ret = system(command);
				*out << command << " " << ret << endl;
			}
		}
		
		time(&current_time);
		*out << "node " << procid << " done spliting transforms time:" << difftime(current_time,start_time) << "s" << endl; out->flush();
		
		// all nodes compelted spliting?
		float a,b;
		MPI_Allreduce(&a, &b, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
	}
	
	// each node sorts transforms in its bucket
	int ret;
	sprintf(tfilename, "%s/%s/%d/interval%d",node_tmp_dir,refpdbcode.c_str(),procid,procid);
	stringstream ss (stringstream::in | stringstream::out);
	ss << "cat ";
	for(int i = 0; i < numprocs; i++){
		//if(i != procid){
			sprintf(command, "cp trimer/interval%d_node%d.gz %s/%s/%d/",procid,i,node_tmp_dir,refpdbcode.c_str(),procid);
			ret = system(command);
			if(ret != 0)	*out << command << " " << ret << endl;
		//}
		sprintf(command, "gunzip %s/%s/%d/interval%d_node%d.gz",node_tmp_dir,refpdbcode.c_str(),procid,procid,i);
		ret = system(command);
		if(ret != 0)	*out << command << " " << ret << endl;

		sprintf(command,"%s/%s/%d/interval%d_node%d",node_tmp_dir,refpdbcode.c_str(),procid,procid,i);
		ss << string(command) << " ";
	}
	sprintf(command, "%s/%s/%d/interval%d",node_tmp_dir,refpdbcode.c_str(),procid,procid);
	ss << " > " << string(command);
	ss.getline(buf,1024*1024);
	ret = system(buf);
	*out << buf << " " << ret << endl;
	
	sprintf(command,"rm %s/%s/%d/interval*_node*",node_tmp_dir,refpdbcode.c_str(),procid);
	ret = system(command);
	*out << command << " " << ret << endl;
	sprintf(command,"sort -nr %s/%s/%d/interval%d > %s/%s/%d/t",node_tmp_dir,refpdbcode.c_str(),procid,procid,node_tmp_dir,refpdbcode.c_str(),procid);
	ret = system(command);
	*out << command << " " << ret << endl;
	sprintf(command,"mv %s/%s/%d/t %s/%s/%d/interval%d",node_tmp_dir,refpdbcode.c_str(),procid,node_tmp_dir,refpdbcode.c_str(),procid,procid);
	ret = system(command);
	*out << command << " " << ret << endl;
	sprintf(command,"gzip %s/%s/%d/interval%d",node_tmp_dir,refpdbcode.c_str(),procid,procid);
	ret = system(command);
	*out << command << " " << ret << endl;
	sprintf(command,"cp %s/%s/%d/interval%d.gz trimer/",node_tmp_dir,refpdbcode.c_str(),procid,procid);
	ret = system(command);
	*out << command << " " << ret << endl;	
	
	time(&current_time);
	*out << "node " << procid << " assemble trimer prepare time:" << difftime(current_time,start_time) << "s" << endl; out->flush();
}

#define TRIMER_CLASH_CUTOFF 45 //55
 
/*
 * compute a quick approximation for clashes and if there are few clashes compute atomic potential
 */
void compute_scores(Transformation* tr1, Reference_Frame *trinv1, Transformation* tr2,int *clashes,float *atomp){
	Reference_Frame *tr = Reference_Frame::compose(tr2,trinv1);
	//*out << tr->translation->x << "," << tr->translation->y << "," << tr->translation->z << " " <<
	//	tr->ex->x << "," << tr->ex->y << "," <<tr->ex->z << " " <<tr->ey->x << "," <<tr->ey->y << "," <<tr->ey->z << endl; 
	
	float osc, oic, occ;
	osc = oic = occ = 0;
	int ligand_atomposition_in_recgrid[ligand->c->num_atoms];
	for(int j=0; j < ligand->c->num_atoms; j++){
		Atom *al = ligand->c->atom[j];
		if((al->name).c_str()[0] != 'H'){
			Vector taposition = tr->inverse_transform(*(al->position)) - (*(receptor->c->center) + *(receptor->grid_origin));
			int vx = ((int) (taposition.x/grid_spacing));
			int vy = ((int) (taposition.y/grid_spacing));
			int vz = ((int) (taposition.z/grid_spacing));
			
			vx = (vx + gridsize[0])%gridsize[0];
			vy = (vy + gridsize[1])%gridsize[1];
			vz = (vz + gridsize[2])%gridsize[2];
			
			unsigned int index = (vx*gridsize[1] + vy)*gridsize[2] + vz;
			ligand_atomposition_in_recgrid[j] = index;
			
            if(rec_shape[index].real == 1.0)	osc++;
            else if(rec_shape[index].imag == INTERMEDIATE_IMAG)	oic++;
            else if(rec_shape[index].imag == INTERIOR_IMAG)	occ++;
            
        	if(oic+occ> TRIMER_CLASH_CUTOFF)	break;
        	if(occ > 8){
        		oic = TRIMER_CLASH_CUTOFF + 1 - occ;
        		break;
        	}
		} else
			ligand_atomposition_in_recgrid[j] = -1;
	}
	
	*clashes = oic + occ;
	//*out << "compute score " << *clashes << " "; out->flush();
	
	if(*clashes <= TRIMER_CLASH_CUTOFF){
		float atompscore=0;
		for(int j=0; j < ligand->c->num_atoms; j++)
			if(ligand_atomposition_in_recgrid[j] != -1){
				short aj = ligand->c->atom[j]->atom_type;
				if(aj >= 0 && aj < NUM_FFT_ATOM_TYPES){
					unsigned int index = ligand_atomposition_in_recgrid[j];
                 	for(int ai=0; ai< NUM_FFT_ATOM_TYPES/2; ai++){
						atompscore += rec_atompfft[ai][index].real * atom18_potential[2*ai][aj] + 
										rec_atompfft[ai][index].imag * atom18_potential[2*ai+1][aj];
                 	}
				}
			}
		*atomp = atompscore; 	
	}
	delete tr;
	//*out << "computescore " << tr1->eSolvation << " " << tr2->eSolvation << " " << *atomp << " " << *clashes << endl;
}

void assemble_trimer(float cutoffE, unsigned int max_multitransformations){
	char buf[1024*1024],tfilename[512], command[512];
	int ret;
	
	delete rotation_scores;
	delete work0;
	delete work1;
	
	if(false){	
		sprintf(command,"cp trimer/interval%d.gz %s/%s/%d/",procid,node_tmp_dir,refpdbcode.c_str(),procid);
		ret = system(command);
		*out << command << " " << ret << endl;
		sprintf(command,"gunzip %s/%s/%d/interval%d.gz",node_tmp_dir,refpdbcode.c_str(),procid,procid);
		ret = system(command);
		*out << command << " " << ret << endl;
		
		// write transforms in binary
		sprintf(tfilename, "%s/%s/%d/interval%d",node_tmp_dir,refpdbcode.c_str(),procid,procid);
		fstream transin(tfilename, ios::in);
		sprintf(tfilename, "%s/%s/%d/interval%dbina",node_tmp_dir,refpdbcode.c_str(),procid,procid);
		fstream transbinout(tfilename, ios::binary|ios::out);
		while(transin.good()){
			transin.getline(buf,8192);
			if(transin.gcount() > 0){
				stringstream ss (stringstream::in | stringstream::out);
				ss << buf;
				float atomp, evdw;
				ss >> atomp;
				ss >> evdw;
				unsigned int translation, rotation;
				ss >> translation;
				ss >> rotation;
				transbinout.write((char*) &atomp,sizeof(float));
				transbinout.write((char*) &evdw,sizeof(float));
				transbinout.write((char*) &translation,sizeof(unsigned int));
				transbinout.write((char*) &rotation,sizeof(unsigned int));
			}
		}
		transin.close();
		transbinout.close();
	
		sprintf(command,"gzip %s/%s/%d/interval%dbina",node_tmp_dir,refpdbcode.c_str(),procid,procid);
		ret = system(command);
		*out << command << " " << ret << endl;
		sprintf(command,"cp %s/%s/%d/interval%dbina.gz trimer/",node_tmp_dir,refpdbcode.c_str(),procid,procid);
		ret = system(command);
		*out << command << " " << ret << endl;
	}
	
	read_rotations();
	    
	if(masterprocessonnode){
		/*sprintf(command,"cp trimer/interval255bina.gz %s/%s/",node_tmp_dir,refpdbcode.c_str());
		ret = system(command);
		*out << command << " " << ret << endl;
		sprintf(command,"gunzip %s/%s/interval255bina.gz",node_tmp_dir,refpdbcode.c_str());*/
		sprintf(command,"cp clustered3.trans %s/%s/",node_tmp_dir,refpdbcode.c_str());
		ret = system(command);
		*out << command << " " << ret << endl;
	}
	float a,b;
	MPI_Allreduce(&a, &b, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);	
	
	// work in stages, each stage consists of searching a region maintaining top scoring results, collecting and storing results
	//sprintf(tfilename, "%s/%s/interval255bina",node_tmp_dir,refpdbcode.c_str());
	sprintf(tfilename, "%s/%s/clustered3.trans",node_tmp_dir,refpdbcode.c_str());
	fstream transin(tfilename, ios::in);
	transin.seekg (0, ios::end);
	unsigned short transbinasize = 2*(sizeof(float)+sizeof(unsigned int));
  	unsigned int num_transforms = transin.tellg()/transbinasize;
  	*out << "num transforms " << num_transforms << endl;
  	//num_transforms = 1024*1024;
  	transin.seekg (0, ios::beg);
  	
  	Transformation *identity = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
	receptor->build_fft_vdw_grid(grid_spacing, ligand->c->diameter,&rec_shape,gridsize, identity, true);
	receptor->build_fft_atomp_grid(grid_spacing, ligand->c->diameter,rec_atompfft,gridsize, identity, true);
  	ligand->build_fft_vdw_grid(grid_spacing, receptor->c->diameter,&lig_shape,gridsize, identity, true);
  	
  	float maxE = 0;		
	int phase=0;
	bool done = false;
	unsigned short blocksize1=256*8, blocksize2=256;
	vector<multitransformationscore*> node_heap;
	unsigned int node_heap_size=0;
	unsigned int token1outer=0,token2outer=0;
	unsigned int phase_limit=blocksize2*1250;
	bool t1block_done=false;
	while(!done){
		bool phase_done = false;
		unsigned int token1,token2;
		token1=token1outer;
		token2=token2outer;
		unsigned int token1limit = (token1outer+1)*blocksize1;
		if(token1limit > num_transforms)	token1limit = num_transforms;
		/*float t1Emin;
		transin.seekg (0, ios::beg);
		transin.seekg(transbinasize*1);
		transin.read(buf,transbinasize);
		Transformation *tr1 = read_transformation(buf);
		/*t1Emin = tr1->eSolvation;*/
		
		if(procid == 0){
			//tr1->print_details(&cout,TN_BASIC);			
			bool phase_node_done[numprocs];
			for(int i = 1; i < numprocs; i++)	phase_node_done[i] = false;
			while(!phase_done){
				// receive a request and send work
				MPI_Recv(buff, BUFSIZE, MPI_CHAR, MPI_ANY_SOURCE, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
				stringstream ss (stringstream::in | stringstream::out);
				ss << buff;
				int node;
				ss >> node;
				float f;
				ss >> f;
				if(f > maxE)	maxE = f;
				ss >> f;
				if(f >cutoffE)	cutoffE = f;
				ss >> phase_node_done[node];
				if(!t1block_done)	ss >> t1block_done;
				
				if(!phase_node_done[node]){
					sprintf(buff, "%d %d %f", token1, token2, cutoffE);
					MPI_Ssend(buff, BUFSIZE, MPI_CHAR, node, GENERATE_TAG, MPI_COMM_WORLD);
					*out << "node " << node << " working on " << token1 << " " << token2 << " " << phase_node_done[node] << endl; out->flush();
					token2 = token2 + 1;
				} else {
					*out << "done phase node " << node << endl; 
				}
				
				// ended the computation at the node
				//phase_node_done[node] = phase_node_done[node] || ((token2-token2outer)*blocksize2 > phase_limit) || (token2*blocksize2 > num_transforms);
				
				if(token2 %1000 == 0){
					time(&current_time);
					cout << "at position " << token1 << " " << token2 << " time " <<  difftime(current_time,start_time) << endl; cout.flush();
				}
				
				phase_done = true;
				for(int i = 1; i < numprocs; i++)	phase_done &= phase_node_done[i];
			}
		} else {
			while(!phase_done){
				sprintf(buff, "%d %f %f %d %d",procid, maxE, cutoffE, phase_done, t1block_done);
				MPI_Ssend(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD);
				MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
				stringstream ss (stringstream::in | stringstream::out);
				ss << buff;
				ss >> token1;
				ss >> token2;
				ss >> cutoffE;
				
				phase_done = ((token2-token2outer)*blocksize2 > phase_limit) || (token2*blocksize2 > num_transforms);
				if(phase_done){
					break;
				} else {
			  		// process the given region of transformation couples
			  		unsigned int limit1 = minimum(num_transforms, (token1+1)*blocksize1);
			  		unsigned int limitlo2 = maximum((token1+1)*blocksize1,token2*blocksize2);
			  		unsigned int limitup2 = minimum(num_transforms, (token2+1)*blocksize2);
			  	 
			  		for(int t1 = token1*blocksize1 ; t1 < limit1; t1++){
			  			transin.seekg (0, ios::beg);
			  			transin.seekg(transbinasize*t1);
			  			transin.read(buf,transbinasize);
						Transformation *tr1 = read_transformation(buf);
						if(tr1->eSolvation < cutoffE/3.0 - 2.0){
							delete tr1;
							if(t1 == token1limit-1){
								phase_done=true;
								t1block_done=true;
							}
							break;
						} else {
							Reference_Frame *trinv1 = Reference_Frame::invert(tr1);
							for(int t2 = limitlo2 ; t2 < limitup2; t2++){
								transin.seekg (0, ios::beg);
				  				transin.seekg(transbinasize*t2);
				  				transin.read(buf,transbinasize);
								Transformation *tr2 = read_transformation(buf);
								float d, ud;
								tr1->distance(&d, &ud, tr2);
								//*out << t1 << " " << t2 << " d " << d << " ud " << ud << endl; out->flush();
								//if( !(d <= 4.0 && ud <= 0.2) && !(d <= 3.0 && ud <= 0.3) ){
								if( !(d <= 6.0 && ud <= 0.4) && !(d <= 4.0 && ud <= 0.5) ){
									//*out << tr2->eSolvation << " " << (cutoffE - tr1->eSolvation)/2.0 - 3.0 << endl;
									if(tr2->eSolvation < (cutoffE - tr1->eSolvation)/2.0 - 3.0){
				  						delete tr2;
				  						if(t1 == token1limit-1){
				  							*out << "reached cutoff " << t1 << " " << t2 << " " << tr2->eSolvation << endl; out->flush();
											t1block_done=true;
											phase_done=true;
				  						}
				  						break;
				  					} else {
				  						int clashes;
				  						float atomp3,etotal;
				  						compute_scores(tr1,trinv1,tr2,&clashes,&atomp3);
				  						if(clashes <=TRIMER_CLASH_CUTOFF){
					  						etotal = tr1->eSolvation + tr2->eSolvation + atomp3;
					  						bool insert = true;
					  						/*if(node_heap_size < max_multitransformations)	insert = true;
					  						else*/ insert = (etotal > cutoffE);
					  						if(insert){
					  							*out << clashes << " " << t1 << " " << t2 << " etotal " << etotal << endl; out->flush();
					  							multitransformationscore *mtr = (multitransformationscore*) malloc(sizeof(multitransformationscore));
					  							mtr->t1 = t1;
					  							mtr->t2 = t2;
					  							mtr->atomp = etotal;
					  							if(node_heap_size < max_multitransformations){
					  								node_heap.push_back(mtr);
					  								node_heap_size++;
					  								if(node_heap_size == max_multitransformations){
					  									make_heap(node_heap.begin(),node_heap.end(),multitransscore_betteratomp);
					  									multitransformationscore *mtr2 = (multitransformationscore*) *(node_heap.begin());
														cutoffE = minimum(mtr2->atomp, cutoffE);
					  								}
					  							} else {
					  								node_heap.push_back(mtr);
													push_heap(node_heap.begin(),node_heap.end(),multitransscore_betteratomp);
													pop_heap(node_heap.begin(),node_heap.end(),multitransscore_betteratomp);
													node_heap.pop_back();
													multitransformationscore *mtr2 = (multitransformationscore*) *(node_heap.end());
													cutoffE = minimum(mtr2->atomp,cutoffE);
													*out << "heapmod " << mtr->atomp << " " << mtr2->atomp << endl;
													delete mtr2;
					  							}
					  							if(etotal > maxE)	maxE = etotal;
					  						}
					  						delete tr2;
					  					} else
					  						delete tr2;
					  				}
								} else
									delete tr2;
								//if(t2 > limitlo2 && (t2-limitlo2)%16 == 0){
								//	*out << "at " << t2 << endl; out->flush();
								//}
				  				if((t1 == token1limit-1) && (t2 == num_transforms-1)){
				  					*out << "reached end of phase " << token1 << " " << token2 << endl;
									phase_done=true;
									t1block_done=true;
								}
				  			}
				  			delete trinv1;
				  			delete tr1;
						} 
			  		}
				}
			}
			sprintf(buff, "%d %f %f %d %d",procid, maxE, cutoffE, phase_done,t1block_done);
			MPI_Ssend(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD);
			if(node_heap_size < max_multitransformations)
				make_heap(node_heap.begin(),node_heap.end(),multitransscore_betteratomp);
			*out << "maxE " << maxE << " " << cutoffE << endl;
		}
		
		// tell all nodes if t1block is done
		if(procid==0){
			//if(phase == 2)	done = true;
			//if(token1outer == 5)	done = true;
			int t1 = (token1outer+1)*blocksize1;
			if(t1 >= num_transforms)	done=true;
			else {
				transin.seekg (0, ios::beg);
			  	transin.seekg(transbinasize*t1);
			  	transin.read(buf,transbinasize);
				Transformation *tr1 = read_transformation(buf);
				if(tr1->eSolvation < cutoffE/3.0 - 2.0){
					done = true;
				}
				delete tr1;
			}
			sprintf(buff, "%d %d",t1block_done, done);
			for(int i = 1; i < numprocs; i++) 
				MPI_Ssend(buff, BUFSIZE, MPI_CHAR, i, GENERATE_TAG, MPI_COMM_WORLD);
		} else {
			MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
			stringstream ss (stringstream::in | stringstream::out);
			ss << buff;
			ss >> t1block_done;
			ss >> done;
		}
		
		//write_nodemultitransforms_tofile();
		float a,b;
		MPI_Allreduce(&a, &b, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);	
		if((phase<4) || (phase<= 32 && phase%8==0) || phase%32==0 || done){
			unsigned int num_multitrans[numprocs];	
			if(procid == 0){
				num_multitrans[0] = 0;
				unsigned int total_multitrans = 0;
				for(int i=1;i<numprocs;i++){
					MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
					stringstream ss (stringstream::in | stringstream::out);
					ss << buff;
					ss >> num_multitrans[i];
					total_multitrans += num_multitrans[i];
				}
				
				cout << phase << " #candidates " << total_multitrans << " " << t1block_done << endl; cout.flush();
				*out << "collecting candidates phase " << phase << endl;
			
				sprintf(tfilename, "%s/%s/phase%dres",node_tmp_dir,refpdbcode.c_str(),phase);
				fstream mtransout;
				//mtransout.open(tfilename,ios::binary|ios::out);
				mtransout.open(tfilename,ios::out);
				
				//merge transformations from different nodes on the basis of less<Transformation*>
				unsigned int multitrans_read[numprocs];
				unsigned int multitrans_written[numprocs];
				vector<multitransformationscore*> heap;
					
				for(int i = 0 ; i < numprocs ; i++){
					multitrans_read[i] = 0;
					multitrans_written[i] = 0;
				}
				unsigned int count = 0;
				queue<multitransformationscore*> mtrbuffer[numprocs];
				int bytesreceived, multitransreceived;
				while(count < minimum(max_multitransformations,total_multitrans)){
					if(count == 0){
						for(int i=1;i<numprocs;i++){
							if(multitrans_read[i] < num_multitrans[i]){
								MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
								MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
								multitransreceived = bytesreceived/sizeof(multitransformationscore);
								multitrans_read[i] += multitransreceived;
								for(int tri=0; tri<multitransreceived; tri++){
									multitransformationscore *mtr = new multitransformationscore;
									memcpy(mtr,buff+tri*sizeof(multitransformationscore),sizeof(multitransformationscore));
									mtrbuffer[i].push(mtr);
								}
								if(multitransreceived > 0){
									multitransformationscore *mtr = (multitransformationscore*) (mtrbuffer[i].front());
									mtrbuffer[i].pop();
									mtr->procid = i;
									heap.push_back(mtr);
								}
							}
						}
						make_heap(heap.begin(),heap.end(),multitransscore_worseatomp);
						*out << "initialized heap\n"; out->flush();
					}
					
					pop_heap(heap.begin(),heap.end(),multitransscore_worseatomp);
					heap.pop_back();
					
					multitransformationscore *min = (multitransformationscore *) *(heap.end());
					//mtransout.write((char*) &(min->t1),sizeof(unsigned int));
					//mtransout.write((char*) &(min->t2),sizeof(unsigned int));
					//mtransout.write((char*) &(min->atomp),sizeof(float));
					mtransout << min->atomp << " " << min->t1 << " " << min->t2 << endl;
					
					if(count <= 10){
						cout << min->atomp << " " << min->t1 << " " << min->t2 << endl;
					}
					
					unsigned int list_picked = min->procid;
					multitrans_written[list_picked]++;
					
					count++;
					if(count % 100000 == 0){	*out << "at " << count << " " << list_picked << endl; out->flush(); }
					if(count == max_multitransformations){
						*out << "collection cutoff " << cutoffE << " " << min->atomp;
						cutoffE = min->atomp;
					}
					
					if(mtrbuffer[list_picked].empty() && multitrans_read[list_picked] < num_multitrans[list_picked]){
						MPI_Recv(buff, BUFSIZE, MPI_CHAR, list_picked, TAG, MPI_COMM_WORLD, &mpistat);
						MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
						multitransreceived = bytesreceived/sizeof(multitransformationscore);
						multitrans_read[list_picked] += multitransreceived;
						for(int tri=0; tri<multitransreceived; tri++){
							multitransformationscore *mtr = new multitransformationscore;
							memcpy(mtr,buff+tri*sizeof(multitransformationscore),sizeof(multitransformationscore));
							mtrbuffer[list_picked].push(mtr);
						}	
					}
					if(!mtrbuffer[list_picked].empty()){
						multitransformationscore *mtr = (multitransformationscore*) (mtrbuffer[list_picked].front());
						mtrbuffer[list_picked].pop();
						mtr->procid = list_picked;
						heap.push_back(mtr);
						push_heap(heap.begin(),heap.end(),multitransscore_worseatomp);
					}
					
					delete min;
				}
				
				mtransout.close();
				cout << "saved transformations " << count << " total " << total_multitrans << " cutoffE " << cutoffE << endl; cout.flush();
				
				// if picked only few transformations, receive Ssend messages from other nodes and relieve them
				if(numprocs > 1 && count < total_multitrans){
					*out << "max reached, relieving other processes" << endl; out->flush();
					for(int i = 1; i < numprocs; i++)
						while(multitrans_read[i] < num_multitrans[i]){
							MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
							MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
							multitransreceived = bytesreceived/sizeof(multitransformationscore);
							multitrans_read[i] += multitransreceived;
						}
				}
				
				sprintf(command, "gzip %s/%s/phase%dres",node_tmp_dir,refpdbcode.c_str(),phase);
				ret = system(command);
				cout << command << " " << ret << endl;			
				sprintf(command, "cp %s/%s/phase%dres.gz trimer/",node_tmp_dir,refpdbcode.c_str(),phase);
				ret = system(command);
				cout << command << " " << ret << endl;
			} else {
				stringstream ss (stringstream::in | stringstream::out);
				ss << node_heap_size;
				ss.getline(buff,BUFSIZE);
				MPI_Ssend(buff, BUFSIZE, MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
				*out << "done sending #multi_trans " << node_heap_size << endl;
				
				if(node_heap_size>0){
					*out << "heap check " << ((multitransformationscore *) *(node_heap.begin()))->atomp << " " << ((multitransformationscore *) node_heap[node_heap.size()-1])->atomp << endl;
					/*for(vector<multitransformationscore*>::iterator hitr = node_heap.begin(); hitr != node_heap.end(); hitr++){
						*out << ((multitransformationscore *) *(hitr))->atomp << " ";
					}
					*out << node_heap_size << endl;*/
					out->flush();
				} 
				sort(node_heap.begin(),node_heap.end(),multitransscore_betteratomp);
				int nmtr=0;
				char *current = buff;
				while(nmtr < node_heap_size){
					multitransformationscore *mtr = node_heap[nmtr];
					memcpy(current,mtr,sizeof(multitransformationscore));
					current += sizeof(multitransformationscore);
					//delete mtr;
					if(nmtr==0)	*out << "sort " << phase << " " << mtr->atomp << endl;
					
					nmtr++;
					if((nmtr % 32) == 0){
						MPI_Ssend(buff,32*(sizeof(multitransformationscore)), MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
						current = buff;
					}
				}
				if((nmtr % 32) != 0){
					MPI_Ssend(buff,(nmtr%32)*(sizeof(multitransformationscore)), MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
				}
				//node_heap.clear();
				//*out << "check " << node_heap.size() << endl; out->flush();
				make_heap(node_heap.begin(),node_heap.end(),multitransscore_betteratomp);
				//*out << "check " << node_heap.size() << endl; out->flush();
				if(node_heap.size()>0){
					*out << "heap check " << ((multitransformationscore *) *(node_heap.begin()))->atomp << " " << ((multitransformationscore *) node_heap[node_heap.size()-1])->atomp << endl;
					out->flush();
				}
				*out << "sent candidates to node 0" << endl;
			}
		}
		phase++;
		
		if(!done){
			if(!t1block_done){
				token2outer += phase_limit/blocksize2;
			} else {
				token1outer++;
				token2outer = (token1outer+1)/blocksize2;
				t1block_done = false;
			}
			if(procid == 0)	*out << "outer limits " << token1outer << " " << token2outer << " " << t1block_done << endl;
		}
	}
	
	time(&current_time);
	*out << "node " << procid << " assembled transformations\t time:" << difftime(current_time,start_time) << "s" << endl; out->flush();
}


int main(int argc, char *argv[]){
	time(&start_time);
	int ret = MPI_Init(&argc,&argv);
	if(ret == MPI_SUCCESS){
		MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
		MPI_Comm_rank(MPI_COMM_WORLD,&procid);
				
		if(procid == 0){
			cout << "Job running on " << numprocs << " processors" << endl;
			cout << "#args " << argc << endl;
			cout.flush();
		}
		
		read_molecule_config();
		coarsen_atomtypesto18();
		read_dock_config();
		node_tmp_dir = (char*) (new string(string(tmp_dir)+"/"+string(getenv(string("JOB_ID").c_str()))))->c_str();
		
		elect_leader_on_node();
		
		//initialize
		refpdbcode = string(argv[9]);
		sprintf(command, "%s/cluster_scripts/setup.sh %s %d %s %d",getenv(string("HOME").c_str()),getenv(string("JOB_ID").c_str()),procid, refpdbcode.c_str(), masterprocessonnode);
		ret = system(command);
		
		sprintf(scratch_dir, "%s/%s/%d",node_tmp_dir,refpdbcode.c_str(),procid);
		sprintf(filename, "%s/%s/%sout%d",node_tmp_dir,refpdbcode.c_str(),refpdbcode.c_str(),procid);
		//cout << filename << endl; cout.flush();
		fstream outstream;
		outstream.open(filename,ios::out);
		if(!outstream.good()){
			cout << "ERROR: could not open file " << filename << " " << errno << "\n"; cout.flush();
			exit(-1);
		}
		out = &outstream;
		
		*out << procid << " " << *host << " am_master " << masterprocessonnode << endl;
		*out << "setup " << command << " " << ret << endl;
		
		filetype = atoi(argv[1]);
		docktype = atoi(argv[2]);
		start_state = atoi(argv[3]);
		end_state = atoi(argv[4]);
		*out << "start " << start_state << " end " << end_state << endl;out->flush();
		
		stringstream ss (stringstream::in | stringstream::out);
		string s;
		ss << argv[5] << "_" << argv[6] << "_vs_" << argv[7] << "_" << argv[8] << "fft";
		ss >> s;
		tag = (char*) (new string(s.c_str()))->c_str();
		
		ss.clear();
		string ts;
		ss << s << ".trans";
		ss >> ts;
		transformations_file = (char*) (new string(ts.c_str()))->c_str();
		sprintf(local_transformations_file,"%s/%s",scratch_dir,transformations_file);
		
		rpdbcode = string(argv[5]);
		rchains = string(argv[6]);
		lpdbcode = string(argv[7]);
		lchains = string(argv[8]);
		refrchains = string(argv[10]);
		reflchains = string(argv[11]);
		
		Complex* cr = new Complex(("../"+rpdbcode).c_str(),rchains.c_str(), filetype);
		Complex* crH =cr;// new Complex(("../"+rpdbcode).c_str(),rchains.c_str(), PQR);
		out->flush();
		receptor = new Object(cr,crH);
		
		Complex* cl = new Complex(("../"+lpdbcode).c_str(),lchains.c_str(), filetype);
		Complex* clH = cl;//new Complex(("../"+lpdbcode).c_str(),lchains.c_str(), PQR);
		ligand = new Object(cl, clH);
		
		
		if(start_state == FFT_GENERATE_TRIMER){
			computeatompscore=true;
			// problem with process_receptor since the ifts are being computed there we need the arrays not the ifts
			process_receptor();
			
			//assemble_trimer_preparefiles(atoi(argv[12]),atoi(argv[13]));
			assemble_trimer(77.0,512*1024);
		}
		
		if(start_state == SCORE_TRIMER && procid==0){
			read_rotations();
			// problem with process_receptor since the ifts are being computed there we need the arrays not the ifts
			process_receptor();
			
			receptor->preprocess_receptor();
			ligand->preprocess_ligand();
			receptor->build_contact_grid(ligand->max_grid_point_distance + sqrt(3)*GRID_SPACING/2.0);
			ligand->build_contact_grid(receptor->max_grid_point_distance + sqrt(3)*GRID_SPACING/2.0);
			
			preprocess();
			
			int start = atoi(argv[14]);
			int end = atoi(argv[15]);
			char buf[8192];
			sprintf(buf,"details%d_%d",start,end);
			fstream fdetails(buf,fstream::out);
			
			int type = atoi(argv[12]);
			fstream transin(argv[13],ios::in);
			
			fstream sortin;
			if(type==0)	sortin.open("phase112res", ios::in);
			else sortin.open("sortedsa20ascore", ios::in);
			
			int lineno=0;
			Transformation *tr[3];
			unsigned short transbinasize = 2*(sizeof(float)+sizeof(unsigned int));
			while(sortin.good() && lineno<end-1){
				float f;
				sortin >> f;
				long tid1,tid2;
				sortin >> tid1;
				if(type==0)	sortin >> tid2;
				if(lineno>=start){
					if(type==0){
						cout << tid1 << " " << tid2 << endl; cout.flush();
						transin.seekg (0, ios::beg);
					  	transin.seekg(transbinasize*tid1);
					  	transin.read(buf,transbinasize);
						tr[0] = read_transformation(buf);
						transin.seekg (0, ios::beg);
					  	transin.seekg(transbinasize*tid2);
					  	transin.read(buf,transbinasize);
						tr[1] = read_transformation(buf);
					} else {
						transin.seekg (0, ios::beg);
					  	transin.seekg(Transformation::basic_byte_size*tid1);
					  	transin.read(buf,Transformation::basic_byte_size);
					  	tr[0] = new Transformation(buf,TN_BASIC);
					  	tr[1] = new Transformation(buf,TN_BASIC);
					}
					Reference_Frame *tr0inv = Reference_Frame::invert(tr[0]);
					
					tr[0]->frame_number = tid1;
					tr[0]->vmetrics = new VerificationMetrics();
					tr[0]->vmetrics->rmsd = tid2;
					if(type==0){
						Reference_Frame *tr2 = Reference_Frame::compose(tr[1],tr0inv);
						tr[2] = new Transformation(tr2->translation, tr2->ex,tr2->ey,1.0,0,0);
						Reference_Frame *tr3 = Reference_Frame::compose(tr[1],tr[1]);
						tr3->distance(&(tr[0]->vmetrics->delta_r),&(tr[0]->vmetrics->delta_U),tr0inv);
					} else {
						Reference_Frame *tr2 = Reference_Frame::compose(tr[1],tr[0]);
						tr[2] = new Transformation(tr2->translation, tr2->ex,tr2->ey,1.0,0,0);
						tr[2]->distance(&(tr[0]->vmetrics->delta_r),&(tr[0]->vmetrics->delta_U),tr0inv);
					}
					
					for(int i=0; i < 3; i++){
						receptor->compute_detailed_scores(ligand,tr[i]); 
					}
					
					DetailedScoringMetrics *details = tr[0]->detailed_scores;
					for(int i = 0 ; i < NUM_RESIDUE_TYPES; i++){
						details->delta_sasa[i] = maximum(details->delta_sasa[i],0);
						details->delta_sasa[i] += maximum(tr[1]->detailed_scores->delta_sasa[i],0);
						details->delta_sasa[i] += maximum(tr[2]->detailed_scores->delta_sasa[i],0);
						details->delta_vdwsa[i] = maximum(details->delta_sasa[i],0);
						details->delta_vdwsa[i] += maximum(tr[1]->detailed_scores->delta_vdwsa[i],0);
						details->delta_vdwsa[i] += maximum(tr[2]->detailed_scores->delta_vdwsa[i],0);
						for(int j = 0; j < NUM_RESIDUE_TYPES; j++){
							details->residue_contacts_core[i][j] += (tr[1]->detailed_scores->residue_contacts_core[i][j]+tr[2]->detailed_scores->residue_contacts_core[i][j]);
							details->residue_contacts_rim[i][j] += (tr[1]->detailed_scores->residue_contacts_rim[i][j]+tr[2]->detailed_scores->residue_contacts_rim[i][j]);
						}
					}
					for(int i = 0; i < NUM_ATOM_TYPES; i++){
						details->delta_sasa_atom[i] = maximum(details->delta_sasa_atom[i],0);
						details->delta_sasa_atom[i] += maximum(tr[1]->detailed_scores->delta_sasa_atom[i],0);
						details->delta_sasa_atom[i] += maximum(tr[2]->detailed_scores->delta_sasa_atom[i],0);
						details->delta_vdwsa_atom[i] = maximum(details->delta_vdwsa_atom[i],0);  
						details->delta_vdwsa_atom[i] += maximum(tr[1]->detailed_scores->delta_vdwsa_atom[i],0);
						details->delta_vdwsa_atom[i] += maximum(tr[2]->detailed_scores->delta_vdwsa_atom[i],0);
						for(int j = 0 ; j < NUM_ATOM_TYPES; j++){
							details->atom_contacts[i][j] += (tr[1]->detailed_scores->atom_contacts[i][j]+tr[2]->detailed_scores->atom_contacts[i][j]);
						}
					}
					
					cout << "clashes " << tr[0]->num_clashes << " " << tr[1]->num_clashes<< " " << tr[2]->num_clashes << endl;
					cout << "bbclashes " << tr[0]->num_bbclashes << " " << tr[1]->num_bbclashes<< " " << tr[2]->num_bbclashes << endl;
					tr[0]->vmetrics->lrmsd = (tr[0]->num_clashes+tr[1]->num_clashes+tr[2]->num_clashes);
					tr[0]->vmetrics->irmsd = (tr[0]->num_bbclashes+tr[1]->num_bbclashes+tr[2]->num_bbclashes);
					tr[0]->print_details(&fdetails,TN_PROTPROT_DETAILED_SCORE_VERIFY);
					
					//delete tr0inv;
					//delete tr2;
					for(int i=0; i < 3; i++)	delete tr[i];
				}
				lineno++;
			}
			transin.close();
			sortin.close();
			fdetails.close();
		}
		
		MPI_Finalize();
		//outstream.close();
		
		if(procid == 0){
			time(&current_time);
			cout << "done" << " " << success << "\t time:" << difftime(current_time,start_time) << "s" << endl;
		}
		
		return 0;
	} else {
		cout << "init failed" << endl;
		return 1;
	}
}
