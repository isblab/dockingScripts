/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "assembl_util.hpp"
#define NUM_FFT_ATOM_TYPES 20

float grid_spacing=FFT_GRID_SPACING;
short num_particlep_arrays=0;

DFTI_DESCRIPTOR_HANDLE fft_desc_handle;
MKL_LONG mkl_status, gridsize[3], strides[4];
unsigned int size;
float sqrt_size;

typedef struct {
	short p1[3],p2[3];
	unsigned int tid[3];
	float particlep;
	short procid;
} multitransformationscore;

bool multitransscore_betterparticlep(multitransformationscore *t1,multitransformationscore *t2){
	return(t1->particlep > t2->particlep);
}

bool multitransscore_worseparticlep(multitransformationscore *t1,multitransformationscore *t2){
	return(t1->particlep < t2->particlep);
}

extern float **atom18_potential, **atom20_potential;
float ***atom_potential;

fstream trans_in[4][4], allsorteddimerscores_in;

#define TRIMER_CLASH_CUTOFF 40
#define TETRAMER_CLASH_CUTOFF 80 // twice trimer_clash_cutoff 60

#define TRIMER_MIN_VDW_REPUL -320*INTERMEDIATE_IMAG*INTERMEDIATE_IMAG
#define TETRAMER_MIN_VDW_REPUL -800*INTERMEDIATE_IMAG*INTERMEDIATE_IMAG

int scoring_function = FFT_GENERATE_MATCHES_VDW;
//int scoring_function = FFT_GENERATE_MATCHES_RESIDUE_BKBNP;

/*
 * Assume first two form a triangle, assume that transformations were generated such that ts->p1 < ts->p2
 * the checking of loop constraints are taken care of in the generation of transformation (3 of them here) and in the formation of trimers (remaining 3 checks here)
 */ 
void compute_tetramer_scores(transformationscore *ts1, Transformation* tr1, Reference_Frame *trinv1, transformationscore *ts2, Transformation* tr2, transformationscore *ts3, Transformation* tr3,
  transformationscore *trimer_ts3, Transformation *trimer_tr3, Reference_Frame *trimer_tr3inv, unsigned short fourth_protein, float *vdw_repul,float *particlep){
 	short p1=0, p2=0;
	float vdw_repul_1 = TRIMER_MIN_VDW_REPUL-1, vdw_repul_2 = TRIMER_MIN_VDW_REPUL-1 ;
	float particlep3_1=0, particlep3_2=0;
	Reference_Frame *rf_1=NULL, *rf_2=NULL;
	
	bool one_three_form_trimer = (ts1->p1 == ts3->p1 || ts1->p1 == ts3->p2 || ts1->p2 == ts3->p1 || ts1->p2 == ts3->p2);
	if(one_three_form_trimer)
		compute_trimer_scores_generalized(ts1, tr1,trinv1, ts3, tr3, &p1, &p2, &rf_1,&vdw_repul_1,TRIMER_MIN_VDW_REPUL,&particlep3_1,NUM_FFT_ATOM_TYPES);
	else {
		Reference_Frame *trinv2 = Reference_Frame::invert(tr2);
		compute_trimer_scores_generalized(ts2, tr2,trinv2, ts3, tr3, &p1, &p2, &rf_1,&vdw_repul_1,TRIMER_MIN_VDW_REPUL,&particlep3_1,NUM_FFT_ATOM_TYPES);
		delete trinv2;
	}
	
	if(vdw_repul_1 > TRIMER_MIN_VDW_REPUL){
		short fixed_protein;
		if(ts1->p1 == ts2->p1 || ts1->p1 == ts2->p2)
			fixed_protein = ts1->p1;
		else
			fixed_protein = ts1->p2;
			
		bool forms_star = (ts3->p1 == fixed_protein || ts3->p2 == fixed_protein);
		if(forms_star){
			Reference_Frame *trinv2 = Reference_Frame::invert(tr2);
			compute_trimer_scores_generalized(ts2, tr2,trinv2, ts3, tr3, &p1, &p2, &rf_2,&vdw_repul_2,TRIMER_MIN_VDW_REPUL,&particlep3_2,NUM_FFT_ATOM_TYPES);
			delete trinv2;
		} else {
			compute_trimer_scores_generalized(trimer_ts3, trimer_tr3,trimer_tr3inv, ts3, tr3, &p1, &p2, &rf_2,&vdw_repul_2,TRIMER_MIN_VDW_REPUL,&particlep3_2,NUM_FFT_ATOM_TYPES);
		}
		
		delete rf_2;
	}
	delete rf_1;
		
	*vdw_repul = vdw_repul_1 + vdw_repul_2;
	
	if(vdw_repul_1 <= TRIMER_MIN_VDW_REPUL || vdw_repul_2 <= TRIMER_MIN_VDW_REPUL)	*vdw_repul = TETRAMER_MIN_VDW_REPUL;
	*particlep = particlep3_1 + particlep3_2;
	
#ifdef ASSMBL_DEBUG		
	//*out << "4mer computescore " << tr1->eSolvation << " " << tr2->eSolvation << " " << tr3->eSolvation << " " << vdw_repul_1 << " " << vdw_repul_2 << " " << *vdw_repul << " " << *particlep << endl;
#endif	
}

unsigned int token1outer=0,token2outer=0,token3outer=0;

void assemble_tetramer(float cutoffE, unsigned int max_multitransformations){
	char buf[1024*1024],tfilename[512], command[512];
	int ret;
	
	int a=0,b;
	MPI_Allreduce(&a,&b, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);	
	
	unsigned int num_transforms = 0;
	allsorteddimerscores_in.seekg (0, ios::beg);
	
	while(!allsorteddimerscores_in.eof()){
		allsorteddimerscores_in.getline(buf,8192);
		if(allsorteddimerscores_in.gcount() > 0)
			num_transforms++;
	}
	allsorteddimerscores_in.clear();
	if(procid == 0)
		cout << "num transforms " << num_transforms << endl;
  	else
  		*out << "num transforms " << num_transforms << endl; out->flush();
  	transformationscore allsorteddimerscores[num_transforms];
  	allsorteddimerscores_in.seekg(0, ios::beg);
  	int ti=0;
  	while(!allsorteddimerscores_in.eof()){
		allsorteddimerscores_in.getline(buf,8192);
		if(allsorteddimerscores_in.gcount() > 0){
			stringstream line(buf,stringstream::in);
			line >> allsorteddimerscores[ti].particlep;
			line >> allsorteddimerscores[ti].tid;
			line >> allsorteddimerscores[ti].p1;
			line >> allsorteddimerscores[ti].p2;
			line >> allsorteddimerscores[ti].num_clashes;
			//*out << string(buf) << endl; out->flush();
			ti++;
		}
	}
  	
	// work in stages, each stage consists of searching a region maintaining top scoring results, collecting and storing results
  	Transformation *identity = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
	
	//what grids to build?
	
  	float maxE = 0;		
	bool done = false;
	unsigned short blocksize1=16, blocksize2=16, blocksize3=128;
	vector<multitransformationscore*> node_heap;
	unsigned int node_heap_size=0;
	/* each unit of work is a cell in the 3 dimensional matrix, a phase is the completion of work along the 3rd dimension 
	 for a given value of token1 and token2 */ 
	int phase=0;
	unsigned int phase_limit=blocksize3*600;
	bool t1block_done=false, t2block_done=false;
	while(!done){
		bool phase_done = false;
		unsigned int token1,token2,token3;
		token1=token1outer;
		token2=token2outer;
		token3=token3outer;
		unsigned int token1limit = (token1outer+1)*blocksize1;
		if(token1limit > num_transforms)	token1limit = num_transforms;
		unsigned int token2limit = (token2outer+1)*blocksize2;
		if(token2limit > num_transforms)	token2limit = num_transforms;
		unsigned int num_phase_iterations=0;
		
		if(procid == 0){
			float cutoffE_at_begin_phase = cutoffE;
			bool phase_node_done[numprocs];
			for(int i = 1; i < numprocs; i++)	phase_node_done[i] = false;
			while(!phase_done){
				// receive a request and send work
				MPI_Recv(buff, BUFSIZE, MPI_CHAR, MPI_ANY_SOURCE, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
				stringstream ss (stringstream::in | stringstream::out);
				ss << buff;
				int node;
				ss >> node;
				float f;
				ss >> f;
				if(f > maxE)	maxE = f;
				ss >> f;
				if(f >cutoffE)	cutoffE = f;
				ss >> phase_node_done[node];
				bool node_block_status;
				ss >> node_block_status;
				if(!t2block_done)	t2block_done = node_block_status;
				if(!t1block_done)	ss >> t1block_done;
				
				if(!phase_node_done[node]){
					sprintf(buff, "%d %d %d %f", token1, token2, token3, cutoffE_at_begin_phase);
					MPI_Ssend(buff, BUFSIZE, MPI_CHAR, node, GENERATE_TAG, MPI_COMM_WORLD);
					*out << "node " << node << " working on " << token1 << " " << token2 << " " << token3 << " " << phase_node_done[node] << endl; out->flush();
					token3 = token3 + 1;
				} else {
					*out << "done phase node " << node << endl; 
				}
				
				if(token3 %1000 == 0){
					time(&current_time);
					cout << "at position " << token1 << " " << token2 << " " << token3 << " time " <<  difftime(current_time,start_time) << endl; cout.flush();
				}
				
				phase_done = true;
				for(int i = 1; i < numprocs; i++)	phase_done &= phase_node_done[i];
			}
		} else {
			float cutoffE_at_begin_phase, cutoffE_at_end_phase;
			while(!phase_done){
				sprintf(buff, "%d %f %f %d %d %d",procid, maxE, cutoffE, phase_done, t2block_done, t1block_done);
				MPI_Ssend(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD);
				*out << "receiving work from master\n"; out->flush();
				MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
				stringstream ss (stringstream::in | stringstream::out);
				ss << buff;
				ss >> token1;
				ss >> token2;
				ss >> token3;
				
				/* Updating cutoffE on the fly speeds up the algorithm, but debugging is difficult */
				if(num_phase_iterations == 0){
					ss >> cutoffE;
					cutoffE_at_begin_phase = cutoffE;
					cutoffE_at_end_phase = cutoffE;
				}
				
				*out << "working on " << token1 << " " << token2 << " " << token3 << " " << cutoffE << endl; out->flush();
				
				phase_done = ((token3-token3outer)*blocksize3 > phase_limit) || (token3*blocksize3 > num_transforms);
				if(phase_done){
					break;
				} else {
			  		// process the given region of transformation triples
			  		unsigned int limit1 = minimum(num_transforms, (token1+1)*blocksize1);
			  		unsigned int limitup2 = minimum(num_transforms, (token2+1)*blocksize2);
			  		unsigned int limitup3 = minimum(num_transforms, (token3+1)*blocksize3);
			  	 	
			  	 	*out << "t1limits " << token1*blocksize1 << ":" << limit1 << endl;
			  		for(int t1 = token1*blocksize1 ; t1 < limit1; t1++){
			  			transformationscore ts1 = allsorteddimerscores[t1];
			  			fstream *transin = &(trans_in[ts1.p1][ts1.p2]);
			  			transin->seekg(0, ios::beg);
			  			transin->seekg(Transformation::basic_byte_size*ts1.tid);
			  			transin->read(buf,Transformation::basic_byte_size);
						Transformation *tr1 = new Transformation(buf,TN_BASIC);
						tr1->eSolvation = ts1.particlep;
#ifdef LOOP_CONSTRAINT
					  if(ts1.p2 == ts1.p1+1 && !chain_continuous(prot_object[ts1.p1]->c,prot_object[ts1.p2]->c,tr1,false,looplength[ts1.p1])){
					  	delete tr1;
					  	continue; 
					  } else
					  {
#else
					  {					  	
#endif
					  	if(tr1->eSolvation < cutoffE/6.0 - 1.5){
							delete tr1;
							if(t1 == token1limit-1){
								phase_done=true;
								t2block_done=t1block_done=true;
							}
							break;
						} else {
							Reference_Frame *trinv1 = Reference_Frame::invert(tr1);
							unsigned int limitlo2 = maximum(t1+1,token2*blocksize2);
#ifdef ASSMBL_DEBUG
							*out << "t2limits " << limitlo2 << ":" << limitup2 << endl;
#endif
							for(int t2 = limitlo2 ; t2 < limitup2; t2++){
								transformationscore ts2 = allsorteddimerscores[t2];
								// not the same edge in the assembly
								if(!(ts1.p1 == ts2.p1 && ts1.p2 == ts2.p2)){
									fstream *transin = &(trans_in[ts2.p1][ts2.p2]);
									transin->seekg (0, ios::beg);
									transin->seekg(Transformation::basic_byte_size*ts2.tid);
			  						transin->read(buf,Transformation::basic_byte_size);
									Transformation *tr2 = new Transformation(buf,TN_BASIC);
									tr2->eSolvation = ts2.particlep;
#ifdef LOOP_CONSTRAINT
					  			  if(ts2.p2 == ts2.p1+1 && !chain_continuous(prot_object[ts2.p1]->c,prot_object[ts2.p2]->c,tr2,false,looplength[ts2.p1])){
					  				delete tr2;
					  				continue;
					  			  } else {
#else
					  			  {
#endif					  				
									if(tr2->eSolvation < ((cutoffE - tr1->eSolvation)/5.0 - 1.5)){
				  						delete tr2;
				  						if(t2 == token2limit-1){
											t2block_done=true;
										}
				  						break;
				  					} else {
						  				bool first_two_form_trimer = (ts1.p1 == ts2.p1 || ts1.p1 == ts2.p2 || ts1.p2 == ts2.p1 || ts1.p2 == ts2.p2);
										bool loop_over_t3 = true;
										unsigned short fourth_protein;
										float trimer_vdw_repul=0;
				  						float particlep3=0,etrimer;
				  						short trimer_p1=0, trimer_p2=0;
				  						Transformation *trimer_tr3=NULL;
				  						Reference_Frame *trimer_rf3=NULL, *trimer_tr3inv=NULL;
				  						transformationscore trimer_ts3;
										
										if(first_two_form_trimer){
						  					compute_trimer_scores_generalized(&ts1, tr1,trinv1, &ts2, tr2,&trimer_p1, &trimer_p2, &trimer_rf3,&trimer_vdw_repul,TRIMER_MIN_VDW_REPUL,&particlep3,NUM_FFT_ATOM_TYPES);
						  					if(trimer_vdw_repul > TRIMER_MIN_VDW_REPUL){
					  							etrimer = tr1->eSolvation + tr2->eSolvation + particlep3;
#ifdef ASSMBL_DEBUG
//					  							*out << "12trimer " << t1 << " " << t2 << " etrimer " << etrimer << " clashes " << trimer_vdw_repul << endl; out->flush();
#endif
					  							unsigned short trimer_pindices[3];
					  							trimer_pindices[0] = ts1.p1;
					  							trimer_pindices[1] = ts1.p2;
					  							if(ts2.p1 == ts1.p1 || ts2.p1 == ts1.p2)	 trimer_pindices[2] = ts2.p2;
					  							else	trimer_pindices[2] = ts2.p1;
					  							
					  							fourth_protein = 6;
					  							for(int pti=0; pti<3; pti++)	fourth_protein = fourth_protein - trimer_pindices[pti];
					  							
					  							trimer_ts3.p1 = trimer_p1;
						  						trimer_ts3.p2 = trimer_p2;
						  						trimer_tr3 = new Transformation(new Vector(trimer_rf3->translation), new Vector(trimer_rf3->ex), new Vector(trimer_rf3->ey), 1.0, 0 , -1);
						  						trimer_tr3inv = Reference_Frame::invert(trimer_tr3);
				  							} else
				  								loop_over_t3 = false;
										} 
										
										if(loop_over_t3){ 
					  						unsigned int limitlo3 = maximum(t2+1,token3*blocksize3);
#ifdef ASSMBL_DEBUG
//					  						*out << "t3limits " << limitlo3 << ":" << limitup3 << endl;
#endif
					  						for(int t3 = limitlo3 ; t3 < limitup3; t3++){
												transformationscore ts3 = allsorteddimerscores[t3];
											
												//*out << t3 << " " << ts1.p1 << ":" << ts1.p2 << " " << ts2.p1 << ":" << ts2.p2 << " " << ts3.p1 << ":" << ts3.p2 << " " << first_two_form_trimer << fourth_protein << endl;
												 
												if((first_two_form_trimer && (ts3.p1 == fourth_protein || ts3.p2 == fourth_protein)) || (!first_two_form_trimer && !(ts1.p1 == ts3.p1 && ts1.p2 == ts3.p2) && !(ts2.p1 == ts3.p1 && ts2.p2 == ts3.p2) 
												 && (ts1.p1 == ts3.p1 || ts1.p1 == ts3.p2 || ts1.p2 == ts3.p1 || ts1.p2 == ts3.p2))){
#ifdef ASSMBL_DEBUG
//													*out << "t123 " << t1 << " " << t2 << " " << t3 << " fourth protein " << fourth_protein << "\t" << tr1->frame_number << " " << tr2->frame_number << " " << ts3.tid << endl; out->flush();
#endif
													fstream *transin = &(trans_in[ts3.p1][ts3.p2]);
													transin->seekg (0, ios::beg);
													transin->seekg(Transformation::basic_byte_size*ts3.tid);
													transin->read(buf,Transformation::basic_byte_size);
							  						Transformation *tr3 = new Transformation(buf,TN_BASIC);
													tr3->eSolvation = ts3.particlep;
													//*out << "after file read tr3->frame_number " << tr3->frame_number << " ts3.tid " << ts3.tid << " p1:p2 " << ts3.p1 << ":" << ts3.p2 << endl;

#ifdef LOOP_CONSTRAINT
					  							  if(ts3.p2 == ts3.p1+1 && !chain_continuous(prot_object[ts3.p1]->c,prot_object[ts3.p2]->c,tr3,false,looplength[ts3.p1])){
					  							  	delete tr3;
					  							  	continue;
					  							  } else {
#else
					  							  {
#endif															
													if((first_two_form_trimer && (tr3->eSolvation < ((cutoffE - etrimer)/3.0 - 1.5))) || 
													 (!first_two_form_trimer && (tr3->eSolvation < ((cutoffE - (tr1->eSolvation + tr2->eSolvation))/4.0 - 1.5)))){
									  					delete tr3;
									  					break;
													} else {
														if(!first_two_form_trimer){
															compute_trimer_scores_generalized(&ts1, tr1,trinv1, &ts3, tr3, &trimer_p1, &trimer_p2, &trimer_rf3,&trimer_vdw_repul,TRIMER_MIN_VDW_REPUL,&particlep3,NUM_FFT_ATOM_TYPES);
								  							if(trimer_vdw_repul >TRIMER_MIN_VDW_REPUL){
									  							etrimer = tr1->eSolvation + tr3->eSolvation + particlep3;
#ifdef ASSMBL_DEBUG
//									  							*out << "13trimer " << t1 << " " << t2 << " " << t3 << " etrimer " << etrimer << " clashes " << trimer_vdw_repul << endl; out->flush();
#endif
									  							if(tr2->eSolvation < (cutoffE - etrimer)/3.0 - 1.5){
									  								delete trimer_rf3;
											  						delete tr3;
											  						continue;
																}
								  							} else {
								  								delete trimer_rf3;
								  								delete tr3;
								  								continue;
								  							}
														}
														float tetramer_vdw_repul;
														float particlep4;
														if(first_two_form_trimer){
															//*out << "before call tr3->frame_number " << tr3->frame_number << endl;
															compute_tetramer_scores(&ts1, tr1,trinv1, &ts2, tr2, &ts3, tr3, &trimer_ts3, trimer_tr3, trimer_tr3inv, fourth_protein, &tetramer_vdw_repul,&particlep4);
														} else {
															unsigned short trimer_pindices[3];
								  							trimer_pindices[0] = ts1.p1;
								  							trimer_pindices[1] = ts1.p2;
								  							if(ts3.p1 == ts1.p1 || ts3.p1 == ts1.p2)	 trimer_pindices[2] = ts3.p2;
								  							else	trimer_pindices[2] = ts3.p1;
								  							
								  							fourth_protein = 6;
								  							for(int pti=0; pti<3; pti++)	fourth_protein = fourth_protein - trimer_pindices[pti];
								  							
								  							trimer_ts3.p1 = trimer_p1;
									  						trimer_ts3.p2 = trimer_p2;
									  						trimer_tr3 = new Transformation(trimer_rf3->translation, trimer_rf3->ex, trimer_rf3->ey, 1.0, 0 , -1);
									  						trimer_tr3inv = Reference_Frame::invert(trimer_tr3);
						  						
															compute_tetramer_scores(&ts1, tr1,trinv1, &ts3, tr3, &ts2, tr2, &trimer_ts3, trimer_tr3, trimer_tr3inv, fourth_protein, &tetramer_vdw_repul,&particlep4);
															
															delete trimer_tr3;
			  												delete trimer_tr3inv;
														}
				  										if(tetramer_vdw_repul > TETRAMER_MIN_VDW_REPUL){  
					  										float etotal = etrimer + tr3->eSolvation + particlep4;
					  										if(etotal > cutoffE){
					  											*out << t1 << " " << t2 << " " << t3 << " etetramer " << etotal << "\t"; out->flush();
									  							multitransformationscore *mtr = (multitransformationscore*) malloc(sizeof(multitransformationscore));
									  							mtr->p1[0] = ts1.p1;
									  							mtr->p2[0] = ts1.p2;
									  							mtr->tid[0] = ts1.tid;
									  							mtr->p1[1] = ts2.p1;
									  							mtr->p2[1] = ts2.p2;
									  							mtr->tid[1] = ts2.tid;
									  							mtr->p1[2] = ts3.p1;
									  							mtr->p2[2] = ts3.p2;
									  							mtr->tid[2] = ts3.tid;
									  							mtr->particlep = etotal;
									  							if(node_heap_size < max_multitransformations){
									  								node_heap.push_back(mtr);
									  								node_heap_size++;
									  								if(node_heap_size == max_multitransformations){
									  									make_heap(node_heap.begin(),node_heap.end(),multitransscore_betterparticlep);
									  									multitransformationscore *mtr2 = (multitransformationscore*) *(node_heap.begin());
																		cutoffE_at_end_phase = minimum(mtr2->particlep, cutoffE_at_end_phase);
									  								}
									  							} else if(mtr->particlep > cutoffE){
									  								node_heap.push_back(mtr);
																	push_heap(node_heap.begin(),node_heap.end(),multitransscore_betterparticlep);
																	pop_heap(node_heap.begin(),node_heap.end(),multitransscore_betterparticlep);
																	node_heap.pop_back();
																	multitransformationscore *mtr2 = (multitransformationscore*) *(node_heap.end());
																	cutoffE_at_end_phase = minimum(mtr2->particlep,cutoffE_at_end_phase);
																	*out << "heapmod " << mtr->particlep << " " << mtr2->particlep << "\t";
																	delete mtr2;
									  							}
									  							if(etotal > maxE)	maxE = etotal;
				  												*out << endl;
				  											}
				  										}
					  									delete tr3;
													}
					  							  }
												}
				  							}
			  							}
			  							if(first_two_form_trimer){ // debug
			  								if(loop_over_t3) {
			  									delete trimer_tr3;
			  									delete trimer_tr3inv;
			  								}
			  								delete trimer_rf3;
			  							}
				  						delete tr2;
				  					}
					  			  }
				  				}
							}
							delete trinv1;
			  			}
			  			delete tr1;
					  }
					} 
					
			  	}
			  	num_phase_iterations++;
			}
			cutoffE = cutoffE_at_end_phase;
			sprintf(buff, "%d %f %f %d %d %d",procid, maxE, cutoffE, phase_done,t2block_done,t1block_done);
			MPI_Ssend(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD);
			if(node_heap_size < max_multitransformations)
				make_heap(node_heap.begin(),node_heap.end(),multitransscore_betterparticlep);
			*out << "maxE " << maxE << " " << cutoffE << endl;
		}
		
		if(procid==0){
			int t1 = (token1outer+1)*blocksize1;
			if(t1 >= num_transforms)	done=true;
			else {
				transformationscore ts = allsorteddimerscores[t1];
				fstream *transin = &(trans_in[ts.p1][ts.p2]);
				transin->seekg (0, ios::beg);
				transin->seekg(Transformation::basic_byte_size*ts.tid);
				transin->read(buf,Transformation::basic_byte_size);
				Transformation *tr1 = new Transformation(buf,TN_BASIC);
				tr1->eSolvation = ts.particlep;
				if(tr1->eSolvation < cutoffE/6.0 - 1.5){
					done = true;
				}
				delete tr1;
			}
			
			int t3 = (token3+1)*blocksize3;
			if(t3 >= num_transforms)	t2block_done = true;
			
			int t2 = (token2+1)*blocksize2;
			if(t2 >= num_transforms)	t1block_done = true;
			
			sprintf(buff, "%d %d %d",t2block_done, t1block_done, done);
			for(int i = 1; i < numprocs; i++) 
				MPI_Ssend(buff, BUFSIZE, MPI_CHAR, i, GENERATE_TAG, MPI_COMM_WORLD);
		} else {
			MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, GENERATE_TAG, MPI_COMM_WORLD, &mpistat);
			stringstream ss (stringstream::in | stringstream::out);
			ss << buff;
			ss >> t2block_done;
			ss >> t1block_done;
			ss >> done;
		}
		
		float a,b;
		MPI_Allreduce(&a, &b, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
		
		// collect multitransforms
		if((phase<4) || (phase<= 32 && phase%16==0) || (phase<=256 && phase%64==0) || (phase<=2048 && phase%256==0) || (phase%8192 == 0) || done){
			int MESSAGES_BEFORE_STATUS_UPDATE=5;  // should be greater than 2	
			if(procid == 0){
				unsigned int num_multitrans[numprocs];
				unsigned int num_messages_received[numprocs];
				num_multitrans[0] = 0;
				unsigned int total_multitrans = 0;
				for(int i=1;i<numprocs;i++){
					MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
					num_messages_received[i] = 1;
					stringstream ss (stringstream::in | stringstream::out);
					ss << buff;
					ss >> num_multitrans[i];
					total_multitrans += num_multitrans[i];
				}
				
				cout << phase << " #candidates " << total_multitrans << " " << t1block_done << endl; cout.flush();
				*out << "collecting candidates phase " << phase << endl;
			
				sprintf(tfilename, "%s/%s/phase%dres",node_tmp_dir,refpdbcode.c_str(),phase);
				fstream mtransout;
				//mtransout.open(tfilename,ios::binary|ios::out);
				mtransout.open(tfilename,ios::out);
				
				//merge transformations from different nodes on the basis of less<Transformation*>
				unsigned int multitrans_read[numprocs];
				unsigned int multitrans_written[numprocs];
				vector<multitransformationscore*> heap;
					
				for(int i = 0 ; i < numprocs ; i++){
					multitrans_read[i] = 0;
					multitrans_written[i] = 0;
				}
				unsigned int count = 0;
				queue<multitransformationscore*> mtrbuffer[numprocs];
				int bytesreceived, multitransreceived;
				// change of stopping condition requires updating status messages
				while(count < minimum(max_multitransformations,total_multitrans)){
					if(count == 0){
						for(int i=1;i<numprocs;i++){
							if(multitrans_read[i] < num_multitrans[i]){
								MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
								num_messages_received[i]++;
								MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
								multitransreceived = bytesreceived/sizeof(multitransformationscore);
								multitrans_read[i] += multitransreceived;
								for(int tri=0; tri<multitransreceived; tri++){
									multitransformationscore *mtr = new multitransformationscore;
									memcpy(mtr,buff+tri*sizeof(multitransformationscore),sizeof(multitransformationscore));
									mtrbuffer[i].push(mtr);
								}
								if(multitransreceived > 0){
									multitransformationscore *mtr = (multitransformationscore*) (mtrbuffer[i].front());
									mtrbuffer[i].pop();
									mtr->procid = i;
									heap.push_back(mtr);
								}
							}
						}
						make_heap(heap.begin(),heap.end(),multitransscore_worseparticlep);
						*out << "initialized heap\n"; out->flush();
					}
					
					pop_heap(heap.begin(),heap.end(),multitransscore_worseparticlep);
					heap.pop_back();
					
					multitransformationscore *min = (multitransformationscore *) *(heap.end());
					mtransout << min->particlep << " "; 
					for(int pti=0; pti<3; pti++)
						mtransout << min->p1[pti] << " " << min->p2[pti] << " " << min->tid[pti] << " ";
					mtransout << endl;
					
					if(count <= 10){
						cout << min->particlep << " ";
						for(int pti=0; pti<3; pti++)
							cout << min->p1[pti] << " " << min->p2[pti] << " " << min->tid[pti] << " ";
						cout << endl;
					}
					
					unsigned int list_picked = min->procid;
					multitrans_written[list_picked]++;
					
					count++;
					if(count % 100000 == 0){	*out << "at " << count << " " << list_picked << endl; out->flush(); }
					if(count == max_multitransformations){
						*out << "collection cutoff " << cutoffE << " " << min->particlep;
						cutoffE = min->particlep;
					}
					
					if(mtrbuffer[list_picked].empty() && multitrans_read[list_picked] < num_multitrans[list_picked]){
						MPI_Recv(buff, BUFSIZE, MPI_CHAR, list_picked, TAG, MPI_COMM_WORLD, &mpistat);
						MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
						multitransreceived = bytesreceived/sizeof(multitransformationscore);
						multitrans_read[list_picked] += multitransreceived;
						num_messages_received[list_picked]++;
						if(num_messages_received[list_picked] % MESSAGES_BEFORE_STATUS_UPDATE == 0){
							bool collection_done = (count >= minimum(max_multitransformations,total_multitrans));
							stringstream ss (stringstream::in | stringstream::out);
							ss << collection_done << " ";
							char buf[128];
							ss.getline(buf,128);
							MPI_Ssend(buf, 128, MPI_CHAR, list_picked, TAG, MPI_COMM_WORLD);
							if(collection_done)	multitrans_read[list_picked] = num_multitrans[list_picked];
						}
						for(int tri=0; tri<multitransreceived; tri++){
							multitransformationscore *mtr = new multitransformationscore;
							memcpy(mtr,buff+tri*sizeof(multitransformationscore),sizeof(multitransformationscore));
							mtrbuffer[list_picked].push(mtr);
						}	
					}
					if(!mtrbuffer[list_picked].empty()){
						multitransformationscore *mtr = (multitransformationscore*) (mtrbuffer[list_picked].front());
						mtrbuffer[list_picked].pop();
						mtr->procid = list_picked;
						heap.push_back(mtr);
						push_heap(heap.begin(),heap.end(),multitransscore_worseparticlep);
					}
					
					delete min;
				}
				
				mtransout.close();
				cout << "saved transformations " << count << " total " << total_multitrans << " cutoffE " << cutoffE << endl; cout.flush();
				
				// if picked only few transformations, receive Ssend messages from other nodes and relieve them
				if(numprocs > 1 && count < total_multitrans){
					*out << "max reached, relieving other processes and clearing buffers" << endl; out->flush();
					for(int i = 1; i < numprocs; i++){
						while(!mtrbuffer[i].empty()){
							multitransformationscore *mtr = (multitransformationscore*) (mtrbuffer[i].front());
							delete mtr;
							mtrbuffer[i].pop();
						}
						
						while(multitrans_read[i] < num_multitrans[i]){
							MPI_Recv(buff, BUFSIZE, MPI_CHAR, i, TAG, MPI_COMM_WORLD, &mpistat);
							MPI_Get_count(&mpistat, MPI_CHAR, &bytesreceived);
							multitransreceived = bytesreceived/sizeof(multitransformationscore);
							multitrans_read[i] += multitransreceived;
							num_messages_received[i]++;
							if(num_messages_received[i] % MESSAGES_BEFORE_STATUS_UPDATE == 0){
								stringstream ss (stringstream::in | stringstream::out);
								ss << true << " ";
								ss.getline(buff,128);
								MPI_Ssend(buff, 128, MPI_CHAR, i, TAG, MPI_COMM_WORLD);
								multitrans_read[i] = num_multitrans[i];
							}
						}
					}
				}
				
				sprintf(command, "gzip %s/%s/phase%dres",node_tmp_dir,refpdbcode.c_str(),phase);
				ret = system(command);
				cout << command << " " << ret << endl;			
				sprintf(command, "cp %s/%s/phase%dres.gz .",node_tmp_dir,refpdbcode.c_str(),phase);
				ret = system(command);
				cout << command << " " << ret << endl;
			} else {
				stringstream ss (stringstream::in | stringstream::out);
				ss << node_heap_size;
				ss.getline(buff,BUFSIZE);
				MPI_Ssend(buff, BUFSIZE, MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
				unsigned int num_messages_sent=1;
				*out << "done sending #multi_trans " << node_heap_size << endl;
				
				sort(node_heap.begin(),node_heap.end(),multitransscore_betterparticlep);
				
				/*if(node_heap_size>0){
					*out << "heap check " << ((multitransformationscore *) *(node_heap.begin()))->particlep << " " << ((multitransformationscore *) node_heap[node_heap.size()-1])->particlep << endl;
					for(vector<multitransformationscore*>::iterator hitr = node_heap.begin(); hitr != node_heap.end(); hitr++){
						multitransformationscore *mtr = *(hitr);
						*out << mtr->particlep << " ";
						for(int pti=0; pti<3; pti++)
							*out << mtr->p1[pti] << " " << mtr->p2[pti] << " " << mtr->tid[pti] << " ";
						*out << endl;
					}
					*out << node_heap_size << endl;
					out->flush();
				}*/ 
				
				int nmtr=0;
				char *current = buff;
				bool collection_done = false;
				while(nmtr < node_heap_size  && !collection_done){
					multitransformationscore *mtr = node_heap[nmtr];
					{	*out << mtr->particlep << " ";
						for(int pti=0; pti<3; pti++)
							*out << mtr->p1[pti] << " " << mtr->p2[pti] << " " << mtr->tid[pti] << " ";
						*out << endl;	}
					memcpy(current,mtr,sizeof(multitransformationscore));
					current += sizeof(multitransformationscore);
					
					if(nmtr==0)	*out << "sort " << phase << " " << mtr->particlep << endl;
					
					nmtr++;
					if((nmtr % 32) == 0){
						MPI_Ssend(buff,32*(sizeof(multitransformationscore)), MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
						current = buff;
						num_messages_sent++;
						if(num_messages_sent % MESSAGES_BEFORE_STATUS_UPDATE == 0){
							MPI_Recv(buff, 128, MPI_CHAR, 0, TAG, MPI_COMM_WORLD, &mpistat);
							stringstream ss (stringstream::in | stringstream::out);
							ss << buff;
							ss >> collection_done;
						}
					}
				}
				if((nmtr % 32) != 0 && !collection_done){
					MPI_Ssend(buff,(nmtr%32)*(sizeof(multitransformationscore)), MPI_CHAR, 0, TAG, MPI_COMM_WORLD);
					num_messages_sent++;
					if(num_messages_sent % MESSAGES_BEFORE_STATUS_UPDATE == 0)
						MPI_Recv(buff, BUFSIZE, MPI_CHAR, 0, TAG, MPI_COMM_WORLD, &mpistat);
				}
				
				//*out << "heap size after sending " << node_heap.size() << endl; out->flush();
				make_heap(node_heap.begin(),node_heap.end(),multitransscore_betterparticlep);
				//*out << "check " << node_heap.size() << endl; out->flush();
				if(node_heap.size()>0){
					*out << "heap check " << ((multitransformationscore *) *(node_heap.begin()))->particlep << " " << ((multitransformationscore *) node_heap[node_heap.size()-1])->particlep << endl;
					out->flush();
				}
				*out << "sent candidates to node 0" << endl;
			}
		}
		phase++;
		
		if(!done){
			if(!t1block_done){
				if(!t2block_done){
					token3outer += phase_limit/blocksize3;
				} else {
					token2outer++;
					token3outer = (token2outer*blocksize2+1)/blocksize3;
					t2block_done = false;
				}
			} else {
				token1outer++;
				token2outer = (token1outer*blocksize1+1)/blocksize2;
				t1block_done = false;
				token3outer = (token2outer*blocksize2+1)/blocksize3;
				t2block_done = false;
			}
			if(procid == 0)	*out << "phase " << phase << " outer limits " << token1outer << " " << token2outer << " " << token3outer << " " << t1block_done << " " << t2block_done << endl;
		}
	}
	
	time(&current_time);
	*out << "node " << procid << " assembled transformations\t time:" << difftime(current_time,start_time) << "s" << endl; out->flush();
}

/*
 * The current implementation takes lot of space, to be optimized
 */
void build_grids(){
	Transformation *identity = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
	
	prot_shape[0] = NULL;
	gridsize[0] = gridsize[1] = gridsize[2] = 0;
	
	float max_diameter=0;
	for(short pi = 0 ; pi < 4; pi++)
		if(prot_object[pi]->c->diameter > max_diameter)
			max_diameter = prot_object[pi]->c->diameter;
		
	for(short pi = 0 ; pi < 4; pi++){
		float max_extent = max_diameter + 20.0 - prot_object[pi]->c->diameter;
		max_extent = minimum(max_extent,40.0);
		prot_object[pi]->build_fft_opls_vdw_grid(grid_spacing,max_extent ,&(prot_shape[pi]),gridsize, identity, true);
	
		if(pi == 0){
			size = gridsize[0] * gridsize[1] * gridsize[2];
			*out << "gridsize " << gridsize[0] << "," << gridsize[1] << "," << gridsize[2] << " " << prot_shape[0] << endl;
			sqrt_size = sqrt(size);
		
			for(short pj = 1 ; pj < 4; pj++)
				prot_shape[pj] = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
		}
		
		if(scoring_function == FFT_GENERATE_MATCHES_ATOMP){
			num_particlep_arrays = (NUM_FFT_ATOM_TYPES+1)/2;
			*out << "num_particlep_arrays " << num_particlep_arrays << endl;

			prot_particlepgrid[pi] = (MKL_Complex8 **) malloc(sizeof(MKL_Complex8 *) * num_particlep_arrays);
			for(int ti = 0; ti < num_particlep_arrays; ti++)
				prot_particlepgrid[pi][ti] = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);
			
			prot_object[pi]->build_fft_atomcontact_grid(grid_spacing,prot_particlepgrid[pi],NUM_FFT_ATOM_TYPES,gridsize, identity, true);
		} else if(scoring_function == FFT_GENERATE_MATCHES_RESIDUE_BKBNP){
			num_particlep_arrays = 11;
			*out << "num_particlep_arrays " << num_particlep_arrays << endl;

			prot_particlepgrid[pi] = (MKL_Complex8 **) malloc(sizeof(MKL_Complex8 *) * num_particlep_arrays);
			for(int ti = 0; ti < num_particlep_arrays; ti++)
				prot_particlepgrid[pi][ti] = (MKL_Complex8 *) malloc(sizeof(MKL_Complex8) * size);

			prot_object[pi]->build_fft_residue_bkbn_centroid_bkbn_centroid_contact_potential_grid(grid_spacing,
				prot_particlepgrid[pi],22, residue_bkbn_potential,gridsize,identity, true);
		}
	}
}

int main(int argc, char *argv[]){
	time(&start_time);
	int ret = MPI_Init(&argc,&argv);
	if(ret == MPI_SUCCESS){
		MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
		MPI_Comm_rank(MPI_COMM_WORLD,&procid);
				
		if(procid == 0){
			cout << "Job running on " << numprocs << " processors" << endl;
			cout << "#args " << argc << endl;
			cout.flush();
		}
		
		read_molecule_config();
		if(NUM_FFT_ATOM_TYPES == 18){
			//coarsen_atomtypesto18();
			atom_potential = &atom18_potential;
		} else if(NUM_FFT_ATOM_TYPES == 20){
			//coarsen_atomtypesto20();
			atom_potential = &atom20_potential;
		}
		read_dock_config();
		node_tmp_dir = (char*) (new string(string(tmp_dir)+"/"+string(getenv(string("JOB_ID").c_str()))))->c_str();
		
		elect_leader_on_node();
		
		//initialize
		refpdbcode = "log";
		sprintf(command, "%s/cluster_scripts/setup.sh %s %d %s %d",getenv(string("HOME").c_str()),getenv(string("JOB_ID").c_str()),procid, refpdbcode.c_str(), masterprocessonnode);
		ret = system(command);
		
		sprintf(scratch_dir, "%s/%s/%d",node_tmp_dir,refpdbcode.c_str(),procid);
		sprintf(filename, "%s/%s/%sout%d",node_tmp_dir,refpdbcode.c_str(),refpdbcode.c_str(),procid);
		//cout << filename << endl; cout.flush();
		fstream outstream;
		outstream.open(filename,ios::out);
		if(!outstream.good()){
			cout << "ERROR: could not open file " << filename << " " << errno << "\n"; cout.flush();
			exit(-1);
		}
		out = &outstream;
		
		*out << procid << " " << *host << " am_master " << masterprocessonnode << endl;
		*out << "setup " << command << " " << ret << endl;
		
		filetype = atoi(argv[1]);
		docktype = atoi(argv[2]);
		start_state = atoi(argv[3]);
		end_state = atoi(argv[4]);
		*out << "start " << start_state << " end " << end_state << endl;out->flush();
		
		num_units = 4; //atoi(argv[5]);
		Complex *c[num_units];
		string optionsfile = *(new string(argv[5]));
		fstream optin(optionsfile.c_str(), ios::in);
		*out << optionsfile << " " << optin.good() << endl; out->flush();
		
		// read information about individual units			
		for(int i = 0; i < num_units; i++){
			optin.getline(buff,8192);
			if(optin.gcount() > 0){
				stringstream line(buff,stringstream::in);
				string tag,pdbcode,chains;
				line >> tag;
				line >> tag;
				line >> pdbcode;
				line >> chains;
			
				prot_pdbcode[i] = *(new string(pdbcode.c_str()));  
				prot_chains[i] = *(new string(chains.c_str()));
			
				c[i] = new Complex(("../"+prot_pdbcode[i]).c_str(),prot_chains[i].c_str(), filetype);
				Complex* cH =c[i];
				prot_object[i] = new Object(c[i],cH);
			} else {
				cout << "ERROR: Do not have all units" << endl; cout.flush(); 
				exit(-1);
			}
		}
		
		// read results of pairwise docking
		string trans_filename[num_units][num_units];
		for(int li = 0; li < num_units*(num_units-1)/2; li++){
			optin.getline(buff,8192);
			if(optin.gcount() > 0){
				stringstream line(buff,stringstream::in);
				string tag;
				line >> tag;
				short i,j;
				line >> i; line >> j;
				line >> trans_filename[i][j];
				trans_in[i][j].open(trans_filename[i][j].c_str(),ios::in);
				if(!trans_in[i][j].good()){
					cout << "ERROR: Do not have all dimer transformations " << endl; cout.flush(); 
					exit(-1);
				} 
			} else {
				cout << "ERROR: Do not have all dimer transformations" << endl; cout.flush(); 
				exit(-1);
			}
		}
		
		// read sorted and clustered lists of transformationids
		string sortedscore_filename[num_units][num_units];
		for(int li = 0; li < num_units*(num_units-1)/2; li++){
			optin.getline(buff,8192);
			if(optin.gcount() > 0){
				stringstream line(buff,stringstream::in);
				string tag;
				line >> tag;
				short i,j;
				line >> i; line >> j;
				line >> sortedscore_filename[i][j];
			}
		}
		string allsorteddimerscores_filename;
		optin.getline(buff,8192);
		if(optin.gcount() > 0){
			stringstream line(buff,stringstream::in);
			string tag;
			line >> tag;
			line >> allsorteddimerscores_filename;
			allsorteddimerscores_in.open(allsorteddimerscores_filename.c_str(), ios::in);
		}
		*out << "filename " << allsorteddimerscores_filename << " " << allsorteddimerscores_in.is_open() << endl; out->flush();
		
		for(int i=0; i < 3; i++)	looplength[i] = 0;

#ifdef LOOP_CONSTRAINT
		do{
			optin.getline(buff,8192);
			if(optin.gcount() > 0){
				stringstream line(buff,stringstream::in);
				string tag;
				line >> tag;
				int loopindex;
				line >> loopindex;
				line >> looplength[loopindex];
				if(procid == 0)
					cout << "loop constraint " << loopindex << "-" << loopindex+1 << " " << looplength[loopindex] << endl;
			}
		} while(optin.good());
		//looplength[0]=16.0 *0.6;
		//looplength[1]=17.0 *0.6;
		//looplength[2]=14 *0.6;
#endif
			
		if(start_state == FFT_GENERATE_TETRAMER){
			build_grids();
			//token1outer=0,token2outer=1025,token3outer=0;
			assemble_tetramer(3.0,1024*64);
		}
		
		MPI_Finalize();
		//outstream.close();
		
		if(procid == 0){
			time(&current_time);
			cout << "done" << " " << success << "\t time:" << difftime(current_time,start_time) << "s" << endl;
		}
		
		return 0;
	} else {
		cout << "init failed" << endl;
		return 1;
	}
}
