/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#ifndef INCL_ASMBLHPP
#include "assemble.hpp"
#define INCL_ASMBLHPP
#endif

extern float grid_spacing;
extern MKL_LONG gridsize[3];
extern float ***atom_potential, vdw_weight;
extern Object *prot_object[MAX_UNITS];
extern MKL_Complex8 *prot_shape[MAX_UNITS], **prot_particlepgrid[MAX_UNITS];
extern bool scoring_function;

extern unsigned short looplength[MAX_UNITS];
extern bool chain_continuous(Complex *receptor,Complex *ligand,Reference_Frame *rf, bool rf_is_lig_vs_rec, unsigned short looplength);

void compute_trimer_scores_generalized(transformationscore *ts1, Transformation* tr1, Reference_Frame *trinv1, transformationscore *ts2, Transformation* tr2, short *trimer_p1, short *trimer_p2, Reference_Frame **rf, 
 float *vdw_repul, float min_vdw_repulsion, float *particlep, unsigned int num_atom_types){
 	Reference_Frame *tr;
 	short p1,p2;
	if(ts1->p1 == ts2->p1){ // AB, AD
		if(ts1->p2 < ts2->p2){
			p1 = ts1->p2;
			p2 = ts2->p2;
			tr = Reference_Frame::compose(tr2,trinv1);
		} else {
			p1 = ts2->p2;
			p2 = ts1->p2;
			Reference_Frame *trinv2 = Reference_Frame::invert(tr2);
			tr = Reference_Frame::compose(tr1,trinv2);
			delete trinv2;
		}
	} else if(ts1->p2 == ts2->p1){ // AB, BD
		// since ts.p1 < ts.p2, ts1.p1 < ts2.p2
		p1 = ts1->p1;
		p2 = ts2->p2;
		
		tr = Reference_Frame::compose(tr2,tr1);
	} else if(ts1->p1 == ts2->p2){ // CD, AC
		// since ts.p1 < ts.p2 , ts2.p1 < ts1.p2
		p1 = ts2->p1;
		p2 = ts1->p2;
		
		tr = Reference_Frame::compose(tr1,tr2);
	} else { // AC, BC
		if(ts1->p1 < ts2->p1) {
			p1 = ts1->p1;
			p2 = ts2->p1;
			Reference_Frame *trinv2 = Reference_Frame::invert(tr2);
			tr = Reference_Frame::compose(trinv2,tr1);
			delete trinv2;
		} else {
			p1 = ts2->p1;
			p2 = ts1->p1;
			tr = Reference_Frame::compose(trinv1,tr2);
		}
	}
	*rf = tr;
	*trimer_p1 = p1;
	*trimer_p2 = p2;
	
	if(false){ // debugging
		*out << tr1->frame_number << " "<< tr2->frame_number << " " << p1 << " " << p2 << endl;
		*out << tr->translation->x << "," << tr->translation->y << "," << tr->translation->z << " " <<
			tr->ex->x << "," << tr->ex->y << "," <<tr->ex->z << " " <<tr->ey->x << "," <<tr->ey->y << "," <<tr->ey->z << endl; 
		//tr->write_as_pdb(prot_object[p2]->c, "-", true, "transformed.pdb", true);
		//tr->write_as_pdb(prot_object[p2]->c, "-", true, "invtransformed.pdb", false);
	}
	
	Object *orec = prot_object[p1], *olig = prot_object[p2];
	float vdw_attr = 0;
	*vdw_repul = 0;
	
	int ligand_atomposition_in_recgrid[olig->c->num_atoms];
	
#ifdef LOOP_CONSTRAINT
	if(p2 == p1+1 && !chain_continuous(prot_object[p1]->c,prot_object[p2]->c,tr,false,looplength[p1])){
		*vdw_repul = min_vdw_repulsion;
	} else {
#else
	{
#endif			
	
		for(int j=0; j < olig->c->num_atoms; j++){
			Atom *al = olig->c->atom[j];
			if((al->name).c_str()[0] != 'H' && *vdw_repul > min_vdw_repulsion){
				Vector taposition = tr->inverse_transform(*(al->position)) - (*(orec->c->center) + *(orec->grid_origin));
				int vx = ((int) (taposition.x/grid_spacing));
				int vy = ((int) (taposition.y/grid_spacing));
				int vz = ((int) (taposition.z/grid_spacing));
				
				if( (vx >=0 && vx < gridsize[0]) && (vy >=0 && vy < gridsize[1]) && (vz >=0 && vz < gridsize[2]) ){
					unsigned int index = (vx*gridsize[1] + vy)*gridsize[2] + vz;
					ligand_atomposition_in_recgrid[j] = index;
					
					MKL_Complex8 shape_value = prot_shape[p1][index];
					
					float factor = al->sqrt_eps;
					Vector v = taposition * (1.0/grid_spacing);
					float wx[2],wy[2],wz[2];
					wx[0] = vx+1.0 - v.x;
					wx[1] = v.x - vx;
					wy[0] = vy+1.0 - v.y;
					wy[1] = v.y - vy;
					wz[0] = vz+1.0 - v.z;
					wz[1] = v.z - vz;
					
					for(int cci =0; cci <=1; cci++)
						for(int ccj =0; ccj <=1; ccj++)
							for(int cck =0; cck <=1; cck++){
								int nx = (vx+cci)% gridsize[0];
								int ny = (vy+ccj)% gridsize[1];
								int nz = (vz+cck)% gridsize[2];
								unsigned int nindex = (nx*gridsize[1] + ny)*gridsize[2] + nz;
								float nfactor = factor *wx[cci]*wy[ccj]*wz[cck];
								
								*vdw_repul += nfactor * shape_value.imag;
								if(*vdw_repul < min_vdw_repulsion)	break;
								vdw_attr += nfactor * shape_value.real;
								
							} 
		          
				} else
					ligand_atomposition_in_recgrid[j] = -1;
			} else
				ligand_atomposition_in_recgrid[j] = -1;
		}
	}
	
	if(scoring_function == FFT_GENERATE_MATCHES_EVATOMP){
	  if(*vdw_repul > min_vdw_repulsion){
		float atompscore=0;
		for(int j=0; j < olig->c->num_atoms; j++)
			if(ligand_atomposition_in_recgrid[j] != -1){
				// opls vdw attr and repul
				
				// pair potential
				short aj = olig->c->atom[j]->atom_type;
				if(aj >= 0 && aj < num_atom_types){
					unsigned int index = ligand_atomposition_in_recgrid[j];
                 	for(int ai=0; ai< num_atom_types/2; ai++){
                 		MKL_Complex8 grid_value = prot_particlepgrid[p1][ai][index];
						atompscore += grid_value.real * (*atom_potential)[2*ai][aj] + 
										grid_value.imag * (*atom_potential)[2*ai+1][aj];
                 	}
				}
			}
		*particlep = atompscore + vdw_weight*(vdw_attr + *vdw_repul);
	  } 	
	} else if(scoring_function == FFT_GENERATE_MATCHES_RESIDUE_BKBNP) {
		if(*vdw_repul > min_vdw_repulsion){
			float respscore=0;
			for(int i = 0 ; i < olig->c->num_aminoacids; i++){
				Aminoacid *aa = olig->c->aminoacid[i];
			   
				for(int aapi = 0; aapi < 3; aapi++){
					Vector *v = NULL;
					short particle_type=-1;
					switch(aapi){
						case 0 :
							v = (aa->centroid);
							particle_type = aa->type;
							break;
						case 1 :
							if(aa->amide_nitrogen != NULL)
								v = aa->amide_nitrogen->position;
							particle_type = 20;
							break;
						case 2:
							if(aa->carbonyl_oxygen != NULL)
								v = aa->carbonyl_oxygen->position;
							particle_type = 21;
							break;
					}
			
					if(particle_type >= 0){
						Vector taposition = tr->inverse_transform(v) - (*(orec->c->center) + *(orec->grid_origin));
						int vx = ((int) (taposition.x/grid_spacing));
						int vy = ((int) (taposition.y/grid_spacing));
						int vz = ((int) (taposition.z/grid_spacing));
				
						if( (vx >=0 && vx < gridsize[0]) && (vy >=0 && vy < gridsize[1]) && (vz >=0 && vz < gridsize[2]) ){
							unsigned int index = (vx*gridsize[1] + vy)*gridsize[2] + vz;
					
							MKL_Complex8 grid_value = prot_particlepgrid[p1][particle_type/2][index];
							float field_value;
							if(particle_type %2 == 0)	field_value = grid_value.real;
							else	field_value = grid_value.imag;
						
							float factor = 1;
							Vector v = taposition * (1.0/grid_spacing);
							float wx[2],wy[2],wz[2];
							wx[0] = vx+1.0 - v.x;
							wx[1] = v.x - vx;
							wy[0] = vy+1.0 - v.y;
							wy[1] = v.y - vy;
							wz[0] = vz+1.0 - v.z;
							wz[1] = v.z - vz;
							
							for(int cci =0; cci <=1; cci++)
								for(int ccj =0; ccj <=1; ccj++)
									for(int cck =0; cck <=1; cck++){
										int nx = (vx+cci)% gridsize[0];
										int ny = (vy+ccj)% gridsize[1];
										int nz = (vz+cck)% gridsize[2];
										unsigned int nindex = (nx*gridsize[1] + ny)*gridsize[2] + nz;
										float nfactor = factor *wx[cci]*wy[ccj]*wz[cck];
										
										respscore += field_value * nfactor;
									} 
				          
                 		}
					}
				}
			}
		*particlep = respscore + vdw_weight*(vdw_attr + *vdw_repul);
		}
	} else {
		*particlep = vdw_attr + *vdw_repul;
	}
#ifdef ASSMBL_DEBUG	
	//*out << "computescore " << tr1->eSolvation << " " << tr2->eSolvation << " p1 " << p1 << " p2 " << p2 << " " << *particlep << " " << *vdw_repul << ":" << vdw_attr << endl;
#endif
}

/*
void compute_trimer_scores_generalized_noopls(transformationscore *ts1, Transformation* tr1, Reference_Frame *trinv1, transformationscore *ts2, Transformation* tr2, short *trimer_p1, short *trimer_p2, Reference_Frame **rf, 
 int *clashes, unsigned int clash_cutoff, float *particlep, unsigned int num_atom_types){
 	Reference_Frame *tr;
 	short p1,p2;
	if(ts1->p1 == ts2->p1){ // AB, AD
		if(ts1->p2 < ts2->p2){
			p1 = ts1->p2;
			p2 = ts2->p2;
			tr = Reference_Frame::compose(tr2,trinv1);
		} else {
			p1 = ts2->p2;
			p2 = ts1->p2;
			Reference_Frame *trinv2 = Reference_Frame::invert(tr2);
			tr = Reference_Frame::compose(tr1,trinv2);
			delete trinv2;
		}
	} else if(ts1->p2 == ts2->p1){ // AB, BD
		// since ts.p1 < ts.p2, ts1.p1 < ts2.p2
		p1 = ts1->p1;
		p2 = ts2->p2;
		
		tr = Reference_Frame::compose(tr2,tr1);
	} else if(ts1->p1 == ts2->p2){ // CD, AC
		// since ts.p1 < ts.p2 , ts2.p1 < ts1.p2
		p1 = ts2->p1;
		p2 = ts1->p2;
		
		tr = Reference_Frame::compose(tr1,tr2);
	} else { // AC, BC
		if(ts1->p1 < ts2->p1) {
			p1 = ts1->p1;
			p2 = ts2->p1;
			Reference_Frame *trinv2 = Reference_Frame::invert(tr2);
			tr = Reference_Frame::compose(trinv2,tr1);
			delete trinv2;
		} else {
			p1 = ts2->p1;
			p2 = ts1->p1;
			tr = Reference_Frame::compose(trinv1,tr2);
		}
	}
	*rf = tr;
	*trimer_p1 = p1;
	*trimer_p2 = p2;
	
	if(false){ // debugging
		*out << tr1->frame_number << " "<< tr2->frame_number << " " << p1 << " " << p2 << endl;
		*out << tr->translation->x << "," << tr->translation->y << "," << tr->translation->z << " " <<
			tr->ex->x << "," << tr->ex->y << "," <<tr->ex->z << " " <<tr->ey->x << "," <<tr->ey->y << "," <<tr->ey->z << endl; 
		//tr->write_as_pdb(prot_object[p2]->c, "-", true, "transformed.pdb", true);
		//tr->write_as_pdb(prot_object[p2]->c, "-", true, "invtransformed.pdb", false);
	}
	
	Object *orec = prot_object[p1], *olig = prot_object[p2];
	float osc, oic, occ;
	osc = oic = occ = 0;
	int ligand_atomposition_in_recgrid[olig->c->num_atoms];
	
#ifdef LOOP_CONSTRAINT
	if(p2 == p1+1 && !chain_continuous(prot_object[p1]->c,prot_object[p2]->c,tr,false,looplength[p1])){
		occ = 9;
		oic = clash_cutoff + 1;
	} else {
#else
	{
#endif			
	
		for(int j=0; j < olig->c->num_atoms; j++){
			Atom *al = olig->c->atom[j];
			if((al->name).c_str()[0] != 'H'){
				Vector taposition = tr->inverse_transform(*(al->position)) - (*(orec->c->center) + *(orec->grid_origin));
				int vx = ((int) (taposition.x/grid_spacing));
				int vy = ((int) (taposition.y/grid_spacing));
				int vz = ((int) (taposition.z/grid_spacing));
				
				if( (vx >=0 && vx < gridsize[0]) && (vy >=0 && vy < gridsize[1]) && (vz >=0 && vz < gridsize[2]) ){
					unsigned int index = (vx*gridsize[1] + vy)*gridsize[2] + vz;
					ligand_atomposition_in_recgrid[j] = index;
					
					MKL_Complex8 shape_value = prot_shape[p1][index];
		           if(shape_value.real == 1.0)	osc++;
		            else if(shape_value.imag == INTERMEDIATE_IMAG)	oic++;
		            else if(shape_value.imag == INTERIOR_IMAG)	occ++;
		            
		        	if(oic+occ*7> clash_cutoff)	break;
		        	if(occ > 8){
		        		oic = clash_cutoff + 1;
		        		break;
		        	}
				} else
					ligand_atomposition_in_recgrid[j] = -1;
			} else
				ligand_atomposition_in_recgrid[j] = -1;
		}
	}
	*clashes = oic + occ*7;
	//*out << "compute score " << *clashes << " " << occ << " " << oic << endl; out->flush();
	
	if(*clashes <= clash_cutoff){
		float atompscore=0;
		for(int j=0; j < olig->c->num_atoms; j++)
			if(ligand_atomposition_in_recgrid[j] != -1){
				// opls vdw attr and repul
				
				// pair potential
				short aj = olig->c->atom[j]->atom_type;
				if(aj >= 0 && aj < num_atom_types){
					unsigned int index = ligand_atomposition_in_recgrid[j];
                 	for(int ai=0; ai< num_atom_types/2; ai++){
                 		MKL_Complex8 grid_value = prot_particlepgrid[p1][ai][index];
						atompscore += grid_value.real * (*atom_potential)[2*ai][aj] + 
										grid_value.imag * (*atom_potential)[2*ai+1][aj];
                 	}
				}
			}
		*particlep = atompscore;
	}
#ifdef ASSMBL_DEBUG	
	*out << "computescore " << tr1->eSolvation << " " << tr2->eSolvation << " p1 " << p1 << " p2 " << p2 << " " << *particlep << " " << *clashes << ":" << occ << ":" << oic << endl;
#endif
}
*/

/* Method was written assuming only 3 proteins
 * Using the general function now, last bug fixed on feb 9 2010, no longer maintained */
void compute_trimer_scores(transformationscore *ts1, Transformation* tr1, Reference_Frame *trinv1, transformationscore *ts2, Transformation* tr2, int *clashes, 
 unsigned int clash_cutoff, float *particlep, unsigned int num_atom_types){
	short p1,p2;
	Reference_Frame *tr;
	if(ts1->p1 == ts2->p1){ // AB, AC
		p1 = 1;
		p2 = 2;
		
		if(ts1->p2 == 1){ // 1 AB
			//*out << "at right position" << endl; 
			tr = Reference_Frame::compose(tr2,trinv1);
		} else { // 1 AC 
			Reference_Frame *trinv2 = Reference_Frame::invert(tr2);
			tr = Reference_Frame::compose(tr1,trinv2);
			delete trinv2;
		}
	} else if(ts1->p2 == ts2->p1){ // AB, BC
		p1 = 0;
		p2 = 2;
		
		if(ts1->p1 == 0) // 1 AB
			tr = Reference_Frame::compose(tr2,tr1);
		else // 1 BC
			tr = Reference_Frame::compose(tr1,tr2);
	} else if(ts1->p1 == ts2->p2){ // BC AB
		p1 = ts2->p1;
		p2 = ts1->p2;
		
		tr = Reference_Frame::compose(tr1,tr2);
	} else{ // BC, AC
		p1 = 0;
		p2 = 1;
		
		if(ts1->p1 == 1) // 1 BC
			tr = Reference_Frame::compose(trinv1,tr2);
		else{ // 1 AC
			Reference_Frame *trinv2 = Reference_Frame::invert(tr2);
			tr = Reference_Frame::compose(trinv2,tr1);
			delete trinv2;
		}
	}
	/*out << tr1->frame_number << " "<< tr2->frame_number << " " << p1 << " " << p2 << endl;
	*out << tr->translation->x << "," << tr->translation->y << "," << tr->translation->z << " " <<
		tr->ex->x << "," << tr->ex->y << "," <<tr->ex->z << " " <<tr->ey->x << "," <<tr->ey->y << "," <<tr->ey->z << endl; 
	/*tr->write_as_pdb(prot_object[p2]->c, "-", true, "transformed.pdb", true);
	tr->write_as_pdb(prot_object[p2]->c, "-", true, "invtransformed.pdb", false);*/
	
	Object *orec = prot_object[p1], *olig = prot_object[p2];
	float osc, oic, occ;
	osc = oic = occ = 0;
	int ligand_atomposition_in_recgrid[olig->c->num_atoms];
	for(int j=0; j < olig->c->num_atoms; j++){
		Atom *al = olig->c->atom[j];
		if((al->name).c_str()[0] != 'H'){
			Vector taposition = tr->inverse_transform(*(al->position)) - (*(orec->c->center) + *(orec->grid_origin));
			int vx = ((int) (taposition.x/grid_spacing));
			int vy = ((int) (taposition.y/grid_spacing));
			int vz = ((int) (taposition.z/grid_spacing));
			
			if( (vx >=0 && vx < gridsize[0]) && (vy >=0 && vy < gridsize[1]) && (vz >=0 && vz < gridsize[2]) ){
				unsigned int index = (vx*gridsize[1] + vy)*gridsize[2] + vz;
				ligand_atomposition_in_recgrid[j] = index;
				
				MKL_Complex8 shape_value = prot_shape[p1][index];
	            if(shape_value.real == 1.0)	osc++;
	            else if(shape_value.imag == INTERMEDIATE_IMAG)	oic++;
	            else if(shape_value.imag == INTERIOR_IMAG)	occ++;
	            
	        	if(oic+occ*7> clash_cutoff)	break;
	        	if(occ > 8){
	        		oic = clash_cutoff + 1 - occ;
	        		break;
	        	}
			} else
				ligand_atomposition_in_recgrid[j] = -1;
		} else
			ligand_atomposition_in_recgrid[j] = -1;
	}
	
	*clashes = oic + occ*7;
	*out << "clashes " << *clashes << " " << occ << " " << oic << endl; out->flush();
	
	if(*clashes <= clash_cutoff){
		float atompscore=0;
		for(int j=0; j < olig->c->num_atoms; j++)
			if(ligand_atomposition_in_recgrid[j] != -1){
				short aj = olig->c->atom[j]->atom_type;
				if(aj >= 0 && aj < num_atom_types){
					unsigned int index = ligand_atomposition_in_recgrid[j];
                 	for(int ai=0; ai< num_atom_types/2; ai++){
                 		MKL_Complex8 grid_value = prot_particlepgrid[p1][ai][index];
						atompscore += grid_value.real * (*atom_potential)[2*ai][aj] + 
										grid_value.imag * (*atom_potential)[2*ai+1][aj];
                 	}
				}
			}
		*particlep = atompscore;
	}
	delete tr;
	*out << "computescore " << p1 << ":" << p2 << " " << tr1->eSolvation << " " << tr2->eSolvation << " " << *particlep << " " << *clashes << " " << occ << " " << oic <<endl;
}
