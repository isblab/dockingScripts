/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];

int main(int argc, char *argv[]){
	read_molecule_config();
	read_dock_config();
	out = &cout;
	
	int num_units = 4; //atoi(argv[5]);
	Complex *c[num_units];
	string optionsfile = *(new string(argv[1]));
	fstream optin(optionsfile.c_str(), ios::in);
	*out << optionsfile << " " << optin.good() << endl; out->flush();
	
	string prot_pdbcode[4], prot_chains[4];
	// read information about individual units			
	for(int i = 0; i < num_units; i++){
		optin.getline(buf,8192);
		if(optin.gcount() > 0){
			stringstream line(buf,stringstream::in);
			string tag,pdbcode,chains;
			line >> tag;
			line >> tag;
			line >> pdbcode;
			line >> chains;
		
			prot_pdbcode[i] = *(new string(pdbcode.c_str()));  
			prot_chains[i] = *(new string(chains.c_str()));
		
			c[i] = new Complex(("../"+prot_pdbcode[i]).c_str(),prot_chains[i].c_str(), PDB);
		} else {
			cout << "ERROR: Do not have all units" << endl; cout.flush(); 
			exit(-1);
		}
	}
		
	// read results of pairwise docking
	string trans_filename[num_units][num_units];
	fstream trans_in[4][4];
	for(int li = 0; li < num_units*(num_units-1)/2; li++){
		optin.getline(buf,8192);
		if(optin.gcount() > 0){
			stringstream line(buf,stringstream::in);
			string tag;
			line >> tag;
			short i,j;
			line >> i; line >> j;
			line >> trans_filename[i][j];
			trans_in[i][j].open(trans_filename[i][j].c_str(),ios::in);
			if(!trans_in[i][j].good()){
				cout << "ERROR: Do not have all dimer transformations " << endl; cout.flush(); 
				exit(-1);
			}
		} else {
			cout << "ERROR: Do not have all dimer transformations" << endl; cout.flush(); 
			exit(-1);
		}
	}
	
	unsigned int model_number = atoi(argv[2]);
	short p1[3],p2[3];
	unsigned int tid[3];
	Transformation *tr[3];
	
	for(int ti = 0; ti < 3; ti++){
		p1[ti] = atoi(argv[3+3*ti]);
		p2[ti] = atoi(argv[4+3*ti]);
		tid[ti] = atoi(argv[5+3*ti]);
	
		fstream *transin = &(trans_in[p1[ti]][p2[ti]]);
		transin->seekg(0, ios::beg);
		transin->seekg(Transformation::basic_byte_size*tid[ti]);
		transin->read(buf,Transformation::basic_byte_size);
		tr[ti] = new Transformation(buf,TN_BASIC);
		tr[ti]->print_details(out,TN_BASIC);
	} 
	
	bool first_two_form_trimer = (p1[0] == p1[1] || p1[0] == p2[1] || p2[0] == p1[1] || p2[0] == p2[1]);
	// swap such that first two form trimer
	if(!first_two_form_trimer){
		short p;
		p = p1[1]; p1[1] = p1[2]; p1[2] = p;
		p = p2[1]; p2[1] = p2[2]; p2[2] = p;
		unsigned int t = tid[1]; tid[1] = tid[2]; tid[2] = t;
		Transformation *trt = tr[1]; tr[1] = tr[2]; tr[2] = trt;
	}
	
	short fixed_protein;
	if(p1[0] == p1[1] || p1[0] == p2[1]){
		fixed_protein = p1[0];
		{
			short p = p2[0];
			stringstream ss (stringstream::in | stringstream::out);
			ss << "m" << model_number << "p" << p << "_vs_" << fixed_protein << ".pdb";
			string s; ss >> s;
			tr[0]->write_as_pdb(c[p], "-", false, s, false);
		}
		if(p1[0] == p1[1]) {
			short p = p2[1];
			stringstream ss (stringstream::in | stringstream::out);
			ss << "m" << model_number << "p" << p << "_vs_" << fixed_protein << ".pdb";
			string s; ss >> s;
			tr[1]->write_as_pdb(c[p], "-", false, s, false);
		} else {
			short p = p1[1];
			stringstream ss (stringstream::in | stringstream::out);
			ss << "m" << model_number << "p" << p << "_vs_" << fixed_protein << ".pdb";
			string s; ss >> s;
			tr[1]->write_as_pdb(c[p], "-", false, s, true);
		}
	} else {
		fixed_protein = p2[0];
		{
			short p = p1[0];
			stringstream ss (stringstream::in | stringstream::out);
			ss << "m" << model_number << "p" << p << "_vs_" << fixed_protein << ".pdb";
			string s; ss >> s;
			tr[0]->write_as_pdb(c[p], "-", false, s, true);
		}
		if(p2[0] == p1[1]) {
			short p = p2[1];
			stringstream ss (stringstream::in | stringstream::out);
			ss << "m" << model_number << "p" << p << "_vs_" << fixed_protein << ".pdb";
			string s; ss >> s;
			tr[1]->write_as_pdb(c[p], "-", false, s, false);
		} else {
			short p = p1[1];
			stringstream ss (stringstream::in | stringstream::out);
			ss << "m" << model_number << "p" << p << "_vs_" << fixed_protein << ".pdb";
			string s; ss >> s;
			tr[1]->write_as_pdb(c[p], "-", false, s, true);
		}
	} 
	
	short fourth_protein = 6 + fixed_protein - (p1[0]+p2[0]+p1[1]+p2[1]);
	bool forms_star = (p1[2] == fixed_protein || p2[2] == fixed_protein);
	*out << "fourth protein " << fourth_protein << " forms star " << forms_star << endl;
	if(forms_star) {
		short p = fourth_protein;
		stringstream ss (stringstream::in | stringstream::out);
		ss << "m" << model_number << "p" << p << "_vs_" << fixed_protein << ".pdb";
		string s; ss >> s;
		tr[2]->write_as_pdb(c[p], "-", false, s, (p2[2] == fixed_protein) );
	} else {	// line, distance to fixed protein is 2
		short edge1;
		if(p1[0] == p1[2] || p1[0] == p2[2] || p2[0] == p1[2] || p2[0] == p2[2])	edge1 = 0;
		else edge1 = 1;
		
		Transformation *tr1 = tr[edge1], *tr2 = tr[2];
		Reference_Frame *rf;
		{
			short rp1, rp2;
			Reference_Frame *trinv1 = Reference_Frame::invert(tr1);
			Reference_Frame *trinv2 = Reference_Frame::invert(tr2);
			
			if(p1[edge1] == p1[2]){
				if(p2[edge1] < p2[2]){
					rp1 = p2[edge1];
					rp2 = p2[2];
					rf = Reference_Frame::compose(tr2,trinv1);
				} else {
					rp1 = p2[2];
					rp2 = p2[edge1];
					rf = Reference_Frame::compose(tr1,trinv2);
				}
			} else if(p2[edge1] == p1[2]){ 
				rp1 = p1[edge1];
				rp2 = p2[2];
				rf = Reference_Frame::compose(tr2,tr1);
			} else if(p1[edge1] == p2[2]){ // CD, AC
				rp1 = p1[2];
				rp2 = p2[edge1];
				rf = Reference_Frame::compose(tr1,tr2);
			} else { 
				if(p1[edge1] < p1[2]) {
					rp1 = p1[edge1];
					rp2 = p1[2];
					rf = Reference_Frame::compose(trinv2,tr1);
				} else {
					rp1 = p1[2];
					rp2 = p1[edge1];
					rf = Reference_Frame::compose(trinv1,tr2);
				}
			}
			
			short p = fourth_protein;
			stringstream ss (stringstream::in | stringstream::out);
			ss << "m" << model_number << "p" << p << "_vs_" << fixed_protein << ".pdb";
			string s; ss >> s;
			rf->write_as_pdb(c[p], "-", false, s, (rp2 == fixed_protein) );
		}
	}
	
	stringstream ss (stringstream::in | stringstream::out);
	ss << "cat ../" << prot_pdbcode[fixed_protein] << ".pdb ";
	for(int pi=0; pi < 4; pi++)
		if(pi != fixed_protein)
			ss << "m" << model_number << "p" << pi << "_vs_" << fixed_protein << ".pdb ";
	ss << " > m" << model_number << ".pdb";
	ss.getline(command,8192);
	int ret = system(command);
	*out << string(command) << " " << ret << endl;
	
}
