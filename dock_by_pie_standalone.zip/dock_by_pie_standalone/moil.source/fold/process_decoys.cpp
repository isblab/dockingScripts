/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"

ostream *out;
char scratch_dir[512], command[8192];
string *native_sequence;
Complex* cnative;
bool **native_contact_core, **native_contact_rim;

void read_profile(Protein *m){
	Aminoacid* aacid[m->aminoacid.size()+1];
	int maaindex=0;
	for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator aaitr = m->aminoacid.begin(); aaitr != m->aminoacid.end(); aaitr++)
		aacid[maaindex++] = ((Aminoacid*) aaitr->second);
	
	sort(aacid, aacid+m->aminoacid.size(),less<Aminoacid*>());	
	/*for(int i = 0; i < maaindex; i++)
		for(int j = i+1; j < maaindex; j++)
			if(less<Aminoacid*>()(aacid[j],aacid[i])){
				Aminoacid* aa = aacid[i];
				aacid[i] = aacid[j];
				aacid[j] = aa;
			}*/
	
	stringstream ss (stringstream::in | stringstream::out);
	string filename;
	ss << m->pdbcode << "_" << m->chain << ".profile";
	ss >> filename;
	fstream fin(filename.c_str(), fstream::in);
	if(!fin.is_open()){
		*out << "ERROR: profile not present" << endl;
		out->flush(); exit(1);
	}
	
	char buf[8192];
	do {
		fin.getline(buf,8192);
	} while ((string(buf)).find("position") == string::npos);
	fin.getline(buf,8192);
	
	int aaindex = 0;
	while(!fin.eof() && ((string(buf)).find("Lambda") == string::npos)){
		fin.getline(buf,8192);
		if(fin.gcount() > 150){
			Aminoacid* aa = aacid[aaindex];
	
			float entropy;
			{
				stringstream line(buf+150,stringstream::in);
				line >> entropy;
			}
		
			aa->entropy_sequence = entropy;
			aaindex++;
			*out << aa->get_symbol() << " " << aa->entropy_sequence << endl;
		}
	}
	fin.close();
}

void process_native(Complex *c){
	for(hash_map<char, Molecule*, hash<char>, eqint>::iterator mitr = c->molecules.begin(); mitr != c->molecules.end(); mitr++){
		Molecule* m = mitr->second;
		string sequence =  ((Protein*) m)->compute_aasequence();
		native_sequence = new string(sequence);
		//read_profile(m);
	}
	*out << "nat\t" << *native_sequence << endl;
	
	c->compute_volume_sasa(false,false);
	for(int i = 0; i < c->num_atoms; i++){
		Atom *a = c->atom[i];
		a->is_buried = a->is_buried || (a->sasa <= 0.2*PI*a->radius*a->radius);
	}
	
	native_contact_core = (bool**) malloc(sizeof(bool*)*c->num_aminoacids);
	native_contact_rim = (bool**) malloc(sizeof(bool*)*c->num_aminoacids);
	for(int i = 0; i < c->num_aminoacids; i++){
		native_contact_core[i] =  (bool *) malloc(sizeof(bool)*c->num_aminoacids);
		native_contact_rim[i] =  (bool *) malloc(sizeof(bool)*c->num_aminoacids);
		for(int j = 0; j < c->num_aminoacids; j++)
			native_contact_core[i][j] = native_contact_rim[i][j] = false;
	}
		
	for(int i = 0; i < c->num_aminoacids; i++){
		Aminoacid *raa = c->aminoacid[i];	 
		for(int j = i+3; j < c->num_aminoacids; j++){
			Aminoacid *laa = c->aminoacid[j];
			for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator laitr=laa->atom.begin(); laitr!=laa->atom.end()&&!native_contact_core[i][j];laitr++){
				Atom *al = laitr->second;
				if((al->name).c_str()[0] != 'H'){
					for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator raitr=raa->atom.begin(); raitr!=raa->atom.end()&&!native_contact_core[i][j];raitr++){
						Atom *ar = raitr->second;
						if((ar->name).c_str()[0] != 'H'){
							double d2 = Vector::distance_squared(al->position,ar->position);
							if(d2 < ATOM_STEPP_DCUTOFF_SQUARED){// && (d2 >= ATOM_STEPP_DMIN_SQUARED))
								if(al->is_buried && ar->is_buried){
									native_contact_core[i][j] = true;
									native_contact_rim[i][j] = false;
								} else	{
									if(!native_contact_core[i][j])
										native_contact_rim[i][j] = true;
								}	
							}
						}
					}
				}
			}
		}
	}
}

void process_decoy(Complex *c, fstream *foutput,float rmsd){
	bool substr_of_native = true;
	string sequence;
	int seq_start_in_native_seq;
	for(hash_map<char, Molecule*, hash<char>, eqint>::iterator mitr = c->molecules.begin(); mitr != c->molecules.end(); mitr++){
		Molecule* m = mitr->second;
		sequence =  ((Protein*)m)->compute_aasequence();
		if(rmsd == 0)	native_sequence = new string(sequence);
		seq_start_in_native_seq = native_sequence->find(sequence,0);
		substr_of_native = (seq_start_in_native_seq != string::npos);
		//read_profile(m);
	}
	
	if(substr_of_native){
		unsigned short native_num_aminoacids = native_sequence->size();
		bool residue_in_decoy[native_num_aminoacids];
		for(unsigned short i = 0; i < native_num_aminoacids; i++)	residue_in_decoy[i] = true;
		*out << "seq:\t";
		for(unsigned short i = 0; i < seq_start_in_native_seq; i++){
			residue_in_decoy[i] = false;
			*out << "-";
		}
		*out << sequence;
		for(unsigned short i = seq_start_in_native_seq+sequence.size(); i < native_sequence->size(); i++){
			residue_in_decoy[i] = false;
			*out << "-";
		}
		*out << endl;
		
		int num_residue_types = 20;
		
		// surface area
		// compute the surface of the matching fragment of the native sequence
		compute_fragment_sasa(cnative, seq_start_in_native_seq, c->num_aminoacids + seq_start_in_native_seq);
		c->compute_volume_sasa(false,false);
		for(int i = 0; i < c->num_atoms; i++){
			Atom *a = c->atom[i];
			a->is_buried = a->is_buried || (a->sasa <= 0.2*PI*a->radius*a->radius);
		}
		
		float surface_area[num_residue_types];
		for(unsigned short i = 0; i < num_residue_types; i++)	surface_area[i] = 0;
		for(unsigned short i = 0; i < c->num_aminoacids; i++){
			Aminoacid *aanative = cnative->aminoacid[i+seq_start_in_native_seq];
		 	Aminoacid *aa = c->aminoacid[i];
		 	surface_area[aa->type] += (aanative->sa - aa->sa);
		}
		
		// pair potential
		short residue_contacts_core[num_residue_types][num_residue_types],residue_contacts_rim[num_residue_types][num_residue_types];
		for(int i = 0; i < num_residue_types; i++)
			for(int j = 0; j < num_residue_types;j++)
				residue_contacts_core[i][j] = residue_contacts_rim[i][j] = 0;

		bool contact[c->num_aminoacids][c->num_aminoacids];
		for(int i = 0; i < c->num_aminoacids; i++)
		 	for(int j = 0; j < c->num_aminoacids; j++)
		 		contact[i][j] = false;
		
		unsigned short num_diff_contacts_core=0,num_diff_contacts_rim=0;
		for(int i = 0; i < c->num_aminoacids; i++){
		 	Aminoacid *ra = c->aminoacid[i];
		 	for(int j = i+3; j < c->num_aminoacids; j++){
				Aminoacid *la = c->aminoacid[j];
				bool decoy_contact_core = false, decoy_contact_rim = false;
				
				for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator laitr=la->atom.begin(); laitr!=la->atom.end()&&!decoy_contact_core;laitr++){
					Atom *al = laitr->second;
					if((al->name).c_str()[0] != 'H'){
						for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator raitr=ra->atom.begin(); raitr!=ra->atom.end()&&!decoy_contact_core;raitr++){
							Atom *ar = raitr->second;
							if((ar->name).c_str()[0] != 'H'){
								double d2 = Vector::distance_squared(al->position,ar->position);
								if(d2 < ATOM_STEPP_DCUTOFF_SQUARED){// && (d2 >= ATOM_STEPP_DMIN_SQUARED))
									if(al->is_buried && ar->is_buried){
										decoy_contact_core = true;
										decoy_contact_rim = false;
									} else	{
										if(!decoy_contact_core)
											decoy_contact_rim = true;
									}
								}
							}
						}
					}
				}
				//if(ra->alpha_carbon != NULL && la->alpha_carbon != NULL && Vector::distance(ra->alpha_carbon->position,la->alpha_carbon->position) < SS_CUTOFF)
				contact[i][j] = decoy_contact_core || decoy_contact_rim;
				
				if(j>i+3){
					int nati = i+seq_start_in_native_seq;
					int natj = j+seq_start_in_native_seq;
					
					if(native_contact_core[nati][natj] || native_contact_rim[nati][natj] || decoy_contact_core || decoy_contact_rim)	{
						short diff_contact = 0;
					
						// differences in core-core contacts
						if(native_contact_core[nati][natj] && !(decoy_contact_core || decoy_contact_rim))	diff_contact = 1;
						if(decoy_contact_core && !(native_contact_core[nati][natj] || native_contact_rim[nati][natj]))	diff_contact = -1;
						
						if(ra->type != GAP && la->type != GAP && diff_contact != 0){
							num_diff_contacts_core++;
						 	short ratype=ra->type,latype=la->type;
						 	if(ratype <= latype)
								residue_contacts_core[ratype][latype] += diff_contact;
							else
								residue_contacts_core[latype][ratype] += diff_contact;
						}
				 	
				 		// core in native is rim contact in decoy?
				 		diff_contact = 0;
				 		if(native_contact_rim[nati][natj] && !(decoy_contact_core || decoy_contact_rim))	diff_contact = 1;
						if(decoy_contact_rim && !(native_contact_core[nati][natj] || native_contact_rim[nati][natj]))	diff_contact = -1;
						
						if(ra->type != GAP && la->type != GAP && diff_contact != 0){
							num_diff_contacts_rim++;
						 	short ratype=ra->type,latype=la->type;
						 	if(ratype <= latype)
								residue_contacts_rim[ratype][latype] += diff_contact;
							else
								residue_contacts_rim[latype][ratype] += diff_contact;
						}
				 	}
				}
		 	}
		}
		
		short threebody_contacts[NUM_COARSE_RTYPES][NUM_COARSE_RTYPES][NUM_COARSE_RTYPES];
		for(int i = 0; i < NUM_COARSE_RTYPES; i++)
			for(int j = i; j < NUM_COARSE_RTYPES; j++)
				for(int k = j; k < NUM_COARSE_RTYPES; k++)
					threebody_contacts[i][j][k] = 0;
		
		for(int i = 0; i < c->num_aminoacids; i++){
		 	Aminoacid *aa1 = c->aminoacid[i];
		 	for(int j = i+3; j < c->num_aminoacids; j++){
				Aminoacid *aa2 = c->aminoacid[j];
				int nati = i+seq_start_in_native_seq;
				int natj = j+seq_start_in_native_seq;
				if(contact[i][j] || (native_contact_core[nati][natj]||native_contact_rim[nati][natj]) && aa1->type != GAP && aa2->type != GAP)
					for(int k = j+3; k < c->num_aminoacids; k++){
						Aminoacid *aa3 = c->aminoacid[k];
						int natk = k+seq_start_in_native_seq;
						short diff_contact = 0;
						bool decoy_3bcontact = (contact[i][k] && contact[j][k]);
						bool nat_3bcontact = (native_contact_core[nati][natk]||native_contact_rim[nati][natk]) && (native_contact_core[natj][natk]||native_contact_rim[natj][natk]);
						if(decoy_3bcontact && !nat_3bcontact)	diff_contact = 1;
						if(!decoy_3bcontact && nat_3bcontact)	diff_contact = -1;
						if(aa3->type != GAP && diff_contact != 0){	
							short type[3];
							type[0] = RTYPE(aa1->type); type[1] = RTYPE(aa2->type); type[2] = RTYPE(aa3->type);
							for(short i = 0; i < 3; i++)
								for(short j = i+1; j < 3; j++)
									if(type[j] < type[i]){
										short t = type[i];
										type[i] = type[j];
										type[j] = t;
									}
							threebody_contacts[type[0]][type[1]][type[2]] += diff_contact;
						}
					}
		 	}
		}			
	
		*foutput << rmsd << "\t" << num_diff_contacts_core << " " << num_diff_contacts_rim << "\t";
		for(int i = 0; i < 20; i++)
			*foutput << (0 - surface_area[i]) << " ";
		for(int i = 0; i < 20; i++)
			for(int j = i; j < 20; j++)
				*foutput << residue_contacts_core[i][j] << " ";
		for(int i = 0; i < 20; i++)
			for(int j = i; j < 20; j++)
				*foutput << residue_contacts_rim[i][j] << " ";
		for(int i = 0; i < NUM_COARSE_RTYPES; i++)
			for(int j = i; j < NUM_COARSE_RTYPES; j++)
				for(int k = j; k < NUM_COARSE_RTYPES; k++)
					*foutput << threebody_contacts[i][j][k] << " ";
		*foutput << endl;
	} else {
		*out << "ERROR : not substring of native string" << endl;
		for(hash_map<char, Molecule*, hash<char>, eqint>::iterator mitr = c->molecules.begin(); mitr != c->molecules.end(); mitr++){
			Molecule* m = mitr->second;
			*out << "seq : " << ((Protein*)m)->num_aminoacids << " " << seq_start_in_native_seq << " "
				<< sequence << endl;
		}
	}
}

/*
 * Arguments: nativeinpdb? filewithlistofdecoys outputfile
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	//cout << "read molecule config" << endl; cout.flush();
	read_dock_config();
	//cout << "read dock config" << endl; cout.flush();
	
	bool nativeinpdb = (atoi(argv[1]) != 0);
	fstream fdecoys(argv[2],fstream::in);
	fstream foutput(argv[3],fstream::out);
	bool processed_native = false;
	
	int lineno=0;
	while(fdecoys.good()){
		char buf[8192];			
		fdecoys.getline(buf,8192);
		if(fdecoys.gcount() > 0){
			stringstream line(buf,stringstream::in);
			string nativepdbid, nativechain;
			line >> nativepdbid;
			line >> nativechain;
			if(!processed_native){
				processed_native=true;
				*out << nativeinpdb << endl;
				if(nativeinpdb){
					cnative = new Complex(string(argv[4]),nativechain.c_str(),PDB);
					process_native(cnative);
					cout << "native_num_residues " << cnative->num_aminoacids << endl;
				} else {
					// use the best positive example
				}
				
			}
			string decoypdbid, decoychain;
			line >> decoypdbid; 
			line >> decoychain;
			string decoypdbfilename;
			line >> decoypdbfilename;
			float rmsd;
			line >> rmsd;
			stringstream ss (stringstream::in | stringstream::out);
			ss << "/proj/pmajek/fready_backup/pdbs/results_2nd_pdb/" << decoypdbfilename.substr(0,decoypdbfilename.find(".pdb"));
			string filename;
			ss >> filename;
			Complex* cd = new Complex(filename.c_str(),string("-").c_str(),PDB);
			process_decoy(cd,&foutput,rmsd);
			lineno++;
			if(lineno%10==0)	foutput.flush();
		}
	}
	
	fdecoys.close();
	foutput.close();	
}
