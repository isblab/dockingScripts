/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"
#include <sys/stat.h>

ostream *out;
char scratch_dir[512], command[8192], buf[8192];
extern char *tmp_dir;

#define LINEAR_SPLINE_POTENTIAL

/*
 * Arguments: list of files with pdb file name (full path without the .pdb extension, expect the filename to end in .pdb)
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	//coarsen_atomtypesto20();
	read_dock_config();
	
	char* filename = (char*) argv[1];
	
	fstream listin(filename,fstream::in);
	sprintf(buf,"%s.piedetails",filename);
	fstream fdetails(buf,fstream::out);
	int lineno=1;
	while(listin.good()){
	    listin.getline(buf,8192);
	    if(listin.gcount() > 0){
	    	string template_name=string(buf);
			//Complex *c = new Complex(buf,"ABCD", PDB);
			Complex *c = new Complex(buf,"-", PDB);
			
			float residue_contacts[NUM_RESIDUE_TYPES][NUM_RESIDUE_TYPES];
			// compute residue contacts
			for(int i = 0; i < NUM_RESIDUE_TYPES; i++)
				for(int j = 0 ; j < NUM_RESIDUE_TYPES; j++)
					residue_contacts[i][j] = 0;
				
			float eVdw = 0, eVdw_repulsion = 0, num_clashes=0, num_bbclashes=0;
			
			for(int laindex = 0; laindex < c->num_aminoacids; laindex++){
				Aminoacid *la = c->aminoacid[laindex];
				if(la->centroid != NULL)
					for(int raindex = laindex+4; raindex < c->num_aminoacids; raindex++){
					 	Aminoacid *ra = c->aminoacid[raindex];
						{				 		
							if(ra->type >= 0 && ra->centroid != NULL){
								float d2 = Vector::distance_squared(*(la->centroid),*(ra->centroid));
								float factor = 0;
	#ifdef 	STEP_POTENTIAL 			
								if(d2 < AA_CUTOFF_SQUARED)
	#endif
	#ifdef LINEAR_SPLINE_POTENTIAL										 			
								if(d2 < AA_SMTHP_CUTOFF_SQUARED)
	#endif												
								{	
	#ifdef 	STEP_POTENTIAL 	
									factor = 1.0;
	#endif
	#ifdef LINEAR_SPLINE_POTENTIAL	 									
						 			if(d2 < AA_CUTOFF_SQUARED)	factor = 1.0;
									else{ float d=sqrt(d2);	factor = AA_SMTHP_FACTOR(d); }
	#endif						
								}
								short ratype=ra->type, latype=la->type;
								if(ratype >= 0 && latype>= 0)
									if(ratype <= latype)
										residue_contacts[ratype][latype] += factor;
									else
										residue_contacts[latype][ratype] += factor;
							}
							
							// backbone centroid and backbone backbone contacts
			 				{
						 		Vector *vaa[3];
								vaa[0] = la->centroid;
								vaa[1] = (la->amide_nitrogen == NULL) ? NULL : la->amide_nitrogen->position;
								vaa[2] = (la->carbonyl_oxygen == NULL) ? NULL : la->carbonyl_oxygen->position;
								for(int aapi = 0; aapi < 3; aapi++) 
									if(vaa[aapi]  != NULL){
										Vector vl = Vector(*(vaa[aapi]));
										if(ra->type >= 0)	
											for(int aapj = 0; aapj < 3; aapj++){  
												float d, d2, factor=0;
												if((aapi == 0 && aapj != 0 && la->type >= 0) || 
												 (aapi != 0 && aapj == 0 && ra->centroid != NULL)) {
												 	bool computefactor=false;
												 	if(aapi == 0 && aapj == 1 && ra->amide_nitrogen != NULL){
												 		computefactor=true;
														d2=Vector::distance_squared(vl,*(ra->amide_nitrogen->position));
												 	}
													if(aapi == 0 && aapj == 2 && ra->carbonyl_oxygen != NULL){
														computefactor=true;
														d2=Vector::distance_squared(vl,*(ra->carbonyl_oxygen->position));
													}
													if(aapi != 0){
														computefactor=true;
														d2=Vector::distance_squared(vl,*(ra->centroid));
													}
													
													if(computefactor)
	#ifdef 	STEP_POTENTIAL 			
														if(d2 < BS_CUTOFF_SQUARED)
	#endif
	#ifdef LINEAR_SPLINE_POTENTIAL										 			
														if(d2 < BS_SMTHP_CUTOFF_SQUARED)
	#endif												
														{	
	#ifdef 	STEP_POTENTIAL 	
															factor = 1.0;
	#endif
	#ifdef LINEAR_SPLINE_POTENTIAL	 									
								 							if(d2 < BS_CUTOFF_SQUARED)	factor = 1.0;
															else{ float d=sqrt(d2);	factor = BS_SMTHP_FACTOR(d); }
	#endif						
														}
													if(aapi == 0 && aapj != 0 && la->type >= 0){									
														residue_contacts[la->type][19+aapj] += factor;
														residue_contacts[19+aapj][la->type] += factor;
													} else {
														residue_contacts[ra->type][19+aapi] += factor;
														residue_contacts[19+aapi][ra->type] += factor;
													}
												}
										
												if(aapi > 0 && aapj > 0){
													bool computefactor=false;
												 	if(aapj == 1 && ra->amide_nitrogen != NULL){
												 		computefactor=true;
														d2=Vector::distance_squared(vl,*(ra->amide_nitrogen->position));
												 	}
													if(aapj == 2 && ra->carbonyl_oxygen != NULL){
														computefactor=true;
														d2=Vector::distance_squared(vl,*(ra->carbonyl_oxygen->position));
													}
													
													if(computefactor)
	#ifdef 	STEP_POTENTIAL 			
														if(d2 < BB_CUTOFF_SQUARED)
	#endif
	#ifdef LINEAR_SPLINE_POTENTIAL										 			
														if(d2 < BB_SMTHP_CUTOFF_SQUARED)
	#endif												
														{	
	#ifdef 	STEP_POTENTIAL 	
															factor = 1.0;
	#endif
	#ifdef LINEAR_SPLINE_POTENTIAL	 									
								 							if(d2 < BB_CUTOFF_SQUARED)	factor = 1.0;
															else{ float d=sqrt(d2);	factor = BB_SMTHP_FACTOR(d); }
	#endif		
														}
													residue_contacts[19+aapi][19+aapj] += factor;
													if(aapi != aapj)	residue_contacts[19+aapj][19+aapi] += factor;											
												}
											} // aapj
									}
					 		}
							
							for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator laitr = la->atom.begin(); laitr != la->atom.end(); laitr++){
								Atom *al = (Atom *) laitr->second;
								for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator raitr = ra->atom.begin(); raitr != ra->atom.end(); raitr++){
									Atom *ar = (Atom *) raitr->second;
									float d2 = Vector::distance_squared(al->position,ar->position);
									
									if(d2 < ATOM_CLASH_CUTOFF_SQUARED){
										num_clashes++;
										if(al->isbbatom && ar->isbbatom && d2 < BBATOM_CLASH_CUTOFF_SQUARED)
											num_bbclashes++;
									}
									
									if(d2 < ATOM_SMTHP_DCUTOFF_SQUARED)							
									{	
											float factor = 0;
											float d_scaled = sqrt(d2/(3.2*ar->sigma));
		 									factor = VDW_ATTR(d_scaled);
		 									if(factor > 0){
												// 6-12 factor = 4 * a->sqrt_eps * ar->sigma_cubed * factor;
												factor = 4 * ar->sqrt_eps * factor;
												eVdw += factor * al->sqrt_eps;
											} else {
												factor = VDW_REPUL(d_scaled);
												factor = 4 * ar->sqrt_eps * factor;
												eVdw_repulsion += factor * al->sqrt_eps;
											}	
									}
								}
					 		}
					 	}
					}
			}
			
			fdetails << template_name << " " << eVdw << " " << eVdw_repulsion << " " << c->num_aminoacids 
			  << " " << num_clashes << " " << num_bbclashes << " ";
			for(unsigned short i = 0; i < NUM_RESIDUE_TYPES; i++)
				for(unsigned short j = i; j < NUM_RESIDUE_TYPES; j++)
					if(i % NUM_RESIDUE_TYPES < 20 && j % NUM_RESIDUE_TYPES < 20)
						fdetails << residue_contacts[i][j] << " ";
			for(unsigned short i = 0; i < 20; i++)
				fdetails << residue_contacts[NTER][i] << " ";
			for(unsigned short i = 0; i < 20; i++)
				fdetails << residue_contacts[CTER][i] << " ";
			fdetails << residue_contacts[NTER][NTER] << " " << residue_contacts[NTER][CTER]
			 << " " << residue_contacts[CTER][CTER] << " ";   
			fdetails << endl;
			
			delete c;
			lineno++;
		 }
	}
	fdetails.close();
}
