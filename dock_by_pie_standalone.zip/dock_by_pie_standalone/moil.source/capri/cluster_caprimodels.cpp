/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];
extern char *tmp_dir;

int rm1_vs_m2[400], lm1_vs_m2[400], rm2_vs_m1[400], lm2_vs_m1[400];

void read_alignments(int id1, int id2){
	for(int i = 0 ; i < 400; i++)
		rm1_vs_m2[i] = lm1_vs_m2[i] = -1;
	
	{
		sprintf(buf,"models/rec_m%d_vs_m%d.ali",id1, id2);
		string filename = string(buf);
		fstream fin;
		fin.open(filename.c_str(), ios::in);
	
		string aseq1,aseq2,s;
		int qstart, sstart;
		bool alignment_done;
		stringstream *line;	
		int offset2 = 0, offset1 = 0;
		
		if(fin.is_open()){
			aseq1 = ""; aseq2 = "";
			qstart = sstart = 1;
				
			// reading input from the output of nwa
			fin.getline(buf,8192);
			fin.getline(buf,8192);
			do{
				line = new stringstream(buf,stringstream::in);
				*line >> s;
				aseq1 += s;
				fin.getline(buf,8192);
			}while((string(buf)).find(">>") == string::npos);
			while(fin.good()){
				fin.getline(buf,8192);
				if(fin.gcount() > 0){
					line = new stringstream(buf,stringstream::in);
					*line >> s;
					aseq2 += s;
					//*out << ">" << aseq2 << endl;
				}
			}
				
			*out << aseq1 << endl << aseq2 << endl;
				
			int qindex = qstart-1, sindex = sstart-1;
			int n = aseq1.size();
			const char* aseq1c = aseq1.c_str();
			const char* aseq2c = aseq2.c_str();
				
			for(int i = 0 ; i < n ; i++){
				int qindexc = qindex + offset1;
				int sindexc = sindex + offset2;
				if(aseq1c[i] != '-' && aseq2c[i] != '-'){
					rm1_vs_m2[qindexc] = sindexc;
					rm2_vs_m1[sindexc] = qindexc;
					*out << qindex << "-" << qindexc << "-" << sindex << "-" << sindexc << " ";
				}
				if(aseq1c[i] != '-')	qindex++;
				if(aseq2c[i] != '-')	sindex++;	
			}
			fin.close();
		} else {
			cout << "ERROR: Alignment does not exist " << filename << endl;
			exit(-1);
		}
		out->flush();
	}
	{
		sprintf(buf,"models/lig_m%d_vs_m%d.ali",id1, id2);
		string filename = string(buf);
		fstream fin;
		fin.open(filename.c_str(), ios::in);
	
		string aseq1,aseq2,s;
		int qstart, sstart;
		bool alignment_done;
		stringstream *line;	
		int offset2 = 0, offset1 = 0;
		
		if(fin.is_open()){
			aseq1 = ""; aseq2 = "";
			qstart = sstart = 1;
				
			// reading input from the output of nwa
			fin.getline(buf,8192);
			fin.getline(buf,8192);
			do{
				line = new stringstream(buf,stringstream::in);
				*line >> s;
				aseq1 += s;
				fin.getline(buf,8192);
			}while((string(buf)).find(">>") == string::npos);
			while(fin.good()){
				fin.getline(buf,8192);
				if(fin.gcount() > 0){
					line = new stringstream(buf,stringstream::in);
					*line >> s;
					aseq2 += s;
					//*out << ">" << aseq2 << endl;
				}
			}
				
			*out << aseq1 << endl << aseq2 << endl;
				
			int qindex = qstart-1, sindex = sstart-1;
			int n = aseq1.size();
			const char* aseq1c = aseq1.c_str();
			const char* aseq2c = aseq2.c_str();
				
			for(int i = 0 ; i < n ; i++){
				int qindexc = qindex + offset1;
				int sindexc = sindex + offset2;
				if(aseq1c[i] != '-' && aseq2c[i] != '-'){
					lm1_vs_m2[qindexc] = sindexc;
					lm2_vs_m1[sindexc] = qindexc;
					*out << qindex << "-" << qindexc << "-" << sindex << "-" << sindexc << " ";
				}
				if(aseq1c[i] != '-')	qindex++;
				if(aseq2c[i] != '-')	sindex++;	
			}
			fin.close();
		} else {
			cout << "ERROR: Alignment does not exist " << filename << endl;
			exit(-1);
		}
		out->flush();
	}
}

/*
 * Arguments: receptor-chains ligand-chains #models
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	read_dock_config();
	
	int target = atoi(argv[1]);
	sprintf(buf,"models/m%d",target);
	Complex *c, *ctarget = new Complex(buf,"AB", PDB);;
	int len1 = ((Protein*)ctarget->molecules['A'])->num_aminoacids;
	int len2 = ((Protein*)ctarget->molecules['B'])->num_aminoacids;
	char trchain = 'A', tlchain = 'B';
	if(len1 < len2){	trchain = 'B'; tlchain='A'; }
			
	fstream selectin("top100ids", ios::in);
	int lineno=0;
	while(selectin.good()){
		int mid;
		selectin >> mid;
		lineno++;
		
		if(target != mid){
			if(target > mid)	read_alignments(target, mid);
			else	read_alignments(mid,target);
		
			sprintf(buf,"models/m%d",mid);
			c = new Complex(buf,"AB", PDB);
			int len1 = ((Protein*)c->molecules['A'])->num_aminoacids;
			int len2 = ((Protein*)c->molecules['B'])->num_aminoacids;
			char rchain = 'A', lchain = 'B';
			if(len1 < len2){	rchain = 'B'; lchain='A'; }
			cout << "comparing model " << mid << endl;
			
			int moffset = c->mmonostart[rchain];
			Vector target_points[c->num_aminoacids+1], model_points[c->num_aminoacids+1];
			int point_index = 0;
			hash_set<int,hash<int>, eqint> added_residue;
			Protein *pl = (Protein*) ctarget->molecules[tlchain];
			for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator mlitr = pl->aminoacid.begin(); mlitr != pl->aminoacid.end(); mlitr++){
				Aminoacid *la = (Aminoacid*) mlitr->second;
				if(la->centroid != NULL){
					Protein *pr = (Protein*) ctarget->molecules[trchain];
					for(hash_map<const char*, Aminoacid*, hash<const char*>,eqstr>::iterator mritr = pr->aminoacid.begin(); mritr != pr->aminoacid.end(); mritr++){
						Aminoacid *ra = (Aminoacid*) mritr->second;
						if(ra->centroid != NULL && Vector::distance_squared(*(la->centroid),*(ra->centroid)) < SS_CUTOFF*SS_CUTOFF){
							if(added_residue.count(ra->cindex) == 0){
								int alignindex = ra->cindex - ctarget->mmonostart[trchain];
								Aminoacid *rma = NULL;
								if(target > mid){ 
									if(rm1_vs_m2[alignindex] != -1)
										rma = c->aminoacid[rm1_vs_m2[alignindex] + c->mmonostart[rchain]];
								} else {
									if(rm2_vs_m1[alignindex] != -1)
										rma = c->aminoacid[rm2_vs_m1[alignindex] + c->mmonostart[rchain]];
								}
								if(ra->alpha_carbon != NULL && rma != NULL && rma->alpha_carbon != NULL){
									target_points[point_index] = Vector(ra->alpha_carbon->position);
									model_points[point_index] = Vector(rma->alpha_carbon->position);
									point_index++;
								}
								added_residue.insert(ra->cindex);
							}
			 				
			 				if(added_residue.count(la->cindex) == 0){
								int alignindex = la->cindex - ctarget->mmonostart[tlchain];
								Aminoacid *lma = NULL;
								if(target > mid){ 
									if(lm1_vs_m2[alignindex] != -1)
										lma = c->aminoacid[lm1_vs_m2[alignindex] + c->mmonostart[lchain]];
								} else {
									if(lm2_vs_m1[alignindex] != -1)
										lma = c->aminoacid[lm2_vs_m1[alignindex] + c->mmonostart[lchain]];
								}
								if(la->alpha_carbon != NULL && lma != NULL && lma->alpha_carbon != NULL){
									target_points[point_index] = Vector(la->alpha_carbon->position);
									cout << lchain << " " << c->mmonostart[lchain] << " " << alignindex << " " << lma->cindex << endl;cout.flush();
									model_points[point_index] = Vector(lma->alpha_carbon->position);
									point_index++;
								}
								added_residue.insert(la->cindex);
							}
						}
					}
				}
			}
			//if(point_index > 0){
				float irmsd = compute_rmsd(point_index, &target_points[0], &model_points[0]);
				cout << mid << " " << lineno << " " << point_index << " irmsd " << irmsd << endl;
			//}
			delete c;
		}
	}
	selectin.close();
	
}
