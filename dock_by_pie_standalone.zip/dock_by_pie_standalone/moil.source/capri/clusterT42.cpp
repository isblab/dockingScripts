/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];

#define SPACED_ROTATIONS "232020.euler"
float **rot_angles;

/*
 * Arguments: transformationfile transformationid ligandpdbid ligandchains gridsize
 */
int main(int argc, char *argv[]){
	out = &cout;
	read_molecule_config();
	read_dock_config();
	
	string filename = string(getenv(string("HOME").c_str())) + "/" + string(DOCK_DIR) + string(SPACED_ROTATIONS);
	fstream frotations(filename.c_str());
	int num_rotations;
    while(frotations.good()){
    	frotations.getline(buf,8192);
    	if(frotations.gcount() > 0)
    		num_rotations++;
    }
	rot_angles = (float**) malloc(sizeof(float*)*num_rotations);
	for(int i = 0 ; i < num_rotations; i++)	rot_angles[i] = (float*) malloc(sizeof(float)*3);
    
    frotations.clear();
    frotations.seekg(ios_base::beg);
    num_rotations=0;
    while(frotations.good()){
    	frotations.getline(buf,8192);
    	if(frotations.gcount() > 0){
    		stringstream ss (stringstream::in | stringstream::out);
			ss << buf;
			ss >> rot_angles[num_rotations][0];
			ss >> rot_angles[num_rotations][1];
			ss >> rot_angles[num_rotations][2];
			num_rotations++;
    	}
    }
    frotations.close();
	
	Complex *c = new Complex(("../"+string(argv[2])).c_str(),argv[3], PDB);
	int gridsize;
	c->compute_motions();
	float minx, maxx, miny, maxy, minz, maxz, maxr;
	int aindex = 0;
	Vector center = Vector(c->center);
	for(int i = 0 ; i < c->num_atoms; i++){
		Atom *a = c->atom[i];
		Vector v = *(a->position) - center;	// set grid_origin such that it is independent of rotation
		//Vector v = tr->transform(*(a->position) - center);
		if(aindex++ == 0){
			minx = maxx = v.x;
			miny = maxy = v.y;
			minz = maxz = v.z;
			maxr = a->radius;
		}
		
		maxx = (v.x > maxx)? v.x : maxx;
		minx = (v.x < minx)? v.x : minx;
		maxy = (v.y > maxy)? v.y : maxy;
		miny = (v.y < miny)? v.y : miny;
		maxz = (v.z > maxz)? v.z : maxz;
		minz = (v.z < minz)? v.z : minz;
		maxr = (a->radius > maxr) ? a->radius : maxr;
	}

	float grid_spacing=1.20;
	float spread = 2*maxr + 2*probe_radius + c->diameter + 10.0;
	float xextent = maxx - minx, yextent = maxy - miny, zextent = maxz - minz;
	float maxextent = max(xextent, (max(yextent,zextent)));
	int maxsize = ceil((spread+maxextent)/grid_spacing); 
	if(maxsize%2 == 1)	maxsize++;
	gridsize = maxsize; 
	*out << "extent " << xextent << " " << yextent << " " << zextent << " max r " << maxr << " " << gridsize << endl; out->flush();
	Vector *grid_origin = new Vector(minx-spread/2.0,miny-spread/2.0,minz-spread/2.0);
	
	// storing cluster size in num_neighbors, worst score in eInterface and sum score in eElectrostatic
	vector<Transformation*> selected_transformations;
	hash_map<long,vector<Transformation*>,hash<long>,eqlong> clustered_transformations;
	fstream transin(argv[1],ios::binary|ios::in);
	*out << argv[1] << " " << transin.good() << endl;
	fstream transout(argv[4],ios::out);
	unsigned int num_trans=0,num_selected=0;
	unsigned short transbinasize = 2*(sizeof(float)+sizeof(unsigned int));
	while(transin.good()){
		transin.read(buf,transbinasize);
		if(transin.gcount() > 0){
			float atomp, evdw;
			unsigned int translation, rotindex;
			char *current = buf;
			memcpy(&atomp,current,sizeof(float));
			current += sizeof(float);
			memcpy(&evdw,current,sizeof(float));
			current += sizeof(float);
			memcpy(&translation,current,sizeof(unsigned int));
			current += sizeof(unsigned int);
			memcpy(&rotindex,current,sizeof(unsigned int));
			current += sizeof(unsigned int);
			
			Transformation *tr = new Transformation(rot_angles[rotindex][0],rot_angles[rotindex][1], rot_angles[rotindex][2],0);
			tr->eSolvation = atomp;
			
			float x = translation/(gridsize*gridsize);
			float y = ((translation/gridsize) % gridsize);
			float z = (translation % gridsize);
				
			if(x >= gridsize/2)	x = x - gridsize;
			if(y >= gridsize/2)	y = y - gridsize;
			if(z >= gridsize/2)	z = z - gridsize;	
			
			*(tr->translation) = *(c->center) +tr->inverse_transform(*(grid_origin) - (Vector(-x,-y,-z)*grid_spacing + *(grid_origin) + *(c->center)));
			
			bool select = true;
			Transformation *trneighbor=NULL;
			int trx = (((int) tr->translation->x) + 200)/5;
			int tr_y = (((int) tr->translation->y) + 200)/5;
			int trz = (((int) tr->translation->z) + 200)/5;
			long index = (trx*100 + tr_y)*100 + trz;
			
			for(short level = 0; level <= 1 && select; level++)
				for(int xi = -level; xi <= level && select; xi++)
					for(int yi = -level; yi <= level && select; yi++)
						for(int zi = -level; zi <= level && select; zi++)
						if(level == 0 || (xi !=0 || yi != 0 || zi != 0) ){
							long index = ((trx + xi)*100 + tr_y + yi)*100 + trz + zi;
							if(clustered_transformations.count(index)>0){
								vector<Transformation*> trlist = clustered_transformations[index];
						//{	{
						//		vector<Transformation*> trlist = selected_transformations;
								for(vector<Transformation*>::iterator itr = trlist.begin(); itr != trlist.end() && select; itr++){
									Transformation *selected_tr = *itr;
									float d, ud;
									selected_tr->distance(&d, &ud, tr);
									//select = !((d <= 4.0 && ud <= 0.2) || (d <= 3.0 && ud <= 0.3));
									select = !((d <= 4.0 && ud <= 0.1) || (d <= 3.0 && ud <= 0.2));
									if(!select)	{
										trneighbor=selected_tr;
										break;
									}
								}
							}
						}
			if(select){
				selected_transformations.push_back(tr);
				transout.write((char*) buf,transbinasize);
				if(clustered_transformations.count(index) == 0){
					clustered_transformations[index] = *(new vector<Transformation*>);
				}
				clustered_transformations[index].push_back(tr);
				tr->num_neighbors = 0;
				tr->eSolvation = tr->eElectrostatic = tr->delta_sasa;
				tr->frame_number = num_selected;
				num_selected++;
			} else {
				trneighbor->num_neighbors++;
				if(tr->eSolvation < trneighbor->delta_sasa)
					trneighbor->eSolvation = tr->delta_sasa;
				trneighbor->eElectrostatic += tr->delta_sasa;
				delete tr;
			}
				
			num_trans++;
			if(num_trans % 500000 == 0){
				*out << "#trans " << num_trans << " #selected " << num_selected << endl;
				//break;
			}
		}
	}
	transin.close();
	transout.close();
	
	for(vector<Transformation*>::iterator itr = selected_transformations.begin(); itr != selected_transformations.end(); itr++){
		Transformation *tr = *itr;
		cout << tr->frame_number << " " << tr->delta_sasa << " " << tr->num_neighbors+1 << " " << tr->eElectrostatic << " " << tr->eSolvation << endl;
	}
}
