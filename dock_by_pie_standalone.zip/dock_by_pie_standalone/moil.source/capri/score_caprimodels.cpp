/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"
#include <sys/stat.h>

ostream *out;
char scratch_dir[512], command[8192], buf[8192];
extern char *tmp_dir;

/*
 * Arguments: receptor-chains ligand-chains #models
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	//coarsen_atomtypesto20();
	read_dock_config();
	
	int start = atoi(argv[1]);
	int end = atoi(argv[2]);
	int nchains=atoi(argv[3]);
	Complex *p[nchains], *c;
	Transformation *tr;
	sprintf(buf,"details%d_to_%d",start,end);
	fstream fdetails(buf,fstream::out | fstream::out);
	
	struct stat filestat;
	for( int mid = start ; mid < end; mid++){
		cout << "scoring model " << mid << endl;
		//sprintf(buf,"models/alignedm%d",mid);
		sprintf(buf,"models/m%d",mid);
	 if(stat((string(buf)+".pdb").c_str(),&filestat)==0){	
		string allchains="";
		for(int mi=0; mi<nchains; mi++){
			char ch[2];
			ch[1] ='\0'; ch[0] = 'A'+mi;
			p[mi] = new Complex(buf,ch, PDB);
			allchains += ch;
		}
		c = new Complex(buf,allchains, PDB);
		
		tr = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,mid);
		tr->vmetrics = new VerificationMetrics();
		tr->vmetrics->rmsd = tr->vmetrics->lrmsd = tr->vmetrics->irmsd = 100; 
		ProtProtDetailedScoringMetrics *details = new ProtProtDetailedScoringMetrics();
		tr->detailed_scores = details;
		
		//change in surface area
		for(int i = 0 ; i < NUM_RESIDUE_TYPES; i++){
			details->delta_sasa[i] = 0;
			details->delta_vdwsa[i] = 0;
		}
		for(int i = 0; i < NUM_ATOM_TYPES; i++){
			details->delta_sasa_atom[i] = 0;
			details->delta_vdwsa_atom[i] = 0;
		}
		
		for(int mi=0; mi<nchains; mi++){
			p[mi]->compute_volume_sasa(false,false);
		}
		c->compute_volume_sasa(false,false);
		
		for(int mi=0; mi<nchains; mi++){
			Complex *r = p[mi];
			for(int i = 0; i < r->num_aminoacids; i++){
				Aminoacid *am = r->aminoacid[i];
				Aminoacid *ac = ((Protein*)c->molecules[am->chain])->aminoacid[am->index.c_str()];
				float delta_sa = am->sa - ac->sa;
				if(delta_sa > 0 && am->type >= 0)
					details->delta_sasa[am->type] += delta_sa;
					 
				for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator aitr = am->atom.begin(); aitr != am->atom.end(); aitr++){
					Atom *atmm = (Atom *) aitr->second;
					Atom *atmc = ac->atom[(const char*) aitr->first];
					delta_sa = atmm->sasa - atmc->sasa;
					if(delta_sa > 0 && atmm->type >= 0)
						details->delta_sasa_atom[atmm->type] += delta_sa;
					delta_sa = atmm->vdwsa - atmc->vdwsa;
					if(delta_sa > 0 && atmm->type >= 0)
						details->delta_vdwsa_atom[atmm->type] += delta_sa;
				}
			}
		}
		
		// compute residue contacts
		for(int i = 0; i < NUM_RESIDUE_TYPES; i++)
			for(int j = 0 ; j < NUM_RESIDUE_TYPES; j++)
				details->residue_contacts_core[i][j] = 0;
			
		for(int i = 0; i < NUM_ATOM_TYPES; i++)
			for(int j = 0; j < NUM_ATOM_TYPES; j++)
				if(NUM_ATOM_DISTANCE_DIVISIONS <=1)
					details->atom_contacts[i][j] = 0;
				else
					for(int k = 0 ; k < NUM_ATOM_DISTANCE_DIVISIONS; k++)
						details->atom_dcontacts[i][j][k] = 0;
		
		int num_clashes = 0, num_bbclashes = 0;	
		tr->eVdw = 0; tr->eVdw_repulsion = 0;
		for(int laindex = 0; laindex < c->num_aminoacids; laindex++){
			Aminoacid *la = c->aminoacid[laindex];
			if(la->centroid != NULL)
				for(int raindex = 0; raindex < c->num_aminoacids; raindex++){
				 	Aminoacid *ra = c->aminoacid[raindex];
				 	if(la->chain < ra->chain){
				 		if(ra->centroid != NULL && Vector::distance_squared(*(la->centroid),*(ra->centroid)) < SS_CUTOFF*SS_CUTOFF){
							short ratype=ra->type, latype=la->type;
							if(ratype >= 0 && latype>= 0)
							if(ratype <= latype)
								details->residue_contacts_core[ratype][latype]++;
							else
								details->residue_contacts_core[latype][ratype]++;						
						}
						
						for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator laitr = la->atom.begin(); laitr != la->atom.end(); laitr++){
							Atom *al = (Atom *) laitr->second;
							for(hash_map<const char*, Atom*, hash<const char*>, eqstr>::iterator raitr = ra->atom.begin(); raitr != ra->atom.end(); raitr++){
								Atom *ar = (Atom *) raitr->second;
								double d2 = Vector::distance_squared(al->position,ar->position);
								if(NUM_ATOM_DISTANCE_DIVISIONS <=1){
									if(d2 < ATOM_STEPP_DCUTOFF_SQUARED)// && (d2 >= ATOM_STEPP_DMIN_SQUARED))
							 		{
										if(al->atom_type < ar->atom_type)
											details->atom_contacts[al->atom_type][ar->atom_type] += 1.0;
										else
											details->atom_contacts[ar->atom_type][al->atom_type] += 1.0;
									}
						 		} else {
						 			short div = ATOM_DISTANCE_DIVISION(d2);
						 			if(div >= 0) 
						 				if(al->atom_type < ar->atom_type)
											details->atom_dcontacts[al->atom_type][ar->atom_type][div] += 1.0;
										else
											details->atom_dcontacts[ar->atom_type][al->atom_type][div] += 1.0;
						 		}
								
								if(d2 < ATOM_CLASH_CUTOFF_SQUARED){
									num_clashes++;
									if(al->isbbatom && ar->isbbatom && d2 < BBATOM_CLASH_CUTOFF_SQUARED)
										num_bbclashes++;
								}
								
								if(d2 < ATOM_SMTHP_DCUTOFF_SQUARED)							
								{	
										float factor = 0;										
								 		//float d6_inv = 1.0/(d2 * d2 * d2);
										//factor = (1.0 - 32.768 * ar->sigma_cubed * d6_inv)* d6_inv;
										float d_scaled = sqrt(d2/(3.2*ar->sigma));
	 									factor = VDW_ATTR(d_scaled);
	 									if(factor > 0){
											// 6-12 factor = 4 * a->sqrt_eps * ar->sigma_cubed * factor;
											factor = 4 * ar->sqrt_eps * factor;
											tr->eVdw += factor * al->sqrt_eps;
										} else {
											factor = VDW_REPUL(d_scaled);
											factor = 4 * ar->sqrt_eps * factor;
											tr->eVdw_repulsion += factor * al->sqrt_eps;
										}	
								}
							}
				 		}
				 	}
				}
		}
		
		cout << mid << " clashes " << num_clashes << " " << num_bbclashes << endl;
		tr->num_clashes = num_clashes;
		tr->num_bbclashes = num_bbclashes;
		tr->sEvolution_interface = tr->eVdw_repulsion;
		tr->print_details(&fdetails,TN_PROTPROT_DETAILED_SCORE_VERIFY);
		delete c;
		for(int mi=0; mi<nchains; mi++)	delete p[mi];	
		delete tr;
	 }
	}
	fdetails.close();
}
