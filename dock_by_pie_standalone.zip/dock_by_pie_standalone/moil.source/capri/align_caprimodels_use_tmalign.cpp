/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];
extern char *tmp_dir;


/*
 * Arguments: receptor-chains ligand-chains #models
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	read_dock_config();
	
	int mid = atoi(argv[1]);
	Complex *c;
	
	{
		string chains = string(argv[2]);
		sprintf(buf,"models/m%d",mid);
		Complex *c = new Complex(buf,chains.c_str(), PDB);
		
		sprintf(buf,"aligned_models/biol_A_vs_m%d_A.tmali",mid);
		fstream aliin(buf,fstream::in);
		Transformation *tr = NULL;
		while(aliin.good() && tr == NULL){
	    	aliin.getline(buf,8192);
	    	if(aliin.gcount() > 0){
	    		cout << string(buf) << endl;
	    		if(string(buf).find("rotation matrix to rotate Chain")!=string::npos){
	    			aliin.getline(buf,8192);
	    			Vector *translation, *ex, *ey, *ez;
	    			float A[3][4];
	    			for(int i = 0; i < 3; i++){
	    				aliin.getline(buf,8192);
	    				stringstream ss(buf,stringstream::in);
						string tag;
						ss >> tag;
						for(int j = 0; j <4; j++){
							ss >> A[i][j];
						}
	    			}
	    			translation = new Vector(A[0][0],A[1][0],A[2][0]);
	    			ex = new Vector(A[0][1],A[0][2],A[0][3]);
	    			ey = new Vector(A[1][1],A[1][2],A[1][3]);
	    			ez = new Vector(A[2][1],A[2][2],A[2][3]);
	    			tr = new Transformation(translation, ex, ey, 1.0, 0, 0);
	    			tr->print_details(&cout,TN_BASIC);
	    		}
	    	}
		}
		aliin.close();
		
		if(tr != NULL){
			sprintf(buf,"aligned_models/alignedm%d.pdb",mid);
			tr->write_as_pdb(c, "-", false, string(buf), true);
		}
		
		delete c;	delete tr;
	}
}
