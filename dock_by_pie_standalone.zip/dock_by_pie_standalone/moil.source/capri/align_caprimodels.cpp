/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "sasautil.hpp"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];
extern char *tmp_dir;

int cligand_vs_model[400], creceptor_vs_model[400];

void read_alignment(int mid){
	for(int i = 0 ; i < 400; i++){
		cligand_vs_model[i] = -1;
		creceptor_vs_model[i] = -1;
	}
	
	sprintf(buf,"models/cp46lA1_-_vs_m%dlig.ali",mid);
	string filename = string(buf);
	fstream fin;
	fin.open(filename.c_str(), ios::in);

	string aseq1,aseq2,s;
	int qstart, sstart;
	bool alignment_done;
	stringstream *line;	
	int offset2 = 0, offset1 = 0;
	
	if(fin.is_open()){
		aseq1 = ""; aseq2 = "";
		qstart = sstart = 1;
			
		// reading input from the output of nwa
		fin.getline(buf,8192);
		fin.getline(buf,8192);
		do{
			line = new stringstream(buf,stringstream::in);
			*line >> s;
			aseq1 += s;
			fin.getline(buf,8192);
		}while((string(buf)).find(">>") == string::npos);
		while(fin.good()){
			fin.getline(buf,8192);
			if(fin.gcount() > 0){
				line = new stringstream(buf,stringstream::in);
				*line >> s;
				aseq2 += s;
				//*out << ">" << aseq2 << endl;
			}
		}
			
		*out << aseq1 << endl << aseq2 << endl;
			
		int qindex = qstart-1, sindex = sstart-1;
		int n = aseq1.size();
		const char* aseq1c = aseq1.c_str();
		const char* aseq2c = aseq2.c_str();
			
		for(int i = 0 ; i < n ; i++){
			int qindexc = qindex + offset1;
			int sindexc = sindex + offset2;
			if(aseq1c[i] != '-' && aseq2c[i] != '-'){
				cligand_vs_model[qindexc] = sindexc;
				*out << qindex << "-" << qindexc << "-" << sindex << "-" << sindexc << " ";
			}
			if(aseq1c[i] != '-')	qindex++;
			if(aseq2c[i] != '-')	sindex++;	
		}
		fin.close();
	} else {
		cout << "ERROR: Alignment does not exist " << filename << endl;
		exit(-1);
	}
	out->flush(); *out << endl;
	
	sprintf(buf,"models/mlB2b3t_-_vs_m%drec.ali",mid);
	filename = string(buf);
	fstream fin2;
	fin2.open(filename.c_str(), ios::in);

	offset2 = 0, offset1 = 0;
	
	if(fin2.is_open()){
		aseq1 = ""; aseq2 = "";
		qstart = sstart = 1;
			
		// reading input from the output of nwa
		fin2.getline(buf,8192);
		fin2.getline(buf,8192);
		do{
			line = new stringstream(buf,stringstream::in);
			*line >> s;
			aseq1 += s;
			fin2.getline(buf,8192);
		}while((string(buf)).find(">>") == string::npos);
		while(fin2.good()){
			fin2.getline(buf,8192);
			if(fin2.gcount() > 0){
				line = new stringstream(buf,stringstream::in);
				*line >> s;
				aseq2 += s;
				//*out << ">" << aseq2 << endl;
			}
		}
			
		*out << aseq1 << endl << aseq2 << endl;
			
		int qindex = qstart-1, sindex = sstart-1;
		int n = aseq1.size();
		const char* aseq1c = aseq1.c_str();
		const char* aseq2c = aseq2.c_str();
			
		for(int i = 0 ; i < n ; i++){
			int qindexc = qindex + offset1;
			int sindexc = sindex + offset2;
			if(aseq1c[i] != '-' && aseq2c[i] != '-'){
				creceptor_vs_model[qindexc] = sindexc;
				*out << qindex << "-" << qindexc << "-" << sindex << "-" << sindexc << " ";
			}
			if(aseq1c[i] != '-')	qindex++;
			if(aseq2c[i] != '-')	sindex++;	
		}
		fin.close();
	} else {
		cout << "ERROR: Alignment does not exist " << filename << endl;
		exit(-1);
	}
	out->flush(); *out << endl;
}

/*
 * Arguments: receptor-chains ligand-chains #models
 */
int main(int argc, char *argv[]){
	out = &cout;
	
	read_molecule_config();
	read_dock_config();
	
	int start = atoi(argv[1]);
	int end = atoi(argv[2]);
	Complex *cr, *cl, *cligand = new Complex("/proj2/ravid/capri/T46/mlB2b3t","-", PDB),
		*creceptor = new Complex("/proj2/ravid/capri/T46/cp46lA1","-", PDB);
	
	for( int mid = start ; mid < end; mid++){
		read_alignment(mid);
		
		string chains = "";
		string filename = "/junior/ravid/capri/T49/score/id_chains";
		fstream fidchains(filename.c_str());
		while(fidchains.good()){
	    	fidchains.getline(buf,8192);
	    	if(fidchains.gcount() > 0){
		    	stringstream ss (stringstream::in | stringstream::out);
		    	ss << buf;
		    	int fidchains_mid;
		    	ss >> fidchains_mid;
		    	if(fidchains_mid == mid){
		    		ss >> chains;
		    		chains = *(new string(chains.c_str()));
		    		break;
	    		}
	    	}
    	}
    	fidchains.close();
    	
    	char* chains_c = (char*) chains.c_str();	
    
		sprintf(buf,"models/m%d",mid);
		char mol_chains[2]; sprintf(mol_chains,"%c",chains_c[0]);
		cl = new Complex(buf,mol_chains, PDB);
		int len1 = cl->num_aminoacids;
		sprintf(buf,"models/m%d",mid);
		sprintf(mol_chains,"%c",chains_c[1]);
		cr = new Complex(buf,mol_chains, PDB);
		int len2 = cr->num_aminoacids;
		
		int lcid = 1;
		if(len1 < len2){
			Complex *c = cl;
			cl = cr;
			cr = c;
			lcid = 2;
		}
		
		/*for(int i = 0; i < cl->num_aminoacids; i++){
			Aminoacid *am = cl->aminoacid[i];
			cout << "debug " << am << " " << am->cindex << " " << " " << am->name << " " << am->alpha_carbon << endl; cout.flush();
	 	}*/
		
		cout << "aligning model " << mid << " " << len1 << " " << len2 << " " << len1+len2 << endl;
		
		Vector ctarget_points[len1+len2+1], model_points[len1+len2+1];
		int point_index = 0;
		
		for(int i = 0 ; i < cligand->num_aminoacids; i++)	
			if(cligand_vs_model[i] != -1 && cligand->aminoacid[i]->alpha_carbon != NULL){
				Aminoacid *atarget = cligand->aminoacid[i];
				//cout << "debug " << i << " " << cligand_vs_model[i] << endl; cout.flush();
			  if(cligand_vs_model[i] < cl->num_aminoacids){
				Aminoacid *am = cl->aminoacid[cligand_vs_model[i]];
				cout << "debug " << am << " " << am->cindex << " " << " " << am->name << " " << " " << atarget->name << " " << am->alpha_carbon << endl; cout.flush();
	 			if(am->alpha_carbon != NULL){
					ctarget_points[point_index] = Vector(atarget->alpha_carbon->position);
					model_points[point_index] = Vector(am->alpha_carbon->position);
					//cout << atarget->index << " " << am->index << endl;
					point_index++;
	 			}
			  }
			}
		Transformation *tr_model_to_target = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
		float lrmsd = compute_rmsd(point_index, &ctarget_points[0], &model_points[0], tr_model_to_target);
		
		sprintf(buf,"models/alignedlm%d.pdb",mid);
		for(int i = 0; i < cl->num_aminoacids; i++)
			cl->aminoacid[i]->chain = 'B';
		tr_model_to_target->write_as_pdb(cl, "-", false, string(buf), true);
		
		sprintf(buf,"models/dockedrm%d.pdb",mid);
		for(int i = 0; i < cr->num_aminoacids; i++)
			cr->aminoacid[i]->chain = 'A';
		tr_model_to_target->write_as_pdb(cr, "-", false, string(buf), true);
		
		point_index = 0;
		for(int i = 0 ; i < creceptor->num_aminoacids; i++)	
			if(creceptor_vs_model[i] != -1 && creceptor->aminoacid[i]->alpha_carbon != NULL){
				Aminoacid *atarget = creceptor->aminoacid[i];
			  if(creceptor_vs_model[i] < cr->num_aminoacids){
				Aminoacid *am = cr->aminoacid[creceptor_vs_model[i]];
	 			if(am->alpha_carbon != NULL){
					ctarget_points[point_index] = Vector(atarget->alpha_carbon->position);
					model_points[point_index] = Vector(am->alpha_carbon->position);
					//cout << atarget->index << " " << am->index << endl;
					point_index++;
	 			}
			  }
			}
		tr_model_to_target = new Transformation(new Vector(0,0,0), new Vector(1,0,0), new Vector(0,1,0), 1.0, 0,0);
		float rrmsd = compute_rmsd(point_index, &ctarget_points[0], &model_points[0], tr_model_to_target);
		sprintf(buf,"models/alignedrm%d.pdb",mid);
		tr_model_to_target->write_as_pdb(cr, "-", false, string(buf), true);
		
		cout << mid << " rrmsd " << lrmsd << " lrmsd " << rrmsd << endl;
		
		delete cl;	delete cr;	delete tr_model_to_target;
	}
	
}
