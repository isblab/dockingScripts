/* PIEDOCK                                                            *
 * Authors: D. V. S. Ravikant                                         *
 * (C) 2011 D. V. S. Ravikant and Ron Elber                           */

#include "object.hpp"
#include "rmsd.h"

ostream *out;
char scratch_dir[512], command[8192], buf[8192];
extern char *tmp_dir;

int main(int argc, char *argv[]){
	out=&cout;
	
	read_molecule_config();
	read_dock_config();
	
	if(argc < 3)	cout << "Usage: model rchains lchains" << endl;
	
	string rchains=string(argv[2]);
	string lchains=string(argv[3]);
	
	Complex* cr = new Complex(argv[1],rchains.c_str(),PDB);
	Complex* cl = new Complex(argv[1],lchains.c_str(),PDB);
	cr->compute_motions();
	cl->compute_motions();
	
	Transformation *tr = new Transformation(new Vector(0,0,0),new Vector(1,0,0), new Vector(0,1,0), 1.0,1,-1);
	
	Vector cml_minus_cmr = tr->inverse_transform(cl->center_of_mass) - *(cr->center_of_mass);
	Vector pull_out_direction = cml_minus_cmr;
	pull_out_direction.normalize();
	
	float increment = 0.1;
	int num_steps = 50;
	float num_clashes[num_steps], num_bbclashes[num_steps];
	for(int inci = 0; inci<num_steps; inci++){
		Transformation *str = new Transformation(new Vector(pull_out_direction*((float) inci)*increment),new Vector(1,0,0), new Vector(0,1,0), 1.0,1,-1);
		
		num_clashes[inci] = num_bbclashes[inci] = 0;
		for(int mli = 0; mli < lchains.length(); mli++){
			Molecule *ml = cl->molecules[lchains.c_str()[mli]];
			for(int mri = 0; mri < rchains.length(); mri++){
				Molecule *mr = cr->molecules[rchains.c_str()[mri]];
				for(hash_map<unsigned short, Atom*, hash<unsigned short>,eqint>::iterator litr = ml->atom.begin(); litr != ml->atom.end(); litr++){
					Atom * al = (Atom *) litr->second;
					if((al->name).c_str()[0] != 'H'){
						for(hash_map<unsigned short, Atom*, hash<unsigned short>,eqint>::iterator ritr = mr->atom.begin(); ritr != mr->atom.end(); ritr++){
							Atom *ar = (Atom *) ritr->second;
							if((ar->name).c_str()[0] != 'H'){
								Vector v = tr->inverse_transform(al->position);
								v = str->inverse_transform(v);
								double d2 = Vector::distance_squared(v,*(ar->position));
								if(d2 < 9.0){
									num_clashes[inci] += 1;
									if(al->isbbatom && ar->isbbatom && d2 < 2.25)
										num_bbclashes[inci] += 1;
								}
							}
						}
					}
				}
			}
		}
		cout << inci << " clashes " << num_clashes[inci] << " bbclashes " << num_bbclashes[inci] << endl;
		
		//if(inci == 40)
		{
			Reference_Frame *rf = str->compose(str,tr);
			Transformation *ctr = new Transformation(rf->translation, rf->ex, rf->ey, 1.0,0,inci);
			stringstream ss (stringstream::in | stringstream::out);
			ss << "lig" << inci << ".pdb";
			string s; ss >> s;
			ctr->write_as_pdb(cl, "-", false, s, false);
		}
	}
}
