# This script looks for job folders on the junior cluster and removes any that are
# old, and deletes them.  Job folders are those whose name is numeric - so we look
# for folders beginning with a "1" or a "2" (unlikely we'll get to "2")
#
# Note that rm will not let us remove any folder that we don't have write perms for
# so this means it should only remove folders owned by us: clsbuser.  In general
# these are ones that result from automated server jobs, like DOCK.  LOOPP jobs
# are prepended with "lp", and LOOPP database generation jobs are prepended 
# with "dbgen", so we will remove those as well.  We are called with an argument 
# that tells us how many days old a folder should be to get removed.  This is 
# specified in the crontab file: at present this value is 3, so that job work
# folders that are more than 3 days old will be removed.
#
# NOTE: the script takes two arguments - <daysOld> <shouldDelete>
#
# So the cronjob runs with "3 1" meaning at least 3 days old, and YES delete them.
#
# If instead you omit the second arguemnt (OMIT, don't pass 0!!!) then the files
# will not be deleted, you'll just get a report of what folders are more than X
# days old.

my $daysOld = shift;
my $delcmd = "";
if( $#ARGV >= 0 ) {
	$delcmd = "rm -rf";
}

open LOG, ">>/junior/clsbuser/cleanJunior.log";
my $now = localtime;
print LOG "cleanJunior.pl running $now - day limit = $daysOld\n"; 

my @folders = glob( "/share/work/dock/server/emailed/jobs/[0-9]* /state/partition1/lp* /state/partition1/dbgen* /state/partition1/1* /state/partition1/2*" );
	# folders that match the above expressions and are writeable (e.g. owned) by us will be removed
	# if they are too old.

foreach( @folders ) {	
	my $age = -M $_;
	if( $age > $daysOld ) {
		print "$age $_\n";
		if( $delcmd ne "" ) {
			`$delcmd $_`;
			print LOG "   do $delcmd on [ $age  $_ ]\n";
		}
	}
}

close LOG;
