
# this script is used to check the node disk space on junior, and report to clsb nightly the
# available space.  I set a cron job to run it.

sub sendmail {
	my %hash = @_;

	my $sendmail = "/usr/sbin/sendmail -t";
	my $replyto  = "Reply-to: $hash{from}\n";
	my $sendto   = "To: $hash{to}\n";
	my $cc       = "Cc: $hash{cc}\n";
	my $subject  = "Subject: $hash{subject}\n";
	my $content  = $hash{body};

	open( SENDMAIL, "|$sendmail") or die "Cannot open $sendmail: $!";
	print SENDMAIL $replyto;
	print SENDMAIL $subject;
	print SENDMAIL $sendto;
	print SENDMAIL $cc;
	print SENDMAIL "Content-type: text/plain\n\n";
	print SENDMAIL $content;
	close( SENDMAIL );
}

$results = "Junior diskspace analysis...\n\n";
$results .= "\n======================  WEB    ===========================\n";
$results .= `df -h /www/sites/clsb/loopp`;
$results .= "\n======================  APPS   ===========================\n";
$results .= `df -h /share/apps/loopp`;
$results .= "\n======================  WORK   ==========================\n";
$results .= `df -h /share/work/loopp`;
$results .= "\n====================== CLUSTER =========================\n";
$results .= `/opt/rocks/sbin/cluster-fork df -h /state/partition1`;
$results .= "\n====================== HOME =========================\n";
$results .= `df -h /junior/`;


sendmail(
				from    => 'clsbuser@ices.utexas.edu', 
				to      => 'clsbuser@ices.utexas.edu',
				subject => "junior disk space",
				body    => $results
		);
